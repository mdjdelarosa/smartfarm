<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Privacy Policy - Smart Farm</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .terms-privacy-page { max-width: 700px; margin: 48px auto; background: #fff; border-radius: 10px; box-shadow: 0 4px 24px rgba(0,0,0,0.10); padding: 36px 32px; }
    .terms-privacy-page h1 { color: #28a745; font-size: 2rem; margin-bottom: 18px; }
    .terms-privacy-page ol { margin-left: 22px; }
    .terms-privacy-page li { margin-bottom: 12px; line-height: 1.6; }
    .back-link { display: inline-block; margin-top: 24px; color: #28a745; font-weight: 600; text-decoration: none; }
    .back-link:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="terms-privacy-page">
    <h1>Privacy Policy</h1>
    <ol>
      <li>We collect your information only for account management and service improvement.</li>
      <li>Your data is stored securely and not shared with third parties except as required by law.</li>
      <li>You may request to view, update, or delete your personal information at any time.</li>
      <li>We use cookies for session management and analytics.</li>
      <li>By using Smart Farm, you consent to this privacy policy and any future updates.</li>
    </ol>
    <a href="login.php" class="back-link">&larr; Back to Signup</a>
  </div>
</body>
</html>
