# Google Maps Integration Setup Guide

## Overview
The account management system now includes **Google Maps integration** for location picking. Instead of manually entering address fields, users can click on a map to mark their home and farm locations.

## What Changed

### Database Schema
- **Old**: Multiple address columns (street_address, barangay, municipality, province, postal_code)
- **New**: Only 3 fields per location:
  - `latitude` (DECIMAL 10,8)
  - `longitude` (DECIMAL 11,8)
  - `address` (auto-filled via reverse geocoding)

#### New Database Columns:

**Farmers:**
- `farmer_home_latitude`, `farmer_home_longitude`, `farmer_home_address`
- `farm_latitude`, `farm_longitude`, `farm_address`

**Clients:**
- `client_home_latitude`, `client_home_longitude`, `client_home_address`

### Files Created/Modified

**New Files:**
- `maps_helper.php` - Geocoding & coordinate helper functions
- `database_sql_maps.sql` - Updated schema with lat/lng
- `css/maps.css` - Styling for map containers & coordinates

**Modified Files:**
- `admin/add-account.php` - Maps instead of address fields in form
- `admin/add_account_process.php` - Validates coordinates, inserts lat/lng
- `admin/view-account.php` - Displays interactive maps for editing
- `admin/edit_account_process.php` - Updates with lat/lng coordinates

## Setup Steps

### Step 1: Get Google Maps API Key
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project
3. Enable these APIs:
   - Maps JavaScript API
   - Geocoding API
   - Places API
4. Create an **API Key** (Credentials → Create)
5. Restrict it to your domain (Optional but recommended)

### Step 2: Set Environment Variable
Add this to your `.env` file or system environment:
```bash
GOOGLE_MAPS_API_KEY=YOUR_API_KEY_HERE
```

Or directly in PHP:
```php
// In config.php or maps_helper.php
define('GOOGLE_MAPS_API_KEY', 'YOUR_API_KEY_HERE');
```

### Step 3: Update Database
Run the migration from `database_sql_maps.sql`:
```bash
# Backup old database first!
mysql -u root -p smartfarm < database_sql_maps.sql
```

If you have existing data, migrate addresses to coordinates:
```sql
-- For test data, set defaults (Philippines coordinates)
UPDATE farmers SET 
  farmer_home_latitude = 12.8766,
  farmer_home_longitude = 121.7740,
  farm_latitude = 12.8800,
  farm_longitude = 121.7800
WHERE farmer_home_latitude IS NULL;

UPDATE clients SET 
  client_home_latitude = 12.8766,
  client_home_longitude = 121.7740
WHERE client_home_latitude IS NULL;
```

### Step 4: Test the Form
1. Go to Admin Dashboard → Add New Account
2. Select role (Farmer or Client)
3. Click on the map to mark location
4. Or drag the marker to move it
5. Address auto-fills from coordinates

## How It Works

### Interactive Map Features:
- **Click on map** → Mark location
- **Drag marker** → Move location
- **Coordinates update** → When location changes
- **Address auto-fill** → Via reverse geocoding
- **Multiple maps** → Farmers have 2 maps (home + farm)

### Data Flow:
```
User clicks on map
    ↓
JavaScript gets coordinates
    ↓
Reverse geocode (get address)
    ↓
Fill form inputs (lat, lng, address)
    ↓
Submit form
    ↓
Backend validates coordinates
    ↓
Store in database
```

### Validation:
- **Valid latitude**: -90 to +90
- **Valid longitude**: -180 to +180
- **Required fields**: Both coordinates must be set
- **Address**: Optional (auto-populated)

## API Security

### Rate Limits:
- Geocoding API: 50 requests per second
- Maps JavaScript API: Unlimited (with quota)

### Best Practices:
1. Restrict API key to your domain
2. Never commit API key to git (use env vars)
3. Monitor usage in Google Cloud Console
4. Use maps_helper.php functions for server-side geocoding

## Troubleshooting

### Map shows blank/error:
- Check API key is correct
- Verify Maps JavaScript API is enabled
- Check browser console for errors
- Ensure HTTPS (Google Maps requires HTTPS in production)

### Address not auto-filling:
- Geocoding API might need enabling
- Network request might be failing
- Try clicking/dragging marker again

### Coordinates not saving:
- Check backend logs
- Verify form is sending correct field names
- Ensure database columns exist
- Check coordinate validation in add_account_process.php

## Performance

**Typical response times:**
- Map load: < 2 seconds
- Marker placement: Instant
- Reverse geocoding: < 1 second
- Form submission: < 2 seconds

**Caching:**
- Geocoding calls are not cached (cost consideration)
- Consider caching if many users in same area

## Future Enhancements

- [ ] Route optimization for multiple farms
- [ ] Distance calculation between home and farm
- [ ] Heat maps for farm concentration
- [ ] Geofencing for notifications
- [ ] Offline map support
- [ ] Custom map markers by crop type

## Cost Estimation

**Google Maps API Pricing (as of 2026):**
- Geocoding: $0.005 per request
- Maps JS: $7 per 1,000 requests
- Estimate: ~$50-100/month for 100 users

Consider using a cache layer if costs become an issue.
