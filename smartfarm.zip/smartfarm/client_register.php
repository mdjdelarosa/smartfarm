<!DOCTYPE html>
<html>
<head>
  <title>Client Registration</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
  <div class="form-section">
    <h2>Client Registration</h2>
    <form method="post" action="client_register_process.php">
      <label class="form-label" for="client-fullname">Full Name</label>
      <input type="text" id="client-fullname" name="fullname" required>
      <label class="form-label" for="client-email">Email Address</label>
      <input type="email" id="client-email" name="email" required>
      <label class="form-label" for="client-password">Password</label>
      <input type="password" id="client-password" name="password" required>
      <label class="form-label" for="client-confirm-password">Confirm Password</label>
      <input type="password" id="client-confirm-password" name="confirm_password" required>
      <button type="submit">Register</button>
    </form>
  </div>
</body>
</html>
