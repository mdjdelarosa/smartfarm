<?php
/**
 * Free Maps Integration Module (Leaflet + OpenStreetMap + Nominatim)
 * NO API KEY NEEDED - Completely FREE
 * Handles map initialization, location picking, and geocoding
 */

/**
 * Get reverse geocoded address from lat/lng using Nominatim (Free)
 * @param float $lat Latitude
 * @param float $lng Longitude
 * @return string Address string or "Location at {lat}, {lng}"
 */
function getAddressFromCoordinates($lat, $lng) {
    $lat = floatval($lat);
    $lng = floatval($lng);
    
    // Use free Nominatim API (OpenStreetMap)
    $url = "https://nominatim.openstreetmap.org/reverse?format=json&lat={$lat}&lon={$lng}";
    
    $response = @file_get_contents($url, false, stream_context_create([
        'http' => ['timeout' => 5, 'user_agent' => 'SmartFarm/1.0']
    ]));
    
    if (!$response) {
        return "Location at {$lat}, {$lng}";
    }
    
    $result = json_decode($response, true);
    
    if (!empty($result['address'])) {
        // Build a nice address from components
        $parts = [];
        if (!empty($result['address']['road'])) $parts[] = $result['address']['road'];
        if (!empty($result['address']['city'])) $parts[] = $result['address']['city'];
        if (!empty($result['address']['state'])) $parts[] = $result['address']['state'];
        if (!empty($result['address']['postcode'])) $parts[] = $result['address']['postcode'];
        
        if (!empty($parts)) {
            return implode(', ', $parts);
        }
    }
    
    if (!empty($result['display_name'])) {
        return $result['display_name'];
    }
    
    return "Location at {$lat}, {$lng}";
}

/**
 * Get coordinates from address using Nominatim (Free)
 * @param string $address Address to geocode
 * @return array ['lat' => float, 'lng' => float] or null if not found
 */
function getCoordinatesFromAddress($address) {
    if (empty($address)) {
        return null;
    }
    
    // Use free Nominatim API
    $url = "https://nominatim.openstreetmap.org/search?format=json&q=" . urlencode($address) . "&limit=1";
    
    $response = @file_get_contents($url, false, stream_context_create([
        'http' => ['timeout' => 5, 'user_agent' => 'SmartFarm/1.0']
    ]));
    
    if (!$response) {
        return null;
    }
    
    $result = json_decode($response, true);
    
    if (is_array($result) && !empty($result[0])) {
        return [
            'lat' => floatval($result[0]['lat']),
            'lng' => floatval($result[0]['lon'])
        ];
    }
    
    return null;
}

/**
 * Validate coordinates
 * @param float $lat Latitude
 * @param float $lng Longitude
 * @return bool True if valid coordinates
 */
function isValidCoordinates($lat, $lng) {
    $lat = floatval($lat);
    $lng = floatval($lng);
    return $lat >= -90 && $lat <= 90 && $lng >= -180 && $lng <= 180;
}
