<?php
// SmartFarm Login Process
// Handles login for Admin, Farmer, and Client accounts
require __DIR__ . '/login_process_improved.php';
