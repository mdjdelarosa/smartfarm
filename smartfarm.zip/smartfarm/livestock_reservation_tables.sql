-- ============================================================
-- SmartFarm - Livestock & Products Reservation System Tables
-- ============================================================

-- Livestock & Products Listings (admin/farmer-managed)
CREATE TABLE IF NOT EXISTS `livestock_products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_id` int(11) DEFAULT NULL,
  `created_by_admin` int(11) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_type` enum('Livestock','Dairy Products','Farm Products','Supplies','Other') NOT NULL DEFAULT 'Other',
  `product_description` text DEFAULT NULL,
  `product_image` longblob DEFAULT NULL,
  `product_image_name` varchar(255) DEFAULT NULL,
  `product_image_mime_type` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `stock` int(11) NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL DEFAULT 'unit',
  `status` enum('Active','Inactive','Out of Stock') NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`product_id`),
  KEY `idx_farmer_id` (`farmer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_type` (`product_type`),
  CONSTRAINT `lp_farmer_fk` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`farmer_id`) ON DELETE SET NULL,
  CONSTRAINT `lp_admin_fk` FOREIGN KEY (`created_by_admin`) REFERENCES `admins` (`admin_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Client Reservations for Livestock & Products
CREATE TABLE IF NOT EXISTS `livestock_reservations` (
  `reservation_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `preferred_date` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `status` enum('pending','confirmed','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`reservation_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_status` (`status`),
  CONSTRAINT `lr_client_fk` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE,
  CONSTRAINT `lr_product_fk` FOREIGN KEY (`product_id`) REFERENCES `livestock_products` (`product_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample livestock product listings
INSERT INTO `livestock_products` (`farmer_id`, `created_by_admin`, `product_name`, `product_type`, `product_description`, `price`, `stock`, `unit`, `status`) VALUES
(NULL, 1, 'Dairy Cow', 'Livestock', 'Healthy dairy cow, high milk yield, vaccinated and dewormed.', 45000.00, 12, 'head', 'Active'),
(NULL, 1, 'Fresh Milk (1L)', 'Dairy Products', 'Fresh farm milk, collected daily. Rich in nutrients.', 85.00, 120, 'bottle', 'Active'),
(NULL, 1, 'Chicken Eggs (Dozen)', 'Farm Products', 'Free-range chicken eggs, large size.', 95.00, 45, 'dozen', 'Active'),
(NULL, 1, 'Organic Vegetables Bundle', 'Farm Products', 'Assorted seasonal vegetables, organically grown.', 250.00, 30, 'bundle', 'Active'),
(NULL, 1, 'Native Goat', 'Livestock', 'Healthy native goat, approximately 25-30 kg.', 8500.00, 8, 'head', 'Active'),
(NULL, 1, 'Broiler Chicken', 'Livestock', 'Ready-to-market broiler chicken, approximately 1.5-2 kg.', 320.00, 60, 'head', 'Active');
