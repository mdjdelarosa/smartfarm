<?php
require 'config.php'; // Make sure this file sets up $conn

header('Content-Type: application/json');

$result = $conn->query("SELECT * FROM seed_inventory");
$seeds = [];
while ($row = $result->fetch_assoc()) {
    $seeds[] = $row;
}

echo json_encode([
    'success' => true,
    'data' => $seeds
]);
?>
