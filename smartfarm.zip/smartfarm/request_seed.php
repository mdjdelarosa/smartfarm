<?php
require 'config.php';

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

$farmer_id = $input['farmer_id'] ?? null;
$seed_id = $input['seed_id'] ?? null;
$quantity = $input['quantity'] ?? null;

if (!$farmer_id || !$seed_id || !$quantity) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

$stmt = $conn->prepare("INSERT INTO seed_requests (farmer_id, seed_id, quantity, status, requested_at) VALUES (?, ?, ?, 'pending', NOW())");
$stmt->bind_param("iii", $farmer_id, $seed_id, $quantity);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Seed requested successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to request seed']);
}
?>
