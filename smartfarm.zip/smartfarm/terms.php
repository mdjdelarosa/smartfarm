<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Terms and Conditions - Smart Farm</title>
  <link rel="stylesheet" href="css/style.css">
  <style>
    .terms-privacy-page { max-width: 700px; margin: 48px auto; background: #fff; border-radius: 10px; box-shadow: 0 4px 24px rgba(0,0,0,0.10); padding: 36px 32px; }
    .terms-privacy-page h1 { color: #28a745; font-size: 2rem; margin-bottom: 18px; }
    .terms-privacy-page ol { margin-left: 22px; }
    .terms-privacy-page li { margin-bottom: 12px; line-height: 1.6; }
    .back-link { display: inline-block; margin-top: 24px; color: #28a745; font-weight: 600; text-decoration: none; }
    .back-link:hover { text-decoration: underline; }
  </style>
</head>
<body>
  <div class="terms-privacy-page">
    <h1>Terms and Conditions</h1>
    <ol>
      <li>You must provide accurate and complete registration information.</li>
      <li>All transactions must comply with Smart Farm rules and local laws.</li>
      <li>Do not share your password or account with others.</li>
      <li>Smart Farm is not liable for losses due to user negligence or fraud.</li>
      <li>We reserve the right to suspend or terminate accounts for violations.</li>
      <li>By using Smart Farm, you agree to these terms and any future updates.</li>
    </ol>
    <a href="login.php" class="back-link">&larr; Back to Signup</a>
  </div>
</body>
</html>
