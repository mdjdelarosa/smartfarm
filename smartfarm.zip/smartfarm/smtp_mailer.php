<?php
/**
 * Minimal dependency-free SMTP client (this project has no Composer/PHPMailer).
 * Speaks just enough SMTP to authenticate with Gmail over STARTTLS and send
 * a single HTML email. Not a general-purpose mailer — no attachments, no
 * multi-recipient support, no retry logic.
 */

function smtpSendMail(
    string $to,
    string $subject,
    string $htmlBody,
    string $fromEmail,
    string $fromName,
    string $host,
    int $port,
    string $username,
    string $password
): array {
    $timeout = 15;
    $errno = 0;
    $errstr = '';

    $socket = @stream_socket_client("tcp://{$host}:{$port}", $errno, $errstr, $timeout);
    if (!$socket) {
        return ['success' => false, 'error' => "Connection failed: {$errstr} ({$errno})"];
    }
    stream_set_timeout($socket, $timeout);

    $readResponse = static function () use ($socket): string {
        $response = '';
        while (($line = fgets($socket, 515)) !== false) {
            $response .= $line;
            // A multi-line SMTP response's final line has a space after the
            // code (e.g. "250 OK"); continuation lines use a dash ("250-...").
            if (preg_match('/^\d{3} /', $line)) {
                break;
            }
        }
        return $response;
    };

    $sendCommand = static function (string $command) use ($socket, $readResponse): string {
        fwrite($socket, $command . "\r\n");
        return $readResponse();
    };

    $expectCode = static function (string $response, array $codes): bool {
        foreach ($codes as $code) {
            if (strpos($response, (string)$code) === 0) {
                return true;
            }
        }
        return false;
    };

    $fail = static function (string $message) use ($socket): array {
        fclose($socket);
        return ['success' => false, 'error' => $message];
    };

    $localDomain = 'smartfarm.local';

    $greeting = $readResponse();
    if (!$expectCode($greeting, [220])) {
        return $fail('No greeting from SMTP server: ' . trim($greeting));
    }

    $response = $sendCommand("EHLO {$localDomain}");
    if (!$expectCode($response, [250])) {
        return $fail('EHLO failed: ' . trim($response));
    }

    $response = $sendCommand('STARTTLS');
    if (!$expectCode($response, [220])) {
        return $fail('STARTTLS failed: ' . trim($response));
    }

    if (!@stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
        return $fail('TLS negotiation failed');
    }

    // Must re-issue EHLO after the TLS upgrade per the SMTP spec.
    $response = $sendCommand("EHLO {$localDomain}");
    if (!$expectCode($response, [250])) {
        return $fail('EHLO (post-TLS) failed: ' . trim($response));
    }

    $response = $sendCommand('AUTH LOGIN');
    if (!$expectCode($response, [334])) {
        return $fail('AUTH LOGIN not accepted: ' . trim($response));
    }

    $response = $sendCommand(base64_encode($username));
    if (!$expectCode($response, [334])) {
        return $fail('Username rejected: ' . trim($response));
    }

    $response = $sendCommand(base64_encode($password));
    if (!$expectCode($response, [235])) {
        return $fail('Authentication failed: ' . trim($response));
    }

    $response = $sendCommand("MAIL FROM:<{$fromEmail}>");
    if (!$expectCode($response, [250])) {
        return $fail('MAIL FROM rejected: ' . trim($response));
    }

    $response = $sendCommand("RCPT TO:<{$to}>");
    if (!$expectCode($response, [250, 251])) {
        return $fail('RCPT TO rejected: ' . trim($response));
    }

    $response = $sendCommand('DATA');
    if (!$expectCode($response, [354])) {
        return $fail('DATA not accepted: ' . trim($response));
    }

    $headers = [
        'From: ' . mb_encode_mimeheader($fromName) . " <{$fromEmail}>",
        "To: <{$to}>",
        'Subject: ' . mb_encode_mimeheader($subject),
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'Date: ' . date('r'),
    ];

    // Dot-stuff any line that starts with a lone "." per the SMTP DATA rules.
    $bodyEscaped = preg_replace('/^\./m', '..', $htmlBody);

    $message = implode("\r\n", $headers) . "\r\n\r\n" . $bodyEscaped . "\r\n.";
    $response = $sendCommand($message);
    if (!$expectCode($response, [250])) {
        return $fail('Message not accepted: ' . trim($response));
    }

    $sendCommand('QUIT');
    fclose($socket);

    return ['success' => true, 'error' => ''];
}
