<?php
require_once '../config.php';

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$user_id = $_SESSION['user_id'] ?? 0;

switch ($action) {
    case 'get_available_seeds':
        getAvailableSeeds($conn);
        break;
    case 'submit_seed_request':
        submitSeedRequest($conn, $user_id);
        break;
    case 'get_seed_requests':
        getSeedRequests($conn, $user_id);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action.']);
        break;
}

function getSeedRequests($conn, $user_id) {
    // Lookup farmer_id from user_id
    $farmer_id = 0;
    $farmer_stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE user_id = ? LIMIT 1");
    $farmer_stmt->bind_param('i', $user_id);
    $farmer_stmt->execute();
    $farmer_stmt->bind_result($farmer_id);
    if (!$farmer_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Farmer profile not found.']);
        return;
    }
    $farmer_stmt->close();

    $stmt = $conn->prepare("SELECT request_id, seed_name, quantity_requested, request_status, requested_at FROM seed_requests WHERE farmer_id = ? ORDER BY requested_at DESC, request_id DESC LIMIT 20");
    $stmt->bind_param('i', $farmer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $requests = [];
    while ($row = $result->fetch_assoc()) {
        $requests[] = $row;
    }
    $stmt->close();
    echo json_encode(['success' => true, 'requests' => $requests]);
}

function getAvailableSeeds($conn) {
    $result = $conn->query("SELECT seed_id, seed_name, seed_unit, available_quantity FROM seed_inventory WHERE available_quantity > 0");
    $seeds = [];
    while ($row = $result->fetch_assoc()) {
        $seeds[] = $row;
    }
    echo json_encode(['success' => true, 'seeds' => $seeds]);
}

function submitSeedRequest($conn, $user_id) {
    $seed_id = (int)($_POST['seed_id'] ?? 0);
    $quantity_requested = (float)($_POST['quantity_requested'] ?? 0);
    $request_notes = trim((string)($_POST['request_notes'] ?? ''));
    if ($seed_id <= 0 || $quantity_requested <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid seed or quantity.']);
        return;
    }
    // Lookup farmer_id from user_id
    $farmer_id = 0;
    $farmer_stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE user_id = ? LIMIT 1");
    $farmer_stmt->bind_param('i', $user_id);
    $farmer_stmt->execute();
    $farmer_stmt->bind_result($farmer_id);
    if (!$farmer_stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Farmer profile not found.']);
        return;
    }
    $farmer_stmt->close();

    $seed_name = '';
    $seed_unit = '';
    $available_qty = 0.0;
    $seed_lookup = $conn->prepare("SELECT seed_name, seed_unit, available_quantity FROM seed_inventory WHERE seed_id = ? LIMIT 1 FOR UPDATE");
    $seed_lookup->bind_param('i', $seed_id);

    $conn->begin_transaction();
    $seed_lookup->execute();
    $seed_lookup->bind_result($seed_name, $seed_unit, $available_qty);
    if (!$seed_lookup->fetch()) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Seed not found.']);
        return;
    }
    $seed_lookup->close();

    if ((float)$available_qty < $quantity_requested) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Insufficient stock. Only ' . number_format((float)$available_qty, 2) . ' ' . $seed_unit . ' available.']);
        return;
    }

    $stmt = $conn->prepare("INSERT INTO seed_requests (farmer_id, seed_id, seed_name, quantity_requested, request_notes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param('iisds', $farmer_id, $seed_id, $seed_name, $quantity_requested, $request_notes);
    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to submit seed request.']);
        return;
    }
    $stmt->close();

    // Deduct stock immediately on request submission
    $deduct = $conn->prepare("UPDATE seed_inventory SET available_quantity = available_quantity - ? WHERE seed_id = ? AND available_quantity >= ?");
    $deduct->bind_param('did', $quantity_requested, $seed_id, $quantity_requested);
    $deduct->execute();
    $deducted = $deduct->affected_rows;
    $deduct->close();

    if ($deducted <= 0) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Insufficient stock. Please try again.']);
        return;
    }

    $conn->commit();

    if (function_exists('pushUserNotification')) {
        pushUserNotification(
            $conn,
            $user_id,
            'Seed Request Submitted',
            'Your seed request for ' . number_format($quantity_requested, 2) . ' ' . $seed_unit . ' of ' . $seed_name . ' was submitted and is pending admin review.',
            'seed_request_submitted',
            null
        );
    }
    echo json_encode(['success' => true, 'message' => 'Seed request submitted successfully.']);
}
