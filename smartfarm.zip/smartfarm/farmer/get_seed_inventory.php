<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

// Database connection
$host = 'localhost';
$user = 'root'; // Default for XAMPP/MAMP/WAMP
$pass = '';     // No password
$db   = 'smartfarm';

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    echo json_encode([
        'success' => false,
        'message' => 'Database connection failed: ' . $conn->connect_error
    ]);
    exit;
}

$sql = "SELECT seed_id, seed_name, seed_unit, available_quantity FROM seed_inventory";
$result = $conn->query($sql);

$seeds = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $seeds[] = [
            'seed_id' => (int)$row['seed_id'],
            'name' => $row['seed_name'],
            'unit' => $row['seed_unit'],
            'quantity' => (float)$row['available_quantity']
        ];
    }
    echo json_encode([
        'success' => true,
        'data' => $seeds
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Query failed: ' . $conn->error
    ]);
}

$conn->close();
?>