<?php
require __DIR__ . '/../config.php';
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);

$farmer_id = isset($input['farmer_id']) ? (int)$input['farmer_id'] : null;
$seed_id   = isset($input['seed_id'])   ? (int)$input['seed_id']   : null;
$quantity  = isset($input['quantity'])  ? (float)$input['quantity'] : null;

if (!$farmer_id || !$seed_id || !$quantity) {
    echo json_encode(['success' => false, 'message' => 'Missing required fields']);
    exit;
}

// Look up seed_name (required NOT NULL column)
$seed_lookup = $conn->prepare("SELECT seed_name FROM seed_inventory WHERE seed_id = ? LIMIT 1");
$seed_lookup->bind_param("i", $seed_id);
$seed_lookup->execute();
$seed_lookup->bind_result($seed_name);
if (!$seed_lookup->fetch()) {
    echo json_encode(['success' => false, 'message' => 'Seed not found']);
    exit;
}
$seed_lookup->close();

$stmt = $conn->prepare("INSERT INTO seed_requests (farmer_id, seed_id, seed_name, quantity_requested, request_status) VALUES (?, ?, ?, ?, 'pending')");
$stmt->bind_param("iisd", $farmer_id, $seed_id, $seed_name, $quantity);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Seed requested successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to request seed: ' . $stmt->error]);
}
?>
