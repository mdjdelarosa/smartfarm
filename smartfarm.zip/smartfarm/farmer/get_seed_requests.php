<?php
require 'config.php';

header('Content-Type: application/json');

$farmer_id = $_GET['farmer_id'] ?? null;

if (!$farmer_id) {
    echo json_encode(['success' => false, 'message' => 'Missing farmer_id']);
    exit;
}

$result = $conn->query("SELECT * FROM seed_requests WHERE farmer_id = " . intval($farmer_id) . " ORDER BY requested_at DESC, request_id DESC");
$requests = [];
while ($row = $result->fetch_assoc()) {
    $requests[] = $row;
}

echo json_encode([
    'success' => true,
    'data' => $requests
]);
?>
