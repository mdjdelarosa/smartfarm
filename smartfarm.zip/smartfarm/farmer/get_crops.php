<?php
ini_set('display_errors', 0);
error_reporting(0);
require __DIR__ . '/../config.php';
header('Content-Type: application/json');

$result = $conn->query(
    "SELECT crop_id, crop_name, crop_description, crop_quantity, crop_unit,
            market_price_per_unit, crop_status, created_at
     FROM crops
     WHERE starting_price <= 0
     ORDER BY crop_name ASC"
);

if (!$result) {
    echo json_encode(['success' => false, 'message' => 'Query failed: ' . $conn->error]);
    exit;
}

$crops = [];
while ($row = $result->fetch_assoc()) {
    $crops[] = [
        'crop_id'      => (int)$row['crop_id'],
        'name'         => (string)$row['crop_name'],
        'description'  => (string)$row['crop_description'],
        'quantity'     => (float)$row['crop_quantity'],
        'unit'         => (string)$row['crop_unit'],
        'market_price' => (float)$row['market_price_per_unit'],
        'status'       => (string)$row['crop_status'],
        'created_at'   => (string)$row['created_at'],
    ];
}

echo json_encode(['success' => true, 'data' => $crops]);
?>
