<?php
require_once '../config.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if (!isset($_SESSION['user_id']) || $sessionRole !== 'farmer') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!ensureFarmerRentalTable($conn)) {
    echo json_encode(['success' => false, 'message' => 'Unable to initialize rental tables']);
    exit;
}

if (!ensureRentalImageColumns($conn)) {
    echo json_encode(['success' => false, 'message' => 'Unable to initialize rental image columns']);
    exit;
}

$user_id = (int)($_SESSION['user_id'] ?? 0);
$farmer_stmt = $conn->prepare(
    "SELECT farmer_id, farmer_fullname, farmer_is_verified, farmer_id_verification_status
     FROM farmers
     WHERE user_id = ?
     LIMIT 1"
);
if (!$farmer_stmt) {
    echo json_encode(['success' => false, 'message' => 'Unable to validate farmer profile']);
    exit;
}

$farmer_stmt->bind_param('i', $user_id);
$farmer_stmt->execute();
$farmer_row = $farmer_stmt->get_result()->fetch_assoc();
$farmer_stmt->close();

if (!$farmer_row) {
    echo json_encode(['success' => false, 'message' => 'Farmer profile not found']);
    exit;
}

$is_farmer_verified = ((int)($farmer_row['farmer_is_verified'] ?? 0) === 1)
    && (strtolower((string)($farmer_row['farmer_id_verification_status'] ?? 'pending')) === 'approved');

if (!$is_farmer_verified) {
    echo json_encode(['success' => false, 'message' => 'Your account is pending admin approval.']);
    exit;
}

$farmer_name = trim((string)($farmer_row['farmer_fullname'] ?? ''));
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'get_available':
            getAvailableMachinery($conn);
            break;
        case 'get_my_rentals':
            getMyRentals($conn, $farmer_name);
            break;
        case 'submit_rentals':
            submitRentals($conn, $farmer_name, $user_id);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}

function ensureFarmerRentalTable(mysqli $conn): bool {
    $sql = "CREATE TABLE IF NOT EXISTS machinery_rentals (
      rental_id INT NOT NULL AUTO_INCREMENT,
      rental_code VARCHAR(20) NOT NULL,
      equipment_name VARCHAR(255) NOT NULL,
      owner_name VARCHAR(255) NOT NULL,
      machinery_image LONGBLOB NULL,
      machinery_image_name VARCHAR(255) NULL,
      machinery_image_mime_type VARCHAR(50) NULL,
      renter_name VARCHAR(255) NOT NULL,
      start_date DATE NOT NULL,
      end_date DATE NOT NULL,
      total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
      rental_status ENUM('pending','approved','in-rental','returned','cancelled') NOT NULL DEFAULT 'pending',
      payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
      payment_marked_at DATETIME NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (rental_id),
      UNIQUE KEY uniq_rental_code (rental_code),
      KEY idx_rental_status (rental_status),
      KEY idx_payment_status (payment_status),
      KEY idx_start_date (start_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    return (bool)$conn->query($sql);
}

function ensureRentalImageColumns(mysqli $conn): bool {
    $queries = [
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image LONGBLOB NULL",
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_name VARCHAR(255) NULL",
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_mime_type VARCHAR(50) NULL"
    ];

    foreach ($queries as $sql) {
        if (!$conn->query($sql)) {
            return false;
        }
    }

    return true;
}

function getAvailableMachinery(mysqli $conn): void {
    $search = trim((string)($_GET['search'] ?? ''));

    $sql = "SELECT rental_id, equipment_name, owner_name, total_cost, rental_status
            FROM machinery_rentals
            WHERE (renter_name = '' OR renter_name IS NULL)
              AND rental_status IN ('pending', 'approved')";

    if ($search !== '') {
        $sql .= " AND (equipment_name LIKE ? OR owner_name LIKE ?)";
    }

    $sql .= " ORDER BY created_at DESC, rental_id DESC";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Unable to load machinery']);
        return;
    }

    if ($search !== '') {
        $search_like = '%' . $search . '%';
        $stmt->bind_param('ss', $search_like, $search_like);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['rental_id'] = (int)$row['rental_id'];
        $row['daily_rate'] = (float)($row['total_cost'] ?? 0);
        $row['rental_status'] = (string)($row['rental_status'] ?? 'pending');
        $rows[] = $row;
    }

    $stmt->close();
    echo json_encode(['success' => true, 'items' => $rows]);
}

function getMyRentals(mysqli $conn, string $farmer_name): void {
    if ($farmer_name === '') {
        echo json_encode(['success' => true, 'rentals' => []]);
        return;
    }

    $stmt = $conn->prepare(
        "SELECT rental_id, rental_code, equipment_name, owner_name, start_date, end_date, total_cost, rental_status, payment_status, created_at
         FROM machinery_rentals
         WHERE renter_name = ?
         ORDER BY created_at DESC, rental_id DESC"
    );

    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Unable to load your rentals']);
        return;
    }

    $stmt->bind_param('s', $farmer_name);
    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['rental_id'] = (int)$row['rental_id'];
        $row['total_cost'] = (float)$row['total_cost'];
        $rows[] = $row;
    }

    $stmt->close();
    echo json_encode(['success' => true, 'rentals' => $rows]);
}

function submitRentals(mysqli $conn, string $farmer_name, int $farmer_user_id): void {
    if ($farmer_name === '') {
        echo json_encode(['success' => false, 'message' => 'Farmer profile is incomplete']);
        return;
    }

    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (!is_array($payload) || !isset($payload['items']) || !is_array($payload['items'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request payload']);
        return;
    }

    $items = $payload['items'];
    if (count($items) === 0) {
        echo json_encode(['success' => false, 'message' => 'No rental items submitted']);
        return;
    }

    $conn->begin_transaction();

    $next_id_result = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS next_id FROM machinery_rentals FOR UPDATE");
    $next_id = 1;
    if ($next_id_result) {
        $next_row = $next_id_result->fetch_assoc();
        $next_id = (int)($next_row['next_id'] ?? 1);
    }

    $insert_stmt = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, renter_name, start_date, end_date, total_cost, rental_status, payment_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'unpaid')"
    );

    if (!$insert_stmt) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Unable to prepare rental request']);
        return;
    }

    $inserted = 0;
    $overlap_conflicts = [];

    foreach ($items as $item) {
        $listing_id = max(0, (int)($item['listing_id'] ?? 0));
        $equipment_name = trim((string)($item['name'] ?? ''));
        $owner_name = trim((string)($item['owner'] ?? ''));
        $start_date = trim((string)($item['start_date'] ?? ''));
        $end_date = trim((string)($item['end_date'] ?? ''));
        $daily_rate = (float)($item['daily_rate'] ?? 0);
        $quantity = max(1, (int)($item['quantity'] ?? 1));
        $machinery_image = null;
        $machinery_image_name = null;
        $machinery_image_mime = null;

        if ($listing_id > 0) {
            $source_stmt = $conn->prepare(
                "SELECT equipment_name, owner_name, total_cost, machinery_image, machinery_image_name, machinery_image_mime_type
                 FROM machinery_rentals
                 WHERE rental_id = ?
                   AND (renter_name = '' OR renter_name IS NULL)
                   AND rental_status IN ('pending', 'approved')
                 LIMIT 1"
            );
            if ($source_stmt) {
                $source_stmt->bind_param('i', $listing_id);
                $source_stmt->execute();
                $source_row = $source_stmt->get_result()->fetch_assoc();
                $source_stmt->close();

                if ($source_row) {
                    $equipment_name = trim((string)($source_row['equipment_name'] ?? $equipment_name));
                    $owner_name = trim((string)($source_row['owner_name'] ?? $owner_name));
                    $daily_rate = (float)($source_row['total_cost'] ?? $daily_rate);
                    $machinery_image = $source_row['machinery_image'] ?? null;
                    $machinery_image_name = $source_row['machinery_image_name'] ?? null;
                    $machinery_image_mime = $source_row['machinery_image_mime_type'] ?? null;
                }
            }
        }

        if ($equipment_name === '' || $owner_name === '' || $start_date === '' || $end_date === '' || $daily_rate <= 0) {
            continue;
        }

        $start_ts = strtotime($start_date);
        $end_ts = strtotime($end_date);
        if ($start_ts === false || $end_ts === false || $end_ts < $start_ts) {
            continue;
        }

        $days = (int)floor(($end_ts - $start_ts) / 86400) + 1;
        if ($days < 1) {
            $days = 1;
        }

        $base_cost = $daily_rate * $days;
        $total_cost = $base_cost * $quantity;

        $conflict_stmt = $conn->prepare(
            "SELECT rental_id
             FROM machinery_rentals
             WHERE equipment_name = ?
               AND owner_name = ?
               AND rental_status IN ('pending', 'approved', 'in-rental')
               AND NOT (end_date < ? OR start_date > ?)
             LIMIT 1"
        );

        if ($conflict_stmt) {
            $conflict_stmt->bind_param('ssss', $equipment_name, $owner_name, $start_date, $end_date);
            $conflict_stmt->execute();
            $conflict_row = $conflict_stmt->get_result()->fetch_assoc();
            $conflict_stmt->close();

            if ($conflict_row) {
                $overlap_conflicts[] = $equipment_name;
                continue;
            }
        }

        $rental_code = 'RNT' . str_pad((string)$next_id, 4, '0', STR_PAD_LEFT);
        $next_id++;

        $insert_stmt->bind_param(
            'sssssssssd',
            $rental_code,
            $equipment_name,
            $owner_name,
            $machinery_image,
            $machinery_image_name,
            $machinery_image_mime,
            $farmer_name,
            $start_date,
            $end_date,
            $total_cost
        );

        if ($insert_stmt->execute()) {
            $inserted++;
        }
    }

    $insert_stmt->close();

    if ($inserted > 0) {
        $conn->commit();

        pushUserNotification(
            $conn,
            $farmer_user_id,
            'Rental request submitted',
            'Your machinery rental request has been submitted successfully.',
            'rental_submitted',
            null
        );

        pushNotificationToRole(
            $conn,
            'admin',
            'New machinery rental request',
            $farmer_name . ' submitted a machinery rental request.',
            'rental_submission',
            null
        );

        $message = 'Rental request submitted successfully.';
        if (!empty($overlap_conflicts)) {
            $message .= ' Some items were skipped due to date conflicts.';
        }

        echo json_encode(['success' => true, 'message' => $message, 'inserted' => $inserted]);
        return;
    }

    $conn->rollback();

    if (!empty($overlap_conflicts)) {
        echo json_encode(['success' => false, 'message' => 'All selected machinery has date conflicts. Please choose different dates.']);
        return;
    }

    echo json_encode(['success' => false, 'message' => 'No valid rental request could be submitted']);
}
