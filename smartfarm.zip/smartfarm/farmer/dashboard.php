<!DOCTYPE html>
<?php
// DEBUG: Show all errors and warnings
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Smart Farm Farmer Dashboard</title>
  <!-- Add your CSS links here -->
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"> -->
  <style>
    #section-profile.farmer-section.active {
      display: block !important;
      opacity: 1 !important;
      visibility: visible !important;
    }
  </style>
</head>
<body>
<script>
document.addEventListener('DOMContentLoaded', function() {
  var seedForm = document.getElementById('pageSeedRequestForm');
  if (seedForm) {
    seedForm.addEventListener('submit', function(e) {
      e.preventDefault();
      var seed_id = document.getElementById('pageSeedRequestId').value;
      var quantity_requested = document.getElementById('pageSeedRequestQty').value;
      var request_notes = document.getElementById('pageSeedRequestNote').value;
      var submitBtn = seedForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Submitting...';
      fetch('seed_request_api.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        credentials: 'same-origin',
        body: new URLSearchParams({
          action: 'submit_seed_request',
          seed_id: seed_id,
          quantity_requested: quantity_requested,
          request_notes: request_notes
        })
      })
      .then(r => r.json())
      .then(data => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit';
        if (data.success) {
          alert('Seed request submitted successfully!');
          window.location.href = 'dashboard.php?section=seed-request-catalog';
        } else {
          alert(data.message || 'Failed to submit seed request.');
        }
      })
      .catch(() => {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Submit';
        alert('Network error. Please try again.');
      });
    });
  }
});
</script>
<?php
require '../config.php';
$session_role = $_SESSION['user_role'] ?? '';
if (!isset($_SESSION['user_id']) || $session_role !== 'farmer') {
  header('Location: ../login.php');
  exit;
}

register_shutdown_function(static function () use ($conn) {
  if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    return;
  }

  if (!empty($_SESSION['skip_farmer_success_auto_notice'])) {
    unset($_SESSION['skip_farmer_success_auto_notice']);
    return;
  }

  $success_message = trim((string)($_SESSION['success'] ?? ''));
  $farmer_user_id = (int)($_SESSION['user_id'] ?? 0);
  if ($success_message === '' || $farmer_user_id <= 0) {
    return;
  }

  $fingerprint = sha1(($success_message . '|' . (string)($_SERVER['REQUEST_URI'] ?? '')));
  if ((string)($_SESSION['last_farmer_success_notice_hash'] ?? '') === $fingerprint) {
    return;
  }

  if (pushUserNotification(
    $conn,
    $farmer_user_id,
    'Submission completed',
    $success_message,
    'submission_success',
    null
  )) {
    $_SESSION['last_farmer_success_notice_hash'] = $fingerprint;
  }
});

$farmer_name = 'Farmer';
$farmer_id = 0;
$crop_rows = [];
$crops_table_exists = false;
$is_farmer_verified_access = false;
$seed_request_rows = [];
$seed_request_options = [];
$seed_request_table_exists = false;
$machinery_catalog = [];
$farmer_form_payload_encoded = (string)($_GET['form_payload'] ?? '');
$farmer_form_payload = [];

$requested_section = strtolower(trim((string)($_GET['section'] ?? 'overview')));
if ($requested_section === '') {
  $requested_section = 'overview';
}
$income_report_key = (string)($_GET['income_report'] ?? 'total-month');

$user_id = (int)$_SESSION['user_id'];

$tableExists = static function ($conn, $table_name) {
  $safe_name = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$table_name);
  if ($safe_name === '') {
    return false;
  }
  $table_result = $conn->query("SHOW TABLES LIKE '" . $safe_name . "'");
  return ($table_result && $table_result->num_rows > 0);
};

$columnExists = static function ($conn, $table_name, $column_name) {
  $safe_table = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$table_name);
  $safe_column = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$column_name);
  if ($safe_table === '' || $safe_column === '') {
    return false;
  }
  $column_result = $conn->query("SHOW COLUMNS FROM `" . $safe_table . "` LIKE '" . $safe_column . "'");
  return ($column_result && $column_result->num_rows > 0);
};

$farmer_profile = [
  'email' => (string)($_SESSION['user_email'] ?? '-'),
  'farm_name' => '-',
  'farm_address' => '-',
  'home_address' => '-',
  'contact' => '-',
  'id_type' => '-',
  'verification_status' => 'pending',
  'verification_notes' => '',
  'id_uploaded_at' => '-',
  'is_verified' => 0,
  'member_since' => '-'
];

$farmer_notifications = [];
$farmer_unread_count = 0;
$farmer_notify_table = $conn->query("SHOW TABLES LIKE 'user_notifications'");
if ($farmer_notify_table && $farmer_notify_table->num_rows > 0 && $user_id > 0) {
  $farmer_notify_stmt = $conn->prepare(
    "SELECT notification_title, notification_message, created_at, is_read
     FROM user_notifications
     WHERE user_id = ?
     ORDER BY created_at DESC
     LIMIT 15"
  );
  if ($farmer_notify_stmt) {
    $farmer_notify_stmt->bind_param('i', $user_id);
    $farmer_notify_stmt->execute();
    $farmer_notify_result = $farmer_notify_stmt->get_result();
    if ($farmer_notify_result) {
      while ($notify_row = $farmer_notify_result->fetch_assoc()) {
        $created_stamp = strtotime((string)($notify_row['created_at'] ?? ''));
        $title = (string)($notify_row['notification_title'] ?? 'Notification');
        $message = (string)($notify_row['notification_message'] ?? '');
        // Make seed request notification more visible
        if (stripos($title, 'seed request') !== false) {
          $title = 'Seed Request Submitted';
          $message = $message ?: 'Your seed request was submitted and is pending admin review.';
        }
        $farmer_notifications[] = [
          'title' => $title,
          'message' => $message,
          'created_label' => $created_stamp ? date('M d, Y h:i A', $created_stamp) : '',
          'is_read' => (int)($notify_row['is_read'] ?? 0) === 1
        ];
        if ((int)($notify_row['is_read'] ?? 0) === 0) {
          $farmer_unread_count++;
        }
      }
    }
    $farmer_notify_stmt->close();
  }
}

$farmer_stmt = $conn->prepare(
  "SELECT
      f.farmer_id,
      f.farmer_fullname,
      f.farmer_farm_name,
      f.farm_address,
      f.farmer_address,
      f.farmer_contact_number,
      f.farmer_id_type,
      f.farmer_id_verification_status,
      f.farmer_id_verification_notes,
      f.farmer_id_uploaded_at,
      f.farmer_is_verified,
      f.farmer_created_at,
      COALESCE(u.email, '') AS farmer_email
   FROM farmers f
   LEFT JOIN users u ON u.user_id = f.user_id
   WHERE f.user_id = ?
   LIMIT 1"
);
if ($farmer_stmt) {
  $farmer_stmt->bind_param('i', $user_id);
  $farmer_stmt->execute();
  $farmer_result = $farmer_stmt->get_result();
  if ($farmer_result && $farmer_result->num_rows > 0) {
    $farmer = $farmer_result->fetch_assoc();
    $farmer_id = (int)$farmer['farmer_id'];
    $farmer_name = $farmer['farmer_fullname'];
    $farmer_profile['email'] = (string)($farmer['farmer_email'] ?? $farmer_profile['email']);
    $farmer_profile['farm_name'] = (string)($farmer['farmer_farm_name'] ?? '-');
    $farmer_profile['farm_address'] = (string)($farmer['farm_address'] ?? '-');
    $farmer_profile['home_address'] = (string)($farmer['farmer_address'] ?? '-');
    $farmer_profile['contact'] = (string)($farmer['farmer_contact_number'] ?? '-');
    $farmer_profile['id_type'] = (string)($farmer['farmer_id_type'] ?? '-');
    $farmer_profile['verification_status'] = strtolower((string)($farmer['farmer_id_verification_status'] ?? 'pending'));
    $farmer_profile['verification_notes'] = trim((string)($farmer['farmer_id_verification_notes'] ?? ''));
    $farmer_profile['is_verified'] = (int)($farmer['farmer_is_verified'] ?? 0);

    $member_stamp = !empty($farmer['farmer_created_at']) ? strtotime((string)$farmer['farmer_created_at']) : false;
    if ($member_stamp) {
      $farmer_profile['member_since'] = date('F Y', $member_stamp);
    }

    $id_uploaded_stamp = !empty($farmer['farmer_id_uploaded_at']) ? strtotime((string)$farmer['farmer_id_uploaded_at']) : false;
    if ($id_uploaded_stamp) {
      $farmer_profile['id_uploaded_at'] = date('M d, Y h:i A', $id_uploaded_stamp);
    }

    $is_farmer_verified_access = ((int)($farmer_profile['is_verified'] ?? 0) === 1)
      && (($farmer_profile['verification_status'] ?? '') === 'approved');
  }
  $farmer_stmt->close();
}

$allowed_sections = $is_farmer_verified_access
  ? ['overview', 'income-transparency-report', 'events', 'crops', 'update-crop-quantity', 'rentals', 'machinery-reservations', 'rental-form', 'seed-request-catalog', 'seed-request-view', 'seed-requests', 'profile']
  : ['profile'];

$active_section = in_array($requested_section, $allowed_sections, true)
	? $requested_section
	: ($is_farmer_verified_access ? 'overview' : 'profile');


if ($farmer_form_payload_encoded !== '') {
  $decoded_form_payload_json = rawurldecode($farmer_form_payload_encoded);
  $decoded_form_payload = json_decode($decoded_form_payload_json, true);
  if (is_array($decoded_form_payload)) {
    $farmer_form_payload = $decoded_form_payload;
  }
}

$farmerImageDataUrl = static function ($blob, $mime): string {
  if ($blob === null || $blob === '' || $mime === null || $mime === '') {
    return '';
  }

  return 'data:' . $mime . ';base64,' . base64_encode($blob);
};

$rentals_table = $conn->query("SHOW TABLES LIKE 'machinery_rentals'");
if ($rentals_table && $rentals_table->num_rows > 0) {
  $machinery_stmt = $conn->prepare(
    "SELECT rental_id, equipment_name, owner_name, total_cost, rental_status,
            machinery_image, machinery_image_mime_type
     FROM machinery_rentals
     WHERE (renter_name = '' OR renter_name IS NULL)
       AND rental_status IN ('pending', 'approved')
     ORDER BY created_at DESC, rental_id DESC"
  );
  if ($machinery_stmt) {
    $machinery_stmt->execute();
    $machinery_result = $machinery_stmt->get_result();
    if ($machinery_result) {
      while ($machinery_row = $machinery_result->fetch_assoc()) {
        $machine_name = (string)($machinery_row['equipment_name'] ?? 'Machinery');
        $status = (string)($machinery_row['rental_status'] ?? 'pending');
        $availability = $status === 'approved' ? 'Available now' : 'Ready for booking';

        $machinery_catalog[] = [
          'listing_id' => (int)($machinery_row['rental_id'] ?? 0),
          'name' => $machine_name,
          'owner' => (string)($machinery_row['owner_name'] ?? '-'),
          'daily_rate' => (float)($machinery_row['total_cost'] ?? 0),
          'image_url' => $farmerImageDataUrl($machinery_row['machinery_image'] ?? null, $machinery_row['machinery_image_mime_type'] ?? ''),
          'availability' => $availability
        ];
      }
    }
    $machinery_stmt->close();
  }
}

$seed_request_table_sql = "CREATE TABLE IF NOT EXISTS seed_requests (
  request_id INT NOT NULL AUTO_INCREMENT,
  farmer_id INT NOT NULL,
  seed_id INT DEFAULT NULL,
  seed_name VARCHAR(255) NOT NULL,
  quantity_requested DECIMAL(10,2) NOT NULL,
  request_notes TEXT DEFAULT NULL,
  request_status ENUM('pending','approved','rejected','fulfilled') NOT NULL DEFAULT 'pending',
  requested_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at DATETIME DEFAULT NULL,
  reviewed_by_user_id INT DEFAULT NULL,
  PRIMARY KEY (request_id),
  KEY idx_farmer_requested (farmer_id, requested_at),
  KEY idx_request_status (request_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";
$seed_request_table_exists = (bool)$conn->query($seed_request_table_sql);

ensureCropHistoryTable($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $farmer_id > 0) {
  if (!$is_farmer_verified_access) {
    $_SESSION['error'] = 'Your account is pending admin verification. Features are hidden until approved.';
    header('Location: dashboard.php?section=profile');
    exit;
  }

  $action = $_POST['action'] ?? '';
  $history_actor_user_id = (int)($_SESSION['user_id'] ?? 0);
  $history_actor_role = 'farmer';
  $history_actor_name = getActorDisplayName($conn, $history_actor_user_id, $history_actor_role);
  $crop_history_ready = ensureCropHistoryTable($conn);

  if ($action === 'add_crop_record' || $action === 'publish_crop_to_bidding') {
    $_SESSION['error'] = 'Crop records and bidding listings are managed on the admin side. You can only update crop quantity here.';
    header('Location: dashboard.php?section=crops');
    exit;
  }

  if ($action === 'submit_seed_request') {
    $seed_id = (int)($_POST['seed_id'] ?? 0);
    $quantity_requested = (float)($_POST['quantity_requested'] ?? 0);
    $request_notes = trim((string)($_POST['request_notes'] ?? ''));
    $errors = [];

    if (!$seed_request_table_exists) {
      $errors[] = 'Seed request feature is not ready. Please try again later.';
    }
    if ($seed_id <= 0) {
      $errors[] = 'Please select a seed type.';
    }
    if ($quantity_requested <= 0) {
      $errors[] = 'Requested quantity must be greater than zero.';
    }

    $seed_name = '';
    if (empty($errors) && $seed_inventory_table_exists) {
      $seed_lookup_stmt = $conn->prepare(
        "SELECT seed_name, available_quantity
         FROM seed_inventory
         WHERE seed_id = ?
         LIMIT 1"
      );
      if ($seed_lookup_stmt) {
        $seed_lookup_stmt->bind_param('i', $seed_id);
        $seed_lookup_stmt->execute();
        $seed_lookup_result = $seed_lookup_stmt->get_result();
        $seed_row = $seed_lookup_result ? $seed_lookup_result->fetch_assoc() : null;
        $seed_lookup_stmt->close();

        if (!$seed_row) {
          $errors[] = 'Selected seed type was not found.';
        } else {
          $seed_name = (string)($seed_row['seed_name'] ?? 'Seed');
        }
      } else {
        $errors[] = 'Failed to validate selected seed.';
      }
    } elseif (empty($errors)) {
      $errors[] = 'Seed inventory is unavailable right now.';
    }

    if (empty($errors)) {
      $insert_request_stmt = $conn->prepare(
        "INSERT INTO seed_requests (farmer_id, seed_id, seed_name, quantity_requested, request_notes, request_status)
         VALUES (?, ?, ?, ?, ?, 'pending')"
      );
      if ($insert_request_stmt) {
        $insert_request_stmt->bind_param('iisds', $farmer_id, $seed_id, $seed_name, $quantity_requested, $request_notes);
        if ($insert_request_stmt->execute()) {
          $seed_request_id = (int)$insert_request_stmt->insert_id;
          pushUserNotification(
            $conn,
            $history_actor_user_id,
            'Seed request submitted',
            'Your request for ' . number_format($quantity_requested, 2) . ' ' . $seed_name . ' was submitted successfully.',
            'seed_request_submitted',
            $seed_request_id
          );

          pushNotificationToRole(
            $conn,
            'admin',
            'New seed request submitted',
            $history_actor_name . ' requested ' . number_format($quantity_requested, 2) . ' of ' . $seed_name . '.',
            'seed_request_submission',
            $seed_request_id
          );

          $_SESSION['skip_farmer_success_auto_notice'] = 1;

          $_SESSION['success'] = 'Seed request submitted successfully.';
        } else {
          $_SESSION['error'] = 'Failed to submit seed request: ' . $insert_request_stmt->error;
        }
        $insert_request_stmt->close();
      } else {
        $_SESSION['error'] = 'Failed to prepare seed request submission.';
      }
    } else {
      $_SESSION['error'] = implode(' ', $errors);
    }

    header('Location: dashboard.php?section=seed-requests');
    exit;
  }

  if ($action === 'update_crop_quantity') {
    $_SESSION['error'] = 'Direct quantity editing is disabled. Use Add Quantity.';
    header('Location: dashboard.php?section=crops');
    exit;
  }

  if ($action === 'add_crop_quantity') {
    $crop_id = (int)($_POST['crop_id'] ?? 0);
    $added_quantity = (float)($_POST['added_quantity'] ?? 0);
    $existing_crop = null;
    $errors = [];

    if ($crop_id <= 0) {
      $errors[] = 'Invalid crop selected.';
    }

    if ($added_quantity <= 0) {
      $errors[] = 'Added quantity must be greater than zero.';
    }

    if (empty($errors)) {
      $check_stmt = $conn->prepare(
        "SELECT crop_id, crop_name, crop_unit, crop_quantity
         FROM crops
         WHERE crop_id = ?
           AND starting_price <= 0
         LIMIT 1"
      );
      if ($check_stmt) {
        $check_stmt->bind_param('i', $crop_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        $existing_crop = $check_result ? $check_result->fetch_assoc() : null;
        $check_stmt->close();

        if (!$existing_crop) {
          $errors[] = 'Crop record not found.';
        }
      } else {
        $errors[] = 'Failed to validate crop record.';
      }
    }

    if (empty($errors)) {
      $old_quantity = (float)($existing_crop['crop_quantity'] ?? 0);
      $new_quantity = $old_quantity + $added_quantity;
      $update_stmt = $conn->prepare("UPDATE crops SET crop_quantity = ? WHERE crop_id = ?");
      if ($update_stmt) {
        $update_stmt->bind_param('di', $new_quantity, $crop_id);
        if ($update_stmt->execute()) {
          if ($crop_history_ready && $existing_crop) {
            $quantity_delta = $added_quantity;
            logCropHistoryEvent($conn, [
              'crop_id' => $crop_id,
              'farmer_id' => (int)($farmer_id > 0 ? $farmer_id : 0),
              'changed_by_user_id' => $history_actor_user_id,
              'actor_role' => $history_actor_role,
              'actor_name' => $history_actor_name,
              'event_type' => 'crop_updated',
              'old_quantity' => $old_quantity,
              'new_quantity' => $new_quantity,
              'quantity_delta' => $quantity_delta,
              'crop_name' => (string)$existing_crop['crop_name'],
              'crop_unit' => (string)$existing_crop['crop_unit'],
              'remarks' => 'Quantity increased by farmer by ' . number_format($added_quantity, 2) . ' via Farmer Dashboard (from ' . number_format($old_quantity, 2) . ' to ' . number_format($new_quantity, 2) . ').'
            ]);
          }

          $crop_name_for_notification = (string)($existing_crop['crop_name'] ?? 'Crop');
          pushUserNotification(
            $conn,
            $history_actor_user_id,
            'Crop quantity updated',
            'You added ' . number_format($added_quantity, 2) . ' to ' . $crop_name_for_notification . '.',
            'crop_quantity_updated',
            $crop_id
          );

          pushNotificationToRole(
            $conn,
            'admin',
            'Farmer updated crop quantity',
            $history_actor_name . ' added ' . number_format($added_quantity, 2) . ' to ' . $crop_name_for_notification . '.',
            'crop_quantity_updated',
            $crop_id
          );

          $_SESSION['skip_farmer_success_auto_notice'] = 1;

          $_SESSION['success'] = 'Crop quantity added successfully.';
        } else {
          $_SESSION['error'] = 'Failed to add crop quantity: ' . $update_stmt->error;
        }
        $update_stmt->close();
      } else {
        $_SESSION['error'] = 'Failed to prepare crop quantity update statement.';
      }
    } else {
      $_SESSION['error'] = implode(' ', $errors);
    }

    header('Location: dashboard.php?section=crops');
    exit;
  }
}

$bids_table_exists = $tableExists($conn, 'bids');
$seed_distribution_table_exists = $tableExists($conn, 'seed_distributions');
$seed_inventory_table_exists = $tableExists($conn, 'seed_inventory');

// Populate seed request options for the catalog
if ($seed_inventory_table_exists) {
  $seed_stmt = $conn->prepare(
    "SELECT seed_id, seed_name, seed_unit, available_quantity, low_stock_threshold
     FROM seed_inventory
     WHERE available_quantity > 0
     ORDER BY seed_name ASC"
  );
  if ($seed_stmt) {
    $seed_stmt->execute();
    $seed_result = $seed_stmt->get_result();
    if ($seed_result) {
      while ($seed_row = $seed_result->fetch_assoc()) {
        $seed_request_options[] = $seed_row;
      }
    }
    $seed_stmt->close();
  }
}
$crop_has_payment_status = false;
$crop_has_payment_marked_at = false;
$crop_has_market_price = false;

if ($tableExists($conn, 'crops') && $farmer_id > 0) {
  $crops_table_exists = true;
  $crop_has_payment_status = $columnExists($conn, 'crops', 'payment_status');
  $crop_has_payment_marked_at = $crop_has_payment_status && $columnExists($conn, 'crops', 'payment_marked_at');
  $crop_has_market_price = $columnExists($conn, 'crops', 'market_price_per_unit');

  $crop_payment_select = $crop_has_payment_status
    ? ", COALESCE(payment_status, 'unpaid') AS payment_status, payment_marked_at"
    : ", 'unpaid' AS payment_status, NULL AS payment_marked_at";

  $crop_market_price_select = $crop_has_market_price
    ? ", COALESCE(market_price_per_unit, 0) AS market_price_per_unit"
    : ", 0 AS market_price_per_unit";

  $crop_query = "
    SELECT crop_id, crop_name, crop_description, crop_quantity, crop_unit, created_at
    " . $crop_market_price_select . "
    FROM crops
    WHERE starting_price <= 0
    ORDER BY created_at DESC, crop_id DESC
  ";
  $crop_stmt = $conn->prepare($crop_query);
  if ($crop_stmt) {
    $crop_stmt->execute();
    $crop_result = $crop_stmt->get_result();
    if ($crop_result) {
      while ($row = $crop_result->fetch_assoc()) {
        $crop_rows[] = $row;
      }
    }
    $crop_stmt->close();
  }
}

$selected_crop_for_update = null;
if ($active_section === 'update-crop-quantity' && $farmer_id > 0) {
  $requested_crop_id = (int)($_GET['crop_id'] ?? 0);
  if ($requested_crop_id <= 0) {
    $_SESSION['error'] = 'Invalid crop selected.';
    header('Location: dashboard.php?section=crops');
    exit;
  }

  $selected_crop_stmt = $conn->prepare(
    "SELECT crop_id, crop_name, crop_unit, crop_quantity
     FROM crops
     WHERE crop_id = ?
       AND starting_price <= 0
     LIMIT 1"
  );
  if ($selected_crop_stmt) {
    $selected_crop_stmt->bind_param('i', $requested_crop_id);
    $selected_crop_stmt->execute();
    $selected_crop_result = $selected_crop_stmt->get_result();
    $selected_crop_for_update = $selected_crop_result ? $selected_crop_result->fetch_assoc() : null;
    $selected_crop_stmt->close();
  }

  if (!$selected_crop_for_update) {
    $_SESSION['error'] = 'Crop record not found.';
    header('Location: dashboard.php?section=crops');
    exit;
  }
}

$selected_seed_for_view = null;
if ($active_section === 'seed-request-view') {
  $requested_seed_id = (int)($_GET['seed_id'] ?? 0);
  if ($requested_seed_id > 0 && $seed_inventory_table_exists) {
    $selected_seed_stmt = $conn->prepare(
      "SELECT seed_id, seed_name, seed_unit, available_quantity, low_stock_threshold, created_at
       FROM seed_inventory
       WHERE seed_id = ?
       LIMIT 1"
    );
    if ($selected_seed_stmt) {
      $selected_seed_stmt->bind_param('i', $requested_seed_id);
      $selected_seed_stmt->execute();
      $selected_seed_result = $selected_seed_stmt->get_result();
      $selected_seed_for_view = $selected_seed_result ? $selected_seed_result->fetch_assoc() : null;
      $selected_seed_stmt->close();
    }
  }
}

$crop_bid_summary_map = [];
$recent_bid_rows = [];
$recent_seed_rows = [];

$total_crop_records = count($crop_rows);
$draft_crop_count = count($crop_rows);
$open_bidding_count = 0;
$sold_crop_count = 0;
$expired_crop_count = 0;
$ended_crop_count = 0;
$unpaid_sold_count = 0;

$total_bids_received = 0;
$active_bids_received = 0;
$highest_single_bid = 0.0;

if ($bids_table_exists && $farmer_id > 0) {
  $crop_bid_summary_stmt = $conn->prepare(
    "SELECT
        c.crop_id,
        COUNT(b.bid_id) AS total_bids,
        SUM(CASE WHEN b.bid_status = 'active' THEN 1 ELSE 0 END) AS active_bids,
        MAX(b.bid_amount) AS highest_bid
     FROM crops c
     LEFT JOIN bids b ON b.crop_id = c.crop_id
     GROUP BY c.crop_id"
  );
  if ($crop_bid_summary_stmt) {
    $crop_bid_summary_stmt->execute();
    $crop_bid_summary_result = $crop_bid_summary_stmt->get_result();
    if ($crop_bid_summary_result) {
      while ($summary_row = $crop_bid_summary_result->fetch_assoc()) {
        $crop_id_key = (int)($summary_row['crop_id'] ?? 0);
        $row_total_bids = (int)($summary_row['total_bids'] ?? 0);
        $row_active_bids = (int)($summary_row['active_bids'] ?? 0);
        $row_highest_bid = (float)($summary_row['highest_bid'] ?? 0);

        $crop_bid_summary_map[$crop_id_key] = [
          'total_bids' => $row_total_bids,
          'active_bids' => $row_active_bids,
          'highest_bid' => $row_highest_bid
        ];

        $total_bids_received += $row_total_bids;
        $active_bids_received += $row_active_bids;
        if ($row_highest_bid > $highest_single_bid) {
          $highest_single_bid = $row_highest_bid;
        }
      }
    }
    $crop_bid_summary_stmt->close();
  }

  $recent_bid_stmt = $conn->prepare(
    "SELECT
        c.crop_id,
        c.crop_name,
        MAX(b.bid_amount) AS highest_bid,
        COUNT(b.bid_id) AS total_bids,
        MAX(b.created_at) AS last_bid_at
     FROM crops c
     INNER JOIN bids b ON b.crop_id = c.crop_id
     GROUP BY c.crop_id, c.crop_name
     ORDER BY last_bid_at DESC
     LIMIT 6"
  );
  if ($recent_bid_stmt) {
    $recent_bid_stmt->execute();
    $recent_bid_result = $recent_bid_stmt->get_result();
    if ($recent_bid_result) {
      while ($recent_bid_row = $recent_bid_result->fetch_assoc()) {
        $recent_bid_rows[] = $recent_bid_row;
      }
    }
    $recent_bid_stmt->close();
  }
}

$seed_distribution_count = 0;
$seed_distribution_total_qty = 0.0;
$seed_last_distribution_label = 'No seed releases yet';
$verified_farmer_count = 0;
$income_farmer_share_rate = 0.70;
$income_coop_share_rate = 0.30;
$coop_monthly_transaction_value = 0.0;
$coop_last_12_months_transaction_value = 0.0;
$income_monthly_bidding_total = 0.0;
$income_monthly_livestock_total = 0.0;
$income_monthly_machinery_total = 0.0;
$income_last_12_bidding_total = 0.0;
$income_last_12_livestock_total = 0.0;
$income_last_12_machinery_total = 0.0;
$income_last_12_month_keys = [];
$income_last_12_month_labels = [];
$income_last_12_coop_by_month = [
  'bidding' => [],
  'livestock' => [],
  'machinery' => []
];
$income_last_12_farmer_by_month = [
  'bidding' => [],
  'livestock' => [],
  'machinery' => []
];
$coop_monthly_farmer_dividend = 0.0;
$coop_monthly_coop_dividend = 0.0;
$coop_last_12_months_farmer_dividend = 0.0;
$coop_last_12_months_coop_dividend = 0.0;
$income_transparency_reports_json = '{}';
$schedule_table_exists = $tableExists($conn, 'scheduled_activities');
$upcoming_farmer_events = [];
$recent_farmer_events = [];
$today_event_count = 0;
$week_event_count = 0;
$upcoming_event_count = 0;
$recent_event_count = 0;

// Handle calendar month navigation
$event_calendar_requested_month = isset($_GET['event_month']) ? (string)$_GET['event_month'] : '';
if (!empty($event_calendar_requested_month) && preg_match('/^\d{4}-\d{2}$/', $event_calendar_requested_month)) {
  $event_calendar_month_start = $event_calendar_requested_month . '-01';
} else {
  $event_calendar_month_start = date('Y-m-01');
}
$event_calendar_month_start = date('Y-m-01', strtotime($event_calendar_month_start));
$event_calendar_month_end = date('Y-m-t', strtotime($event_calendar_month_start));
$event_calendar_month_label = date('F Y', strtotime($event_calendar_month_start));
$event_calendar_total_days = (int)date('t', strtotime($event_calendar_month_start));
$event_calendar_first_weekday = (int)date('N', strtotime($event_calendar_month_start));
$event_calendar_leading_blanks = max(0, $event_calendar_first_weekday - 1);
$event_calendar_today_day = (date('Y-m') === date('Y-m', strtotime($event_calendar_month_start))) ? (int)date('j') : 0;
$event_calendar_day_counts = array_fill(1, $event_calendar_total_days, 0);
$event_calendar_events_by_date = [];
$event_calendar_total_events = 0;
$event_calendar_days_with_events = 0;
$next_farmer_event_label = 'No upcoming events';
$event_calendar_month_prev = date('Y-m', strtotime($event_calendar_month_start . ' -1 month'));
$event_calendar_month_next = date('Y-m', strtotime($event_calendar_month_start . ' +1 month'));

if ($seed_distribution_table_exists && $farmer_id > 0) {
  $seed_summary_stmt = $conn->prepare(
    "SELECT
        COUNT(*) AS distribution_count,
        COALESCE(SUM(quantity_distributed), 0) AS total_qty,
        MAX(distribution_date) AS latest_distribution
     FROM seed_distributions"
  );
  if ($seed_summary_stmt) {
    $seed_summary_stmt->execute();
    $seed_summary_result = $seed_summary_stmt->get_result();
    if ($seed_summary_result) {
      $seed_summary_row = $seed_summary_result->fetch_assoc();
      $seed_distribution_count = (int)($seed_summary_row['distribution_count'] ?? 0);
      $seed_distribution_total_qty = (float)($seed_summary_row['total_qty'] ?? 0);
      $latest_distribution = (string)($seed_summary_row['latest_distribution'] ?? '');
      if ($latest_distribution !== '') {
        $seed_last_distribution_label = date('M d, Y', strtotime($latest_distribution));
      }
    }
    $seed_summary_stmt->close();
  }

  if ($seed_inventory_table_exists) {
    $seed_recent_query = "
      SELECT sd.distribution_date, sd.quantity_distributed, sd.status, si.seed_name, si.seed_unit
      FROM seed_distributions sd
      LEFT JOIN seed_inventory si ON si.seed_id = sd.seed_id
      ORDER BY sd.distribution_date DESC, sd.distribution_id DESC
      LIMIT 6
    ";
  } else {
    $seed_recent_query = "
      SELECT sd.distribution_date, sd.quantity_distributed, sd.status, 'Seed' AS seed_name, '' AS seed_unit
      FROM seed_distributions sd
      ORDER BY sd.distribution_date DESC, sd.distribution_id DESC
      LIMIT 6
    ";
  }

  $seed_recent_stmt = $conn->prepare($seed_recent_query);
  if ($seed_recent_stmt) {
    $seed_recent_stmt->execute();
    $seed_recent_result = $seed_recent_stmt->get_result();
    if ($seed_recent_result) {
      while ($seed_recent_row = $seed_recent_result->fetch_assoc()) {
        $recent_seed_rows[] = $seed_recent_row;
      }
    }
    $seed_recent_stmt->close();
  }
}

if ($seed_request_table_exists && $farmer_id > 0) {
  $seed_request_stmt = $conn->prepare(
    "SELECT request_id, seed_name, quantity_requested, request_notes, request_status, requested_at
     FROM seed_requests
     WHERE farmer_id = ?
     ORDER BY requested_at DESC, request_id DESC
     LIMIT 20"
  );
  if ($seed_request_stmt) {
    $seed_request_stmt->bind_param('i', $farmer_id);
    $seed_request_stmt->execute();
    $seed_request_result = $seed_request_stmt->get_result();
    if ($seed_request_result) {
      while ($seed_request_row = $seed_request_result->fetch_assoc()) {
        $seed_request_rows[] = $seed_request_row;
      }
    }
    $seed_request_stmt->close();
  }
}

$pending_seed_request_count = 0;
foreach ($seed_request_rows as $seed_request_row) {
  if (strtolower((string)($seed_request_row['request_status'] ?? '')) === 'pending') {
    $pending_seed_request_count++;
  }
}

$sumIncomeQuery = static function ($conn, $query) {
  $result = $conn->query($query);
  if ($result) {
    $row = $result->fetch_assoc();
    return (float)($row['total_amount'] ?? 0);
  }
  return 0.0;
};

$income_current_month_start = date('Y-m-01');
$income_next_month_start = date('Y-m-01', strtotime('+1 month'));
$income_last_12_months_start = date('Y-m-01', strtotime('-11 months'));

$income_month_map = [];
$income_month_base = strtotime(date('Y-m-01'));
for ($income_offset = 11; $income_offset >= 0; $income_offset--) {
  $income_ts = strtotime('-' . $income_offset . ' months', $income_month_base);
  $income_key = date('Y-m', $income_ts);
  $income_last_12_month_keys[] = $income_key;
  $income_last_12_month_labels[] = date('M Y', $income_ts);
  $income_month_map[$income_key] = [
    'bidding' => 0.0,
    'livestock' => 0.0,
    'machinery' => 0.0
  ];
}

if ($tableExists($conn, 'bids')) {
  $income_monthly_bidding_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(bid_amount), 0) AS total_amount
     FROM bids
     WHERE bid_status = 'won'
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_current_month_start) . "'
       AND created_at < '" . $conn->real_escape_string($income_next_month_start) . "'"
  );
  $coop_monthly_transaction_value += $income_monthly_bidding_total;

  $income_last_12_bidding_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(bid_amount), 0) AS total_amount
     FROM bids
     WHERE bid_status = 'won'
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'"
  );
  $coop_last_12_months_transaction_value += $income_last_12_bidding_total;

  $income_bidding_monthly_result = $conn->query(
    "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, COALESCE(SUM(bid_amount), 0) AS total_amount
     FROM bids
     WHERE bid_status = 'won'
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'
     GROUP BY DATE_FORMAT(created_at, '%Y-%m')"
  );
  if ($income_bidding_monthly_result) {
    while ($income_row = $income_bidding_monthly_result->fetch_assoc()) {
      $month_key = (string)($income_row['month_key'] ?? '');
      if (isset($income_month_map[$month_key])) {
        $income_month_map[$month_key]['bidding'] = (float)($income_row['total_amount'] ?? 0);
      }
    }
  }
}

if ($tableExists($conn, 'livestock_reservations')) {
  $income_monthly_livestock_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(total_price), 0) AS total_amount
     FROM livestock_reservations
     WHERE status IN ('confirmed', 'ready', 'completed')
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_current_month_start) . "'
       AND created_at < '" . $conn->real_escape_string($income_next_month_start) . "'"
  );
  $coop_monthly_transaction_value += $income_monthly_livestock_total;

  $income_last_12_livestock_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(total_price), 0) AS total_amount
     FROM livestock_reservations
     WHERE status IN ('confirmed', 'ready', 'completed')
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'"
  );
  $coop_last_12_months_transaction_value += $income_last_12_livestock_total;

  $income_livestock_monthly_result = $conn->query(
    "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, COALESCE(SUM(total_price), 0) AS total_amount
     FROM livestock_reservations
     WHERE status IN ('confirmed', 'ready', 'completed')
       AND payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'
     GROUP BY DATE_FORMAT(created_at, '%Y-%m')"
  );
  if ($income_livestock_monthly_result) {
    while ($income_row = $income_livestock_monthly_result->fetch_assoc()) {
      $month_key = (string)($income_row['month_key'] ?? '');
      if (isset($income_month_map[$month_key])) {
        $income_month_map[$month_key]['livestock'] = (float)($income_row['total_amount'] ?? 0);
      }
    }
  }
}

if ($tableExists($conn, 'machinery_rentals')) {
  $income_monthly_machinery_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(total_cost), 0) AS total_amount
     FROM machinery_rentals
     WHERE payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_current_month_start) . "'
       AND created_at < '" . $conn->real_escape_string($income_next_month_start) . "'"
  );
  $coop_monthly_transaction_value += $income_monthly_machinery_total;

  $income_last_12_machinery_total = $sumIncomeQuery(
    $conn,
    "SELECT COALESCE(SUM(total_cost), 0) AS total_amount
     FROM machinery_rentals
     WHERE payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'"
  );
  $coop_last_12_months_transaction_value += $income_last_12_machinery_total;

  $income_machinery_monthly_result = $conn->query(
    "SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, COALESCE(SUM(total_cost), 0) AS total_amount
     FROM machinery_rentals
     WHERE payment_status = 'paid'
       AND created_at >= '" . $conn->real_escape_string($income_last_12_months_start) . "'
     GROUP BY DATE_FORMAT(created_at, '%Y-%m')"
  );
  if ($income_machinery_monthly_result) {
    while ($income_row = $income_machinery_monthly_result->fetch_assoc()) {
      $month_key = (string)($income_row['month_key'] ?? '');
      if (isset($income_month_map[$month_key])) {
        $income_month_map[$month_key]['machinery'] = (float)($income_row['total_amount'] ?? 0);
      }
    }
  }
}

$coop_monthly_farmer_dividend = $coop_monthly_transaction_value * $income_farmer_share_rate;
$coop_monthly_coop_dividend = $coop_monthly_transaction_value * $income_coop_share_rate;
$coop_last_12_months_farmer_dividend = $coop_last_12_months_transaction_value * $income_farmer_share_rate;
$coop_last_12_months_coop_dividend = $coop_last_12_months_transaction_value * $income_coop_share_rate;

if ($farmer_id > 0) {
  $verified_farmer_stmt = $conn->prepare(
    "SELECT COUNT(*) AS count
     FROM farmers
     WHERE farmer_is_verified = 1
       AND farmer_id_verification_status = 'approved'"
  );
  if ($verified_farmer_stmt) {
    $verified_farmer_stmt->execute();
    $verified_farmer_result = $verified_farmer_stmt->get_result();
    if ($verified_farmer_result) {
      $verified_farmer_count = (int)($verified_farmer_result->fetch_assoc()['count'] ?? 0);
    }
    $verified_farmer_stmt->close();
  }
}

$monthly_one_farmer_share = $verified_farmer_count > 0
  ? ((float)$coop_monthly_farmer_dividend / (float)$verified_farmer_count)
  : 0.0;

$monthly_one_farmer_bidding_share = $verified_farmer_count > 0
  ? (((float)$income_monthly_bidding_total * $income_farmer_share_rate) / (float)$verified_farmer_count)
  : 0.0;
$monthly_one_farmer_livestock_share = $verified_farmer_count > 0
  ? (((float)$income_monthly_livestock_total * $income_farmer_share_rate) / (float)$verified_farmer_count)
  : 0.0;
$monthly_one_farmer_machinery_share = $verified_farmer_count > 0
  ? (((float)$income_monthly_machinery_total * $income_farmer_share_rate) / (float)$verified_farmer_count)
  : 0.0;

foreach ($income_last_12_month_keys as $income_key) {
  $income_month = $income_month_map[$income_key] ?? ['bidding' => 0.0, 'livestock' => 0.0, 'machinery' => 0.0];
  $income_last_12_coop_by_month['bidding'][] = round((float)$income_month['bidding'] * $income_coop_share_rate, 2);
  $income_last_12_coop_by_month['livestock'][] = round((float)$income_month['livestock'] * $income_coop_share_rate, 2);
  $income_last_12_coop_by_month['machinery'][] = round((float)$income_month['machinery'] * $income_coop_share_rate, 2);
  $income_last_12_farmer_by_month['bidding'][] = round((float)$income_month['bidding'] * $income_farmer_share_rate, 2);
  $income_last_12_farmer_by_month['livestock'][] = round((float)$income_month['livestock'] * $income_farmer_share_rate, 2);
  $income_last_12_farmer_by_month['machinery'][] = round((float)$income_month['machinery'] * $income_farmer_share_rate, 2);
}

$income_transparency_reports = [
  'one-farmer-share-month' => [
    'title' => 'One Farmer Share (This Month)',
    'subtitle' => 'Per verified farmer share for ' . date('F Y') . '. Verified farmers: ' . (int)$verified_farmer_count . '.',
    'rows' => [
      ['label' => 'Bidding Share Per Farmer', 'amount' => round((float)$monthly_one_farmer_bidding_share, 2)],
      ['label' => 'Livestock Share Per Farmer', 'amount' => round((float)$monthly_one_farmer_livestock_share, 2)],
      ['label' => 'Machinery Share Per Farmer', 'amount' => round((float)$monthly_one_farmer_machinery_share, 2)]
    ],
    'summary_label' => 'Per Farmer Share',
    'summary_amount' => round((float)$monthly_one_farmer_share, 2)
  ],
  'farmers-total-share-month' => [
    'title' => 'Total Share of All Farmers (This Month)',
    'subtitle' => 'Combined farmer share from paid transactions this month.',
    'rows' => [
      ['label' => 'Bidding Farmer Share', 'amount' => round((float)$income_monthly_bidding_total * $income_farmer_share_rate, 2)],
      ['label' => 'Livestock Farmer Share', 'amount' => round((float)$income_monthly_livestock_total * $income_farmer_share_rate, 2)],
      ['label' => 'Machinery Farmer Share', 'amount' => round((float)$income_monthly_machinery_total * $income_farmer_share_rate, 2)]
    ],
    'summary_label' => 'All Farmers Share',
    'summary_amount' => round((float)$coop_monthly_farmer_dividend, 2)
  ],
  'coop-share-month' => [
    'title' => 'Coop Share (This Month)',
    'subtitle' => 'Coop dividend based on monthly paid transactions.',
    'rows' => [
      ['label' => 'Bidding Coop Share', 'amount' => round((float)$income_monthly_bidding_total * $income_coop_share_rate, 2)],
      ['label' => 'Livestock Coop Share', 'amount' => round((float)$income_monthly_livestock_total * $income_coop_share_rate, 2)],
      ['label' => 'Machinery Coop Share', 'amount' => round((float)$income_monthly_machinery_total * $income_coop_share_rate, 2)]
    ],
    'summary_label' => 'Coop Share',
    'summary_amount' => round((float)$coop_monthly_coop_dividend, 2)
  ],
  'total-month' => [
    'title' => 'Total Transaction Income (This Month)',
    'subtitle' => 'Overall paid transaction income for ' . date('F Y') . '.',
    'rows' => [
      ['label' => 'Bidding', 'amount' => round((float)$income_monthly_bidding_total, 2)],
      ['label' => 'Livestock Reservations', 'amount' => round((float)$income_monthly_livestock_total, 2)],
      ['label' => 'Machinery Rentals', 'amount' => round((float)$income_monthly_machinery_total, 2)]
    ],
    'summary_label' => 'Total Transaction Income',
    'summary_amount' => round((float)$coop_monthly_transaction_value, 2)
  ]
];

$income_transparency_reports_json = json_encode($income_transparency_reports, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
if ($income_transparency_reports_json === false) {
  $income_transparency_reports_json = '{}';
}

if (!isset($income_transparency_reports[$income_report_key])) {
  $income_report_key = 'one-farmer-share-month';
}

$active_income_report = $income_transparency_reports[$income_report_key] ?? $income_transparency_reports['one-farmer-share-month'];
$active_income_report_rows = is_array($active_income_report['rows'] ?? null)
  ? $active_income_report['rows']
  : [];

$active_income_report_chart_payload = [
  'report_key' => $income_report_key,
  'rows' => $active_income_report_rows,
  'summary_amount' => (float)($active_income_report['summary_amount'] ?? 0),
  'labels_12m' => $income_last_12_month_labels,
  'series_12m' => [
    'bidding' => $income_report_key === 'farmer-share-12m' ? $income_last_12_farmer_by_month['bidding'] : $income_last_12_coop_by_month['bidding'],
    'livestock' => $income_report_key === 'farmer-share-12m' ? $income_last_12_farmer_by_month['livestock'] : $income_last_12_coop_by_month['livestock'],
    'machinery' => $income_report_key === 'farmer-share-12m' ? $income_last_12_farmer_by_month['machinery'] : $income_last_12_coop_by_month['machinery']
  ]
];

$active_income_report_chart_payload_json = json_encode($active_income_report_chart_payload, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
if ($active_income_report_chart_payload_json === false) {
  $active_income_report_chart_payload_json = '{}';
}

if ($schedule_table_exists) {
  $event_summary_stmt = $conn->prepare(
    "SELECT
        SUM(CASE WHEN activity_date = CURDATE() AND target_farmer = 1 THEN 1 ELSE 0 END) AS today_events,
        SUM(CASE WHEN activity_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND target_farmer = 1 THEN 1 ELSE 0 END) AS week_events,
        SUM(CASE WHEN activity_date >= CURDATE() AND target_farmer = 1 THEN 1 ELSE 0 END) AS upcoming_events
     FROM scheduled_activities"
  );
  if ($event_summary_stmt) {
    $event_summary_stmt->execute();
    $event_summary_result = $event_summary_stmt->get_result();
    if ($event_summary_result) {
      $event_summary_row = $event_summary_result->fetch_assoc();
      $today_event_count = (int)($event_summary_row['today_events'] ?? 0);
      $week_event_count = (int)($event_summary_row['week_events'] ?? 0);
      $upcoming_event_count = (int)($event_summary_row['upcoming_events'] ?? 0);
    }
    $event_summary_stmt->close();
  }

  $upcoming_event_stmt = $conn->prepare(
    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator
     FROM scheduled_activities
     WHERE target_farmer = 1
       AND activity_date >= CURDATE()
     ORDER BY activity_date ASC, activity_time ASC, activity_id ASC
     LIMIT 8"
  );
  if ($upcoming_event_stmt) {
    $upcoming_event_stmt->execute();
    $upcoming_event_result = $upcoming_event_stmt->get_result();
    if ($upcoming_event_result) {
      while ($event_row = $upcoming_event_result->fetch_assoc()) {
        $event_stamp = strtotime((string)($event_row['activity_date'] ?? '') . ' ' . (string)($event_row['activity_time'] ?? ''));
        $event_row['date_label'] = $event_stamp ? date('M d, Y', $event_stamp) : (string)($event_row['activity_date'] ?? '-');
        $event_row['time_label'] = $event_stamp ? date('h:i A', $event_stamp) : (string)($event_row['activity_time'] ?? '-');
        $upcoming_farmer_events[] = $event_row;
      }
    }
    $upcoming_event_stmt->close();
  }

  $recent_event_stmt = $conn->prepare(
    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator
     FROM scheduled_activities
     WHERE target_farmer = 1
       AND activity_date < CURDATE()
     ORDER BY activity_date DESC, activity_time DESC, activity_id DESC
     LIMIT 8"
  );
  if ($recent_event_stmt) {
    $recent_event_stmt->execute();
    $recent_event_result = $recent_event_stmt->get_result();
    if ($recent_event_result) {
      while ($event_row = $recent_event_result->fetch_assoc()) {
        $event_stamp = strtotime((string)($event_row['activity_date'] ?? '') . ' ' . (string)($event_row['activity_time'] ?? ''));
        $event_row['date_label'] = $event_stamp ? date('M d, Y', $event_stamp) : (string)($event_row['activity_date'] ?? '-');
        $event_row['time_label'] = $event_stamp ? date('h:i A', $event_stamp) : (string)($event_row['activity_time'] ?? '-');
        $recent_farmer_events[] = $event_row;
      }
    }
    $recent_event_stmt->close();
  }

  $recent_event_count = count($recent_farmer_events);

  $calendar_event_stmt = $conn->prepare(
    "SELECT activity_date, COUNT(*) AS total
     FROM scheduled_activities
     WHERE target_farmer = 1
       AND activity_date BETWEEN ? AND ?
     GROUP BY activity_date"
  );
  if ($calendar_event_stmt) {
    $calendar_event_stmt->bind_param('ss', $event_calendar_month_start, $event_calendar_month_end);
    $calendar_event_stmt->execute();
    $calendar_event_result = $calendar_event_stmt->get_result();
    if ($calendar_event_result) {
      while ($calendar_row = $calendar_event_result->fetch_assoc()) {
        $day_index = (int)date('j', strtotime((string)($calendar_row['activity_date'] ?? '')));
        $day_total = (int)($calendar_row['total'] ?? 0);
        if ($day_index >= 1 && $day_index <= $event_calendar_total_days) {
          $event_calendar_day_counts[$day_index] = $day_total;
        }
      }
    }
    $calendar_event_stmt->close();
  }

  $calendar_event_details_stmt = $conn->prepare(
    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator
     FROM scheduled_activities
     WHERE target_farmer = 1
       AND activity_date BETWEEN ? AND ?
     ORDER BY activity_date ASC, activity_time ASC, activity_id ASC"
  );
  if ($calendar_event_details_stmt) {
    $calendar_event_details_stmt->bind_param('ss', $event_calendar_month_start, $event_calendar_month_end);
    $calendar_event_details_stmt->execute();
    $calendar_event_details_result = $calendar_event_details_stmt->get_result();
    if ($calendar_event_details_result) {
      while ($event_row = $calendar_event_details_result->fetch_assoc()) {
        $event_date = (string)($event_row['activity_date'] ?? '');
        if ($event_date === '') {
          continue;
        }
        $event_stamp = strtotime($event_date . ' ' . (string)($event_row['activity_time'] ?? ''));
        $event_row['date_label'] = $event_stamp ? date('M d, Y', $event_stamp) : $event_date;
        $event_row['time_label'] = $event_stamp ? date('h:i A', $event_stamp) : (string)($event_row['activity_time'] ?? '-');
        if (!isset($event_calendar_events_by_date[$event_date])) {
          $event_calendar_events_by_date[$event_date] = [];
        }
        $event_calendar_events_by_date[$event_date][] = $event_row;
      }
    }
    $calendar_event_details_stmt->close();
  }
}

foreach ($event_calendar_day_counts as $calendar_count) {
  if ((int)$calendar_count > 0) {
    $event_calendar_days_with_events++;
    $event_calendar_total_events += (int)$calendar_count;
  }
}

if (!empty($upcoming_farmer_events)) {
  $first_upcoming = $upcoming_farmer_events[0];
  $next_farmer_event_label = trim(
    (string)($first_upcoming['date_label'] ?? '-')
    . ' '
    . (string)($first_upcoming['time_label'] ?? '')
  );
}

$month_start = date('Y-m-01 00:00:00');
$month_crop_records = 0;
$month_bids_received = 0;
$month_seed_distributions = 0;
$paid_sales_value = 0.0;
$month_paid_sales_value = 0.0;

if ($crops_table_exists && $farmer_id > 0) {
  $month_crop_stmt = $conn->prepare("SELECT COUNT(*) AS count FROM crops WHERE created_at >= ?");
  if ($month_crop_stmt) {
    $month_crop_stmt->bind_param('s', $month_start);
    $month_crop_stmt->execute();
    $month_crop_result = $month_crop_stmt->get_result();
    if ($month_crop_result) {
      $month_crop_records = (int)($month_crop_result->fetch_assoc()['count'] ?? 0);
    }
    $month_crop_stmt->close();
  }
}

if ($bids_table_exists && $farmer_id > 0) {
  $month_bids_stmt = $conn->prepare(
    "SELECT COUNT(*) AS count
     FROM bids b
     WHERE b.created_at >= ?"
  );
  if ($month_bids_stmt) {
    $month_bids_stmt->bind_param('s', $month_start);
    $month_bids_stmt->execute();
    $month_bids_result = $month_bids_stmt->get_result();
    if ($month_bids_result) {
      $month_bids_received = (int)($month_bids_result->fetch_assoc()['count'] ?? 0);
    }
    $month_bids_stmt->close();
  }
}

if ($seed_distribution_table_exists && $farmer_id > 0) {
  $month_seed_start = date('Y-m-01');
  $month_seed_stmt = $conn->prepare(
    "SELECT COUNT(*) AS count
     FROM seed_distributions
     WHERE distribution_date >= ?"
  );
  if ($month_seed_stmt) {
    $month_seed_stmt->bind_param('s', $month_seed_start);
    $month_seed_stmt->execute();
    $month_seed_result = $month_seed_stmt->get_result();
    if ($month_seed_result) {
      $month_seed_distributions = (int)($month_seed_result->fetch_assoc()['count'] ?? 0);
    }
    $month_seed_stmt->close();
  }
}

if ($crops_table_exists && $bids_table_exists && $farmer_id > 0) {
  $paid_condition = $crop_has_payment_status ? "AND c.payment_status = 'paid'" : '';
  $sales_date_field = $crop_has_payment_marked_at ? 'COALESCE(c.payment_marked_at, c.updated_at)' : 'c.updated_at';

  $paid_sales_query = "
    SELECT COALESCE(SUM(bmax.highest_bid), 0) AS paid_total
    FROM crops c
    LEFT JOIN (
      SELECT crop_id, MAX(bid_amount) AS highest_bid
      FROM bids
      GROUP BY crop_id
    ) bmax ON bmax.crop_id = c.crop_id
    WHERE c.crop_status = 'sold'
      " . $paid_condition;

  $paid_sales_stmt = $conn->prepare($paid_sales_query);
  if ($paid_sales_stmt) {
    $paid_sales_stmt->execute();
    $paid_sales_result = $paid_sales_stmt->get_result();
    if ($paid_sales_result) {
      $paid_sales_value = (float)($paid_sales_result->fetch_assoc()['paid_total'] ?? 0);
    }
    $paid_sales_stmt->close();
  }

  $month_paid_sales_query = "
    SELECT COALESCE(SUM(bmax.highest_bid), 0) AS paid_total
    FROM crops c
    LEFT JOIN (
      SELECT crop_id, MAX(bid_amount) AS highest_bid
      FROM bids
      GROUP BY crop_id
    ) bmax ON bmax.crop_id = c.crop_id
    WHERE c.crop_status = 'sold'
      " . $paid_condition . "
        AND " . $sales_date_field . " >= ?";
  $month_paid_sales_stmt = $conn->prepare($month_paid_sales_query);
  if ($month_paid_sales_stmt) {
    $month_paid_sales_stmt->bind_param('s', $month_start);
    $month_paid_sales_stmt->execute();
    $month_paid_sales_result = $month_paid_sales_stmt->get_result();
    if ($month_paid_sales_result) {
      $month_paid_sales_value = (float)($month_paid_sales_result->fetch_assoc()['paid_total'] ?? 0);
    }
    $month_paid_sales_stmt->close();
  }
}

$review_items = [];
if ($farmer_profile['verification_status'] === 'pending') {
  $review_items[] = [
    'item' => 'Account verification',
    'status' => 'Pending',
    'status_class' => 'pending',
    'action' => 'Wait for admin approval before engaging in paid transactions.'
  ];
} elseif ($farmer_profile['verification_status'] === 'rejected') {
  $review_items[] = [
    'item' => 'Account verification',
    'status' => 'Needs update',
    'status_class' => 'danger',
    'action' => 'Contact admin to resolve ID verification requirements.'
  ];
}

foreach ($crop_rows as $crop_row) {
  if (count($review_items) >= 6) {
    break;
  }

  $crop_id = (int)($crop_row['crop_id'] ?? 0);
  $crop_name = (string)($crop_row['crop_name'] ?? 'Crop');
  $crop_status = (string)($crop_row['crop_status'] ?? 'available');
  $is_listed = ((float)($crop_row['starting_price'] ?? 0) > 0);
  $end_ts = !empty($crop_row['bidding_end_date']) ? strtotime((string)$crop_row['bidding_end_date']) : false;
  $is_open = ($is_listed && $crop_status === 'available' && $end_ts && $end_ts > time());
  $hours_left = $end_ts ? (int)floor(($end_ts - time()) / 3600) : 0;
  $bid_info = $crop_bid_summary_map[$crop_id] ?? ['total_bids' => 0, 'active_bids' => 0, 'highest_bid' => 0];

  if (!$is_listed) {
    $review_items[] = [
      'item' => $crop_name,
      'status' => 'Draft',
      'status_class' => 'neutral',
      'action' => 'Update quantity as needed. Admin will handle bidding publication.'
    ];
  } elseif ($is_open && $hours_left <= 24) {
    $review_items[] = [
      'item' => $crop_name,
      'status' => 'Closing soon',
      'status_class' => 'pending',
      'action' => 'Monitor final bids and prepare for post-bidding coordination.'
    ];
  } elseif ($is_open && (int)$bid_info['active_bids'] === 0) {
    $review_items[] = [
      'item' => $crop_name,
      'status' => 'No bids yet',
      'status_class' => 'info',
      'action' => 'Promote this listing to attract clients.'
    ];
  } elseif ($crop_status === 'sold' && ((string)($crop_row['payment_status'] ?? 'unpaid')) !== 'paid') {
    $review_items[] = [
      'item' => $crop_name,
      'status' => 'Sold / unpaid',
      'status_class' => 'danger',
      'action' => 'Coordinate with admin for payment confirmation.'
    ];
  } elseif ($crop_status === 'expired') {
    $review_items[] = [
      'item' => $crop_name,
      'status' => 'Expired',
      'status_class' => 'neutral',
      'action' => 'Coordinate with admin if this crop should be relisted.'
    ];
  }
}

if (empty($review_items)) {
  $review_items[] = [
    'item' => 'All listings',
    'status' => 'Healthy',
    'status_class' => '',
    'action' => 'No urgent tasks. Keep crop records updated.'
  ];
}

$success_msg = $_SESSION['success'] ?? '';
$error_msg = $_SESSION['error'] ?? '';
if ($success_msg !== '') {
  unset($_SESSION['success']);
}
if ($error_msg !== '') {
  unset($_SESSION['error']);
}

$today = date('F j, Y');
$verification_status_text = ucfirst((string)($farmer_profile['verification_status'] ?? 'pending'));
$is_verified_farmer = ((int)($farmer_profile['is_verified'] ?? 0) === 1) && (($farmer_profile['verification_status'] ?? '') === 'approved');
$farmer_badge_text = $is_verified_farmer ? 'Verified Farmer' : ($verification_status_text . ' Verification');
$farmer_badge_class = $is_verified_farmer ? 'verified' : (($farmer_profile['verification_status'] ?? '') === 'rejected' ? 'rejected' : 'pending');
$verification_notes_text = trim((string)($farmer_profile['verification_notes'] ?? ''));
$verification_notes_text = $verification_notes_text !== ''
  ? $verification_notes_text
  : 'No additional admin notes yet. Please wait while your documents are reviewed.';

$verification_step1_state = ((string)($farmer_profile['id_type'] ?? '-')) !== '-' ? 'complete' : 'pending';
$verification_step2_state = ($farmer_profile['verification_status'] ?? '') === 'rejected'
  ? 'rejected'
  : ((($farmer_profile['verification_status'] ?? '') === 'pending') ? 'current' : 'complete');
$verification_step3_state = $is_verified_farmer ? 'complete' : 'pending';

$sold_paid_count = max(0, (int)$sold_crop_count - (int)$unpaid_sold_count);
?>
<!DOCTYPE html>
<html>
<head>
  <title>Smart Farm Farmer Dashboard</title>
  <link rel="stylesheet" type="text/css" href="../css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    html,
    body {
      overflow: hidden;
    }

    body.farmer {
      background: linear-gradient(135deg, #f5f5f5 0%, #e8f5e9 50%, #f0f7f3 100%);
    }

    body.farmer .admin-top-nav {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 50%, #41753e 100%);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.25);
    }

    body.farmer .admin-sidebar {
      background: linear-gradient(135deg, rgba(40, 167, 69, 0.08), rgba(40, 167, 69, 0.05));
      border-right: 2px solid rgba(40, 167, 69, 0.15);
      overflow: hidden;
    }

    body.farmer .admin-nav-scroll {
      overflow: visible;
    }

    body.farmer .nav-category,
    body.farmer .nav-item.active,
    body.farmer .nav-item:hover {
      color: #1b5a2a;
    }

    body.farmer .nav-item.active {
      background: rgba(40, 167, 69, 0.12);
      border-left-color: #1b5a2a;
    }

    .farmer-main {
      flex: 1;
      min-width: 0;
      padding: 2rem;
      overflow-y: auto;
      overflow-x: hidden;
      height: calc(100vh - 70px);
      max-height: calc(100vh - 70px);
    }

    body.farmer .admin-main {
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 70px);
    }

    .farmer-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .farmer-title h1 {
      font-size: 1.8rem;
      color: #1b5a2a;
      margin-bottom: 0.35rem;
    }

    .farmer-title p {
      color: #4b5563;
      font-size: 0.95rem;
    }

    .farmer-badge {
      background: #e8f5e9;
      color: #1b5a2a;
      border: 1px solid #cde9d3;
      padding: 0.4rem 0.8rem;
      border-radius: 999px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .farmer-badge.pending {
      background: #fff7e0;
      color: #a16207;
      border-color: #fde68a;
    }

    .farmer-badge.rejected {
      background: #fef2f2;
      color: #b91c1c;
      border-color: #fecaca;
    }

    .stat-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .stat-card {
      background: #fff;
      border-radius: 12px;
      padding: 1rem 1.25rem;
      box-shadow: 0 10px 30px rgba(27, 90, 42, 0.08);
      border: 1px solid rgba(40, 167, 69, 0.08);
    }

    .stat-card.clickable {
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
    }

    .stat-card.clickable:hover {
      transform: translateY(-2px);
      box-shadow: 0 14px 28px rgba(27, 90, 42, 0.12);
      border-color: rgba(40, 167, 69, 0.25);
    }

    .stat-card.clickable:focus {
      outline: 2px solid rgba(40, 167, 69, 0.45);
      outline-offset: 2px;
    }

    .stat-card h3 {
      font-size: 0.9rem;
      color: #4b5563;
      margin-bottom: 0.4rem;
    }

    .stat-card .stat-value {
      font-size: 1.6rem;
      color: #1b5a2a;
      font-weight: 700;
    }

    .stat-card .stat-note {
      font-size: 0.8rem;
      color: #6b7280;
      margin-top: 0.4rem;
    }

    .section-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }

    .panel {
      background: #fff;
      border-radius: 12px;
      padding: 1.25rem;
      box-shadow: 0 12px 30px rgba(27, 90, 42, 0.06);
      border: 1px solid rgba(40, 167, 69, 0.08);
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 1rem;
      flex-wrap: wrap;
      margin-bottom: 1.4rem;
      padding-bottom: 1rem;
      border-bottom: 2px solid #e0e0e0;
      overflow: visible;
      position: relative;
    }

    .section-header h1 {
      margin: 0;
      font-size: 2rem;
      color: #1b5a2a;
      font-weight: 600;
    }

    .catalog-view-back-btn {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      border: 1px solid #c7ded0;
      background: #ffffff;
      color: #1b5a2a;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
    }

    .catalog-view-back-btn:hover {
      background: #eef8f1;
      border-color: #b8dcc8;
      transform: translateY(-1px);
      text-decoration: none;
    }

    .catalog-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 0.85rem;
      align-items: start !important;
    }

    .catalog-card {
      border: 1px solid #cfe4d7;
      border-radius: 14px;
      background: #ffffff;
      padding: 0.85rem;
      display: grid;
      gap: 0.55rem;
      align-content: start;
      box-shadow: 0 8px 22px rgba(20, 84, 46, 0.08);
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
      width: 100%;
      max-width: 315px;
      justify-self: center;
      align-self: start !important;
      height: fit-content !important;
      min-height: unset !important;
    }

    .catalog-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 14px 28px rgba(20, 84, 46, 0.12);
      border-color: #a8d3bb;
    }

    .catalog-thumb {
      height: 88px;
      border-radius: 12px;
      background: linear-gradient(145deg, #e7f3ea 0%, #d8eadf 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #1f6b3c;
      font-size: 2rem;
    }

    .catalog-thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 12px;
      display: block;
    }

    .catalog-card h4 {
      color: #1b5a2a;
      font-size: 1rem;
      font-weight: 700;
      margin: 0;
      word-wrap: break-word;
      flex: 1;
      line-height: 1.3;
    }

    .catalog-header {
      display: flex;
      align-items: flex-start;
      gap: 0.55rem;
      justify-content: space-between;
    }

    .catalog-title-wrap {
      display: grid;
      gap: 0.15rem;
      min-width: 0;
      flex: 1;
    }

    .catalog-unit {
      color: #5b6f61;
      font-size: 0.74rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }

    .favorite-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1.3rem;
      color: #1b5a2a;
      padding: 0.25rem;
      transition: all 0.2s;
      flex-shrink: 0;
    }

    .favorite-btn:hover {
      transform: scale(1.2);
    }

    .catalog-chip {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      padding: 0.2rem 0.55rem;
      border-radius: 999px;
      font-size: 0.72rem;
      font-weight: 600;
      background: rgba(40, 167, 69, 0.14);
      color: #1b5a2a;
    }

    .catalog-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.6rem;
      color: #4f6f58;
      font-size: 0.82rem;
      line-height: 1.35;
    }

    .catalog-stock {
      border: 1px solid #b8dcc8;
      border-radius: 10px;
      background: #f7fcf9;
      padding: 0.45rem 0.6rem;
      text-align: center;
    }

    .catalog-stock-label {
      display: block;
      color: #567160;
      font-size: 0.74rem;
      font-weight: 700;
      letter-spacing: 0.03em;
      text-transform: uppercase;
    }

    .catalog-stock-value {
      display: block;
      color: #14532d;
      font-size: 1.02rem;
      font-weight: 800;
      margin-top: 0.2rem;
      line-height: 1.15;
    }

    .catalog-actions {
      display: grid;
      grid-template-columns: 44px 1fr;
      align-items: center;
      gap: 0.45rem;
      width: 100%;
    }

    .catalog-view-btn {
      width: 44px;
      min-width: 44px;
      height: 36px;
      border-radius: 10px;
      border: 1px solid #9ecfb0;
      background: #ffffff;
      color: #166534;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 0.95rem;
      text-decoration: none !important;
      transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
    }

    .catalog-view-btn:hover {
      background: #f2fbf5;
      border-color: #79ba95;
      transform: translateY(-1px);
      text-decoration: none !important;
    }

    .catalog-view-btn:focus,
    .catalog-view-btn:active,
    .catalog-view-btn:visited {
      text-decoration: none !important;
    }

    .catalog-view-btn i {
      text-decoration: none !important;
    }

    .catalog-add-btn {
      border: none;
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #fff;
      padding: 0.45rem 0.9rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.2);
      font-size: 0.8rem;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.4rem;
      min-height: 36px;
      text-decoration: none !important;
    }

    .catalog-add-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.3);
    }

    .catalog-add-btn:active {
      transform: translateY(0);
    }

    #section-rentals .catalog-card {
      min-height: 0;
    }

    #section-rentals .section-header h1 {
      color: #1b5a2a;
      font-size: 2rem;
      font-weight: 600;
      margin: 0;
    }

    #section-rentals .seed-filter-toolbar {
      display: flex;
      gap: 1rem;
      margin: 0 0 1rem 0;
      width: 100%;
      box-sizing: border-box;
      align-items: stretch;
    }

    #section-rentals .seed-filter-toolbar .filter-input {
      flex: 1 1 auto;
      min-width: 0;
      width: 100%;
    }

    #section-rentals .seed-filter-toolbar .filter-select {
      flex: 0 0 320px;
      max-width: 320px;
      width: 100%;
    }

    @media (max-width: 1100px) {
      #section-rentals .seed-filter-toolbar {
        flex-direction: column;
        gap: 0.8rem;
      }

      #section-rentals .seed-filter-toolbar .filter-select {
        flex: 1 1 auto;
        max-width: none;
      }
    }

    .machinery-card {
      height: 380px;
      display: flex;
      flex-direction: column;
    }

    .panel h2 {
      font-size: 1.1rem;
      color: #1b5a2a;
      margin-bottom: 0.8rem;
    }

    .panel p {
      color: #4b5563;
      font-size: 0.9rem;
      line-height: 1.6;
    }

    .quick-actions {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 0.75rem;
      margin-top: 1rem;
    }

    .quick-action {
      border: 1px solid rgba(40, 167, 69, 0.2);
      border-radius: 10px;
      padding: 0.85rem;
      color: #1b5a2a;
      display: flex;
      align-items: center;
      gap: 0.6rem;
      font-weight: 600;
      cursor: pointer;
      background: #f0f7f3;
      text-align: left;
      width: 100%;
      font-size: 0.98rem;
      font-family: Arial, sans-serif;
    }

    .quick-action i {
      font-size: 1.1rem;
    }

    .quick-action:hover {
      background: #e8f5e9;
      border-color: rgba(40, 167, 69, 0.35);
    }

    .report-kpi-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 0.9rem;
      margin-top: 1rem;
      margin-bottom: 1rem;
    }

    .report-kpi {
      border: 1px solid rgba(40, 167, 69, 0.15);
      border-radius: 10px;
      padding: 0.85rem;
      background: #f8fcf9;
    }

    .report-kpi.report-kpi-clickable {
      width: 100%;
      text-align: left;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease;
    }

    .report-kpi.report-kpi-clickable:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(27, 90, 42, 0.1);
      border-color: rgba(40, 167, 69, 0.28);
      background: #f2fbf4;
    }

    .report-kpi.report-kpi-clickable.active {
      border-color: rgba(21, 128, 61, 0.45);
      background: #ecfdf3;
      box-shadow: 0 10px 22px rgba(21, 128, 61, 0.12);
    }

    .report-kpi.report-kpi-clickable:focus {
      outline: 2px solid rgba(40, 167, 69, 0.4);
      outline-offset: 2px;
    }

    .report-kpi.report-kpi-clickable {
      width: 100%;
      text-align: left;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease, background 0.2s ease;
    }

    .report-kpi.report-kpi-clickable:hover {
      transform: translateY(-2px);
      box-shadow: 0 8px 20px rgba(27, 90, 42, 0.1);
      border-color: rgba(40, 167, 69, 0.28);
      background: #f2fbf4;
    }

    .report-kpi-label {
      color: #4b5563;
      font-size: 0.8rem;
      font-weight: 600;
      margin-bottom: 0.35rem;
    }

    .report-kpi-value {
      color: #14532d;
      font-size: 1.25rem;
      font-weight: 700;
    }

    .report-columns {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-top: 1rem;
    }

    .income-report-view {
      border: 1px solid rgba(40, 167, 69, 0.16);
      border-radius: 10px;
      background: #f9fdfb;
      padding: 0.9rem;
    }

    .income-report-layout {
      margin-top: 0.6rem;
      display: grid;
      grid-template-columns: minmax(320px, 1fr) minmax(420px, 1.35fr);
      gap: 0.85rem;
      align-items: stretch;
    }

    .income-report-right {
      display: grid;
      gap: 0.85rem;
      align-content: start;
    }

    #section-income-transparency-report .report-kpi-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      margin: 0;
    }

    #section-income-transparency-report .income-report-right .report-kpi-grid {
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 0.55rem;
    }

    #section-income-transparency-report .income-report-right .report-kpi {
      padding: 0.62rem !important;
      border-radius: 8px;
    }

    #section-income-transparency-report .income-report-right .report-kpi-label {
      font-size: 0.72rem;
      line-height: 1.2;
      margin-bottom: 0.2rem;
    }

    #section-income-transparency-report .income-report-right .report-kpi-value {
      font-size: 0.95rem;
      line-height: 1.15;
    }

    .income-graph-card {
      border: 1px solid rgba(40, 167, 69, 0.16);
      border-radius: 10px;
      background: #f9fdfb;
      padding: 0.9rem;
      display: flex;
      flex-direction: column;
      min-height: 340px;
    }

    .income-graph-card h3 {
      margin: 0;
      color: #14532d;
      font-size: 1rem;
      font-weight: 700;
    }

    .income-graph-note {
      margin: 0.3rem 0 0.7rem;
      color: #5b6b5b;
      font-size: 0.84rem;
    }

    .income-graph-canvas-wrap {
      position: relative;
      width: 100%;
      flex: 1;
      min-height: 260px;
      border: 1px solid rgba(40, 167, 69, 0.14);
      border-radius: 9px;
      background: #ffffff;
      padding: 0.5rem;
    }

    .income-graph-canvas {
      width: 100%;
      height: 100%;
      display: block;
    }

    .income-graph-empty {
      color: #6b7280;
      font-size: 0.85rem;
      padding: 0.6rem;
      text-align: center;
    }

    .income-report-head {
      margin-bottom: 0.7rem;
    }

    .income-report-head h3 {
      margin: 0;
      color: #14532d;
      font-size: 1rem;
      font-weight: 700;
    }

    .income-report-head p {
      margin: 0.3rem 0 0;
      color: #5b6b5b;
      font-size: 0.84rem;
    }

    .income-report-summary {
      margin-top: 0.7rem;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      gap: 0.6rem;
      font-size: 0.88rem;
      color: #374151;
    }

    .income-report-summary strong {
      color: #14532d;
      font-size: 0.95rem;
    }

    .panel-header-flex {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      flex-wrap: wrap;
      margin-bottom: 1rem;
    }

    .filter-controls {
      display: flex;
      align-items: center;
      gap: 0.6rem;
      flex-wrap: wrap;
    }

    .filter-select,
    .filter-input {
      padding: 0.5rem 0.75rem;
      border: 1px solid #d1e7d8;
      border-radius: 8px;
      background: #fff;
      color: #1b5a2a;
      font-size: 0.9rem;
    }

    .action-btn {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      padding: 0.6rem 1rem;
      border-radius: 8px;
      border: none;
      background: #28a745;
      color: #fff;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .action-btn.secondary {
      background: #e8f5e9;
      color: #1b5a2a;
      border: 1px solid #cde9d3;
    }

    .action-btn.small {
      padding: 0.4rem 0.75rem;
      font-size: 0.85rem;
    }

    .farmer-alert {
      padding: 0.85rem 1rem;
      border-radius: 10px;
      margin-bottom: 1rem;
      font-size: 0.92rem;
      font-weight: 600;
      border: 1px solid #cde9d3;
      background: #ecfdf3;
      color: #166534;
    }

    .farmer-alert.error {
      background: #fef2f2;
      border-color: #fecaca;
      color: #b91c1c;
    }

    .crop-form-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 1rem;
      margin-top: 1rem;
    }

    .crop-form-field {
      display: flex;
      flex-direction: column;
      gap: 0.45rem;
      color: #4b5563;
      font-size: 0.9rem;
      font-weight: 600;
    }

    .crop-form-field input,
    .crop-form-field select,
    .crop-form-field textarea {
      padding: 0.7rem 0.85rem;
      border: 1px solid #d1e7d8;
      border-radius: 8px;
      background: #fff;
      color: #1b5a2a;
      font-size: 0.95rem;
      font-family: Arial, sans-serif;
    }

    .crop-form-field textarea {
      min-height: 110px;
      resize: vertical;
    }

    .crop-helper {
      margin-top: 0.85rem;
      color: #6b7280;
      font-size: 0.9rem;
    }

    .table-muted {
      color: #6b7280;
    }

    .quick-card-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .quick-card {
      background: #fff;
      border-radius: 12px;
      padding: 1rem 1.1rem;
      border: 1px solid rgba(40, 167, 69, 0.12);
      box-shadow: 0 10px 26px rgba(27, 90, 42, 0.08);
      display: flex;
      align-items: center;
      gap: 0.9rem;
      cursor: pointer;
    }

    .quick-card-icon {
      width: 44px;
      height: 44px;
      border-radius: 10px;
      background: rgba(40, 167, 69, 0.12);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #1b5a2a;
      font-size: 1.2rem;
      flex-shrink: 0;
    }

    .quick-card-title {
      font-size: 0.8rem;
      color: #6b7280;
      font-weight: 600;
    }

    .quick-card-value {
      font-size: 1.05rem;
      color: #1b5a2a;
      font-weight: 700;
    }

    .overview-focus {
      display: grid;
      grid-template-columns: 1fr;
      gap: 1rem;
      margin-bottom: 1rem;
    }

    .focus-hero {
      border-radius: 14px;
      border: 1px solid #c9e7d2;
      background:
        radial-gradient(circle at 85% 20%, rgba(35, 143, 72, 0.18), transparent 42%),
        linear-gradient(145deg, #eef9f1 0%, #f9fdf9 100%);
      padding: 1rem 1.05rem;
      box-shadow: 0 8px 24px rgba(22, 101, 52, 0.08);
    }

    .focus-label {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      border-radius: 999px;
      padding: 0.25rem 0.6rem;
      font-size: 0.74rem;
      font-weight: 700;
      letter-spacing: 0.02em;
      color: #166534;
      background: #dcfce7;
      border: 1px solid #b7e8c6;
      margin-bottom: 0.5rem;
    }

    .focus-title {
      margin: 0;
      color: #14532d;
      font-size: 1.12rem;
      line-height: 1.25;
    }

    .focus-sub {
      margin: 0.45rem 0 0;
      color: #466451;
      font-size: 0.9rem;
      line-height: 1.45;
    }

    .focus-mini {
      border-radius: 14px;
      border: 1px solid #d4e9da;
      background: #ffffff;
      padding: 0.95rem 1rem;
      display: grid;
      gap: 0.5rem;
      align-content: center;
    }

    .focus-mini-label {
      color: #6b7280;
      font-size: 0.78rem;
      text-transform: uppercase;
      letter-spacing: 0.03em;
      font-weight: 700;
    }

    .focus-mini-value {
      color: #14532d;
      font-size: 1.5rem;
      font-weight: 800;
      line-height: 1;
    }

    .focus-mini-note {
      color: #466451;
      font-size: 0.84rem;
      line-height: 1.35;
    }

    .event-stream {
      display: grid;
      gap: 0.6rem;
      margin-top: 0.55rem;
    }

    .event-item {
      border: 1px solid #d9eadf;
      border-radius: 11px;
      background: #fcfefc;
      padding: 0.7rem 0.75rem;
      display: grid;
      grid-template-columns: 1.25fr 0.9fr 0.9fr;
      gap: 0.65rem;
      align-items: center;
    }

    .event-item-title {
      color: #14532d;
      font-size: 0.92rem;
      font-weight: 700;
      line-height: 1.3;
      margin: 0;
    }

    .event-item-meta {
      color: #6b7280;
      font-size: 0.78rem;
      margin-top: 0.2rem;
    }

    .event-cell {
      color: #2f4f3a;
      font-size: 0.84rem;
      line-height: 1.35;
    }

    .event-empty {
      border: 1px dashed #c9ddd1;
      border-radius: 11px;
      background: #f8fcf9;
      color: #607769;
      font-size: 0.88rem;
      padding: 0.9rem;
      text-align: center;
    }

    #section-events .panel {
      background: transparent;
      border: none;
      box-shadow: none;
      padding: 0;
    }

    .events-calendar-shell {
      display: grid;
      grid-template-columns: 1fr 280px;
      gap: 1.5rem;
      margin-bottom: 1rem;
    }

    .events-sidebar-wrapper {
      display: flex;
      flex-direction: column;
      gap: 1rem;
      border: 1px solid #d5e8dc;
      border-radius: 12px;
      background: #ffffff;
      padding: 1rem;
      height: fit-content;
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.08);
    }

    .events-calendar-card {
      border: 1px solid #d5e8dc;
      border-radius: 12px;
      background: #ffffff;
      padding: 1.2rem;
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.08);
    }

    .events-calendar-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      margin-bottom: 1.2rem;
    }

    .events-calendar-head h3 {
      margin: 0;
      color: #1b5a2a;
      font-size: 1rem;
      font-weight: 600;
    }

    .calendar-nav-btn {
      width: 36px;
      height: 36px;
      border-radius: 6px;
      border: 1px solid #d1d5db;
      background: #ffffff;
      color: #4b5563;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      font-size: 0.95rem;
      transition: background 0.2s ease, border-color 0.2s ease;
    }

    .calendar-nav-btn:hover {
      background: #f3f4f6;
      border-color: #9ca3af;
    }

    .events-calendar-month {
      color: #4b5563;
      font-size: 0.8rem;
      font-weight: 700;
      background: #f3faf5;
      border: 1px solid #d4e9da;
      border-radius: 999px;
      padding: 0.2rem 0.55rem;
    }

    .events-calendar-grid {
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 0.5rem;
      margin-top: 1rem;
    }

    .calendar-weekday {
      text-align: center;
      font-size: 0.75rem;
      font-weight: 700;
      color: #4b5563;
      padding: 0.5rem 0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .calendar-day {
      min-height: 55px;
      border-radius: 8px;
      border: 1px solid #e0e7e2;
      background: #ffffff;
      padding: 0.4rem 0.35rem;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      align-items: center;
      gap: 0.3rem;
      cursor: pointer;
      transition: background 0.2s ease, border-color 0.2s ease;
    }

    .calendar-day.blank {
      border: none;
      background: transparent;
      cursor: default;
    }

    .calendar-day.today {
      border-color: #3b82f6;
      background: #eff6ff;
    }

    .calendar-day.has-event {
      cursor: pointer;
      border-color: #d1f2e8;
      background: #f0faf8;
    }

    .calendar-day.has-event:hover {
      background: #e8f4ed;
      border-color: #4ade80;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.15);
    }

    .calendar-day.is-selected {
      border-color: #3b82f6;
      background: #e8f0ff;
      box-shadow: inset 0 0 0 1px #3b82f6;
    }

    .calendar-day-number {
      color: #1f2937;
      font-size: 0.95rem;
      font-weight: 700;
      line-height: 1;
    }

    .calendar-day-count {
      align-self: center;
      font-size: 0.6rem;
      font-weight: 700;
      color: #ffffff;
      background: #16a34a;
      border: none;
      border-radius: 999px;
      padding: 0.2rem 0.4rem;
      line-height: 1;
      margin-top: 0.2rem;
    }

    .calendar-day.today::before {
      content: '';
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: #3b82f6;
      margin-top: 0.2rem;
    }

    .calendar-day.has-event::before {
      content: '';
      width: 5px;
      height: 5px;
      border-radius: 50%;
      background: #16a34a;
      margin-top: 0.2rem;
    }

    .events-calendar-side {
      border: 1px solid #d5e8dc;
      border-radius: 12px;
      background: #fcfefc;
      padding: 1rem;
      height: fit-content;
    }

    .events-quick-filter {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 0.75rem;
    }

    .events-calendar-side h3 {
      margin: 0 0 0.5rem 0;
      color: #1b5a2a;
      font-size: 0.98rem;
      font-weight: 600;
    }

    .events-calendar-side p {
      margin: 0 0 0.75rem 0;
      color: #4d6357;
      font-size: 0.85rem;
      line-height: 1.4;
    }

    .events-snapshot-list {
      display: grid;
      gap: 0.45rem;
      margin-top: 0.2rem;
    }

    .events-snapshot-item {
      border: 1px solid #dbece1;
      background: #ffffff;
      border-radius: 9px;
      padding: 0.5rem 0.58rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.6rem;
    }

    .events-day-detail-item {
      border: 1px solid #dbece1;
      background: #ffffff;
      border-radius: 9px;
      padding: 0.65rem 0.7rem;
      display: grid;
      gap: 0.35rem;
    }

    .events-day-detail-title {
      color: #14532d;
      font-size: 0.9rem;
      font-weight: 700;
      line-height: 1.3;
    }

    .events-day-detail-row {
      display: flex;
      justify-content: space-between;
      gap: 0.55rem;
      color: #4d6357;
      font-size: 0.8rem;
    }

    .events-day-empty {
      border: 1px solid #dbece1;
      background: #ffffff;
      border-radius: 9px;
      padding: 0.75rem;
      color: #4d6357;
      font-size: 0.85rem;
    }

    .events-snapshot-item strong {
      color: #14532d;
      font-size: 0.82rem;
      font-weight: 700;
    }

    .events-snapshot-item span {
      color: #1f6b3c;
      font-size: 0.84rem;
      font-weight: 800;
      white-space: nowrap;
    }

    #section-crops .section-tools {
      display: flex;
      justify-content: flex-start;
      margin-bottom: 1rem;
    }

    #section-crops .crop-filter-toolbar {
      display: grid;
      grid-template-columns: 2.6fr 1fr;
      gap: 0.7rem;
      width: min(760px, 100%);
    }

    #section-crops .filter-input,
    #section-crops .filter-select {
      width: 100%;
      height: 42px;
      border: 1px solid #d3dfd6;
      border-radius: 8px;
      padding: 0 0.7rem;
      font-size: 0.9rem;
      color: #35543d;
      background: #fff;
    }

    #section-update-crop-quantity .panel {
      max-width: 800px;
    }

    .crop-update-shell {
      border: 1px solid #d9eadf;
      border-radius: 12px;
      background: linear-gradient(180deg, #f9fcfa 0%, #ffffff 100%);
      padding: 1rem;
    }

    .crop-update-meta {
      border: 1px solid #e1eee6;
      border-radius: 10px;
      background: #f8fcf9;
      padding: 0;
      margin-bottom: 0.9rem;
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 0.7rem;
    }

    .crop-update-meta-item {
      border: 1px solid #e4efe8;
      border-radius: 9px;
      background: #ffffff;
      padding: 0.65rem 0.7rem;
    }

    .crop-update-meta-label {
      display: block;
      color: #6b7280;
      font-size: 0.8rem;
      margin-bottom: 0.2rem;
    }

    .crop-update-meta-value {
      color: #14532d;
      font-size: 1.02rem;
      font-weight: 700;
      line-height: 1.25;
    }

    .crop-update-form {
      display: grid;
      gap: 0.75rem;
      max-width: 460px;
      padding-top: 0.2rem;
    }

    .crop-update-field {
      display: grid;
      gap: 0.4rem;
    }

    .crop-update-field label {
      color: #35543d;
      font-size: 0.9rem;
      font-weight: 600;
    }

    .crop-update-field input {
      width: 100%;
      height: 42px;
      border: 1px solid #c8d9cc;
      border-radius: 9px;
      padding: 0 0.75rem;
      font-size: 0.95rem;
      color: #14532d;
      background: #fff;
      outline: none;
    }

    .crop-update-field input:focus {
      border-color: #28a745;
      box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }

    .crop-update-actions {
      display: flex;
      gap: 0.55rem;
      flex-wrap: wrap;
      align-items: center;
    }

    .farmer-section {
      display: none;
    }

    .farmer-section.active {
      display: block;
    }

    .table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 0.75rem;
      font-size: 0.9rem;
    }

    .table th,
    .table td {
      text-align: left;
      padding: 0.75rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .pill {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      padding: 0.2rem 0.6rem;
      border-radius: 999px;
      font-size: 0.78rem;
      font-weight: 600;
      background: #ecfdf3;
      color: #15803d;
    }

    .pill.pending {
      background: #fef9c3;
      color: #a16207;
    }

    .pill.info {
      background: #dbeafe;
      color: #1d4ed8;
    }

    .pill.danger {
      background: #fee2e2;
      color: #b91c1c;
    }

    .pill.neutral {
      background: #f3f4f6;
      color: #4b5563;
    }

    .back-title-row {
      display: flex;
      align-items: center;
      gap: 0.8rem;
    }

    .crop-back-btn {
      width: 36px;
      height: 36px;
      border-radius: 8px;
      border: 1px solid #d5e8dc;
      background: #f8fcf9;
      color: #14532d;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      box-shadow: 0 4px 10px rgba(20, 84, 46, 0.08);
      transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
    }

    .crop-back-btn:hover {
      background: #eef8f1;
      border-color: #b8dcc8;
      transform: translateY(-1px);
    }

    #section-seed-request-catalog .seed-filter-toolbar {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(220px, 280px);
      gap: 0.7rem;
      margin-bottom: 1rem;
      width: 100%;
      max-width: none;
      box-sizing: border-box;
      align-items: stretch;
    }

    #section-seed-request-catalog .seed-filter-toolbar .filter-input,
    #section-seed-request-catalog .seed-filter-toolbar .filter-select {
      width: 100%;
      min-width: 0;
      max-width: none;
      display: block;
    }

    #section-seed-request-catalog .seed-store-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 0.85rem;
    }

    #section-seed-request-catalog .seed-store-card {
      border: 1px solid #cfe4d7;
      border-radius: 14px;
      background: #ffffff;
      padding: 1rem;
      display: grid;
      gap: 0.7rem;
      box-shadow: 0 8px 22px rgba(20, 84, 46, 0.08);
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
      width: 100%;
      max-width: 315px;
      justify-self: center;
    }

    #section-seed-request-catalog .seed-store-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 14px 28px rgba(20, 84, 46, 0.12);
      border-color: #a8d3bb;
    }

    #section-seed-request-catalog .seed-store-thumb {
      height: 96px;
      border-radius: 12px;
      background: linear-gradient(145deg, #e7f3ea 0%, #d8eadf 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #1f6b3c;
      font-size: 2rem;
    }

    #section-seed-request-catalog .seed-store-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.55rem;
    }

    #section-seed-request-catalog .seed-store-title {
      color: #14532d;
      font-size: 1rem;
      font-weight: 700;
      line-height: 1.3;
    }

    #section-seed-request-catalog .seed-store-unit {
      color: #5b6f61;
      font-size: 0.8rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }

    #section-seed-request-catalog .seed-store-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.6rem;
      color: #4f6f58;
      font-size: 0.82rem;
      line-height: 1.35;
    }

    #section-seed-request-catalog .seed-store-chip {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      border-radius: 999px;
      padding: 0.24rem 0.58rem;
      background: #e8f5ec;
      color: #166534;
      font-size: 0.78rem;
      font-weight: 700;
      white-space: nowrap;
    }

    #section-seed-request-catalog .seed-store-stock {
      border: 1px solid #b8dcc8;
      border-radius: 10px;
      background: #f7fcf9;
      padding: 0.55rem 0.65rem;
      text-align: center;
    }

    #section-seed-request-catalog .seed-store-stock-label {
      display: block;
      color: #567160;
      font-size: 0.74rem;
      font-weight: 700;
      letter-spacing: 0.03em;
      text-transform: uppercase;
    }

    #section-seed-request-catalog .seed-store-stock-value {
      display: block;
      color: #14532d;
      font-size: 1.05rem;
      font-weight: 800;
      margin-top: 0.2rem;
      line-height: 1.15;
    }

    #section-seed-request-catalog .seed-store-request-btn {
      width: 100%;
      justify-content: center;
      background: linear-gradient(135deg, #1b7a3a 0%, #1fa547 100%);
      color: #ffffff;
      border: 1px solid #17883a;
      box-shadow: 0 6px 14px rgba(26, 122, 57, 0.22);
    }

    #section-seed-request-catalog .seed-store-actions {
      display: grid;
      grid-template-columns: 44px 1fr;
      gap: 0.55rem;
      align-items: center;
    }

    #section-seed-request-catalog .seed-store-view-btn {
      width: 44px;
      min-width: 44px;
      height: 38px;
      border-radius: 10px;
      border: 1px solid #9ecfb0;
      background: #ffffff;
      color: #166534;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 0.95rem;
      text-decoration: none;
      transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
    }

    #section-seed-request-catalog .seed-store-view-btn:hover {
      background: #f2fbf5;
      border-color: #79ba95;
      transform: translateY(-1px);
      text-decoration: none;
    }

    #section-seed-request-catalog .seed-store-view-btn:focus,
    #section-seed-request-catalog .seed-store-view-btn:active {
      text-decoration: none;
    }

    #section-seed-request-view .section-header {
      align-items: center;
    }

    #section-seed-request-view .seed-view-title-wrap {
      display: flex;
      align-items: center;
      gap: 0.65rem;
    }

    #section-seed-request-view .seed-view-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 0.9rem;
    }

    #section-seed-request-view .seed-view-item {
      border: 1px solid #d5e8dc;
      border-radius: 10px;
      padding: 0.8rem 0.85rem;
      background: #f9fcfa;
    }

    #section-seed-request-view .seed-view-label {
      display: block;
      color: #6a7b6d;
      font-size: 0.82rem;
      margin-bottom: 0.3rem;
    }

    #section-seed-request-view .seed-view-value {
      color: #14532d;
      font-size: 1.05rem;
      font-weight: 700;
      line-height: 1.3;
    }

    #section-seed-request-view .seed-view-actions {
      display: flex;
      gap: 0.55rem;
      flex-wrap: wrap;
      margin-top: 1rem;
    }

    #section-seed-requests .panel-header-flex {
      display: block;
    }

    #section-seed-requests .panel-header-flex > div {
      width: 100%;
    }

    #section-seed-requests .section-header {
      align-items: flex-end;
      margin-bottom: 0.55rem;
    }

    #section-seed-requests .filter-bar {
      display: flex;
      gap: 0.7rem;
      margin-bottom: 1.2rem;
      align-items: center;
      flex-wrap: wrap;
    }

    #section-seed-requests .search-input,
    #section-seed-requests .filter-select {
      height: 42px;
      border: 1px solid #d3dfd6;
      border-radius: 8px;
      padding: 0 0.7rem;
      font-size: 0.9rem;
      color: #35543d;
      background: #fff;
    }

    #section-seed-requests .search-input {
      flex: 1;
      min-width: 250px;
    }

    #section-seed-requests .filter-select {
      min-width: 160px;
    }

    #section-crops .section-tools {
      display: flex;
      gap: 0.7rem;
      margin-bottom: 1.2rem;
      align-items: center;
      flex-wrap: wrap;
    }

    #section-crops .crop-filter-toolbar {
      display: flex;
      gap: 0.7rem;
      align-items: center;
      flex-wrap: wrap;
      width: 100%;
    }

    #section-crops .filter-input,
    #section-crops .filter-select {
      height: 42px;
      border: 1px solid #d3dfd6;
      border-radius: 8px;
      padding: 0 0.7rem;
      font-size: 0.9rem;
      color: #35543d;
      background: #fff;
    }

    #section-crops .filter-input {
      flex: 1;
      min-width: 250px;
    }

    #section-crops .filter-select {
      min-width: 160px;
    }

    #section-seed-requests .table-container {
      width: 100%;
      overflow-x: auto;
      border-radius: 8px;
      border: 1px solid #e0e0e0;
    }

    #section-seed-requests .data-table {
      width: 100%;
      border-collapse: collapse;
      background: #fff;
    }

    #section-seed-requests .data-table thead {
      background: #f5f5f5;
      border-bottom: 2px solid #e0e0e0;
    }

    #section-seed-requests .data-table th {
      padding: 0.9rem 0.85rem;
      text-align: left;
      font-weight: 600;
      color: #374151;
      font-size: 0.9rem;
    }

    #section-seed-requests .data-table td {
      padding: 0.85rem;
      border-bottom: 1px solid #f0f0f0;
      color: #4b5563;
      font-size: 0.9rem;
    }

    #section-seed-requests .data-table tbody tr:hover {
      background: #f9f9f9;
    }

    #section-seed-requests .status {
      display: inline-block;
      padding: 0.35rem 0.65rem;
      border-radius: 999px;
      font-size: 0.8rem;
      font-weight: 600;
      white-space: nowrap;
    }

    #section-seed-requests .status.pending {
      background-color: #fef3c7;
      color: #92400e;
    }

    #section-seed-requests .status.confirmed {
      background-color: #d1fae5;
      color: #065f46;
    }

    #section-seed-requests .status.completed {
      background-color: #dcfce7;
      color: #166534;
    }

    #section-seed-requests .status.cancelled {
      background-color: #fee2e2;
      color: #991b1b;
    }

    #section-seed-requests .seed-catalog-card {
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    #section-seed-requests .seed-catalog-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 6px 16px rgba(27, 90, 42, 0.12);
    }

    #section-seed-requests .filter-input {
      width: 100%;
      height: 42px;
      border: 1px solid #d3dfd6;
      border-radius: 8px;
      padding: 0 0.7rem;
      font-size: 0.9rem;
      color: #35543d;
      background: #fff;
    }

    .profile-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .profile-item {
      background: #f8fafc;
      border-radius: 10px;
      padding: 0.9rem;
      border: 1px solid #e2e8f0;
    }

    .profile-item span {
      display: block;
      color: #64748b;
      font-size: 0.8rem;
      margin-bottom: 0.35rem;
    }

    .profile-item strong {
      color: #1b5a2a;
      font-size: 0.95rem;
    }

    .sidebar-pending-card {
      background: linear-gradient(150deg, #f0f8f3 0%, #e0f0e6 100%);
      border: 1px solid #c7e3d1;
      border-radius: 12px;
      padding: 0.85rem;
      margin-bottom: 0.75rem;
    }

    .sidebar-pending-title {
      display: flex;
      align-items: center;
      gap: 0.45rem;
      color: #14532d;
      font-weight: 700;
      font-size: 0.9rem;
      margin-bottom: 0.35rem;
    }

    .sidebar-pending-title i {
      color: #15803d;
    }

    .sidebar-pending-text {
      color: #3f5f49;
      font-size: 0.82rem;
      line-height: 1.4;
      margin-bottom: 0.65rem;
    }

    .sidebar-pending-btn {
      width: 100%;
      border: 1px solid #9ecfb0;
      background: #ffffff;
      color: #14532d;
      border-radius: 8px;
      padding: 0.45rem 0.6rem;
      font-size: 0.82rem;
      font-weight: 700;
      cursor: pointer;
    }

    .sidebar-pending-btn:hover {
      background: #f3faf5;
    }

    .restricted-nav-stack {
      position: relative;
      margin-bottom: 0.7rem;
      min-height: 160px;
    }

    .restricted-nav-stack .nav-item {
      opacity: 0.5;
      pointer-events: none;
      filter: saturate(0.7);
    }

    .restricted-nav-overlay {
      position: absolute;
      top: 0.25rem;
      left: 0.8rem;
      right: 0.8rem;
      bottom: 0.25rem;
      border-radius: 10px;
      border: 1px dashed #9fcdb1;
      background: rgba(240, 248, 243, 0.9);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: 0.3rem;
      z-index: 2;
      text-align: center;
      color: #14532d;
      font-size: 0.82rem;
      font-weight: 700;
      backdrop-filter: blur(1px);
      padding: 0.55rem;
    }

    .restricted-nav-overlay i {
      color: #15803d;
      font-size: 1rem;
    }

    .restricted-nav-overlay small {
      color: #3f5f49;
      font-weight: 600;
      font-size: 0.74rem;
      line-height: 1.25;
    }

    .unverified-shell {
      margin-top: 1rem;
      display: grid;
      gap: 1rem;
    }

    .unverified-hero {
      display: flex;
      align-items: center;
      gap: 1rem;
      border-radius: 14px;
      padding: 1.05rem 1.15rem;
      border: 1px solid #b9e2c9;
      background:
        radial-gradient(circle at top right, rgba(40, 167, 69, 0.18), transparent 50%),
        linear-gradient(160deg, #ecf8ef 0%, #f8fcf9 100%);
    }

    .unverified-hero-icon {
      width: 54px;
      height: 54px;
      border-radius: 14px;
      background: linear-gradient(140deg, #1f7a3e, #2c9a54);
      color: #fff;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.4rem;
      flex-shrink: 0;
      box-shadow: 0 10px 24px rgba(27, 90, 42, 0.22);
    }

    .unverified-hero h3 {
      margin: 0;
      color: #14532d;
      font-size: 1.12rem;
      line-height: 1.2;
    }

    .unverified-hero p {
      margin: 0.2rem 0 0;
      color: #40614a;
      font-size: 0.9rem;
    }

    .unverified-chip {
      margin-left: auto;
      border-radius: 999px;
      padding: 0.38rem 0.9rem;
      font-size: 0.78rem;
      font-weight: 700;
      border: 1px solid transparent;
      white-space: nowrap;
    }

    .unverified-chip.pending {
      background: #fff6da;
      color: #9a6700;
      border-color: #f4d58f;
    }

    .unverified-chip.rejected {
      background: #fff0f0;
      color: #b42318;
      border-color: #f5b8b8;
    }

    .unverified-layout {
      display: grid;
      grid-template-columns: 1.5fr 1fr;
      gap: 1rem;
    }

    .unverified-card {
      background: #f9fbfa;
      border: 1px solid #dcebe1;
      border-radius: 12px;
      padding: 1rem;
    }

    .unverified-card h4 {
      margin: 0 0 0.75rem;
      color: #14532d;
      font-size: 1rem;
    }

    .verify-step-list {
      display: grid;
      gap: 0.7rem;
    }

    .verify-step {
      display: flex;
      align-items: flex-start;
      gap: 0.7rem;
      border-radius: 10px;
      padding: 0.75rem;
      border: 1px solid #d5e8dc;
      background: #ffffff;
    }

    .verify-step-icon {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 0.82rem;
      font-weight: 700;
      flex-shrink: 0;
      border: 1px solid #c8d7ce;
      color: #40614a;
      background: #f7faf8;
    }

    .verify-step-title {
      color: #174f30;
      font-weight: 700;
      font-size: 0.9rem;
      margin-bottom: 0.18rem;
    }

    .verify-step-desc {
      color: #4f6f58;
      font-size: 0.82rem;
      line-height: 1.35;
    }

    .verify-step.complete {
      border-color: #bde3c9;
      background: #f2fbf5;
    }

    .verify-step.complete .verify-step-icon {
      background: #15803d;
      border-color: #15803d;
      color: #fff;
    }

    .verify-step.current {
      border-color: #f1d28a;
      background: #fff9ea;
    }

    .verify-step.current .verify-step-icon {
      background: #b7791f;
      border-color: #b7791f;
      color: #fff;
    }

    .verify-step.rejected {
      border-color: #f3bbbb;
      background: #fff3f3;
    }

    .verify-step.rejected .verify-step-icon {
      background: #b42318;
      border-color: #b42318;
      color: #fff;
    }

    .unverified-note {
      margin-top: 0.8rem;
      border-radius: 10px;
      border: 1px dashed #c8ddd0;
      padding: 0.75rem;
      background: #ffffff;
      color: #3f5f49;
      font-size: 0.84rem;
      line-height: 1.35;
    }

    .unverified-note strong {
      display: block;
      margin-bottom: 0.25rem;
      color: #14532d;
      font-size: 0.86rem;
    }

    .unverified-mini-grid {
      display: grid;
      gap: 0.65rem;
    }

    .unverified-mini-item {
      border: 1px solid #d7e7de;
      border-radius: 10px;
      padding: 0.7rem 0.75rem;
      background: #ffffff;
    }

    .unverified-mini-label {
      display: block;
      color: #5e7b66;
      font-size: 0.76rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      margin-bottom: 0.25rem;
    }

    .unverified-mini-value {
      color: #14532d;
      font-size: 0.92rem;
      font-weight: 700;
      line-height: 1.3;
      word-break: break-word;
    }

    .unverified-actions {
      display: flex;
      gap: 0.55rem;
      flex-wrap: wrap;
      margin-top: 0.75rem;
    }

    @media (max-width: 1100px) {
      .unverified-layout {
        grid-template-columns: 1fr;
      }

      .unverified-chip {
        margin-left: 0;
      }

      .unverified-hero {
        flex-wrap: wrap;
      }
    }

    @media (max-width: 1100px) {
      .stat-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .overview-focus {
        grid-template-columns: 1fr;
      }

      .events-calendar-shell {
        grid-template-columns: 1fr;
      }

      .quick-card-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .section-grid {
        grid-template-columns: 1fr;
      }

      .report-kpi-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .report-columns {
        grid-template-columns: 1fr;
      }

      .income-report-layout {
        grid-template-columns: 1fr;
      }

      #section-income-transparency-report .report-kpi-grid {
        grid-template-columns: 1fr;
      }

      #section-income-transparency-report .income-report-right .report-kpi-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      #section-seed-requests .seed-store-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.75rem;
      }

      #section-seed-requests .seed-filter-toolbar {
        grid-template-columns: 1fr;
      }

      #section-seed-request-catalog .seed-store-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.75rem;
      }

      #section-seed-request-catalog .seed-filter-toolbar {
        grid-template-columns: 1fr;
      }

      #section-crops .crop-filter-toolbar {
        flex-direction: column;
        align-items: stretch;
      }

      #section-seed-requests .seed-header-top {
        flex-wrap: wrap;
      }

      .event-item {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 720px) {
      .quick-card-grid {
        grid-template-columns: 1fr;
      }

      .stat-grid {
        grid-template-columns: 1fr;
      }

      .quick-actions {
        grid-template-columns: 1fr;
      }

      .profile-grid {
        grid-template-columns: 1fr;
      }

      .crop-form-grid {
        grid-template-columns: 1fr;
      }

      .focus-title {
        font-size: 1rem;
      }

      #section-seed-requests .seed-store-grid {
        grid-template-columns: 1fr;
        gap: 0.75rem;
      }

      #section-seed-requests .seed-filter-toolbar {
        grid-template-columns: 1fr;
      }

      #section-seed-request-catalog .seed-store-grid {
        grid-template-columns: 1fr;
        gap: 0.75rem;
      }

      #section-seed-request-catalog .seed-filter-toolbar {
        grid-template-columns: 1fr;
      }

      #section-crops .crop-filter-toolbar {
        flex-direction: column;
        align-items: stretch;
      }

      #section-seed-requests .seed-header-top {
        flex-wrap: wrap;
      }

      .event-item {
        grid-template-columns: 1fr;
      }
    }

    /* Month Selector Styles */
    #eventCalendarMonthLabel {
      cursor: pointer;
      transition: background 0.2s ease, transform 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      padding: 0.35rem 0.65rem;
      border-radius: 999px;
    }

    #eventCalendarMonthLabel:hover {
      background: #e8f4ed;
      transform: scale(1.05);
    }

    .month-selector-modal {
      display: none;
      position: fixed;
      inset: 0;
      background: rgba(16, 24, 16, 0.45);
      z-index: 1300;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }

    .month-selector-modal.showing {
      display: flex;
    }

    .month-selector-content {
      width: min(420px, 100%);
      background: #ffffff;
      border: 1px solid #d6e5d9;
      border-radius: 14px;
      box-shadow: 0 18px 36px rgba(20, 40, 20, 0.22);
      padding: 1.5rem;
    }

    .month-selector-content h3 {
      margin: 0 0 1.2rem;
      color: #1a5f2b;
      font-size: 1.1rem;
      font-weight: 600;
    }

    .month-selector-year-section {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.8rem;
      margin-bottom: 1.5rem;
      padding-bottom: 1rem;
      border-bottom: 1px solid #e5ede7;
    }

    .month-selector-year-section label {
      color: #4d6357;
      font-size: 0.9rem;
      font-weight: 500;
    }

    .month-selector-year-btn {
      width: 36px;
      height: 36px;
      border-radius: 6px;
      border: 1px solid #d4e9da;
      background: #ffffff;
      color: #1b5a2a;
      cursor: pointer;
      font-size: 1rem;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s ease;
    }

    .month-selector-year-btn:hover {
      background: #f0faf8;
      border-color: #4ade80;
    }

    .month-selector-year-display {
      font-size: 1.1rem;
      font-weight: 600;
      color: #1b5a2a;
      min-width: 80px;
      text-align: center;
    }

    .month-selector-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 0.6rem;
      margin-bottom: 1rem;
    }

    .month-selector-btn {
      padding: 0.7rem 0.5rem;
      border: 1px solid #d4e9da;
      border-radius: 8px;
      background: #ffffff;
      color: #1b5a2a;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s ease, border-color 0.2s ease;
    }

    .month-selector-btn:hover {
      background: #f0faf8;
      border-color: #4ade80;
    }

    .month-selector-btn.active {
      background: #1b5a2a;
      color: #ffffff;
      border-color: #1b5a2a;
    }

    .month-selector-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.6rem;
    }

    .month-selector-actions button {
      padding: 0.6rem 1rem;
      border: 1px solid #d4e9da;
      border-radius: 8px;
      background: #ffffff;
      color: #1b5a2a;
      font-size: 0.9rem;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s ease;
      width: 100%;
    }

    .month-selector-close button:hover {
      background: #f3faf5;
    }
  </style>
</head>
<body class="farmer">

  <div class="admin-top-nav" style="display: flex; align-items: center; justify-content: space-between; padding-right: 2.5rem;">
    <div class="admin-logo" style="display: flex; align-items: center; gap: 0.7rem;">
      <img src="../images/smartfarm_logo.png" alt="Smart Farm Logo">
      <span>Smart Farm</span>
    </div>
    <!-- Notification Bell Button -->
    <div class="topbar-actions" style="display: flex; align-items: center; gap: 1.2rem; position: relative;">
      <button type="button" id="farmerNotifBellBtn" class="notif-bell-btn" aria-label="Notifications" style="background: none; border: none; position: relative; font-size: 1.45rem; color: #fff; cursor: pointer;">
        <i class="fas fa-bell"></i>
        <?php if ($farmer_unread_count > 0): ?>
        <span class="notif-badge" style="position: absolute; top: -7px; right: -7px; background: #dc3545; color: #fff; border-radius: 50%; font-size: 0.72rem; min-width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; padding: 0 5px; font-weight: 700; border: 2px solid #fff; z-index: 2;">
          <?php echo (int)$farmer_unread_count; ?>
        </span>
        <?php endif; ?>
      </button>
      <!-- Notification Dropdown -->
      <div id="farmerNotifDropdown" class="notif-dropdown" style="display: none; position: absolute; right: 0; top: 120%; min-width: 340px; background: #fff; border-radius: 12px; box-shadow: 0 8px 32px rgba(27,90,42,0.18); border: 1px solid #cde9d3; z-index: 1000;">
        <div style="padding: 1rem 1.1rem 0.5rem 1.1rem; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between;">
          <span style="font-weight: 700; color: #1b5a2a; font-size: 1rem;">Notifications</span>
          <button type="button" onclick="markFarmerNotificationsRead()" style="background: none; border: none; color: #28a745; font-size: 0.9rem; font-weight: 600; cursor: pointer;">Mark all read</button>
        </div>
        <div style="max-height: 340px; overflow-y: auto;">
          <?php if (!empty($farmer_notifications)): ?>
            <?php foreach ($farmer_notifications as $notif): ?>
              <div style="padding: 0.85rem 1.1rem; border-bottom: 1px solid #f0f4f2; background: <?php echo !$notif['is_read'] ? '#e8f5e9' : '#fff'; ?>; display: flex; flex-direction: column; gap: 0.18rem;">
                <span style="font-weight: 700; color: #14532d; font-size: 0.97rem;"><i class="fas fa-bell" style="margin-right:0.4rem;"></i><?php echo htmlspecialchars($notif['title']); ?></span>
                <span style="color: #4b6357; font-size: 0.89rem;"> <?php echo htmlspecialchars($notif['message']); ?></span>
                <span style="color: #6b776b; font-size: 0.78rem; margin-top: 0.1rem;"><i class="far fa-clock"></i> <?php echo htmlspecialchars($notif['created_label']); ?></span>
              </div>
            <?php endforeach; ?>
          <?php else: ?>
            <div style="padding: 1.2rem; text-align: center; color: #6b7280; font-size: 0.97rem;">No notifications yet.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <script>
    // Notification Bell Dropdown Toggle
    const notifBellBtn = document.getElementById('farmerNotifBellBtn');
    const notifDropdown = document.getElementById('farmerNotifDropdown');
    if (notifBellBtn && notifDropdown) {
      notifBellBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notifDropdown.style.display = notifDropdown.style.display === 'block' ? 'none' : 'block';
      });
      document.addEventListener('click', function(e) {
        if (!notifDropdown.contains(e.target) && e.target !== notifBellBtn) {
          notifDropdown.style.display = 'none';
        }
      });
    }
    // Mark notifications as read (AJAX)
    function markFarmerNotificationsRead() {
      fetch('../mark_notifications_read.php', { method: 'POST', credentials: 'same-origin' })
        .then(() => { window.location.reload(); });
    }
  </script>

  <div class="admin-container">
    <aside class="admin-sidebar">
      <nav class="admin-nav">
        <h3 class="nav-title">Farmer Menu</h3>
        <?php if ($is_farmer_verified_access): ?>
        <a href="#" class="nav-item<?php echo in_array($active_section, ['overview', 'income-transparency-report', 'events', 'crops', 'update-crop-quantity', 'rentals', 'machinery-reservations', 'rental-form', 'seed-request-catalog', 'seed-request-view', 'seed-requests', 'profile'], true) ? ' active' : ''; ?>" data-section="overview" onclick="showSection('overview'); return false;">
          <i class="fas fa-seedling"></i>
          <span>Home</span>
        </a>
        <a href="#" class="nav-item<?php echo $active_section === 'events' ? ' active' : ''; ?>" data-section="events" onclick="showSection('events'); return false;">
          <i class="fas fa-calendar-days"></i>
          <span>Farmer Events</span>
        </a>
        <a href="#" class="nav-item<?php echo $active_section === 'crops' ? ' active' : ''; ?>" data-section="crops" onclick="showSection('crops'); return false;">
          <i class="fas fa-leaf"></i>
          <span>Crops & Listings</span>
        </a>
        <a href="#" class="nav-item<?php echo in_array($active_section, ['seed-request-catalog', 'seed-request-view', 'seed-requests', 'seed-request-form'], true) ? ' active' : ''; ?>" data-section="seed-request-catalog" onclick="showSection('seed-request-catalog'); return false;">
          <i class="fas fa-seedling"></i>
          <span>Seed Requests</span>
        </a>
        <a href="#" class="nav-item<?php echo in_array($active_section, ['rentals', 'machinery-reservations', 'rental-form'], true) ? ' active' : ''; ?>" data-section="rentals" onclick="showSection('rentals'); return false;">
          <i class="fas fa-tractor"></i>
          <span>Machinery Rentals</span>
        </a>
        <?php else: ?>
        <div class="restricted-nav-stack">
          <a href="#" class="nav-item" data-section="overview" onclick="return false;">
            <i class="fas fa-seedling"></i>
            <span>Home</span>
          </a>
          <a href="#" class="nav-item" data-section="events" onclick="return false;">
            <i class="fas fa-calendar-days"></i>
            <span>Farmer Events</span>
          </a>
          <a href="#" class="nav-item" data-section="crops" onclick="return false;">
            <i class="fas fa-leaf"></i>
            <span>Crops & Listings</span>
          </a>
          <a href="#" class="nav-item" data-section="seed-requests" onclick="return false;">
            <i class="fas fa-seedling"></i>
            <span>Seed Requests</span>
          </a>
          <a href="#" class="nav-item" data-section="rentals" onclick="return false;">
            <i class="fas fa-tractor"></i>
            <span>Machinery Rentals</span>
          </a>
          <div class="restricted-nav-overlay">
            <i class="fas fa-lock"></i>
            <span>Access Restricted</span>
            <small>Complete admin verification to unlock these tabs.</small>
          </div>
        </div>
        <?php endif; ?>
        <div class="admin-profile" data-user-id="<?php echo htmlspecialchars($_SESSION['user_id'] ?? ''); ?>">
          <button type="button" class="admin-profile-trigger" id="adminProfileTrigger" aria-haspopup="true" aria-expanded="false">
            <span class="admin-profile-avatar">
              <i class="fas fa-user-circle"></i>
            </span>
            <span class="admin-profile-info">
              <span class="admin-profile-name">
                <?php echo htmlspecialchars($farmer_name); ?>
              </span>
              <span class="admin-profile-meta"><?php echo htmlspecialchars($farmer_badge_text); ?></span>
            </span>
            <i class="fas fa-chevron-down admin-profile-caret"></i>
          </button>
          <div class="admin-profile-dropdown" id="adminProfileDropdown" aria-hidden="true">
            <!-- View Profile button removed -->
            <button type="button" class="admin-profile-action admin-profile-logout" onclick="window.location.href='../logout.php'">
              <i class="fas fa-sign-out-alt"></i>
              Logout
            </button>
          </div>
        </div>
      </nav>
    </aside>

    <main class="farmer-main">

      <?php if ($success_msg !== ''): ?>
      <div class="farmer-alert" id="farmerSuccessBanner"><?php echo htmlspecialchars($success_msg); ?></div>
      <script>
        setTimeout(function() {
          var banner = document.getElementById('farmerSuccessBanner');
          if (banner) banner.style.display = 'none';
        }, 2000);
      </script>
      <?php endif; ?>

      <?php if ($error_msg !== ''): ?>
      <div class="farmer-alert error"><?php echo htmlspecialchars($error_msg); ?></div>
      <?php endif; ?>

      <?php if ($is_farmer_verified_access): ?>
      <section id="section-overview" class="farmer-section<?php echo $active_section === 'overview' ? ' active' : ''; ?>">
        <div class="farmer-header">
          <div class="farmer-title">
            <h1>Welcome back, <?php echo htmlspecialchars($farmer_name); ?></h1>
            <p><?php echo htmlspecialchars($today); ?> - Track farm events, crop updates, and cooperative announcements.</p>
          </div>
          <div class="farmer-badge <?php echo htmlspecialchars($farmer_badge_class); ?>"><?php echo htmlspecialchars($farmer_badge_text); ?></div>
        </div>

        <div class="stat-grid">
          <div class="stat-card clickable" role="button" tabindex="0" onclick="showSection('events')" onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); showSection('events'); }">
            <h3>Upcoming Events</h3>
            <div class="stat-value"><?php echo (int)$upcoming_event_count; ?></div>
            <div class="stat-note">All farmer activities scheduled from today onward</div>
          </div>
          <div class="stat-card clickable" role="button" tabindex="0" onclick="showSection('crops')" onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); showSection('crops'); }">
            <h3>Crop Records</h3>
            <div class="stat-value"><?php echo $total_crop_records; ?></div>
            <div class="stat-note">Total crop entries available for inventory updates</div>
          </div>
          <div class="stat-card clickable" role="button" tabindex="0" onclick="showSection('seed-requests')" onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); showSection('seed-requests'); }">
            <h3>Pending Seed Requests</h3>
            <div class="stat-value"><?php echo (int)$pending_seed_request_count; ?></div>
            <div class="stat-note">Requests still waiting for admin review</div>
          </div>
          <div class="stat-card clickable" role="button" tabindex="0" onclick="showSection('rentals')" onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); showSection('rentals'); }">
            <h3>Machinery Rentals</h3>
            <div class="stat-value"><?php echo count($machinery_catalog); ?></div>
            <div class="stat-note">Available machinery listings ready for booking</div>
          </div>
        </div>

        <div class="panel" style="margin-bottom:1rem;">
          <h2>Cooperative Profit Dividends</h2>
          <p style="margin-bottom:0.5rem;">Cooperative paid transactions are shared using the agreed split.</p>
          <div class="report-kpi-grid" style="margin-top:0;">
            <a class="report-kpi report-kpi-clickable" href="dashboard.php?section=income-transparency-report&income_report=one-farmer-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
              <div class="report-kpi-label">One Farmer Share (This Month)</div>
              <div class="report-kpi-value">PHP <?php echo number_format((float)$monthly_one_farmer_share, 2); ?></div>
            </a>
            <a class="report-kpi report-kpi-clickable" href="dashboard.php?section=income-transparency-report&income_report=farmers-total-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
              <div class="report-kpi-label">Total Share of All Farmers (This Month)</div>
              <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_farmer_dividend, 2); ?></div>
            </a>
            <a class="report-kpi report-kpi-clickable" href="dashboard.php?section=income-transparency-report&income_report=coop-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
              <div class="report-kpi-label">Coop Share (This Month)</div>
              <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_coop_dividend, 2); ?></div>
            </a>
            <a class="report-kpi report-kpi-clickable" href="dashboard.php?section=income-transparency-report&income_report=total-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
              <div class="report-kpi-label">Total Transaction Income (This Month)</div>
              <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_transaction_value, 2); ?></div>
            </a>
          </div>
        </div>

      </section>

      <!-- Seed Request Form Section (SPA-style, for openSeedRequestForm) -->

      <section id="section-seed-request-form" class="farmer-section">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="#" onclick="showSection('seed-request-catalog');return false;" aria-label="Back to Seed Catalog">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1 style="margin:0;">Request Seed</h1>
          </div>
        </div>
        <div class="panel">
          <h2 style="margin:0;color:#1b5a2a;" id="seedRequestFormName">-</h2>
          <p style="margin-top:0.25rem;">
            <span id="seedRequestFormOwner" style="display:none;"></span>
            <span>Available: <span id="seedRequestFormAvailable">-</span></span>
            <span id="seedRequestFormUnitWrap">| Unit: <span id="seedRequestFormUnit">-</span></span>
          </p>
          <form id="pageSeedRequestForm" class="action-form" style="margin-top:0.8rem;">
            <input type="hidden" id="pageSeedRequestId" name="seed_id" value="">
            <input type="hidden" id="pageSeedRequestName" value="">
            <input type="hidden" id="pageSeedRequestUnit" value="">
            <input type="hidden" id="pageSeedRequestAvailable" value="">
            <div class="form-row">
              <div class="form-field">
                <label for="pageSeedRequestQty">Quantity to Request</label>
                <input type="number" id="pageSeedRequestQty" name="quantity_requested" min="0.01" step="0.01" required placeholder="e.g. 10">
              </div>
              <div class="form-field">
                <label for="pageSeedRequestNote">Request Notes (optional)</label>
                <input type="text" id="pageSeedRequestNote" name="request_notes" placeholder="e.g., urgent planting">
              </div>
            </div>
            <div class="form-actions" style="margin-top:2rem; display: flex; justify-content: flex-end; gap: 16px;">
              <a class="action-btn small secondary" href="#" onclick="showSection('seed-request-catalog');return false;">Cancel</a>
              <button type="submit" class="action-btn small">Submit</button>
            </div>
          </form>
        </div>
        <script>
        // Ensure openSeedRequestForm pre-fills and updates the form section
        function openSeedRequestForm(seedId, seedName, seedUnit, availableQty) {
          showSection('seed-request-form');
          setTimeout(function() {
            document.getElementById('pageSeedRequestId').value = seedId;
            document.getElementById('pageSeedRequestName').value = seedName;
            document.getElementById('pageSeedRequestUnit').value = seedUnit;
            document.getElementById('pageSeedRequestAvailable').value = availableQty;
            document.querySelector('#section-seed-request-form h2').textContent = 'Seed: ' + seedName;
            document.querySelector('#section-seed-request-form p').textContent = 'Available: ' + Number(availableQty).toFixed(2) + ' ' + seedUnit;
            document.getElementById('pageSeedRequestQty').value = '';
            document.getElementById('pageSeedRequestNote').value = '';
            document.getElementById('pageSeedRequestQty').focus();
          }, 50);
        }
        </script>
      </section>

      <section id="section-income-transparency-report" class="farmer-section<?php echo $active_section === 'income-transparency-report' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=overview" aria-label="Back to Overview">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Profit Dividends</h1>
          </div>
        </div>

        <div class="panel" style="margin-bottom:1rem;">
          <div class="income-report-layout">
            <div class="income-graph-card">
              <h3>Graph View</h3>
              <p class="income-graph-note">Distribution and source breakdown for the selected dividend.</p>
              <div class="income-graph-canvas-wrap">
                <canvas id="incomeTransparencyChart" class="income-graph-canvas" aria-label="Income transparency chart"></canvas>
              </div>
              <div id="incomeTransparencyChartEmpty" class="income-graph-empty" style="display:none;">No chart data available for this report.</div>
            </div>

            <div class="income-report-right">
              <div class="report-kpi-grid">
                <a class="report-kpi report-kpi-clickable<?php echo $income_report_key === 'one-farmer-share-month' ? ' active' : ''; ?>" href="dashboard.php?section=income-transparency-report&income_report=one-farmer-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
                  <div class="report-kpi-label">One Farmer Share (This Month)</div>
                  <div class="report-kpi-value">PHP <?php echo number_format((float)$monthly_one_farmer_share, 2); ?></div>
                </a>
                <a class="report-kpi report-kpi-clickable<?php echo $income_report_key === 'farmers-total-share-month' ? ' active' : ''; ?>" href="dashboard.php?section=income-transparency-report&income_report=farmers-total-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
                  <div class="report-kpi-label">Total Share of All Farmers (This Month)</div>
                  <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_farmer_dividend, 2); ?></div>
                </a>
                <a class="report-kpi report-kpi-clickable<?php echo $income_report_key === 'coop-share-month' ? ' active' : ''; ?>" href="dashboard.php?section=income-transparency-report&income_report=coop-share-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
                  <div class="report-kpi-label">Coop Share (This Month)</div>
                  <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_coop_dividend, 2); ?></div>
                </a>
                <a class="report-kpi report-kpi-clickable<?php echo $income_report_key === 'total-month' ? ' active' : ''; ?>" href="dashboard.php?section=income-transparency-report&income_report=total-month" style="padding:0.85rem;text-align:left;text-decoration:none;display:block;">
                  <div class="report-kpi-label">Total Transaction Income (This Month)</div>
                  <div class="report-kpi-value">PHP <?php echo number_format((float)$coop_monthly_transaction_value, 2); ?></div>
                </a>
              </div>

              <div class="income-report-view">
                <div class="income-report-head">
                  <h3><?php echo htmlspecialchars((string)($active_income_report['title'] ?? 'Income Report'), ENT_QUOTES, 'UTF-8'); ?></h3>
                  <p><?php echo htmlspecialchars((string)($active_income_report['subtitle'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
                <div class="table-container">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Source</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (empty($active_income_report_rows)): ?>
                      <tr>
                        <td colspan="2" class="table-muted">No report data available.</td>
                      </tr>
                      <?php else: ?>
                      <?php foreach ($active_income_report_rows as $report_row): ?>
                      <tr>
                        <td><?php echo htmlspecialchars((string)($report_row['label'] ?? 'Source'), ENT_QUOTES, 'UTF-8'); ?></td>
                        <td>PHP <?php echo number_format((float)($report_row['amount'] ?? 0), 2); ?></td>
                      </tr>
                      <?php endforeach; ?>
                      <?php endif; ?>
                    </tbody>
                  </table>
                </div>
                <div class="income-report-summary">
                  <span><?php echo htmlspecialchars((string)($active_income_report['summary_label'] ?? 'Total'), ENT_QUOTES, 'UTF-8'); ?></span>
                  <strong>PHP <?php echo number_format((float)($active_income_report['summary_amount'] ?? 0), 2); ?></strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="section-events" class="farmer-section">
        <div id="eventCalendarHeader" class="section-header">
          <h1>Farmer Events</h1>
        </div>
        <div class="panel">
          <div id="eventCalendarView">
            <div class="events-calendar-shell">
            <div class="events-calendar-card">
              <div class="events-calendar-head">
                <button type="button" class="calendar-nav-btn" onclick="navigateEventCalendar('<?php echo htmlspecialchars($event_calendar_month_prev); ?>')" aria-label="Previous month">
                  <i class="fas fa-chevron-left"></i>
                </button>
                <div style="display:flex;flex-direction:column;align-items:center;gap:0.5rem;">
                  <h3 style="margin:0;color:#1b5a2a;">Activity Calendar</h3>
                  <span id="eventCalendarMonthLabel" class="events-calendar-month" onclick="openEventCalendarMonthSelector()"><?php echo htmlspecialchars($event_calendar_month_label); ?></span>
                  <button type="button" onclick="navigateEventCalendar('<?php echo date('Y-m'); ?>')" style="background:none;border:1px solid #d4e9da;color:#1b5a2a;padding:0.35rem 0.75rem;border-radius:6px;font-size:0.85rem;cursor:pointer;transition:background 0.2s;font-weight:500;">Today</button>
                </div>
                <button type="button" class="calendar-nav-btn" onclick="navigateEventCalendar('<?php echo htmlspecialchars($event_calendar_month_next); ?>')" aria-label="Next month">
                  <i class="fas fa-chevron-right"></i>
                </button>
              </div>
              <div class="events-calendar-grid">
                <div class="calendar-weekday">Mon</div>
                <div class="calendar-weekday">Tue</div>
                <div class="calendar-weekday">Wed</div>
                <div class="calendar-weekday">Thu</div>
                <div class="calendar-weekday">Fri</div>
                <div class="calendar-weekday">Sat</div>
                <div class="calendar-weekday">Sun</div>

                <?php for ($blank = 0; $blank < $event_calendar_leading_blanks; $blank++): ?>
                <div class="calendar-day blank" aria-hidden="true"></div>
                <?php endfor; ?>

                <?php for ($day = 1; $day <= $event_calendar_total_days; $day++): ?>
                <?php
                  $day_count = (int)($event_calendar_day_counts[$day] ?? 0);
                  $day_class = 'calendar-day';
                  $day_date = date('Y-m-d', strtotime($event_calendar_month_start . ' +' . ($day - 1) . ' days'));
                  if ($day_count > 0) {
                    $day_class .= ' has-event';
                  }
                  if ($event_calendar_today_day === $day) {
                    $day_class .= ' today';
                  }
                ?>
                <div
                  class="<?php echo htmlspecialchars($day_class); ?>"
                  data-date="<?php echo htmlspecialchars($day_date); ?>"
                  role="button"
                  tabindex="0"
                  onclick="showEventDetailsForDay('<?php echo htmlspecialchars($day_date); ?>')"
                  onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); showEventDetailsForDay('<?php echo htmlspecialchars($day_date); ?>'); }"
                >
                  <span class="calendar-day-number"><?php echo $day; ?></span>
                  <?php if ($day_count > 0): ?>
                  <span class="calendar-day-count"><?php echo $day_count; ?></span>
                  <?php endif; ?>
                </div>
                <?php endfor; ?>
              </div>
            </div>

            <div class="events-sidebar-wrapper">
              <div class="events-quick-filter">
                <button type="button" class="report-kpi report-kpi-clickable" onclick="toggleEventDetailsView('today')" style="padding:0.75rem;text-align:left;">
                  <div class="report-kpi-label">Events Today</div>
                  <div class="report-kpi-value"><?php echo (int)$today_event_count; ?></div>
                </button>
                <button type="button" class="report-kpi report-kpi-clickable" onclick="toggleEventDetailsView('week')" style="padding:0.75rem;text-align:left;">
                  <div class="report-kpi-label">Events Next 7 Days</div>
                  <div class="report-kpi-value"><?php echo (int)$week_event_count; ?></div>
                </button>
                <button type="button" class="report-kpi report-kpi-clickable" onclick="toggleEventDetailsView('upcoming')" style="padding:0.75rem;text-align:left;">
                  <div class="report-kpi-label">Total Upcoming</div>
                  <div class="report-kpi-value"><?php echo (int)$upcoming_event_count; ?></div>
                </button>
                <button type="button" class="report-kpi report-kpi-clickable" onclick="toggleEventDetailsView('recent')" style="padding:0.75rem;text-align:left;">
                  <div class="report-kpi-label">Recent Completed</div>
                  <div class="report-kpi-value"><?php echo (int)$recent_event_count; ?></div>
                </button>
              </div>

              <aside class="events-calendar-side">
                <h3 id="eventsSidebarTitle">Events This Month</h3>
                <p id="eventsSidebarDescription">Use this to quickly see event-heavy days and prepare attendance or farm tasks in advance.</p>
                <div id="eventsSidebarContent" class="events-snapshot-list">
                  <div class="events-snapshot-item">
                    <strong>Total Scheduled Events</strong>
                    <span><?php echo (int)$event_calendar_total_events; ?></span>
                  </div>
                  <div class="events-snapshot-item">
                    <strong>Active Event Days</strong>
                    <span><?php echo (int)$event_calendar_days_with_events; ?></span>
                  </div>
                  <div class="events-snapshot-item">
                    <strong>Next Event</strong>
                    <span><?php echo htmlspecialchars($next_farmer_event_label); ?></span>
                  </div>
                </div>
              </aside>
            </div>
          </div>
            </div>

          <!-- Month Selector Modal -->
          <div id="eventCalendarMonthSelector" class="month-selector-modal" onclick="if(event.target.id === 'eventCalendarMonthSelector') closeEventCalendarMonthSelector()">
            <div class="month-selector-content">
              <h3>Select Month & Year</h3>
              
              <div class="month-selector-year-section">
                <button type="button" class="month-selector-year-btn" onclick="selectorPreviousYear()">
                  <i class="fas fa-chevron-left"></i>
                </button>
                <label>Year:</label>
                <div class="month-selector-year-display" id="monthSelectorYearDisplay">2026</div>
                <button type="button" class="month-selector-year-btn" onclick="selectorNextYear()">
                  <i class="fas fa-chevron-right"></i>
                </button>
              </div>

              <div class="month-selector-grid" id="monthSelectorGrid">
                <!-- Month buttons will be populated by JavaScript -->
              </div>
              
              <div class="month-selector-actions">
                <button type="button" onclick="closeEventCalendarMonthSelector()">Cancel</button>
                <button type="button" class="confirm" onclick="confirmMonthSelection()">Select</button>
              </div>
            </div>
          </div>

          <div id="eventDetailedTableView" style="display:none;">
            <div class="seed-history-header">
              <button type="button" class="seed-back-btn" onclick="toggleEventDetailsView()" aria-label="Back to calendar">
                <i class="fas fa-arrow-left"></i>
              </button>
              <h2 id="eventTableViewTitle">Events</h2>
            </div>

            <table class="table">
              <thead>
                <tr>
                  <th>Event Title</th>
                  <th>Date & Time</th>
                  <th>Category</th>
                  <th>Location</th>
                  <th>Coordinator</th>
                </tr>
              </thead>
              <tbody id="eventTableBody">
                <tr>
                  <td colspan="5" class="table-muted">No events to display</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div id="eventDetailView" style="display:none;">
            <div class="seed-history-header">
              <button type="button" class="seed-back-btn" onclick="closeEventDetailView()" aria-label="Back to calendar">
                <i class="fas fa-arrow-left"></i>
              </button>
              <h2 id="eventDetailTitle">Event Details</h2>
            </div>

            <div id="eventDetailContent" style="background:#f9fbfa;border:1px solid rgba(40, 167, 69, 0.15);border-radius:10px;padding:1.5rem;">
              <!-- Event details populated by JavaScript -->
            </div>
          </div>

        </div>
      </section>

      <section id="section-crops" class="farmer-section">
        <div class="section-header">
          <h1>Crop Inventory</h1>
        </div>
        <div class="section-tools">
          <div class="crop-filter-toolbar">
            <input type="text" id="cropSearchInput" class="filter-input" placeholder="Search crop..." oninput="filterFarmerCropRows()">
            <select id="cropStockFilter" class="filter-select" onchange="filterFarmerCropRows()">
              <option value="">All Stock Levels</option>
              <option value="high">High (500+)</option>
              <option value="medium">Medium (100-499)</option>
              <option value="low">Low (&lt;100)</option>
            </select>
          </div>
        </div>
        <div class="panel">
          <table class="table" id="farmerCropTable">
            <thead>
              <tr>
                <th>Crop</th>
                <th>Quantity</th>
                <th>Market Price</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php if (!$crops_table_exists): ?>
              <tr>
                <td colspan="4" class="table-muted">Crops table not found. Run crop setup first.</td>
              </tr>
              <?php elseif (empty($crop_rows)): ?>
              <tr>
                <td colspan="4" class="table-muted">No crops in the inventory yet. Ask admin to add crops to the system.</td>
              </tr>
              <?php else: ?>
              <?php foreach ($crop_rows as $crop): ?>
              <?php $crop_id = (int)$crop['crop_id']; ?>
              <tr data-search="<?php echo htmlspecialchars(strtolower($crop['crop_name'] . ' ' . $crop['crop_description'])); ?>">
                <td><?php echo htmlspecialchars($crop['crop_name']); ?></td>
                <td><?php echo number_format((float)$crop['crop_quantity'], 2); ?> <?php echo htmlspecialchars($crop['crop_unit']); ?></td>
                <td>
                  <?php if ((float)($crop['market_price_per_unit'] ?? 0) > 0): ?>
                    ₱<?php echo number_format((float)$crop['market_price_per_unit'], 2); ?> / <?php echo htmlspecialchars($crop['crop_unit']); ?>
                  <?php else: ?>
                    <span class="table-muted">Not set</span>
                  <?php endif; ?>
                </td>
                <td>
                  <a class="action-btn small secondary" href="dashboard.php?section=update-crop-quantity&crop_id=<?php echo (int)$crop['crop_id']; ?>"><i class="fas fa-pen"></i> Update Qty</a>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </section>


      <section id="section-update-crop-quantity" class="farmer-section">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=crops" aria-label="Back to Crop Inventory">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1 style="margin:0;">Add Crop Quantity</h1>
          </div>
        </div>
        <div class="panel">
          <?php if ($selected_crop_for_update): ?>
            <h2 style="margin:0;color:#1b5a2a;">Crop: <?php echo htmlspecialchars((string)$selected_crop_for_update['crop_name'], ENT_QUOTES, 'UTF-8'); ?></h2>
            <p style="margin-top:0.25rem;">
              <span>Current Quantity: <span style="font-weight:bold; color:#15803d;"><?php echo number_format((float)$selected_crop_for_update['crop_quantity'], 2); ?> <?php echo htmlspecialchars((string)$selected_crop_for_update['crop_unit'], ENT_QUOTES, 'UTF-8'); ?></span></span>
            </p>
            <form class="action-form" method="post" action="dashboard.php?section=update-crop-quantity&crop_id=<?php echo (int)$selected_crop_for_update['crop_id']; ?>" style="margin-top:0.8rem;">
              <input type="hidden" name="action" value="add_crop_quantity">
              <input type="hidden" name="crop_id" value="<?php echo (int)$selected_crop_for_update['crop_id']; ?>">
              <div class="form-row">
                <div class="form-field">
                  <label for="updateCropQuantityInput">Quantity to add</label>
                  <input id="updateCropQuantityInput" name="added_quantity" type="number" min="0.01" step="0.01" required placeholder="e.g. 10">
                </div>
              </div>
              <div class="form-actions" style="margin-top:2rem; display: flex; justify-content: flex-end; gap: 16px;">
                <a class="action-btn small secondary" href="dashboard.php?section=crops">Cancel</a>
                <button type="submit" class="action-btn small" style="background:#16a34a;color:#ffffff;border:1px solid #15803d;"><i class="fas fa-plus"></i> Add Quantity</button>
              </div>
            </form>
          <?php endif; ?>
        </div>
      </section>

      <section id="section-rentals" class="farmer-section<?php echo $active_section === 'rentals' ? ' active' : ''; ?>">
        <div class="section-header">
          <h1>Machinery Rentals</h1>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <a class="action-btn small secondary" href="dashboard.php?section=machinery-reservations">
              <i class="fas fa-list"></i> View Reservation
            </a>
          </div>
        </div>

        <div class="seed-filter-toolbar">
          <input
            type="text"
            id="farmerRentalSearch"
            class="filter-input"
            placeholder="Search available machinery..."
            oninput="filterRentalCatalogCards()"
          >
          <select id="farmerRentalFilter" class="filter-select" onchange="filterRentalCatalogCards()">
            <option value="">All Category</option>
            <option value="tractor">Tractor</option>
            <option value="sprayer">Sprayer</option>
            <option value="harvester">Harvester</option>
            <option value="seeder">Seeder</option>
            <option value="pump">Pump</option>
          </select>
        </div>

        <div class="panel">
          <div id="machineryGrid" class="catalog-grid">
            <?php if (empty($machinery_catalog)): ?>
            <div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;">
              <i class="fas fa-tractor" style="opacity:0.35;margin-right:0.4rem;"></i>
              No available machinery listings yet.
            </div>
            <?php else: ?>
            <?php foreach ($machinery_catalog as $machine): ?>
              <?php
                $machine_name_lower = strtolower((string)$machine['name']);
                $machine_type_key = 'other';
                if (strpos($machine_name_lower, 'tractor') !== false) {
                  $machine_type_key = 'tractor';
                } elseif (strpos($machine_name_lower, 'sprayer') !== false) {
                  $machine_type_key = 'sprayer';
                } elseif (strpos($machine_name_lower, 'harvester') !== false) {
                  $machine_type_key = 'harvester';
                } elseif (strpos($machine_name_lower, 'seeder') !== false) {
                  $machine_type_key = 'seeder';
                } elseif (strpos($machine_name_lower, 'pump') !== false) {
                  $machine_type_key = 'pump';
                }
                $machine_form_payload = rawurlencode(json_encode([
                  'listing_id' => (int)$machine['listing_id'],
                  'name' => (string)$machine['name'],
                  'owner' => (string)$machine['owner'],
                  'daily_rate' => (float)$machine['daily_rate']
                ], JSON_UNESCAPED_UNICODE));
              ?>
              <div
                class="catalog-card machinery-card"
                data-item-id="<?php echo (int)$machine['listing_id']; ?>"
                data-machine="<?php echo htmlspecialchars($machine['name']); ?>"
                data-search="<?php echo htmlspecialchars(strtolower(((string)$machine['name']) . ' ' . ((string)$machine['owner']) . ' ' . ((string)$machine['availability'])), ENT_QUOTES, 'UTF-8'); ?>"
                data-type="<?php echo htmlspecialchars($machine_type_key, ENT_QUOTES, 'UTF-8'); ?>"
              >
                <div class="catalog-thumb">
                  <?php if (!empty($machine['image_url'])): ?>
                  <img src="<?php echo htmlspecialchars((string)$machine['image_url'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($machine['name']); ?>">
                  <?php else: ?>
                  <i class="fas fa-tractor"></i>
                  <?php endif; ?>
                </div>
                <div class="catalog-header">
                  <div class="catalog-title-wrap">
                    <h4><?php echo htmlspecialchars($machine['name']); ?></h4>
                    <!-- Removed Equipment Rental text for farmer's end -->
                  </div>
                  <!-- Removed favorite button for farmer's end -->
                </div>
                <div class="catalog-meta">
                  <span class="catalog-chip" style="display:inline-flex;text-align:left;"><i class="fas fa-circle-check"></i> Ready to reserve</span>
                </div>
                <div class="catalog-stock">
                  <span class="catalog-stock-label">Daily Rate</span>
                  <span class="catalog-stock-value crop-price">₱<?php echo number_format((float)$machine['daily_rate'], 2); ?></span>
                </div>
                <div class="catalog-actions" style="display:block;">
                  <a class="catalog-add-btn" style="width:100%;justify-content:center;align-items:center;display:flex;box-sizing:border-box;text-align:center;" href="dashboard.php?section=rental-form&origin=rentals&form_payload=<?php echo htmlspecialchars($machine_form_payload, ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-calendar-check"></i> Reserve</a>
                </div>
              </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
          <div id="machineryGridEmpty" style="text-align: center; padding: 2rem; color: #5b6b5b; display: none;">
            <i class="fas fa-search" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
            <p style="font-size: 1rem; margin: 0.5rem 0;">No machinery found</p>
            <p style="font-size: 0.9rem; margin: 0;">Try adjusting your search or type filter to find available machinery</p>
          </div>
        </div>
      </section>

      <section id="section-machinery-reservations" class="farmer-section<?php echo $active_section === 'machinery-reservations' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=rentals" aria-label="Back to Rentals">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>My Machinery Reservations</h1>
          </div>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button type="button" class="action-btn small secondary" onclick="loadMyMachineryRentals()"><i class="fas fa-rotate-right"></i> Refresh</button>
          </div>
        </div>
        <div class="panel">
          <table class="table">
            <thead>
              <tr>
                <th>Equipment</th>
                <th>Qty</th>
                <th>Schedule</th>
                <th>Status</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody id="rentalsTableBody">
              <tr>
                <td colspan="5" style="text-align:center;color:#6b7280;">Loading rentals...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section id="section-rental-form" class="farmer-section<?php echo $active_section === 'rental-form' ? ' active' : ''; ?>">
        <?php
          $rental_form_listing_id = (int)($farmer_form_payload['listing_id'] ?? 0);
          $rental_form_name = (string)($farmer_form_payload['name'] ?? 'Machinery');
          $rental_form_owner = (string)($farmer_form_payload['owner'] ?? '-');
          $rental_form_daily_rate = (float)($farmer_form_payload['daily_rate'] ?? 0);
        ?>
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=rentals" aria-label="Back to Rentals">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Reserve Machinery</h1>
          </div>
        </div>
        <div class="panel">
          <h2 style="margin:0;color:#1b5a2a;"><?php echo htmlspecialchars($rental_form_name, ENT_QUOTES, 'UTF-8'); ?></h2>
          <p style="margin-top:0.25rem;">Owner: <?php echo htmlspecialchars($rental_form_owner, ENT_QUOTES, 'UTF-8'); ?> | Daily Rate: ₱<?php echo number_format($rental_form_daily_rate, 2); ?></p>
          <form id="pageRentalForm" class="action-form" style="margin-top:0.8rem;">
            <input type="hidden" id="pageRentalListingId" value="<?php echo (int)$rental_form_listing_id; ?>">
            <input type="hidden" id="pageRentalName" value="<?php echo htmlspecialchars($rental_form_name, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" id="pageRentalOwner" value="<?php echo htmlspecialchars($rental_form_owner, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" id="pageRentalDailyRate" value="<?php echo htmlspecialchars(number_format($rental_form_daily_rate, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="form-row">
              <div class="form-field">
                <label for="pageRentalStartDate">Start Date <span style="font-weight:400;color:#6b7280;font-size:0.85em;">(first day of rental)</span></label>
                <input type="date" id="pageRentalStartDate" required>
              </div>
              <div class="form-field">
                <label for="pageRentalEndDate">End Date <span style="font-weight:400;color:#6b7280;font-size:0.85em;">(last day of rental)</span></label>
                <input type="date" id="pageRentalEndDate" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-field">
                <label for="pageRentalNote">Special Notes (optional)</label>
                <input type="text" id="pageRentalNote" placeholder="e.g., urgent delivery needed">
              </div>
            </div>
            <div class="form-actions" style="margin-top:2rem; display: flex; justify-content: flex-end; gap: 16px;">
              <a class="action-btn small secondary" href="dashboard.php?section=rentals">Cancel</a>
              <button type="submit" class="action-btn small">Submit</button>
            </div>
          </form>
        </div>
      </section>

      <section id="section-seed-request-catalog" class="farmer-section">
        <div class="section-header">
          <h1>Seed Requests</h1>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button type="button" class="action-btn small secondary" onclick="showSection('seed-requests')">
              <i class="fas fa-list"></i> View Requested Seeds
            </button>
          </div>
        </div>

        <div class="seed-filter-toolbar">
          <input
            type="text"
            id="seedCatalogInlineSearch"
            class="filter-input"
            placeholder="Search available seeds..."
            oninput="filterSeedCatalogInline()"
          >
          <select id="seedCatalogInlineStock" class="filter-select" onchange="filterSeedCatalogInline()">
            <option value="">All Availability</option>
            <option value="in-stock">In Stock</option>
            <option value="low-stock">Low Stock</option>
          </select>
        </div>

        <div class="panel">
          <div id="seedCatalogInlineGrid" class="seed-store-grid">
            <?php if (empty($seed_request_options)): ?>
            <div class="seed-store-card" style="grid-column:1/-1;text-align:center;color:#6b7280;">
              <i class="fas fa-seedling" style="font-size:2rem;margin-bottom:0.5rem;display:block;"></i>
              No seeds available for request at the moment.
            </div>
            <?php else: ?>
            <?php foreach ($seed_request_options as $seed_option): ?>
            <?php
              $seed_id = (int)($seed_option['seed_id'] ?? 0);
              $seed_name = (string)($seed_option['seed_name'] ?? 'Seed');
              $seed_unit = (string)($seed_option['seed_unit'] ?? '');
              $seed_available = (float)($seed_option['available_quantity'] ?? 0);
              $is_low_stock = ($seed_available > 0 && $seed_available < 100);
              $stock_key = $seed_available > 0 ? ($is_low_stock ? 'low-stock' : 'in-stock') : 'out-stock';
            ?>
            <div
              class="seed-store-card"
              data-search="<?php echo htmlspecialchars(strtolower($seed_name . ' ' . $seed_unit), ENT_QUOTES, 'UTF-8'); ?>"
              data-stock="<?php echo htmlspecialchars($stock_key, ENT_QUOTES, 'UTF-8'); ?>"
            >
              <div class="seed-store-thumb"><i class="fas fa-seedling"></i></div>
              <div class="seed-store-head">
                <div class="seed-store-title"><?php echo htmlspecialchars($seed_name, ENT_QUOTES, 'UTF-8'); ?></div>
                <span class="seed-store-unit"><?php echo htmlspecialchars($seed_unit, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
              <div class="seed-store-meta">
                <span class="seed-store-chip"><i class="fas fa-circle-check"></i> Ready to request</span>
              </div>
              <div class="seed-store-stock">
                <span class="seed-store-stock-label">Available</span>
                <span class="seed-store-stock-value"><?php echo number_format($seed_available, 2); ?> <?php echo htmlspecialchars($seed_unit, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
              <div class="seed-store-actions" style="display:block;">
                <button
                  type="button"
                  class="action-btn small seed-store-request-btn"
                  style="width:100%;justify-content:center;align-items:center;display:flex;box-sizing:border-box;text-align:center;"
                  onclick="openSeedRequestForm(<?php echo $seed_id; ?>, <?php echo htmlspecialchars(json_encode($seed_name)); ?>, <?php echo htmlspecialchars(json_encode($seed_unit)); ?>, <?php echo number_format($seed_available, 2, '.', ''); ?>)"
                >
                  <i class="fas fa-paper-plane"></i> Request
                </button>
              </div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <section id="section-seed-request-view" class="farmer-section<?php echo $active_section === 'seed-request-view' ? ' active' : ''; ?>">
        <div class="section-header">
          <div class="back-title-row seed-view-title-wrap">
            <a class="crop-back-btn" href="dashboard.php?section=seed-request-catalog" aria-label="Back to Seed Requests">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Seed Details</h1>
          </div>
        </div>
        <div class="panel">
          <?php if ($selected_seed_for_view): ?>
          <?php
            $view_seed_name = (string)($selected_seed_for_view['seed_name'] ?? 'Seed');
            $view_seed_unit = (string)($selected_seed_for_view['seed_unit'] ?? '-');
            $view_seed_qty = (float)($selected_seed_for_view['available_quantity'] ?? 0);
            $view_seed_threshold = (float)($selected_seed_for_view['low_stock_threshold'] ?? 0);
            $view_seed_created = (string)($selected_seed_for_view['created_at'] ?? '');
            $view_seed_low = ($view_seed_threshold > 0 && $view_seed_qty <= $view_seed_threshold);
          ?>
          <div class="seed-view-grid">
            <div class="seed-view-item">
              <span class="seed-view-label">Seed Type</span>
              <div class="seed-view-value"><?php echo htmlspecialchars($view_seed_name, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
            <div class="seed-view-item">
              <span class="seed-view-label">Unit</span>
              <div class="seed-view-value"><?php echo htmlspecialchars($view_seed_unit, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
            <div class="seed-view-item">
              <span class="seed-view-label">Available Quantity</span>
              <div class="seed-view-value"><?php echo number_format($view_seed_qty, 2); ?> <?php echo htmlspecialchars($view_seed_unit, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
            <div class="seed-view-item">
              <span class="seed-view-label">Stock Status</span>
              <div class="seed-view-value"><?php echo $view_seed_low ? 'Low Stock' : 'In Stock'; ?></div>
            </div>
            <div class="seed-view-item">
              <span class="seed-view-label">Low Stock Threshold</span>
              <div class="seed-view-value"><?php echo number_format($view_seed_threshold, 2); ?> <?php echo htmlspecialchars($view_seed_unit, ENT_QUOTES, 'UTF-8'); ?></div>
            </div>
            <div class="seed-view-item">
              <span class="seed-view-label">Added On</span>
              <div class="seed-view-value"><?php echo $view_seed_created !== '' ? htmlspecialchars(date('M d, Y', strtotime($view_seed_created)), ENT_QUOTES, 'UTF-8') : '-'; ?></div>
            </div>
          </div>

          <div class="seed-view-actions">
            <button
              type="button"
              class="action-btn small"
              style="background:#16a34a;color:#ffffff;border:1px solid #15803d;"
              onclick="openSeedRequestModal(<?php echo (int)$selected_seed_for_view['seed_id']; ?>, <?php echo htmlspecialchars(json_encode($view_seed_name)); ?>, <?php echo htmlspecialchars(json_encode($view_seed_unit)); ?>, <?php echo number_format($view_seed_qty, 2, '.', ''); ?>)"
            >
              <i class="fas fa-paper-plane"></i> Request This Seed
            </button>
            <a class="action-btn small secondary" href="dashboard.php?section=seed-request-catalog"><i class="fas fa-arrow-left"></i> Back to Seed List</a>
          </div>
          <?php else: ?>
          <div class="table-muted">Seed record not found. Please return to the seed list and select a valid item.</div>
          <div style="margin-top:0.85rem;">
            <a class="action-btn small secondary" href="dashboard.php?section=seed-request-catalog"><i class="fas fa-arrow-left"></i> Back to Seed List</a>
          </div>
          <?php endif; ?>
        </div>
      </section>

      <section id="section-seed-requests" class="farmer-section">

        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=seed-request-catalog" aria-label="Back to Request Page">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1 style="margin:0;">Requested Seeds</h1>
          </div>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button type="button" class="action-btn small secondary" onclick="window.location.reload()">
              <i class="fas fa-rotate-right"></i> Refresh
            </button>
          </div>
        </div>

        <div class="panel">
          <table class="table">
            <thead>
              <tr>
                <th>Seed Type</th>
                <th>Requested Qty</th>
                <th>Requested Date</th>
                <th>Status</th>
                <th>Request ID</th>
              </tr>
            </thead>
            <tbody id="seedRequestsTableBody">
              <?php if (!$seed_request_table_exists): ?>
              <tr>
                <td colspan="5" style="text-align:center;color:#6b7280;">Seed request feature is not ready yet.</td>
              </tr>
              <?php elseif (empty($seed_request_rows)): ?>
              <tr>
                <td colspan="5" style="text-align:center;color:#6b7280;">No seed requests yet.</td>
              </tr>
              <?php else: ?>
              <?php foreach ($seed_request_rows as $request_row): ?>
              <?php
                $request_id = (int)($request_row['request_id'] ?? 0);
                $seed_name = (string)($request_row['seed_name'] ?? '-');
                $quantity = (float)($request_row['quantity_requested'] ?? 0);
                $request_status = strtolower((string)($request_row['request_status'] ?? 'pending'));
                $requested_at = (string)($request_row['requested_at'] ?? '');
                $status_label = ucfirst($request_status);
                $reference = '#REQ' . str_pad((string)$request_id, 4, '0', STR_PAD_LEFT);
                $schedule = !empty($requested_at) ? date('M d, Y', strtotime($requested_at)) : '-';
              ?>
              <tr>
                <td><?php echo htmlspecialchars($seed_name); ?></td>
                <td><?php echo number_format($quantity, 2); ?></td>
                <td><?php echo $schedule; ?></td>
                <td><?php echo htmlspecialchars($status_label); ?></td>
                <td><?php echo htmlspecialchars($reference); ?></td>
              </tr>
              <?php endforeach; ?>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
        <script>
        // Live update for Requested Seeds table
        document.addEventListener('DOMContentLoaded', function() {
          function updateSeedRequestsTable() {
            // Only run if the section is visible
            var section = document.getElementById('section-seed-requests');
            if (!section || section.style.display === 'none') return;
            fetch('seed_request_api.php?action=get_seed_requests', {
              credentials: 'same-origin'
            })
            .then(r => r.json())
            .then(data => {
              var tbody = document.getElementById('seedRequestsTableBody');
              if (!tbody) return;
              if (!data.success) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#b91c1c;">Failed to load seed requests.</td></tr>';
                return;
              }
              var rows = data.requests;
              if (!rows || rows.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">No seed requests yet.</td></tr>';
                return;
              }
              tbody.innerHTML = rows.map(function(row) {
                var reference = '#REQ' + String(row.request_id).padStart(4, '0');
                var schedule = row.requested_at ? (new Date(row.requested_at)).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '-';
                var status = row.request_status ? row.request_status.charAt(0).toUpperCase() + row.request_status.slice(1) : '-';
                return '<tr>' +
                  '<td>' + escapeHtml(row.seed_name || '-') + '</td>' +
                  '<td>' + (parseFloat(row.quantity_requested).toFixed(2)) + '</td>' +
                  '<td>' + schedule + '</td>' +
                  '<td>' + escapeHtml(status) + '</td>' +
                  '<td>' + escapeHtml(reference) + '</td>' +
                '</tr>';
              }).join('');
            });
          }
          // Simple HTML escape
          function escapeHtml(text) {
            var map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
            return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
          }
          // Poll every 5 seconds
          if (document.getElementById('section-seed-requests')) {
            setInterval(updateSeedRequestsTable, 5000);
          }
        });
        </script>

        <!-- Available Seeds Catalog Modal -->
        <div id="seedCatalogModalBackdrop" style="display:none;position:fixed;inset:0;background:rgba(16,24,16,0.45);z-index:1300;align-items:center;justify-content:center;padding:16px;overflow-y:auto;">
          <div role="dialog" aria-modal="true" aria-labelledby="seedCatalogModalTitle" style="width:min(820px,100%);background:#fff;border:1px solid #d6e5d9;border-radius:14px;box-shadow:0 18px 36px rgba(20,40,20,0.22);padding:1.5rem;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1.2rem;">
              <h2 id="seedCatalogModalTitle" style="margin:0;color:#1a5f2b;font-size:1.3rem;">Available Seeds for Request</h2>
              <button type="button" style="background:none;border:none;color:#6b7280;font-size:1.3rem;cursor:pointer;" onclick="closeSeedCatalogModal()">✕</button>
            </div>

            <input type="text" id="seedCatalogSearch" class="filter-input" placeholder="Search seeds..." oninput="filterSeedCatalogCards()" style="margin-bottom:1rem;">

            <div id="seedCatalogGrid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:0.85rem;">
              <?php if (empty($seed_request_options)): ?>
              <div style="grid-column:1/-1;padding:1.5rem;text-align:center;color:#6b7280;">
                <i class="fas fa-seedling" style="font-size:2rem;margin-bottom:0.5rem;display:block;"></i>
                No seeds available for request at the moment.
              </div>
              <?php else: ?>
              <?php foreach ($seed_request_options as $seed_option): ?>
              <?php
                $seed_id = (int)($seed_option['seed_id'] ?? 0);
                $seed_name = (string)($seed_option['seed_name'] ?? 'Seed');
                $seed_unit = (string)($seed_option['seed_unit'] ?? '');
                $seed_available = (float)($seed_option['available_quantity'] ?? 0);
              ?>
              <div class="seed-catalog-card" data-search="<?php echo htmlspecialchars(strtolower($seed_name . ' ' . $seed_unit)); ?>" style="border:1px solid rgba(40,167,69,0.2);border-radius:10px;padding:1rem;background:#fff;display:flex;flex-direction:column;gap:0.6rem;transition:transform 0.2s,box-shadow 0.2s ease, border-color 0.2s ease;">
                <div style="height:60px;background:linear-gradient(135deg,rgba(27,90,42,0.12),rgba(40,167,69,0.2));border-radius:8px;display:flex;align-items:center;justify-content:center;color:#1b5a2a;font-size:1.8rem;">
                  <i class="fas fa-leaf"></i>
                </div>
                <h4 style="margin:0;color:#1b5a2a;font-weight:600;font-size:0.95rem;"><?php echo htmlspecialchars($seed_name); ?></h4>
                <div style="color:#6b776b;font-size:0.85rem;">Available: <strong><?php echo number_format($seed_available, 2); ?> <?php echo htmlspecialchars($seed_unit); ?></strong></div>
                <button type="button" class="catalog-add-btn" onclick="openSeedRequestModal(<?php echo $seed_id; ?>, <?php echo htmlspecialchars(json_encode($seed_name)); ?>, <?php echo htmlspecialchars(json_encode($seed_unit)); ?>, <?php echo number_format($seed_available, 2, '.', ''); ?>)" style="width:100%;border:none;background:linear-gradient(135deg,#1b5a2a 0%,#28a745 100%);color:#fff;padding:0.45rem 0.75rem;border-radius:6px;font-weight:600;cursor:pointer;font-size:0.8rem;transition:transform 0.2s,box-shadow 0.2s;">
                  <i class="fas fa-paper-plane"></i> Request
                </button>
              </div>
              <?php endforeach; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>



          <div id="seedPreviewModalBackdrop" style="display:none;position:fixed;inset:0;background:rgba(16,24,16,0.45);z-index:1300;align-items:center;justify-content:center;padding:16px;">
            <div role="dialog" aria-modal="true" aria-labelledby="seedPreviewModalTitle" style="width:min(440px,100%);background:#fff;border:1px solid #d6e5d9;border-radius:14px;box-shadow:0 18px 36px rgba(20,40,20,0.22);padding:1rem;">
              <h3 id="seedPreviewModalTitle" style="margin:0 0 0.35rem;color:#1a5f2b;">Seed Details</h3>
              <div id="seedPreviewName" style="margin:0 0 0.5rem;padding:0.55rem 0.7rem;background:#f3faf4;border:1px solid #d7eadb;border-radius:8px;color:#1f5a2f;font-size:0.95rem;font-weight:700;">Seed: -</div>
              <div id="seedPreviewUnit" style="margin:0 0 0.45rem;color:#5a695c;font-size:0.9rem;">Unit: -</div>
              <div id="seedPreviewAvail" style="margin:0;color:#5a695c;font-size:0.9rem;">Available: -</div>

              <div style="display:flex;justify-content:flex-end;gap:0.55rem;margin-top:1rem;">
                <button type="button" class="action-btn small" style="background:#ffffff;color:#1f2937;border:1px solid #d1d5db;" onclick="closeSeedPreviewModal()">Close</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <?php endif; ?>

      <section id="section-profile" class="farmer-section<?php echo (!$is_farmer_verified_access || $active_section === 'profile') ? ' active' : ''; ?>">
        <div class="panel">
          <h2>Profile</h2>
          <?php if (!$is_farmer_verified_access): ?>
          <p>Your account is pending admin verification. Access to dashboard features is locked until approval.</p>
          <div style="margin-top:1rem;padding:1rem;border-radius:10px;border:1px solid #f3d08a;background:#fff8e6;color:#7a5a16;line-height:1.55;">
            <strong style="display:block;margin-bottom:0.35rem;">Verification in progress</strong>
            <div>Status: <?php echo htmlspecialchars($verification_status_text); ?></div>
          </div>
          <?php else: ?>
          <p>Update your contact information to speed up approvals and rentals.</p>
          <?php endif; ?>
          <div class="profile-grid">
            <div class="profile-item">
              <span>Full Name</span>
              <strong><?php echo htmlspecialchars($farmer_name); ?></strong>
            </div>
            <div class="profile-item">
              <span>Member Since</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['member_since']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Contact</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['contact']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Farm Name</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['farm_name']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Farm Address</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['farm_address']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Email</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['email']); ?></strong>
            </div>
            <div class="profile-item">
              <span>ID Type</span>
              <strong><?php echo htmlspecialchars((string)$farmer_profile['id_type']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Verification Status</span>
              <strong><?php echo htmlspecialchars($verification_status_text); ?></strong>
            </div>
          </div>
        </div>
      </section>
    </main>
  </div>

  <script>
    const RENTAL_API = 'rental_api.php';
    const incomeChartPayload = <?php echo $active_income_report_chart_payload_json; ?>;

    function renderIncomeTransparencyChart() {
      const canvas = document.getElementById('incomeTransparencyChart');
      if (!canvas) return;

      const emptyEl = document.getElementById('incomeTransparencyChartEmpty');
      const wrap = canvas.parentElement;
      const rows = Array.isArray(incomeChartPayload.rows) ? incomeChartPayload.rows : [];
      const labels = rows.map((row) => String(row.label || 'Source'));
      const values = rows.map((row) => Math.max(0, Number(row.amount || 0)));
      const colors = ['#2563eb', '#f59e0b', '#7c3aed'];
      const reportKey = String(incomeChartPayload.report_key || '');

      if (!rows.length || !wrap) {
        canvas.style.display = 'none';
        if (emptyEl) emptyEl.style.display = 'block';
        return;
      }

      canvas.style.display = 'block';
      if (emptyEl) emptyEl.style.display = 'none';

      const rect = wrap.getBoundingClientRect();
      const width = Math.max(320, Math.floor(rect.width - 4));
      const height = Math.max(260, Math.floor(rect.height - 4));
      const dpr = window.devicePixelRatio || 1;
      canvas.width = width * dpr;
      canvas.height = height * dpr;

      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, width, height);

      const state = {
        mode: '',
        targets: [],
        hover: null,
        draw: null
      };

      const formatPhp = (value, compact = false) => {
        const safe = Number(value || 0);
        if (compact && Math.abs(safe) >= 1000) {
          return 'PHP ' + (safe / 1000).toFixed(1) + 'k';
        }
        return 'PHP ' + safe.toLocaleString('en-PH', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
      };

      const drawTooltip = (hover) => {
        if (!hover) return;
        const lines = Array.isArray(hover.lines) ? hover.lines : [String(hover.text || '')];

        ctx.save();
        ctx.font = '12px Arial';
        const paddingX = 10;
        const paddingY = 8;
        const lineGap = 16;
        let maxW = 0;
        lines.forEach((line) => {
          maxW = Math.max(maxW, ctx.measureText(line).width);
        });

        const boxW = Math.ceil(maxW + paddingX * 2);
        const boxH = Math.ceil(lines.length * lineGap + paddingY * 2 - 4);

        let x = hover.x + 12;
        let y = hover.y - boxH - 10;
        if (x + boxW > width - 8) x = hover.x - boxW - 12;
        if (y < 8) y = hover.y + 12;

        ctx.fillStyle = 'rgba(17, 24, 39, 0.94)';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(x, y, boxW, boxH, 8);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = '#f9fafb';
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        lines.forEach((line, i) => {
          ctx.fillText(line, x + paddingX, y + paddingY + i * lineGap + 4);
        });
        ctx.restore();
      };

      const setupHoverHandlers = () => {
        canvas.onmousemove = (event) => {
          const rect = canvas.getBoundingClientRect();
          const mx = event.clientX - rect.left;
          const my = event.clientY - rect.top;

          let found = null;
          for (const target of state.targets) {
            if (target.type === 'bar') {
              if (mx >= target.x && mx <= (target.x + target.w) && my >= target.y && my <= (target.y + target.h)) {
                found = target;
                break;
              }
            } else if (target.type === 'point') {
              const dx = mx - target.x;
              const dy = my - target.y;
              if ((dx * dx + dy * dy) <= target.r * target.r) {
                found = target;
                break;
              }
            }
          }

          state.hover = found;
          if (typeof state.draw === 'function') state.draw();
        };

        canvas.onmouseleave = () => {
          state.hover = null;
          if (typeof state.draw === 'function') state.draw();
        };
      };

      const drawMonthlyBars = () => {
        state.mode = 'monthly';
        state.targets = [];

        const pad = { top: 24, right: 20, bottom: 40, left: 56 };
        const plotW = width - pad.left - pad.right;
        const plotH = height - pad.top - pad.bottom;
        const maxValue = Math.max(1, ...values);
        const tickCount = 4;

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);

        ctx.strokeStyle = '#e5e7eb';
        ctx.lineWidth = 1;
        for (let i = 0; i <= tickCount; i++) {
          const y = pad.top + (plotH * i) / tickCount;
          ctx.beginPath();
          ctx.moveTo(pad.left, y);
          ctx.lineTo(width - pad.right, y);
          ctx.stroke();

          const val = maxValue - (maxValue * i) / tickCount;
          ctx.fillStyle = '#6b7280';
          ctx.font = '11px Arial';
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          ctx.fillText(formatPhp(val, true), pad.left - 8, y);
        }

        const groupW = plotW / Math.max(1, values.length);
        const barW = Math.min(64, Math.max(24, groupW * 0.56));

        values.forEach((value, index) => {
          const x = pad.left + groupW * index + (groupW - barW) / 2;
          const h = (value / maxValue) * plotH;
          const y = pad.top + plotH - h;

          ctx.fillStyle = colors[index % colors.length];
          ctx.beginPath();
          ctx.roundRect(x, y, barW, h, 6);
          ctx.fill();

          ctx.fillStyle = '#374151';
          ctx.font = '11px Arial';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          ctx.fillText((labels[index] || '').replace(/\s+(Share|Transactions).*/i, ''), x + barW / 2, pad.top + plotH + 8);

          state.targets.push({
            type: 'bar',
            x,
            y,
            w: barW,
            h,
            lines: [labels[index] || 'Source', formatPhp(value)]
          });
        });

        if (state.hover && state.hover.type === 'bar') {
          drawTooltip({ x: state.hover.x + state.hover.w / 2, y: state.hover.y, lines: state.hover.lines });
        }
      };

      const drawLineTrend = () => {
        state.mode = 'trend';
        state.targets = [];

        const labels12 = Array.isArray(incomeChartPayload.labels_12m) ? incomeChartPayload.labels_12m : [];
        const series12 = incomeChartPayload.series_12m || {};
        const bidding = Array.isArray(series12.bidding) ? series12.bidding.map((v) => Number(v || 0)) : [];
        const livestock = Array.isArray(series12.livestock) ? series12.livestock.map((v) => Number(v || 0)) : [];
        const machinery = Array.isArray(series12.machinery) ? series12.machinery.map((v) => Number(v || 0)) : [];

        const all = [...bidding, ...livestock, ...machinery];
        const maxValue = Math.max(1, ...all);
        const minValue = 0;

        const pad = { top: 16, right: 20, bottom: 34, left: 52 };
        const plotW = width - pad.left - pad.right;
        const plotH = height - pad.top - pad.bottom;

        ctx.font = '11px Arial';
        ctx.fillStyle = '#6b7280';
        ctx.strokeStyle = '#e5efe8';
        ctx.lineWidth = 1;

        const ticks = 4;
        for (let i = 0; i <= ticks; i++) {
          const y = pad.top + (plotH * i) / ticks;
          ctx.beginPath();
          ctx.moveTo(pad.left, y);
          ctx.lineTo(width - pad.right, y);
          ctx.stroke();

          const value = maxValue - ((maxValue - minValue) * i) / ticks;
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          ctx.fillText(formatPhp(value, true), pad.left - 8, y);
        }

        const xDen = Math.max(1, labels12.length - 1);
        labels12.forEach((label, index) => {
          const x = pad.left + (plotW * index) / xDen;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          const shortLabel = String(label || '').slice(0, 3);
          ctx.fillText(shortLabel, x, height - pad.bottom + 8);
        });

        const shareLabel = reportKey === 'farmers-total-share-month' ? 'Farmers Share' : 'Coop Share';
        const lines = [
          { data: bidding, color: '#2563eb', name: 'Bidding' },
          { data: livestock, color: '#f59e0b', name: 'Livestock' },
          { data: machinery, color: '#7c3aed', name: 'Machinery' }
        ];

        lines.forEach((line) => {
          if (!line.data.length) return;
          ctx.strokeStyle = line.color;
          ctx.lineWidth = 2;
          ctx.beginPath();
          line.data.forEach((value, index) => {
            const x = pad.left + (plotW * index) / xDen;
            const ratio = (value - minValue) / (maxValue - minValue || 1);
            const y = pad.top + plotH * (1 - ratio);
            if (index === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          });
          ctx.stroke();

          line.data.forEach((value, index) => {
            const x = pad.left + (plotW * index) / xDen;
            const ratio = (value - minValue) / (maxValue - minValue || 1);
            const y = pad.top + plotH * (1 - ratio);
            ctx.fillStyle = line.color;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();

            state.targets.push({
              type: 'point',
              x,
              y,
              r: 8,
              lines: [
                line.name + ' - ' + (labels12[index] || 'Month'),
                formatPhp(value)
              ]
            });
          });
        });

        const legendX = pad.left;
        const legendY = 8;
        lines.forEach((line, index) => {
          const y = legendY + index * 16;
          ctx.fillStyle = line.color;
          ctx.fillRect(legendX, y, 10, 10);
          ctx.fillStyle = '#374151';
          ctx.textAlign = 'left';
          ctx.textBaseline = 'top';
          ctx.fillText(line.name + ' (' + shareLabel + ')', legendX + 14, y - 1);
        });

        if (state.hover && state.hover.type === 'point') {
          drawTooltip({ x: state.hover.x, y: state.hover.y, lines: state.hover.lines });
        }
      };

      state.draw = () => {
        ctx.clearRect(0, 0, width, height);
        if (reportKey === 'coop-share-12m' || reportKey === 'farmer-share-12m') {
          drawLineTrend();
        } else {
          drawMonthlyBars();
        }
      };

      state.draw();
      setupHoverHandlers();
    }

    function showSection(section) {
      const normalizedSection = String(section || '').trim() || '<?php echo $is_farmer_verified_access ? 'overview' : 'profile'; ?>';
      document.querySelectorAll('.farmer-section').forEach((el) => {
        el.classList.remove('active');
      });
      const requestedTarget = document.getElementById('section-' + normalizedSection);
      const fallbackSection = '<?php echo $is_farmer_verified_access ? 'overview' : 'profile'; ?>';
      const fallbackTarget = document.getElementById('section-' + fallbackSection);
      const target = requestedTarget || fallbackTarget || document.querySelector('.farmer-section');
      if (target) target.classList.add('active');

      const effectiveSection = target && target.id && target.id.indexOf('section-') === 0
        ? target.id.slice(8)
        : normalizedSection;

      document.querySelectorAll('.admin-sidebar .nav-item').forEach((el) => {
        el.classList.remove('active');
      });
      const navSection = effectiveSection === 'update-crop-quantity'
        ? 'crops'
        : (effectiveSection === 'income-transparency-report' ? 'overview'
        : ((effectiveSection === 'machinery-reservations' || effectiveSection === 'rental-form') ? 'rentals'
        : ((effectiveSection === 'seed-requests' || effectiveSection === 'seed-request-view') ? 'seed-request-catalog' : effectiveSection)));
      const activeNav = document.querySelector(`.admin-sidebar .nav-item[data-section="${navSection}"]`);
      if (activeNav) activeNav.classList.add('active');

      try {
        const url = new URL(window.location.href);
        url.searchParams.set('section', effectiveSection);
        window.history.replaceState({}, '', url.toString());
      } catch (e) {
        // ignore URL update errors
      }
    }

    function formatDate(value) {
      if (!value) return '';
      const date = new Date(value + 'T00:00:00');
      if (Number.isNaN(date.getTime())) return '';
      return date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
    }

    function rentalStatusPill(status) {
      const key = String(status || '').toLowerCase();
      if (key === 'approved') return '<span class="pill">Approved</span>';
      if (key === 'in-rental') return '<span class="pill info">In Use</span>';
      if (key === 'returned') return '<span class="pill">Returned</span>';
      if (key === 'cancelled') return '<span class="pill pending">Cancelled</span>';
      return '<span class="pill pending">Pending</span>';
    }

    function loadMyMachineryRentals() {
      const rentalsTableBody = document.getElementById('rentalsTableBody');
      if (!rentalsTableBody) return;

      rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">Loading rentals...</td></tr>';

      fetch(RENTAL_API + '?action=get_my_rentals')
        .then((response) => response.json())
        .then((data) => {
          if (!data.success || !Array.isArray(data.rentals) || data.rentals.length === 0) {
            rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">No machinery rentals yet.</td></tr>';
            return;
          }

          rentalsTableBody.innerHTML = data.rentals.map((row) => {
            const start = formatDate(row.start_date);
            const end = formatDate(row.end_date);
            const schedule = start && end ? `${start} - ${end}` : 'Date pending';
            return `
              <tr>
                <td>${row.equipment_name || 'Machinery'}</td>
                <td>1</td>
                <td>${schedule}</td>
                <td>${rentalStatusPill(row.rental_status)}</td>
                <td>${row.rental_code || '#'}</td>
              </tr>
            `;
          }).join('');
        })
        .catch(() => {
          rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#dc3545;">Could not load rentals.</td></tr>';
        });
    }

    function filterRentalCatalogCards() {
      const search = (document.getElementById('farmerRentalSearch')?.value || '').trim().toLowerCase();
      const typeFilter = (document.getElementById('farmerRentalFilter')?.value || '').trim().toLowerCase();
      const cards = document.querySelectorAll('#machineryGrid .catalog-card[data-search]');
      let visibleCount = 0;

      cards.forEach((card) => {
        const text = (card.getAttribute('data-search') || '').toLowerCase();
        const type = (card.getAttribute('data-type') || '').toLowerCase();
        const matchSearch = search === '' || text.includes(search);
        const matchType = typeFilter === '' || type === typeFilter;
        const isVisible = matchSearch && matchType;
        card.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleCount++;
      });

      const emptyContainer = document.getElementById('machineryGridEmpty');
      if (emptyContainer) {
        emptyContainer.style.display = visibleCount === 0 ? '' : 'none';
      }
    }

    function filterFarmerCropRows() {
      const table = document.getElementById('farmerCropTable');
      const searchInput = document.getElementById('cropSearchInput');
      const stockFilter = document.getElementById('cropStockFilter');
      if (!table || !searchInput) return;

      const search = searchInput.value.toLowerCase();
      const selectedStock = stockFilter ? stockFilter.value : '';

      table.querySelectorAll('tbody tr').forEach((row) => {
        const rowSearch = (row.getAttribute('data-search') || '').toLowerCase();
        const text = row.textContent.toLowerCase();
        const qtyCell = row.querySelector('td:nth-child(2)');
        let qtyText = qtyCell ? qtyCell.textContent : '';
        // Remove all except digits, commas, periods, and minus
        qtyText = qtyText.replace(/[^\d.,-]/g, '');
        // Remove commas for thousands
        qtyText = qtyText.replace(/,/g, '');
        const qty = Number.parseFloat(qtyText) || 0;

        if (!row.hasAttribute('data-search')) {
          row.style.display = '';
          return;
        }

        const matchesSearch = search === '' || rowSearch.includes(search) || text.includes(search);
        let matchesStock = true;
        if (selectedStock === 'high') matchesStock = qty >= 500;
        if (selectedStock === 'medium') matchesStock = qty >= 100 && qty < 500;
        if (selectedStock === 'low') matchesStock = qty < 100;

        row.style.display = (matchesSearch && matchesStock) ? '' : 'none';
      });
    }

    let pendingSeedRequest = {
      seedId: 0,
      seedName: '',
      seedUnit: '',
      availableQty: 0
    };

    function filterSeedRequestTable() {
      const table = document.getElementById('seedRequestTable');
      const searchInput = document.getElementById('seedRequestTableSearch');
      const statusFilter = document.getElementById('seedRequestStatusFilter');
      if (!table || !searchInput) return;

      const search = searchInput.value.toLowerCase();
      const selectedStatus = statusFilter ? statusFilter.value : '';

      table.querySelectorAll('tbody tr').forEach((row) => {
        const rowSearch = (row.getAttribute('data-search') || '').toLowerCase();
        const rowStatus = row.getAttribute('data-status') || '';

        const matchesSearch = search === '' || rowSearch.includes(search);
        const matchesStatus = selectedStatus === '' || rowStatus === selectedStatus;

        row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
      });
    }

    function filterSeedCatalogInline() {
      const searchInput = document.getElementById('seedCatalogInlineSearch');
      const stockFilter = document.getElementById('seedCatalogInlineStock');
      const cards = document.querySelectorAll('#seedCatalogInlineGrid .seed-store-card[data-search]');
      if (!cards.length) return;

      const search = searchInput ? searchInput.value.toLowerCase().trim() : '';
      const selectedStock = stockFilter ? stockFilter.value : '';

      cards.forEach((card) => {
        const cardSearch = (card.getAttribute('data-search') || '').toLowerCase();
        const cardStock = (card.getAttribute('data-stock') || '').toLowerCase();
        const matchesSearch = search === '' || cardSearch.includes(search);
        const matchesStock = selectedStock === '' || cardStock === selectedStock;
        card.style.display = (matchesSearch && matchesStock) ? '' : 'none';
      });
    }

    function openSeedCatalogModal() {
      const backdrop = document.getElementById('seedCatalogModalBackdrop');
      if (backdrop) {
        backdrop.style.display = 'flex';
        const searchInput = document.getElementById('seedCatalogSearch');
        if (searchInput) {
          searchInput.value = '';
          setTimeout(() => searchInput.focus(), 50);
        }
      }
    }

    function closeSeedCatalogModal() {
      const backdrop = document.getElementById('seedCatalogModalBackdrop');
      if (backdrop) {
        backdrop.style.display = 'none';
      }
      const searchInput = document.getElementById('seedCatalogSearch');
      if (searchInput) searchInput.value = '';
    }

    function filterSeedCatalogCards() {
      const searchInput = document.getElementById('seedCatalogSearch');
      const cards = document.querySelectorAll('#seedCatalogGrid .seed-catalog-card');
      if (!cards.length) return;

      const search = searchInput ? searchInput.value.toLowerCase() : '';

      cards.forEach((card) => {
        const cardSearch = (card.getAttribute('data-search') || '').toLowerCase();
        const matchesSearch = search === '' || cardSearch.includes(search);
        card.style.display = matchesSearch ? '' : 'none';
      });
    }

    function toggleSeedRequestHistory() {
      // This function is now replaced by the modal system
      // Keeping it for backward compatibility if called elsewhere
      openSeedCatalogModal();
    }

    function openSeedRequestModal(seedId, seedName, seedUnit, availableQty) {
      const backdrop = document.getElementById('seedRequestModalBackdrop');
      const seedBox = document.getElementById('seedReqModalSeed');
      const availBox = document.getElementById('seedReqModalAvail');
      const qtyInput = document.getElementById('seedReqQtyInput');
      const notesInput = document.getElementById('seedReqNotesInput');
      if (!backdrop || !qtyInput || !notesInput) return;

      pendingSeedRequest = {
        seedId: Number.parseInt(String(seedId), 10) || 0,
        seedName: String(seedName || '').trim(),
        seedUnit: String(seedUnit || '').trim(),
        availableQty: Number.parseFloat(String(availableQty)) || 0
      };

      if (seedBox) seedBox.textContent = 'Seed: ' + (pendingSeedRequest.seedName || '-');
      if (availBox) {
        availBox.textContent = 'Available: ' + pendingSeedRequest.availableQty.toFixed(2) + ' ' + pendingSeedRequest.seedUnit;
      }

      qtyInput.value = '';
      notesInput.value = '';
      backdrop.style.display = 'flex';
      window.setTimeout(() => qtyInput.focus(), 40);
    }

    function closeSeedRequestModal() {
      const backdrop = document.getElementById('seedRequestModalBackdrop');
      const qtyInput = document.getElementById('seedReqQtyInput');
      const notesInput = document.getElementById('seedReqNotesInput');
      const seedBox = document.getElementById('seedReqModalSeed');
      const availBox = document.getElementById('seedReqModalAvail');
      if (backdrop) backdrop.style.display = 'none';
      if (qtyInput) qtyInput.value = '';
      if (notesInput) notesInput.value = '';
      if (seedBox) seedBox.textContent = 'Seed: -';
      if (availBox) availBox.textContent = 'Available: -';

      pendingSeedRequest = { seedId: 0, seedName: '', seedUnit: '', availableQty: 0 };
    }

    function submitSeedRequestModal() {
      const form = document.getElementById('seedRequestSubmitForm');
      const seedIdField = document.getElementById('seedRequestSeedId');
      const qtyField = document.getElementById('seedRequestQuantityValue');
      const notesField = document.getElementById('seedRequestNotesValue');
      const qtyInput = document.getElementById('seedReqQtyInput');
      const notesInput = document.getElementById('seedReqNotesInput');
      if (!form || !seedIdField || !qtyField || !notesField || !qtyInput || !notesInput) return;

      const qty = Number.parseFloat(qtyInput.value);
      if (pendingSeedRequest.seedId <= 0) {
        closeSeedRequestModal();
        return;
      }
      if (!Number.isFinite(qty) || qty <= 0) {
        window.alert('Please enter a valid requested quantity greater than zero.');
        qtyInput.focus();
        return;
      }

      seedIdField.value = String(pendingSeedRequest.seedId);
      qtyField.value = qty.toFixed(2);
      notesField.value = notesInput.value.trim();
      if (typeof form.requestSubmit === 'function') {
        if (pendingSubmitter && pendingSubmitter.form === form) {
          form.requestSubmit(pendingSubmitter);
        } else {
          form.requestSubmit();
        }
      } else {
        form.submit();
      }
    }

    function openSeedPreviewModal(seedName, seedUnit, availableQty) {
      const backdrop = document.getElementById('seedPreviewModalBackdrop');
      const nameEl = document.getElementById('seedPreviewName');
      const unitEl = document.getElementById('seedPreviewUnit');
      const availEl = document.getElementById('seedPreviewAvail');
      if (!backdrop) return;

      if (nameEl) nameEl.textContent = 'Seed: ' + String(seedName || '-');
      if (unitEl) unitEl.textContent = 'Unit: ' + String(seedUnit || '-');
      if (availEl) {
        const qty = Number.parseFloat(String(availableQty));
        const safeQty = Number.isFinite(qty) ? qty.toFixed(2) : '0.00';
        availEl.textContent = 'Available: ' + safeQty + ' ' + String(seedUnit || '').trim();
      }

      backdrop.style.display = 'flex';
    }

    function closeSeedPreviewModal() {
      const backdrop = document.getElementById('seedPreviewModalBackdrop');
      if (backdrop) backdrop.style.display = 'none';
    }

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') {
        closeSeedRequestModal();
        closeSeedCatalogModal();
        closeSeedPreviewModal();
      }
      if (event.key === 'Enter') {
        const seedBackdrop = document.getElementById('seedRequestModalBackdrop');
        if (seedBackdrop && seedBackdrop.style.display === 'flex') {
          event.preventDefault();
          submitSeedRequestModal();
        }
      }
    });

    // Click outside to close modals
    document.addEventListener('click', (event) => {
      const catalogBackdrop = document.getElementById('seedCatalogModalBackdrop');
      if (catalogBackdrop && event.target === catalogBackdrop) {
        closeSeedCatalogModal();
      }
      const requestBackdrop = document.getElementById('seedRequestModalBackdrop');
      if (requestBackdrop && event.target === requestBackdrop) {
        closeSeedRequestModal();
      }
      const previewBackdrop = document.getElementById('seedPreviewModalBackdrop');
      if (previewBackdrop && event.target === previewBackdrop) {
        closeSeedPreviewModal();
      }
    });

    function toggleNotifyDropdown(e) {
      e.stopPropagation();
      const dropdown = document.getElementById('notifyDropdown');
      if (!dropdown) return;
      const opening = !dropdown.classList.contains('active');
      dropdown.classList.toggle('active');
      if (opening) {
        // Mark all notifications as read when the dropdown is first opened
        fetch('../mark_notifications_read.php', { method: 'POST', credentials: 'same-origin' })
          .then(r => r.json())
          .then(data => {
            if (data.ok && data.updated > 0) {
              // Remove unread badge from bell button
              const badge = document.querySelector('.admin-notify-btn .badge');
              if (badge) badge.remove();
            }
          })
          .catch(() => {});
      }
    }

    // Event Details Toggle View Functionality
    const farmerEventData = {
      today: <?php echo json_encode(array_filter($upcoming_farmer_events, function($event) { 
        return date('Y-m-d', strtotime($event['activity_date'])) === date('Y-m-d'); 
      })); ?>,
      week: <?php echo json_encode(array_filter($upcoming_farmer_events, function($event) { 
        $eventDate = strtotime($event['activity_date']);
        return $eventDate >= strtotime('today') && $eventDate <= strtotime('+7 days'); 
      })); ?>,
      upcoming: <?php echo json_encode($upcoming_farmer_events); ?>,
      recent: <?php echo json_encode($recent_farmer_events); ?>
    };
    const farmerCalendarEventsByDate = <?php echo json_encode($event_calendar_events_by_date); ?>;
    const eventCalendarTodayDate = '<?php echo date('Y-m-d'); ?>';

    function navigateEventCalendar(monthStr) {
      try {
        const url = new URL(window.location.href);
        url.searchParams.set('event_month', monthStr);
        window.location.href = url.toString();
      } catch (e) {
        console.error('Error navigating calendar:', e);
      }
    }

    // Month selector state
    let monthSelectorState = {
      selectedYear: new Date().getFullYear(),
      selectedMonth: new Date().getMonth() + 1
    };

    function openEventCalendarMonthSelector() {
      try {
        const modal = document.getElementById('eventCalendarMonthSelector');
        const grid = document.getElementById('monthSelectorGrid');
        const yearDisplay = document.getElementById('monthSelectorYearDisplay');
        
        if (!modal || !grid || !yearDisplay) return;

        // Get current displayed month from URL
        const urlParams = new URLSearchParams(window.location.search);
        let currentMonth = urlParams.get('event_month');
        
        if (currentMonth) {
          const [year, month] = currentMonth.split('-');
          monthSelectorState.selectedYear = parseInt(year);
          monthSelectorState.selectedMonth = parseInt(month);
        } else {
          monthSelectorState.selectedYear = new Date().getFullYear();
          monthSelectorState.selectedMonth = new Date().getMonth() + 1;
        }

        // Update year display
        yearDisplay.textContent = monthSelectorState.selectedYear;

        // Populate month buttons
        populateMonthSelectorGrid();
        modal.classList.add('showing');
      } catch (e) {
        console.error('Error opening month selector:', e);
      }
    }

    function populateMonthSelectorGrid() {
      try {
        const grid = document.getElementById('monthSelectorGrid');
        if (!grid) return;

        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
                          'July', 'August', 'September', 'October', 'November', 'December'];
        
        grid.innerHTML = '';
        
        for (let month = 1; month <= 12; month++) {
          const btn = document.createElement('button');
          btn.type = 'button';
          btn.className = 'month-selector-btn';
          btn.textContent = monthNames[month - 1];
          
          // Highlight selected month
          if (month === monthSelectorState.selectedMonth) {
            btn.classList.add('active');
          }
          
          btn.onclick = () => {
            // Remove active class from all buttons
            document.querySelectorAll('.month-selector-btn').forEach(b => b.classList.remove('active'));
            // Add active class to clicked button
            btn.classList.add('active');
            // Update state
            monthSelectorState.selectedMonth = month;
          };
          
          grid.appendChild(btn);
        }
      } catch (e) {
        console.error('Error populating month grid:', e);
      }
    }

    function selectorPreviousYear() {
      try {
        monthSelectorState.selectedYear--;
        const yearDisplay = document.getElementById('monthSelectorYearDisplay');
        if (yearDisplay) {
          yearDisplay.textContent = monthSelectorState.selectedYear;
        }
      } catch (e) {
        console.error('Error decrementing year:', e);
      }
    }

    function selectorNextYear() {
      try {
        monthSelectorState.selectedYear++;
        const yearDisplay = document.getElementById('monthSelectorYearDisplay');
        if (yearDisplay) {
          yearDisplay.textContent = monthSelectorState.selectedYear;
        }
      } catch (e) {
        console.error('Error incrementing year:', e);
      }
    }

    function confirmMonthSelection() {
      try {
        const year = monthSelectorState.selectedYear;
        const month = String(monthSelectorState.selectedMonth).padStart(2, '0');
        const monthStr = year + '-' + month;
        navigateEventCalendar(monthStr);
      } catch (e) {
        console.error('Error confirming month selection:', e);
      }
    }

    function closeEventCalendarMonthSelector() {
      try {
        const modal = document.getElementById('eventCalendarMonthSelector');
        if (modal) {
          modal.classList.remove('showing');
        }
      } catch (e) {
        console.error('Error closing month selector:', e);
      }
    }

    function showEventDetailsForDay(dateStr) {
      const sidebarTitle = document.getElementById('eventsSidebarTitle');
      const sidebarDescription = document.getElementById('eventsSidebarDescription');
      const sidebarContent = document.getElementById('eventsSidebarContent');

      if (!sidebarTitle || !sidebarDescription || !sidebarContent) return;

      // Get all events for the selected date from the month map.
      const dayEvents = farmerCalendarEventsByDate[dateStr] || [];

      // Set title with date
      const dateObj = new Date(dateStr + 'T00:00:00');
      const formattedDate = dateObj.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
      sidebarTitle.textContent = 'Events on ' + formattedDate;
      sidebarDescription.textContent = dayEvents.length > 0
        ? 'Selected date schedule details.'
        : '';

      document.querySelectorAll('.events-calendar-grid .calendar-day').forEach((dayEl) => {
        dayEl.classList.remove('is-selected');
      });
      const selectedDay = document.querySelector('.events-calendar-grid .calendar-day[data-date="' + dateStr + '"]');
      if (selectedDay) {
        selectedDay.classList.add('is-selected');
      }

      // Build event details HTML
      let html = '';
      if (dayEvents.length === 0) {
        html = `
          <div class="events-day-empty">
            No events scheduled for this day.
          </div>
        `;
      } else {
        dayEvents.forEach((event) => {
          html += `
            <div class="events-day-detail-item">
              <div class="events-day-detail-title">${escapeHtml(event.title || 'Untitled Event')}</div>
              <div class="events-day-detail-row"><strong>Time</strong><span>${escapeHtml(event.time_label || event.activity_time || '-')}</span></div>
              <div class="events-day-detail-row"><strong>Category</strong><span>${escapeHtml(event.category || '-')}</span></div>
              <div class="events-day-detail-row"><strong>Location</strong><span>${escapeHtml(event.location || '-')}</span></div>
              <div class="events-day-detail-row"><strong>Coordinator</strong><span>${escapeHtml(event.coordinator || '-')}</span></div>
              <div class="events-day-detail-row"><strong>Date</strong><span>${escapeHtml(event.date_label || event.activity_date || '-')}</span></div>
              </div>
            </div>
          `;
        });
      }

      sidebarContent.innerHTML = html;
    }

    function closeEventDetailView() {
      const calendarHeader = document.getElementById('eventCalendarHeader');
      const calendarView = document.getElementById('eventCalendarView');
      const detailView = document.getElementById('eventDetailView');
      
      if (calendarHeader) calendarHeader.style.display = 'flex';
      if (calendarView) calendarView.style.display = 'block';
      if (detailView) detailView.style.display = 'none';
    }

    function toggleEventDetailsView(mode = null) {
      const calendarHeader = document.getElementById('eventCalendarHeader');
      const calendarView = document.getElementById('eventCalendarView');
      const tableView = document.getElementById('eventDetailedTableView');
      const tableBody = document.getElementById('eventTableBody');
      const tableTitle = document.getElementById('eventTableViewTitle');

      // If no mode is provided, toggle back to calendar
      if (mode === null) {
        if (calendarHeader) calendarHeader.style.display = 'flex';
        if (calendarView) calendarView.style.display = 'block';
        if (tableView) tableView.style.display = 'none';
        return;
      }

      // Get the events for this mode
      const events = farmerEventData[mode] || [];
      
      // Set title
      const titles = {
        today: 'My Events Today',
        week: 'My Events Next 7 Days',
        upcoming: 'My Upcoming Events',
        recent: 'My Completed Events'
      };
      if (tableTitle) tableTitle.textContent = titles[mode] || 'Events';

      // Build event rows
      let html = '';
      if (events && events.length > 0) {
        events.forEach(event => {
          html += `
            <tr>
              <td><strong>${escapeHtml(event.title || 'Untitled Event')}</strong><div style="font-size:0.8rem;color:#6b7280;margin-top:2px;">${escapeHtml(event.category || 'General')}</div></td>
              <td>${escapeHtml(event.date_label || event.activity_date || '-')}, ${escapeHtml(event.time_label || event.activity_time || '-')}</td>
              <td>${escapeHtml(event.category || '-')}</td>
              <td>${escapeHtml(event.location || '-')}</td>
              <td>${escapeHtml(event.coordinator || '-')}</td>
            </tr>
          `;
        });
      } else {
        html = '<tr><td colspan="5" class="table-muted">No events to display</td></tr>';
      }

      if (tableBody) {
        tableBody.innerHTML = html;
      }

      // Hide the header and calendar view, show table view
      if (calendarHeader) calendarHeader.style.display = 'none';
      if (calendarView) calendarView.style.display = 'none';
      if (tableView) tableView.style.display = 'block';
    }

    function escapeHtml(text) {
      const div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    const profileTrigger = document.getElementById('adminProfileTrigger');
    const profileDropdown = document.getElementById('adminProfileDropdown');

    if (profileTrigger) {
      profileTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        const isExpanded = profileTrigger.getAttribute('aria-expanded') === 'true';
        profileTrigger.setAttribute('aria-expanded', String(!isExpanded));
        if (profileDropdown) {
          profileDropdown.classList.toggle('active');
          profileDropdown.setAttribute('aria-hidden', String(isExpanded));
        }
      });
    }

    document.addEventListener('click', (event) => {
      const notifyDropdown = document.getElementById('notifyDropdown');
      const adminUserMenu = document.querySelector('.admin-user-menu');
      if (adminUserMenu && !adminUserMenu.contains(event.target)) {
        if (notifyDropdown && notifyDropdown.classList.contains('active')) {
          notifyDropdown.classList.remove('active');
        }
      }

      if (profileDropdown) {
        profileDropdown.classList.remove('active');
        profileDropdown.setAttribute('aria-hidden', 'true');
      }
      if (profileTrigger) profileTrigger.setAttribute('aria-expanded', 'false');
    });

    let initialSection = '<?php echo htmlspecialchars($active_section, ENT_QUOTES); ?>';
    try {
      const initialUrl = new URL(window.location.href);
      const urlSection = String(initialUrl.searchParams.get('section') || '').trim();
      if (urlSection !== '') {
        initialSection = urlSection;
      }
    } catch (e) {
      // ignore URL parsing errors and keep server-provided section
    }

    showSection(initialSection);

    if (!document.querySelector('.farmer-section.active')) {
      const profileFallback = document.getElementById('section-profile');
      const firstSectionFallback = document.querySelector('.farmer-section');
      if (profileFallback) {
        profileFallback.classList.add('active');
      } else if (firstSectionFallback) {
        firstSectionFallback.classList.add('active');
      }
    }
    renderIncomeTransparencyChart();
    window.addEventListener('resize', renderIncomeTransparencyChart);

    // Set min dates for rental date pickers
    (function() {
      const today = new Date().toISOString().split('T')[0];
      const startEl = document.getElementById('pageRentalStartDate');
      const endEl   = document.getElementById('pageRentalEndDate');
      if (startEl) {
        startEl.min = today;
        startEl.addEventListener('change', () => {
          if (endEl) {
            endEl.min = startEl.value || today;
            if (endEl.value && endEl.value < startEl.value) endEl.value = startEl.value;
          }
        });
      }
      if (endEl) endEl.min = today;
    })();

    const pageRentalForm = document.getElementById('pageRentalForm');
    if (pageRentalForm) {
      pageRentalForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const listingId = parseInt(document.getElementById('pageRentalListingId')?.value || '0', 10) || 0;
        const name = document.getElementById('pageRentalName')?.value || '';
        const owner = document.getElementById('pageRentalOwner')?.value || '';
        const dailyRate = parseFloat(document.getElementById('pageRentalDailyRate')?.value || '0') || 0;
        const startDate = document.getElementById('pageRentalStartDate')?.value || '';
        const endDate = document.getElementById('pageRentalEndDate')?.value || '';
        const note = document.getElementById('pageRentalNote')?.value || '';

        if (!listingId || !startDate || !endDate) {
          alert('Please complete all required rental fields.');
          return;
        }
        if (endDate < startDate) {
          alert('End Date cannot be before Start Date. Please check your selected dates.');
          return;
        }

        const submitBtn = pageRentalForm.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Submitting...';
        }

        fetch(RENTAL_API + '?action=submit_rentals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: [{
              listing_id: listingId,
              name,
              owner,
              quantity: 1,
              daily_rate: dailyRate,
              start_date: startDate,
              end_date: endDate,
              note
            }]
          })
        })
          .then((response) => response.json())
          .then((data) => {
            if (!data.success) {
              alert(data.message || 'Unable to submit rental request.');
              return;
            }
            alert('Rental request submitted successfully.');
            window.location.href = 'dashboard.php?section=rentals';
          })
          .catch(() => {
            alert('Connection error while submitting rental request.');
          })
          .finally(() => {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = '<i class="fas fa-calendar-check"></i> Submit Rental Request';
            }
          });
      });
    }

    if (document.querySelector('#section-machinery-reservations.active')) {
      loadMyMachineryRentals();
    }

    const todayCell = document.querySelector('.events-calendar-grid .calendar-day[data-date="' + eventCalendarTodayDate + '"]');
    if (todayCell) {
      showEventDetailsForDay(eventCalendarTodayDate);
    }
  </script>
  <div id="sfConfirmModal" class="sf-confirm-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sfConfirmTitle">
    <div class="sf-confirm-dialog" role="document">
      <h2 id="sfConfirmTitle">Confirm Submission</h2>
      <p id="sfConfirmMessage">Are you sure you want to continue?</p>
      <div class="sf-confirm-actions">
        <button type="button" class="btn-secondary" id="sfConfirmCancelBtn">Cancel</button>
        <button type="button" class="btn-primary" id="sfConfirmOkBtn">Continue</button>
      </div>
    </div>
  </div>

  <script>
    (function () {
      const modal = document.getElementById('sfConfirmModal');
      const messageEl = document.getElementById('sfConfirmMessage');
      const confirmBtn = document.getElementById('sfConfirmOkBtn');
      const cancelBtn = document.getElementById('sfConfirmCancelBtn');
      if (!modal || !messageEl || !confirmBtn || !cancelBtn) return;

      let pendingForm = null;
      let pendingSubmitter = null;

      function closeModal() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
      }

      function openModal(message, form, submitter) {
        pendingForm = form;
        pendingSubmitter = submitter || null;
        messageEl.textContent = message;
        modal.classList.add('is-visible');
        modal.setAttribute('aria-hidden', 'false');
        cancelBtn.focus();
      }

      confirmBtn.addEventListener('click', () => {
        if (!pendingForm) {
          closeModal();
          return;
        }

        const form = pendingForm;
        const submitter = pendingSubmitter;
        pendingForm = null;
        pendingSubmitter = null;
        form.dataset.sfConfirmArmed = '1';
        closeModal();

        if (typeof form.requestSubmit === 'function') {
          if (submitter && submitter.form === form) {
            form.requestSubmit(submitter);
          } else {
            form.requestSubmit();
          }
        } else {
          form.submit();
        }
      });

      cancelBtn.addEventListener('click', () => {
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      modal.addEventListener('click', (event) => {
        if (event.target !== modal) return;
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('is-visible')) {
          pendingForm = null;
          pendingSubmitter = null;
          closeModal();
        }
      });

      document.addEventListener('submit', (event) => {
        const form = event.target;
        if (!(form instanceof HTMLFormElement)) return;

        if (form.dataset.sfConfirmArmed === '1') {
          delete form.dataset.sfConfirmArmed;
          return;
        }

        if (form.getAttribute('data-skip-confirm') === 'true') {
          return;
        }

        const submitter = event.submitter || null;
        const message = (submitter && submitter.getAttribute('data-confirm-message'))
          || form.getAttribute('data-confirm-message')
          || 'Are you sure you want to continue with this submission?';

        event.preventDefault();
        event.stopImmediatePropagation();
        openModal(message, form, submitter);
      }, true);
    })();
  </script>
</body>
</html>
