<?php
// SmartFarm - Standalone API for Income Report (for mobile app)
// Place this file in your htdocs/smartfarm/farmer/ directory

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}


require_once '../config.php';

try {

    // Compute total income from all paid won bids and calculate dividends
    $total_income = 0.0;
    $verified_farmers = 0;
    $farmer_share = 0.0;
    $coop_share = 0.0;
    $dividend_per_farmer = 0.0;

    // Get total income from paid transactions in the current month (bids + livestock + machinery)
    $current_month = date('Y-m');
    $bids_income = 0.0;
    $livestock_income = 0.0;
    $machinery_income = 0.0;

    if ($stmt = $conn->prepare("SELECT IFNULL(SUM(b.bid_amount),0) AS total FROM bids b JOIN crops c ON c.crop_id = b.crop_id WHERE b.bid_status = 'won' AND c.payment_status = 'paid' AND DATE_FORMAT(c.payment_marked_at, '%Y-%m') = ?")) {
        $stmt->bind_param('s', $current_month);
        $stmt->execute();
        $bids_income = (float)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt->close();
    }
    if ($stmt = $conn->prepare("SELECT IFNULL(SUM(total_price),0) AS total FROM livestock_reservations WHERE payment_status = 'paid' AND status IN ('confirmed','ready','completed') AND DATE_FORMAT(payment_marked_at, '%Y-%m') = ?")) {
        $stmt->bind_param('s', $current_month);
        $stmt->execute();
        $livestock_income = (float)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt->close();
    }
    if ($stmt = $conn->prepare("SELECT IFNULL(SUM(total_cost),0) AS total FROM machinery_rentals WHERE payment_status = 'paid' AND DATE_FORMAT(payment_marked_at, '%Y-%m') = ?")) {
        $stmt->bind_param('s', $current_month);
        $stmt->execute();
        $machinery_income = (float)($stmt->get_result()->fetch_assoc()['total'] ?? 0);
        $stmt->close();
    }

    $total_income = $bids_income + $livestock_income + $machinery_income;

    // Get verified farmers
    if ($farmer_stmt = $conn->prepare("SELECT COUNT(*) AS verified_count FROM farmers WHERE farmer_is_verified = 1")) {
        $farmer_stmt->execute();
        $farmer_result = $farmer_stmt->get_result()->fetch_assoc();
        $verified_farmers = (int)($farmer_result['verified_count'] ?? 0);
        $farmer_stmt->close();
    }

    // Calculate shares
    $farmer_share = round($total_income * 0.70, 2); // 70% for farmers
    $coop_share = round($total_income * 0.30, 2);   // 30% for coop
    $dividend_per_farmer = $verified_farmers > 0 ? round($farmer_share / $verified_farmers, 2) : 0.00;

    http_response_code(200);
    echo json_encode([
        'success' => true,
        'data' => [
            'total_income' => $total_income,
            'verified_farmers' => $verified_farmers,
            'farmer_share' => $farmer_share,
            'coop_share' => $coop_share,
            'dividend_per_farmer' => $dividend_per_farmer
        ],
        'message' => 'Income report',
        'timestamp' => date('c')
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'data' => null,
        'message' => 'Server error: ' . $e->getMessage(),
        'timestamp' => date('c')
    ]);
    exit;
}
