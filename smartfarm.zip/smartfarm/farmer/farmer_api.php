<?php
/**
 * SmartFarm Farmer REST API
 * Endpoints for Android app access
 * All endpoints require valid JWT token via Authorization header
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../config.php';

// ============================================
// AUTHENTICATION & SECURITY
// ============================================

/**
 * Get JWT token from Authorization header
 */
function getBearerToken() {
    // Check getallheaders() first
    if (function_exists('getallheaders')) {
        $headers = getallheaders();
        if (isset($headers['Authorization'])) {
            $matches = [];
            if (preg_match('/Bearer\s+(.*)$/i', $headers['Authorization'], $matches)) {
                return trim($matches[1]);
            }
        }
        // Some servers lowercase the header name
        if (isset($headers['authorization'])) {
            $matches = [];
            if (preg_match('/Bearer\s+(.*)$/i', $headers['authorization'], $matches)) {
                return trim($matches[1]);
            }
        }
    }
    // Fallback for nginx / PHP-FPM where getallheaders() may miss Authorization
    if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
        $matches = [];
        if (preg_match('/Bearer\s+(.*)$/i', $_SERVER['HTTP_AUTHORIZATION'], $matches)) {
            return trim($matches[1]);
        }
    }
    if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
        $matches = [];
        if (preg_match('/Bearer\s+(.*)$/i', $_SERVER['REDIRECT_HTTP_AUTHORIZATION'], $matches)) {
            return trim($matches[1]);
        }
    }
    return null;
}

/**
 * Validate JWT token (simple implementation - use proper JWT library in production)
 * Returns farmer_id if valid, false otherwise
 */
function validateToken($token) {
    // For MVP: Store tokens in session/cache
    // In production, use Firebase or proper JWT library
    
    // For now, accept tokens that are farm_id_timestamp_hash format
    if (!$token || strlen($token) < 10) {
        return false;
    }
    
    // Extract farmer_id from token (format: farmer_{id}_timestamp_hash)
    if (preg_match('/farmer_(\d+)_/', $token, $matches)) {
        $farmer_id = (int)$matches[1];
        return $farmer_id > 0 ? $farmer_id : false;
    }
    
    return false;
}

/**
 * Generate simple JWT token (MVP version)
 */
function generateToken($farmer_id) {
    $timestamp = time();
    $hash = sha1($farmer_id . $timestamp . 'smartfarm_secret');
    return "farmer_{$farmer_id}_{$timestamp}_{$hash}";
}

/**
 * Send JSON response
 */
function sendResponse($success, $data = null, $message = '', $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode([
        'success' => $success,
        'data' => $data,
        'message' => $message,
        'timestamp' => date('c')
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

// ============================================
// ENDPOINTS
// ============================================

$request_method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path = str_replace('/smartfarm/farmer/farmer_api.php', '', $path);

// Routes
$action = $_GET['action'] ?? $_GET['endpoint'] ?? '';

try {
    switch ($action) {
        
        // ============================================
        // AUTH ENDPOINTS
        // ============================================
        
        case 'login':
            if ($request_method !== 'POST') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            $email = (string)($input['email'] ?? '');
            $password = (string)($input['password'] ?? '');
            
            if (!$email || !$password) {
                sendResponse(false, null, 'Email and password required', 400);
            }
            
            // Find user in users table
            $stmt = $conn->prepare("SELECT user_id, email, password, is_active FROM users WHERE email = ? LIMIT 1");
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if (!$user || !password_verify($password, $user['password'])) {
                sendResponse(false, null, 'Invalid credentials', 401);
            }

            if (isset($user['is_active']) && (int)$user['is_active'] !== 1) {
                sendResponse(false, null, 'Your account has been deactivated. Contact administrator.', 403);
            }
            
            $user_id = (int)$user['user_id'];
            
            // Get farmer details
            $farmer_stmt = $conn->prepare(
                "SELECT f.farmer_id, f.farmer_fullname, f.farmer_farm_name, f.farmer_is_verified 
                 FROM farmers f 
                 WHERE f.user_id = ? LIMIT 1"
            );
            if (!$farmer_stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $farmer_stmt->bind_param('i', $user_id);
            $farmer_stmt->execute();
            $farmer = $farmer_stmt->get_result()->fetch_assoc();
            $farmer_stmt->close();
            
            if (!$farmer) {
                sendResponse(false, null, 'Farmer profile not found', 404);
            }
            
            $farmer_id = (int)$farmer['farmer_id'];
            $token = generateToken($farmer_id);
            
            sendResponse(true, [
                'token' => $token,
                'farmer_id' => $farmer_id,
                'farmer_name' => (string)$farmer['farmer_fullname'],
                'farm_name' => (string)$farmer['farmer_farm_name'],
                'is_verified' => (int)$farmer['farmer_is_verified'] === 1,
                'email' => (string)$email
            ], 'Login successful');
            
            break;
            
        // ============================================
        // PROFILE ENDPOINTS
        // ============================================
        
        case 'profile':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            $stmt = $conn->prepare(
                "SELECT 
                    farmer_id, farmer_fullname, farmer_farm_name, farm_address, 
                    farmer_address, farmer_contact_number, farmer_id_type, 
                    farmer_is_verified, farmer_id_verification_status, 
                          farmer_created_at, u.email AS email
                 FROM farmers f
                 LEFT JOIN users u ON f.user_id = u.user_id
                 WHERE f.farmer_id = ? LIMIT 1"
            );
            
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('i', $farmer_id);
            $stmt->execute();
            $farmer = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if (!$farmer) {
                sendResponse(false, null, 'Profile not found', 404);
            }
            
            sendResponse(true, [
                'farmer_id' => (int)$farmer['farmer_id'],
                'name' => (string)$farmer['farmer_fullname'],
                'farm_name' => (string)$farmer['farmer_farm_name'],
                'farm_address' => (string)$farmer['farm_address'],
                'home_address' => (string)$farmer['farmer_address'],
                'contact' => (string)$farmer['farmer_contact_number'],
                'email' => (string)$farmer['email'],
                'is_verified' => (int)$farmer['farmer_is_verified'] === 1,
                'verification_status' => (string)$farmer['farmer_id_verification_status'],
                'member_since' => (string)$farmer['farmer_created_at']
            ], 'Profile retrieved');
            
            break;
            
        // ============================================
        // CROP ENDPOINTS
        // ============================================
        
        case 'crops':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            $stmt = $conn->prepare(
                "SELECT 
                    crop_id, crop_name, crop_description, crop_quantity, crop_unit, 
                    starting_price, crop_status, bidding_end_date, created_at,
                    (SELECT COUNT(*) FROM bids WHERE crop_id = crops.crop_id) AS bid_count,
                    (SELECT MAX(bid_amount) FROM bids WHERE crop_id = crops.crop_id) AS highest_bid
                 FROM crops 
                 WHERE farmer_id = ? 
                 ORDER BY created_at DESC"
            );
            
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('i', $farmer_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $crops = [];
            
            while ($row = $result->fetch_assoc()) {
                $crops[] = [
                    'crop_id' => (int)$row['crop_id'],
                    'name' => (string)$row['crop_name'],
                    'description' => (string)$row['crop_description'],
                    'quantity' => (int)$row['crop_quantity'],
                    'unit' => (string)$row['crop_unit'],
                    'starting_price' => (float)$row['starting_price'],
                    'status' => (string)$row['crop_status'],
                    'bidding_end_date' => (string)$row['bidding_end_date'],
                    'created_at' => (string)$row['created_at'],
                    'bid_count' => (int)$row['bid_count'],
                    'highest_bid' => $row['highest_bid'] ? (float)$row['highest_bid'] : 0
                ];
            }
            $stmt->close();
            
            sendResponse(true, ['crops' => $crops], 'Crops retrieved');
            
            break;
            
        case 'crop':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            $crop_id = (int)($_GET['crop_id'] ?? 0);
            if ($crop_id <= 0) {
                sendResponse(false, null, 'Crop ID required', 400);
            }
            
            $stmt = $conn->prepare(
                "SELECT 
                    crop_id, crop_name, crop_description, crop_quantity, crop_unit, 
                    starting_price, crop_status, bidding_end_date, created_at
                 FROM crops 
                 WHERE crop_id = ? AND farmer_id = ? LIMIT 1"
            );
            
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('ii', $crop_id, $farmer_id);
            $stmt->execute();
            $crop = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            
            if (!$crop) {
                sendResponse(false, null, 'Crop not found', 404);
            }
            
            // Get bids for this crop
            $bids_stmt = $conn->prepare(
                "SELECT bid_id, bid_amount, bid_date FROM bids WHERE crop_id = ? ORDER BY bid_amount DESC LIMIT 5"
            );
            $bids = [];
            if ($bids_stmt) {
                $bids_stmt->bind_param('i', $crop_id);
                $bids_stmt->execute();
                $bids_result = $bids_stmt->get_result();
                while ($bid = $bids_result->fetch_assoc()) {
                    $bids[] = [
                        'bid_id' => (int)$bid['bid_id'],
                        'amount' => (float)$bid['bid_amount'],
                        'date' => (string)$bid['bid_date']
                    ];
                }
                $bids_stmt->close();
            }
            
            sendResponse(true, [
                'crop' => [
                    'crop_id' => (int)$crop['crop_id'],
                    'name' => (string)$crop['crop_name'],
                    'description' => (string)$crop['crop_description'],
                    'quantity' => (int)$crop['crop_quantity'],
                    'unit' => (string)$crop['crop_unit'],
                    'starting_price' => (float)$crop['starting_price'],
                    'status' => (string)$crop['crop_status'],
                    'bidding_end_date' => (string)$crop['bidding_end_date'],
                    'created_at' => (string)$crop['created_at'],
                    'bids' => $bids
                ]
            ], 'Crop retrieved');
            
            break;

        case 'update-crop-quantity':
            if ($request_method !== 'POST') {
                sendResponse(false, null, 'Method not allowed', 405);
            }

            $input = json_decode(file_get_contents('php://input'), true);
            $crop_id = isset($input['crop_id'])     ? (int)$input['crop_id']       : 0;
            $add_qty = isset($input['add_quantity']) ? (float)$input['add_quantity'] : 0;

            if ($crop_id <= 0 || $add_qty <= 0) {
                sendResponse(false, null, 'Invalid crop_id or quantity', 400);
            }

            $check = $conn->prepare("SELECT crop_id, crop_quantity FROM crops WHERE crop_id = ? LIMIT 1");
            $check->bind_param('i', $crop_id);
            $check->execute();
            $row = $check->get_result()->fetch_assoc();
            $check->close();

            if (!$row) {
                sendResponse(false, null, 'Crop not found', 404);
            }

            $stmt = $conn->prepare("UPDATE crops SET crop_quantity = crop_quantity + ? WHERE crop_id = ?");
            $stmt->bind_param('di', $add_qty, $crop_id);

            if ($stmt->execute()) {
                $new_qty = (float)$row['crop_quantity'] + $add_qty;
                sendResponse(true, ['new_quantity' => $new_qty], 'Quantity updated');
            } else {
                sendResponse(false, null, 'Failed to update quantity', 500);
            }
            $stmt->close();
            break;

        // ============================================
        // SEED DISTRIBUTION ENDPOINTS
        // ============================================
        
        case 'seed-distributions':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            // Check if table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'seed_distributions'");
            if (!$table_check || $table_check->num_rows === 0) {
                sendResponse(true, ['distributions' => []], 'Seed distribution table not yet created');
            }
            
            $stmt = $conn->prepare(
                "SELECT 
                    distribution_id, seed_id, quantity_distributed, distribution_date, 
                    status, notes, created_by, created_at
                 FROM seed_distributions 
                 WHERE farmer_id = ? 
                 ORDER BY distribution_date DESC"
            );
            
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('i', $farmer_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $distributions = [];
            
            while ($row = $result->fetch_assoc()) {
                $distributions[] = [
                    'distribution_id' => (int)$row['distribution_id'],
                    'seed_id' => (int)$row['seed_id'],
                    'quantity' => (int)$row['quantity_distributed'],
                    'distribution_date' => (string)$row['distribution_date'],
                    'status' => (string)$row['status'],
                    'notes' => (string)$row['notes'],
                    'created_at' => (string)$row['created_at']
                ];
            }
            $stmt->close();
            
            sendResponse(true, ['distributions' => $distributions], 'Seed distributions retrieved');
            
            break;
            
        // ============================================
        // NOTIFICATION ENDPOINTS
        // ============================================
        
        case 'notifications':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            // Get user_id from farmer_id
            $user_stmt = $conn->prepare("SELECT user_id FROM farmers WHERE farmer_id = ? LIMIT 1");
            if (!$user_stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $user_stmt->bind_param('i', $farmer_id);
            $user_stmt->execute();
            $user = $user_stmt->get_result()->fetch_assoc();
            $user_stmt->close();
            
            if (!$user) {
                sendResponse(false, null, 'User not found', 404);
            }
            
            $user_id = (int)$user['user_id'];
            
            // Check if notification table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'user_notifications'");
            if (!$table_check || $table_check->num_rows === 0) {
                sendResponse(true, [
                    'notifications' => [],
                    'unread_count' => 0
                ], 'No notifications');
            }
            
            $stmt = $conn->prepare(
                "SELECT 
                    notification_id, notification_title, notification_message, 
                    created_at, is_read
                 FROM user_notifications 
                 WHERE user_id = ? 
                 ORDER BY created_at DESC 
                 LIMIT 50"
            );
            
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $notifications = [];
            $unread_count = 0;
            
            while ($row = $result->fetch_assoc()) {
                $is_read = (int)$row['is_read'] === 1;
                if (!$is_read) $unread_count++;
                
                $notifications[] = [
                    'notification_id' => (int)$row['notification_id'],
                    'title' => (string)$row['notification_title'],
                    'message' => (string)$row['notification_message'],
                    'created_at' => (string)$row['created_at'],
                    'is_read' => $is_read
                ];
            }
            $stmt->close();
            
            sendResponse(true, [
                'notifications' => $notifications,
                'unread_count' => $unread_count
            ], 'Notifications retrieved');
            
            break;
            
        case 'mark-notification-read':
            if ($request_method !== 'POST') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            $input = json_decode(file_get_contents('php://input'), true);
            $notification_id = (int)($input['notification_id'] ?? 0);
            
            if ($notification_id <= 0) {
                sendResponse(false, null, 'Notification ID required', 400);
            }
            
            $stmt = $conn->prepare("UPDATE user_notifications SET is_read = 1 WHERE notification_id = ?");
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            
            $stmt->bind_param('i', $notification_id);
            if ($stmt->execute()) {
                sendResponse(true, null, 'Notification marked as read');
            } else {
                sendResponse(false, null, 'Failed to update notification', 500);
            }
            
            break;
            
        // ============================================
        // MARKET PRICE ENDPOINTS
        // ============================================
        
        case 'market-prices':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }
            
            $token = getBearerToken();
            $farmer_id = validateToken($token);
            
            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }
            
            // Check if market_prices table exists
            $table_check = $conn->query("SHOW TABLES LIKE 'market_prices'");
            if (!$table_check || $table_check->num_rows === 0) {
                // Return sample market data if table doesn't exist
                sendResponse(true, [
                    'prices' => [
                        ['crop' => 'Rice', 'price_per_unit' => 25.00, 'unit' => 'kg', 'date' => date('c'), 'trend' => 'up'],
                        ['crop' => 'Corn', 'price_per_unit' => 18.50, 'unit' => 'kg', 'date' => date('c'), 'trend' => 'stable'],
                        ['crop' => 'Wheat', 'price_per_unit' => 22.00, 'unit' => 'kg', 'date' => date('c'), 'trend' => 'down']
                    ]
                ], 'Market prices retrieved');
            }
            
            $stmt = $conn->query(
                "SELECT crop_type, market_price, unit, recorded_date 
                 FROM market_prices 
                 ORDER BY recorded_date DESC 
                 LIMIT 20"
            );
            
            $prices = [];
            if ($stmt && $stmt->num_rows > 0) {
                while ($row = $stmt->fetch_assoc()) {
                    $prices[] = [
                        'crop' => (string)$row['crop_type'],
                        'price_per_unit' => (float)$row['market_price'],
                        'unit' => (string)$row['unit'],
                        'date' => (string)$row['recorded_date']
                    ];
                }
            }
            
            sendResponse(true, ['prices' => $prices], 'Market prices retrieved');
            
            break;
            
        // ============================================
        // MACHINERY RENTAL ENDPOINTS
        // ============================================

        case 'get-available-machinery':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }

            // Public endpoint — no token required to browse available listings

            // Ensure rental table exists
            $conn->query("CREATE TABLE IF NOT EXISTS machinery_rentals (
                rental_id INT NOT NULL AUTO_INCREMENT,
                rental_code VARCHAR(20) NOT NULL,
                equipment_name VARCHAR(255) NOT NULL,
                owner_name VARCHAR(255) NOT NULL,
                machinery_image LONGBLOB NULL,
                machinery_image_name VARCHAR(255) NULL,
                machinery_image_mime_type VARCHAR(50) NULL,
                renter_name VARCHAR(255) NOT NULL DEFAULT '',
                start_date DATE NOT NULL DEFAULT '2000-01-01',
                end_date DATE NOT NULL DEFAULT '2000-01-01',
                total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
                rental_status ENUM('pending','approved','in-rental','returned','cancelled') NOT NULL DEFAULT 'pending',
                payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
                payment_marked_at DATETIME NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (rental_id),
                UNIQUE KEY uniq_rental_code (rental_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $search = trim((string)($_GET['search'] ?? ''));
            $sql = "SELECT rental_id, equipment_name, owner_name, total_cost, rental_status
                    FROM machinery_rentals
                    WHERE (renter_name = '' OR renter_name IS NULL)
                      AND rental_status IN ('pending', 'approved')";
            if ($search !== '') {
                $sql .= " AND (equipment_name LIKE ? OR owner_name LIKE ?)";
            }
            $sql .= " ORDER BY created_at DESC, rental_id DESC";

            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            if ($search !== '') {
                $like = '%' . $search . '%';
                $stmt->bind_param('ss', $like, $like);
            }
            $stmt->execute();
            $result = $stmt->get_result();
            $items = [];
            while ($row = $result->fetch_assoc()) {
                $items[] = [
                    'rental_id'      => (int)$row['rental_id'],
                    'equipment_name' => (string)$row['equipment_name'],
                    'owner_name'     => (string)$row['owner_name'],
                    'daily_rate'     => (float)$row['total_cost'],
                    'rental_status'  => (string)$row['rental_status'],
                ];
            }
            $stmt->close();
            sendResponse(true, ['items' => $items], 'Available machinery retrieved');
            break;

        case 'get-my-rentals':
            if ($request_method !== 'GET') {
                sendResponse(false, null, 'Method not allowed', 405);
            }

            $token = getBearerToken();
            $farmer_id = validateToken($token);

            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }

            $name_stmt = $conn->prepare("SELECT farmer_fullname FROM farmers WHERE farmer_id = ? LIMIT 1");
            if (!$name_stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            $name_stmt->bind_param('i', $farmer_id);
            $name_stmt->execute();
            $name_row = $name_stmt->get_result()->fetch_assoc();
            $name_stmt->close();

            $farmer_name = trim((string)($name_row['farmer_fullname'] ?? ''));
            if ($farmer_name === '') {
                sendResponse(true, ['rentals' => []], 'No rentals');
            }

            // Check table exists
            $tbl = $conn->query("SHOW TABLES LIKE 'machinery_rentals'");
            if (!$tbl || $tbl->num_rows === 0) {
                sendResponse(true, ['rentals' => []], 'No rentals yet');
            }

            $stmt = $conn->prepare(
                "SELECT rental_id, rental_code, equipment_name, owner_name,
                        start_date, end_date, total_cost, rental_status, payment_status, created_at
                 FROM machinery_rentals
                 WHERE renter_name = ?
                 ORDER BY created_at DESC, rental_id DESC"
            );
            if (!$stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            $stmt->bind_param('s', $farmer_name);
            $stmt->execute();
            $result = $stmt->get_result();
            $rentals = [];
            while ($row = $result->fetch_assoc()) {
                $rentals[] = [
                    'rental_id'      => (int)$row['rental_id'],
                    'rental_code'    => (string)$row['rental_code'],
                    'equipment_name' => (string)$row['equipment_name'],
                    'owner_name'     => (string)$row['owner_name'],
                    'start_date'     => (string)$row['start_date'],
                    'end_date'       => (string)$row['end_date'],
                    'total_cost'     => (float)$row['total_cost'],
                    'rental_status'  => (string)$row['rental_status'],
                    'payment_status' => (string)$row['payment_status'],
                    'created_at'     => (string)$row['created_at'],
                ];
            }
            $stmt->close();
            sendResponse(true, ['rentals' => $rentals], 'Rentals retrieved');
            break;

        case 'submit-rental':
            if ($request_method !== 'POST') {
                sendResponse(false, null, 'Method not allowed', 405);
            }

            $token = getBearerToken();
            $farmer_id = validateToken($token);

            if (!$farmer_id) {
                sendResponse(false, null, 'Unauthorized', 401);
            }

            // Get farmer name and user_id
            $fn_stmt = $conn->prepare(
                "SELECT f.farmer_fullname, f.user_id, f.farmer_is_verified, f.farmer_id_verification_status
                 FROM farmers f WHERE f.farmer_id = ? LIMIT 1"
            );
            if (!$fn_stmt) {
                sendResponse(false, null, 'Database error', 500);
            }
            $fn_stmt->bind_param('i', $farmer_id);
            $fn_stmt->execute();
            $fn_row = $fn_stmt->get_result()->fetch_assoc();
            $fn_stmt->close();

            if (!$fn_row) {
                sendResponse(false, null, 'Farmer profile not found', 404);
            }

            $is_verified = ((int)($fn_row['farmer_is_verified'] ?? 0) === 1)
                && (strtolower((string)($fn_row['farmer_id_verification_status'] ?? '')) === 'approved');
            if (!$is_verified) {
                sendResponse(false, null, 'Your account is pending admin approval.', 403);
            }

            $farmer_name = trim((string)($fn_row['farmer_fullname'] ?? ''));
            $farmer_user_id = (int)($fn_row['user_id'] ?? 0);

            // Ensure table exists
            $conn->query("CREATE TABLE IF NOT EXISTS machinery_rentals (
                rental_id INT NOT NULL AUTO_INCREMENT,
                rental_code VARCHAR(20) NOT NULL,
                equipment_name VARCHAR(255) NOT NULL,
                owner_name VARCHAR(255) NOT NULL,
                machinery_image LONGBLOB NULL,
                machinery_image_name VARCHAR(255) NULL,
                machinery_image_mime_type VARCHAR(50) NULL,
                renter_name VARCHAR(255) NOT NULL DEFAULT '',
                start_date DATE NOT NULL DEFAULT '2000-01-01',
                end_date DATE NOT NULL DEFAULT '2000-01-01',
                total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
                rental_status ENUM('pending','approved','in-rental','returned','cancelled') NOT NULL DEFAULT 'pending',
                payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
                payment_marked_at DATETIME NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (rental_id),
                UNIQUE KEY uniq_rental_code (rental_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $input = json_decode(file_get_contents('php://input'), true);
            $listing_id = (int)($input['listing_id'] ?? 0);
            $start_date  = trim((string)($input['start_date'] ?? ''));
            $end_date    = trim((string)($input['end_date'] ?? ''));

            if ($start_date === '' || $end_date === '') {
                sendResponse(false, null, 'Start and end dates are required', 400);
            }

            $start_ts = strtotime($start_date);
            $end_ts   = strtotime($end_date);
            if ($start_ts === false || $end_ts === false || $end_ts < $start_ts) {
                sendResponse(false, null, 'Invalid date range', 400);
            }

            $equipment_name = '';
            $owner_name     = '';
            $daily_rate     = 0.0;
            $machinery_image = null;
            $machinery_image_name = null;
            $machinery_image_mime = null;

            if ($listing_id > 0) {
                $src = $conn->prepare(
                    "SELECT equipment_name, owner_name, total_cost, machinery_image, machinery_image_name, machinery_image_mime_type
                     FROM machinery_rentals
                     WHERE rental_id = ?
                       AND (renter_name = '' OR renter_name IS NULL)
                       AND rental_status IN ('pending', 'approved')
                     LIMIT 1"
                );
                if ($src) {
                    $src->bind_param('i', $listing_id);
                    $src->execute();
                    $src_row = $src->get_result()->fetch_assoc();
                    $src->close();
                    if ($src_row) {
                        $equipment_name      = trim((string)$src_row['equipment_name']);
                        $owner_name          = trim((string)$src_row['owner_name']);
                        $daily_rate          = (float)$src_row['total_cost'];
                        $machinery_image     = $src_row['machinery_image'] ?? null;
                        $machinery_image_name = $src_row['machinery_image_name'] ?? null;
                        $machinery_image_mime = $src_row['machinery_image_mime_type'] ?? null;
                    }
                }
            }

            // Fallback to posted values if listing not found
            if ($equipment_name === '') $equipment_name = trim((string)($input['equipment_name'] ?? ''));
            if ($owner_name === '')     $owner_name     = trim((string)($input['owner_name'] ?? ''));
            if ($daily_rate <= 0)      $daily_rate     = (float)($input['daily_rate'] ?? 0);

            if ($equipment_name === '' || $owner_name === '' || $daily_rate <= 0) {
                sendResponse(false, null, 'Incomplete machinery details', 400);
            }

            $days = (int)floor(($end_ts - $start_ts) / 86400) + 1;
            if ($days < 1) $days = 1;
            $total_cost = $daily_rate * $days;

            // Conflict check
            $chk = $conn->prepare(
                "SELECT rental_id FROM machinery_rentals
                 WHERE equipment_name = ? AND owner_name = ?
                   AND rental_status IN ('pending','approved','in-rental')
                   AND NOT (end_date < ? OR start_date > ?)
                 LIMIT 1"
            );
            if ($chk) {
                $chk->bind_param('ssss', $equipment_name, $owner_name, $start_date, $end_date);
                $chk->execute();
                $chk_row = $chk->get_result()->fetch_assoc();
                $chk->close();
                if ($chk_row) {
                    sendResponse(false, null, 'This equipment is already booked for the selected dates.', 409);
                }
            }

            // Generate rental code
            $nxt = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS nxt FROM machinery_rentals");
            $next_id = 1;
            if ($nxt) {
                $next_row = $nxt->fetch_assoc();
                $next_id = (int)($next_row['nxt'] ?? 1);
            }
            $rental_code = 'RNT' . str_pad((string)$next_id, 4, '0', STR_PAD_LEFT);

            $ins = $conn->prepare(
                "INSERT INTO machinery_rentals
                 (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type,
                  renter_name, start_date, end_date, total_cost, rental_status, payment_status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'unpaid')"
            );
            if (!$ins) {
                sendResponse(false, null, 'Unable to prepare rental', 500);
            }

            $ins->bind_param(
                'sssssssssd',
                $rental_code,
                $equipment_name,
                $owner_name,
                $machinery_image,
                $machinery_image_name,
                $machinery_image_mime,
                $farmer_name,
                $start_date,
                $end_date,
                $total_cost
            );

            if (!$ins->execute()) {
                $ins->close();
                sendResponse(false, null, 'Failed to submit rental request', 500);
            }
            $ins->close();

            // Push notifications
            if ($farmer_user_id > 0) {
                pushUserNotification(
                    $conn,
                    $farmer_user_id,
                    'Rental request submitted',
                    'Your machinery rental request for ' . $equipment_name . ' has been submitted.',
                    'rental_submitted',
                    null
                );
            }
            pushNotificationToRole(
                $conn,
                'admin',
                'New machinery rental request',
                $farmer_name . ' submitted a rental request for ' . $equipment_name . '.',
                'rental_submission',
                null
            );

            sendResponse(true, [
                'rental_code' => $rental_code,
                'total_cost'  => $total_cost,
                'days'        => $days,
            ], 'Rental request submitted successfully.');
            break;

        // ============================================
        // HEALTH CHECK
        // ============================================
        
        case 'health':
            sendResponse(true, ['status' => 'OK'], 'API is running');
            break;
        
        // ============================================
        // EVENTS
        // ============================================
        
        case 'get-events':
            // Public endpoint - no auth required
            // Returns events targeted at farmers from scheduled_activities table
            $check = $conn->query("SHOW TABLES LIKE 'scheduled_activities'");
            if (!$check || $check->num_rows === 0) {
                sendResponse(true, [], 'No events available');
            }
            
            $date_filter = isset($_GET['date']) ? trim($_GET['date']) : null;
            
            if ($date_filter !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_filter)) {
                sendResponse(false, null, 'Invalid date format. Use YYYY-MM-DD', 400);
            }
            
            if ($date_filter !== null) {
                $stmt = $conn->prepare(
                    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator, message
                     FROM scheduled_activities
                     WHERE target_farmer = 1 AND activity_date = ?
                     ORDER BY activity_time ASC, activity_id ASC"
                );
                if (!$stmt) { sendResponse(false, null, 'Database error', 500); }
                $stmt->bind_param('s', $date_filter);
            } else {
                $stmt = $conn->prepare(
                    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator, message
                     FROM scheduled_activities
                     WHERE target_farmer = 1
                     ORDER BY activity_date ASC, activity_time ASC, activity_id ASC"
                );
                if (!$stmt) { sendResponse(false, null, 'Database error', 500); }
            }
            
            $stmt->execute();
            $result = $stmt->get_result();
            $events = [];
            while ($row = $result->fetch_assoc()) {
                $time_str = (string)($row['activity_time'] ?? '');
                $time_label = '';
                if ($time_str !== '' && $time_str !== '00:00:00') {
                    $ts = strtotime($time_str);
                    if ($ts !== false) {
                        $time_label = date('h:i A', $ts);
                    }
                }
                $events[] = [
                    'id'          => (int)($row['activity_id'] ?? 0),
                    'title'       => (string)($row['title'] ?? ''),
                    'category'    => (string)($row['category'] ?? ''),
                    'date'        => (string)($row['activity_date'] ?? ''),
                    'time'        => $time_label,
                    'location'    => (string)($row['location'] ?? ''),
                    'coordinator' => (string)($row['coordinator'] ?? ''),
                    'message'     => (string)($row['message'] ?? ''),
                ];
            }
            $stmt->close();
            sendResponse(true, $events, 'Events loaded');
            break;
            
        default:
            sendResponse(false, null, 'Unknown action: ' . $action, 400);
    }
    
} catch (Exception $e) {
    sendResponse(false, null, 'Server error: ' . $e->getMessage(), 500);
}
