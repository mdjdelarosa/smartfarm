<?php
$crop_id = (int)($_GET['crop_id'] ?? 0);
header('Location: dashboard.php?section=update-crop-quantity&crop_id=' . $crop_id);
exit;
