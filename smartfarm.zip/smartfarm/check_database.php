<?php
/**
 * Database Structure Checker
 * Run this to see your actual table structure
 */

require 'config.php';

echo "<pre style='font-family: monospace; background: #f5f5f5; padding: 20px; border-radius: 8px;'>";

// Check admins table
echo "=== ADMINS TABLE STRUCTURE ===\n";
$query = "DESCRIBE admins";
$result = $conn->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ") - " . ($row['Null'] === 'NO' ? 'NOT NULL' : 'NULL') . "\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

echo "\n=== FARMERS TABLE STRUCTURE ===\n";
$query = "DESCRIBE farmers";
$result = $conn->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

echo "\n=== CLIENTS TABLE STRUCTURE ===\n";
$query = "DESCRIBE clients";
$result = $conn->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        echo $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "Error: " . $conn->error . "\n";
}

echo "</pre>";
echo "<p style='margin-top: 20px;'><strong>After checking this, let me know the admins table column names and I'll fix create_admin.php</strong></p>";
?>
