<?php
require 'config.php';

/*
 * Insert historical livestock reservations (Sep 2025 – Apr 2026)
 * Status: completed + paid  |  Stock deducted per completed reservation
 *
 * Client IDs: Juan=1, Maria=2, Carlo=3, Angela=4, Mark=5, Christine=6, Joshua=7
 * Products: Carabao=1(60k), Cow=2(55k), Pig=3(12k), Goat=4(5k), Chicken=5(250),
 *           Duck=6(300), Sheep=7(7k), Horse=8(80k), Turkey=9(1.5k), Rabbit=10(800)
 */

// [client_id, product_id, qty, unit_price, preferred_date, notes, reserved_at, completed_at, paid_at]
$reservations = [
    // Oct 2025
    [1, 5,  2,   250.00, '2025-10-12', 'For backyard poultry',           '2025-10-08 09:00:00', '2025-10-15 14:00:00', '2025-10-15 14:30:00'],
    [2, 4,  1,  5000.00, '2025-10-25', 'Goat for family',                '2025-10-20 10:00:00', '2025-10-28 11:00:00', '2025-10-28 11:30:00'],
    // Nov 2025
    [3, 6,  3,   300.00, '2025-11-08', 'Duck farming starter',           '2025-11-03 08:30:00', '2025-11-10 13:00:00', '2025-11-10 13:30:00'],
    [4, 3,  1, 12000.00, '2025-11-20', 'Pig for lechon next month',      '2025-11-14 09:00:00', '2025-11-22 10:00:00', '2025-11-22 10:30:00'],
    // Dec 2025
    [5, 10, 5,   800.00, '2025-12-03', 'Rabbit breeding pair + extras',  '2025-11-28 10:00:00', '2025-12-05 14:00:00', '2025-12-05 14:30:00'],
    [6, 5,  4,   250.00, '2025-12-15', 'Chicken for Noche Buena',        '2025-12-10 09:30:00', '2025-12-18 11:00:00', '2025-12-18 11:30:00'],
    // Jan 2026
    [7, 4,  1,  5000.00, '2026-01-08', 'Goat for family farm',           '2026-01-03 09:00:00', '2026-01-10 13:00:00', '2026-01-10 13:30:00'],
    [1, 9,  3,  1500.00, '2026-01-22', '3 turkeys for small farm',       '2026-01-17 10:00:00', '2026-01-24 14:00:00', '2026-01-24 14:30:00'],
    // Feb 2026
    [2, 6,  2,   300.00, '2026-02-04', 'Additional ducks',               '2026-01-30 09:00:00', '2026-02-06 11:00:00', '2026-02-06 11:30:00'],
    [3, 7,  1,  7000.00, '2026-02-18', 'Sheep for wool production',      '2026-02-13 10:00:00', '2026-02-20 13:00:00', '2026-02-20 13:30:00'],
    // Mar 2026
    [4, 10, 3,   800.00, '2026-03-06', 'Rabbit for breeding',            '2026-03-01 09:00:00', '2026-03-08 14:00:00', '2026-03-08 14:30:00'],
    // Apr 2026 (for monthly dividend reflection)
    [5, 5,  5,   250.00, '2026-04-01', 'Chicken flock expansion',        '2026-03-27 09:00:00', '2026-04-03 11:00:00', '2026-04-03 11:30:00'],
    [7, 9,  2,  1500.00, '2026-04-08', '2 turkeys for small farm',       '2026-04-03 10:00:00', '2026-04-10 13:00:00', '2026-04-10 13:30:00'],
    [6, 3,  1, 12000.00, '2026-04-13', 'Pig for cooperative farm',       '2026-04-08 09:30:00', '2026-04-14 14:00:00', '2026-04-14 14:30:00'],
];

$stmt = $conn->prepare(
    "INSERT INTO livestock_reservations
        (client_id, product_id, quantity, unit_price, total_price, preferred_date, notes,
         status, admin_notes, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'completed', 'Picked up and payment received.', 'paid', ?, ?, ?)"
);
// 10 ? placeholders: i i i d d s s s s s
// client_id(i) product_id(i) qty(i) unit_price(d) total_price(d) preferred_date(s) notes(s) paid_at(s) reserved_at(s) completed_at(s)

$upd_stock = $conn->prepare(
    "UPDATE livestock_products SET stock = stock - ? WHERE product_id = ? AND stock >= ?"
);

// Track total deductions per product
$deductions = [];

$conn->begin_transaction();
try {
    foreach ($reservations as $idx => [$client_id, $product_id, $qty, $unit_price, $preferred_date, $notes, $reserved_at, $completed_at, $paid_at]) {
        $total_price = $qty * $unit_price;

        $stmt->bind_param('iiiddsssss',
            $client_id, $product_id, $qty,
            $unit_price, $total_price,
            $preferred_date, $notes,
            $paid_at, $reserved_at, $completed_at
        );
        if (!$stmt->execute()) throw new Exception("Row $idx insert failed: " . $stmt->error);

        $rid = $conn->insert_id;

        // Deduct stock
        $upd_stock->bind_param('iii', $qty, $product_id, $qty);
        $upd_stock->execute();
        if ($upd_stock->affected_rows <= 0) throw new Exception("Insufficient stock for product_id=$product_id (need $qty)");

        $deductions[$product_id] = ($deductions[$product_id] ?? 0) + $qty;
        echo "Reservation #$rid: client=$client_id product=$product_id qty=$qty total=P$total_price paid=$paid_at\n";
    }

    $conn->commit();
    echo "\nAll reservations inserted successfully.\n";
} catch (Exception $e) {
    $conn->rollback();
    echo "FAILED: " . $e->getMessage() . "\n";
    exit(1);
}

$stmt->close();
$upd_stock->close();

echo "\nCurrent livestock stock:\n";
$r = $conn->query("SELECT product_id, product_name, price, stock FROM livestock_products ORDER BY product_id");
while ($row = $r->fetch_assoc()) {
    echo "  [{$row['product_id']}] {$row['product_name']}: {$row['stock']} remaining @ P{$row['price']}\n";
}
