<?php
// Test connection and check for admin accounts
require 'config.php';

echo "<h2>SmartFarm Diagnostic Test</h2>";

// Test database connection
echo "<h3>1. Database Connection:</h3>";
if ($conn->connect_error) {
    echo "<p style='color:red;'><strong>ERROR:</strong> Connection failed - " . $conn->connect_error . "</p>";
} else {
    echo "<p style='color:green;'><strong>SUCCESS:</strong> Database connected</p>";
}

// Check admin accounts
echo "<h3>2. Admin Accounts in Database:</h3>";
$query = "SELECT admin_id, fullname, email, is_active FROM admins";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Active</th></tr>";
    while ($admin = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $admin['admin_id'] . "</td>";
        echo "<td>" . $admin['fullname'] . "</td>";
        echo "<td>" . $admin['email'] . "</td>";
        echo "<td>" . ($admin['is_active'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:orange;'><strong>WARNING:</strong> No admin accounts found. You need to create one.</p>";
}

// Check farmers and clients
echo "<h3>3. Account Summary:</h3>";
$farmers = $conn->query("SELECT COUNT(*) as count FROM farmers")->fetch_assoc()['count'];
$clients = $conn->query("SELECT COUNT(*) as count FROM clients")->fetch_assoc()['count'];
$admins = $conn->query("SELECT COUNT(*) as count FROM admins")->fetch_assoc()['count'];
echo "<p>Admins: " . $admins . " | Farmers: " . $farmers . " | Clients: " . $clients . "</p>";

// Create test admin if none exist
if ($admins == 0) {
    echo "<h3>4. Creating Test Admin Account:</h3>";
    $test_email = "admin@smartfarm.local";
    $test_name = "Administrator";
    $test_password = "TestPass123!"; // Example password
    
    echo "<p><strong>Creating account:</strong></p>";
    echo "<ul>";
    echo "<li>Email: " . $test_email . "</li>";
    echo "<li>Name: " . $test_name . "</li>";
    echo "<li>Password: " . $test_password . "</li>";
    echo "</ul>";
    
    // Check if email already exists
    $check = $conn->query("SELECT admin_id FROM admins WHERE email = '$test_email'");
    if ($check && $check->num_rows == 0) {
        $hashed_pwd = password_hash($test_password, PASSWORD_BCRYPT, ['cost' => 12]);
        $insert_query = "INSERT INTO admins (email, password, fullname, is_active) VALUES ('$test_email', '$hashed_pwd', '$test_name', 1)";
        if ($conn->query($insert_query)) {
            echo "<p style='color:green;'><strong>SUCCESS:</strong> Admin account created!</p>";
            echo "<p><strong>You can now login with:</strong></p>";
            echo "<ul>";
            echo "<li>Email: " . $test_email . "</li>";
            echo "<li>Password: " . $test_password . "</li>";
            echo "</ul>";
        } else {
            echo "<p style='color:red;'><strong>ERROR:</strong> " . $conn->error . "</p>";
        }
    } else {
        echo "<p style='color:orange;'>Admin account already exists with this email</p>";
    }
}

$conn->close();
?>

<hr>
<p><a href="login.php">← Back to Login</a></p>
