# Login System - Design Analysis & Improvement

## Current System vs Improved System

### ❌ CURRENT APPROACH (Sequential Table Checking)

```
User enters email → Login checks:
1. Is user in admins table? 
   → Yes = Admin Login
   → No = Continue...
2. Is user in farmers table?
   → Yes = Farmer Login
   → No = Continue...
3. Is user in clients table?
   → Yes = Client Login
   → No = User not found
```

**Problems:**
- **Multiple queries** - 3 queries worst case
- **Email must be unique globally** - across all 3 tables
- **Hard to scale** - add new role = add new query
- **Not maintainable** - code is long and repetitive
- **Inefficient** - sequential checks waste time

---

### ✅ IMPROVED APPROACH (Unified Users Table)

```
User enters email → Login checks:
1. Query unified users table with email
   → Found = Get role from 'role' column
   → Not found = User not found
2. Fetch role-specific data (admin, farmer, or client)
```

**Benefits:**
- **Single query** - Only 1 query to find user (vs 3)
- **Email unique once** - Only unique in users table
- **Easy to scale** - Add new roles without changing login logic
- **Maintainable** - Clean, simple code
- **Efficient** - Faster lookups, better indexing

---

## Database Design Comparison

### Current Design
```
admins table:
├── admin_id
├── email ← UNIQUE (but only in this table)
├── password
└── fullname

farmers table:
├── farmer_id
├── farmer_email ← UNIQUE (but only in this table)
├── farmer_password
└── farmer_fullname

clients table:
├── client_id
├── client_email ← UNIQUE (but only in this table)
├── client_password
└── client_fullname
```

**Issue:** If emails aren't globally unique, you could theoretically have the same email in multiple tables, which breaks the login logic.

---

### Improved Design
```
users table (NEW - Central Registry):
├── user_id ← PRIMARY KEY
├── email ← GLOBALLY UNIQUE
├── password
├── role ← ENUM('admin','farmer','client')
└── is_active

admins table:
├── admin_id
├── user_id ← FOREIGN KEY to users
└── fullname (admin-specific data)

farmers table:
├── farmer_id
├── user_id ← FOREIGN KEY to users
├── farmer_fullname
├── farm_name
└── (farmer-specific data)

clients table:
├── client_id
├── user_id ← FOREIGN KEY to users
├── client_fullname
└── (client-specific data)
```

**Advantage:** Email is globally unique in ONE place, role is explicit, relationships are clear.

---

## How the System Recognizes the Role

### Current System
```php
// Check each table until user is found
$query = "SELECT * FROM admins WHERE email = ?";  // Query 1
if (found) { $role = 'admin'; }
else {
    $query = "SELECT * FROM farmers WHERE farmer_email = ?";  // Query 2
    if (found) { $role = 'farmer'; }
    else {
        $query = "SELECT * FROM clients WHERE client_email = ?";  // Query 3
        if (found) { $role = 'client'; }
    }
}
```

### Improved System
```php
// Single unified query
$query = "SELECT role FROM users WHERE email = ?";  // Only 1 query!
$result = fetch();
$role = $result['role'];  // Already know the role!
```

---

## Migration Steps (If You Want to Upgrade)

### Option 1: Use New System Going Forward
1. Use `database_sql_improved.sql` for new installations
2. Use `login_process_improved.php` for login logic
3. Keep old system as reference

### Option 2: Migrate Current Data
If you already have data in current tables:

```sql
-- Step 1: Create new users table
CREATE TABLE users (...);

-- Step 2: Migrate admin data
INSERT INTO users (email, password, role, is_active)
SELECT email, password, 'admin', is_active FROM admins;

-- Step 3: Add user_id to admin records
ALTER TABLE admins ADD COLUMN user_id INT;
UPDATE admins SET user_id = (SELECT user_id FROM users WHERE users.email = admins.email);

-- Similar steps for farmers and clients...
```

---

## Recommendation

**For your current system:** The sequential checking approach works fine since it enforces email uniqueness globally. However, the **improved design is recommended** because it:

1. **Makes role detection explicit** - The role is stored in the database, not inferred from which table the user is in
2. **Slightly faster** - 1 query instead of 3
3. **Cleaner code** - Login logic is simpler
4. **Better scalability** - Easy to add new roles later
5. **Industry standard** - This is how most systems handle multiple user roles

---

## Answer to Your Question

> "How would the system recognize the role of the user logging in?"

**Current Answer:** The system tries each table (admin → farmer → client) until it finds the user. The table it's found in indicates the role.

**Better Answer:** The system queries a unified users table that explicitly stores the role. This is faster, safer, and more maintainable.

Both work, but the unified approach is superior for larger systems.
