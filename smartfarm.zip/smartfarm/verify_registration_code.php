<?php
// Confirms the code sent by send_registration_code.php. On success, flags
// the session as pre-verified so client_register_process.php /
// farmer_register_process.php will allow the final registration to proceed.

require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$code = trim($_POST['code'] ?? '');

if ($code === '') {
    die(json_encode(['success' => false, 'message' => 'Please enter the code you received.']));
}

if (empty($_SESSION['reg_verify_code']) || empty($_SESSION['reg_verify_expires'])) {
    die(json_encode(['success' => false, 'message' => 'No verification code was sent. Please request a new one.']));
}

if (time() > (int)$_SESSION['reg_verify_expires']) {
    unset($_SESSION['reg_verify_code'], $_SESSION['reg_verify_expires'], $_SESSION['reg_verify_passed']);
    die(json_encode(['success' => false, 'message' => 'This code has expired. Please request a new one.']));
}

if (!hash_equals((string)$_SESSION['reg_verify_code'], $code)) {
    die(json_encode(['success' => false, 'message' => 'Incorrect code. Please try again.']));
}

$_SESSION['reg_verify_passed'] = true;

echo json_encode([
    'success' => true,
    'message' => 'Verified! You can now finish creating your account.',
]);
