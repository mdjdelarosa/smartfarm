<?php
require_once '../config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

header('Content-Type: application/json');

// Check if user is logged in as client
$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if (!isset($_SESSION['user_id']) || $sessionRole !== 'client') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit;
}

$user_id = (int)($_SESSION['user_id'] ?? 0);
$client_access_stmt = $conn->prepare(
    "SELECT client_id, client_is_verified, client_id_verification_status
     FROM clients
     WHERE user_id = ?
     LIMIT 1"
);
if (!$client_access_stmt) {
    echo json_encode(['success' => false, 'message' => 'Unable to validate client access']);
    exit;
}

$client_access_stmt->bind_param('i', $user_id);
$client_access_stmt->execute();
$client_row = $client_access_stmt->get_result()->fetch_assoc();
$client_access_stmt->close();

if (!$client_row) {
    echo json_encode(['success' => false, 'message' => 'Client profile not found']);
    exit;
}

$client_id = (int)($client_row['client_id'] ?? 0);
$client_verified = ((int)($client_row['client_is_verified'] ?? 0) === 1)
    && (strtolower((string)($client_row['client_id_verification_status'] ?? 'pending')) === 'approved');

if (!$client_verified) {
    echo json_encode(['success' => false, 'message' => 'Your account is pending admin approval. Access is locked until verification is approved.']);
    exit;
}

$action = $_GET['action'] ?? '';

try {
    // Auto-finalize expired bidding lots before serving any bidding action
    finalizeExpiredBiddingLots($conn);

    switch ($action) {
        case 'get_crops':
            getAvailableCrops($conn);
            break;
        
        case 'place_bid':
            placeBid($conn, $client_id, $user_id);
            break;
        
        case 'get_my_bids':
            getMyBids($conn, $client_id);
            break;
        
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error: ' . $e->getMessage()]);
}

function getAvailableCrops($conn) {
    $query = "
        SELECT 
            c.crop_id,
            c.crop_name,
            c.crop_description,
            c.crop_quantity,
            c.crop_unit,
            c.starting_price,
            c.bidding_end_date,
            f.farmer_fullname,
            f.farm_address,
            (
                SELECT MAX(b.bid_amount)
                FROM bids b
                WHERE b.crop_id = c.crop_id
                AND b.bid_status = 'active'
            ) as highest_bid,
            (
                SELECT COUNT(*)
                FROM bids b
                WHERE b.crop_id = c.crop_id
                AND b.bid_status = 'active'
            ) as bid_count
        FROM crops c
        LEFT JOIN farmers f ON c.farmer_id = f.farmer_id
        WHERE c.starting_price > 0
        AND c.bidding_end_date > NOW()
        ORDER BY c.bidding_end_date ASC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $crops = [];
    while ($row = $result->fetch_assoc()) {
        // Calculate current price (highest bid or starting price)
        $currentPrice = $row['highest_bid'] ? floatval($row['highest_bid']) : floatval($row['starting_price']);
        $row['current_price'] = $currentPrice;
        $row['starting_price'] = floatval($row['starting_price']);
        $row['highest_bid'] = $row['highest_bid'] ? floatval($row['highest_bid']) : null;
        $row['bid_count'] = intval($row['bid_count']);
        $row['crop_quantity'] = floatval($row['crop_quantity']);
        $row['farmer_fullname'] = (string)($row['farmer_fullname'] ?? 'Admin Entry');
        $row['farm_address'] = (string)($row['farm_address'] ?? '');
        
        $crops[] = $row;
    }
    
    echo json_encode(['success' => true, 'crops' => $crops]);
}

function placeBid($conn, $client_id, $client_user_id) {
    
    // Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    $crop_id = $data['crop_id'] ?? 0;
    $bid_amount = $data['bid_amount'] ?? 0;
    
    // Validate inputs
    if (empty($crop_id) || empty($bid_amount)) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        return;
    }
    
    // Check if crop exists and is available
    $stmt = $conn->prepare("
                SELECT c.crop_id, c.crop_name, c.starting_price, c.bidding_end_date, f.user_id AS farmer_user_id,
        (SELECT MAX(bid_amount) FROM bids WHERE crop_id = ? AND bid_status = 'active') as highest_bid
                FROM crops c
                LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
                WHERE c.crop_id = ? 
                    AND c.crop_status = 'available' 
                    AND c.bidding_end_date > NOW()
    ");
    $stmt->bind_param("ii", $crop_id, $crop_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'Crop not available for bidding']);
        return;
    }
    
    $crop = $result->fetch_assoc();
    $crop_name = (string)($crop['crop_name'] ?? 'Crop Listing');
    $farmer_user_id = (int)($crop['farmer_user_id'] ?? 0);
    $current_price = $crop['highest_bid'] ? floatval($crop['highest_bid']) : floatval($crop['starting_price']);

    // Capture currently leading/active client users so we can notify outbid users.
    $outbid_user_ids = [];
    $outbid_stmt = $conn->prepare(
        "SELECT DISTINCT c.user_id
         FROM bids b
         INNER JOIN clients c ON c.client_id = b.client_id
         WHERE b.crop_id = ?
           AND b.bid_status = 'active'
           AND b.client_id <> ?"
    );
    if ($outbid_stmt) {
        $outbid_stmt->bind_param('ii', $crop_id, $client_id);
        $outbid_stmt->execute();
        $outbid_result = $outbid_stmt->get_result();
        if ($outbid_result) {
            while ($outbid_row = $outbid_result->fetch_assoc()) {
                $outbid_uid = (int)($outbid_row['user_id'] ?? 0);
                if ($outbid_uid > 0) {
                    $outbid_user_ids[] = $outbid_uid;
                }
            }
        }
        $outbid_stmt->close();
    }
    
    // Validate bid amount is higher than current price
    if ($bid_amount <= $current_price) {
        echo json_encode([
            'success' => false, 
            'message' => 'Bid amount must be higher than current price of ₱' . number_format($current_price, 2)
        ]);
        return;
    }
    
    // Mark previous bids for this crop as 'outbid'
    $stmt = $conn->prepare("
        UPDATE bids 
        SET bid_status = 'outbid' 
        WHERE crop_id = ? 
        AND bid_status = 'active'
    ");
    $stmt->bind_param("i", $crop_id);
    $stmt->execute();
    
    // Insert new bid
    $stmt = $conn->prepare("
        INSERT INTO bids (crop_id, client_id, bid_amount, bid_status) 
        VALUES (?, ?, ?, 'active')
    ");
    $stmt->bind_param("iid", $crop_id, $client_id, $bid_amount);
    
    if ($stmt->execute()) {
        $new_bid_id = (int)$conn->insert_id;

        $client_name = 'Client';
        $client_name_stmt = $conn->prepare("SELECT client_fullname FROM clients WHERE client_id = ? LIMIT 1");
        if ($client_name_stmt) {
            $client_name_stmt->bind_param('i', $client_id);
            $client_name_stmt->execute();
            $client_name_row = $client_name_stmt->get_result()->fetch_assoc();
            if ($client_name_row && !empty($client_name_row['client_fullname'])) {
                $client_name = (string)$client_name_row['client_fullname'];
            }
            $client_name_stmt->close();
        }

        $bid_amount_label = 'PHP ' . number_format((float)$bid_amount, 2);
        pushUserNotification(
            $conn,
            (int)$client_user_id,
            'Bid submitted successfully',
            'Your bid for ' . $crop_name . ' has been submitted at ' . $bid_amount_label . '.',
            'bid_submitted',
            $new_bid_id
        );

        foreach (array_values(array_unique($outbid_user_ids)) as $outbid_uid) {
            pushUserNotification(
                $conn,
                (int)$outbid_uid,
                'You were outbid',
                'Another bidder placed a higher bid on ' . $crop_name . '. Review your bid to stay competitive.',
                'bid_outbid',
                $crop_id
            );
        }

        if ($farmer_user_id > 0) {
            pushUserNotification(
                $conn,
                $farmer_user_id,
                'New bid received',
                $client_name . ' placed a bid on your listing for ' . $crop_name . ' at ' . $bid_amount_label . '.',
                'bid_received',
                $crop_id
            );
        }

        pushNotificationToRole(
            $conn,
            'admin',
            'New client bid submitted',
            $client_name . ' submitted a new bid for ' . $crop_name . ' at ' . $bid_amount_label . '.',
            'bid_submission',
            $new_bid_id
        );

        echo json_encode([
            'success' => true, 
            'message' => 'Bid placed successfully',
            'bid_id' => $new_bid_id
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to place bid']);
    }
}

function getMyBids($conn, $client_id) {
    
    $query = "
        SELECT 
            b.bid_id,
            b.bid_amount,
            b.bid_status,
            b.created_at,
            c.crop_name,
            c.crop_quantity,
            c.crop_unit,
            c.bidding_end_date,
            c.starting_price,
            f.farmer_fullname,
            (
                SELECT MAX(b2.bid_amount)
                FROM bids b2
                WHERE b2.crop_id = c.crop_id
                AND b2.bid_status = 'active'
            ) as highest_bid,
            (
                SELECT COUNT(*)
                FROM bids b2
                WHERE b2.crop_id = c.crop_id
            ) as total_bids
        FROM bids b
        INNER JOIN crops c ON b.crop_id = c.crop_id
        INNER JOIN farmers f ON c.farmer_id = f.farmer_id
        WHERE b.client_id = ?
        ORDER BY b.created_at DESC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $bids = [];
    while ($row = $result->fetch_assoc()) {
        $row['bid_amount'] = floatval($row['bid_amount']);
        $row['starting_price'] = floatval($row['starting_price']);
        $row['highest_bid'] = floatval($row['highest_bid']);
        $row['total_bids'] = intval($row['total_bids']);
        $row['crop_quantity'] = floatval($row['crop_quantity']);
        $row['is_leading'] = ($row['bid_amount'] == $row['highest_bid']);
        
        $bids[] = $row;
    }
    
    echo json_encode(['success' => true, 'bids' => $bids]);
}
