<?php
require_once '../config.php';

header('Content-Type: application/json');

// Must be logged in as client
$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if (!isset($_SESSION['user_id']) || $sessionRole !== 'client') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Get client_id from session user_id
$user_id = (int)$_SESSION['user_id'];
$stmt = $conn->prepare("SELECT client_id, client_is_verified, client_id_verification_status FROM clients WHERE user_id = ? LIMIT 1");
$stmt->bind_param('i', $user_id);
$stmt->execute();
$client_row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$client_row) {
    echo json_encode(['success' => false, 'message' => 'Client profile not found']);
    exit;
}

$client_id = (int)$client_row['client_id'];
$is_client_verified_access = ((int)($client_row['client_is_verified'] ?? 0) === 1)
    && (strtolower((string)($client_row['client_id_verification_status'] ?? 'pending')) === 'approved');

if (!$is_client_verified_access) {
    echo json_encode(['success' => false, 'message' => 'Your account is pending admin approval. Access is locked until verification is approved.']);
    exit;
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    ensureProductImageColumns($conn);

    switch ($action) {
        case 'get_products':
            getProducts($conn);
            break;
        case 'get_my_reservations':
            getMyReservations($conn, $client_id);
            break;
        case 'submit_reservation':
            submitReservation($conn, $client_id, $user_id);
            break;
        case 'cancel_reservation':
            cancelReservation($conn, $client_id, $user_id);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}

function ensureProductImageColumns($conn) {
    $table_check = $conn->query("SHOW TABLES LIKE 'livestock_products'");
    if (!$table_check || $table_check->num_rows === 0) {
        return;
    }

    $queries = [
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image LONGBLOB NULL",
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_name VARCHAR(255) NULL",
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_mime_type VARCHAR(50) NULL"
    ];

    foreach ($queries as $sql) {
        if (!$conn->query($sql)) {
            throw new Exception('Unable to prepare product image columns.');
        }
    }
}

function buildImageDataUrl($blob, $mime): string {
    if ($blob === null || $blob === '' || $mime === null || $mime === '') {
        return '';
    }

    return 'data:' . $mime . ';base64,' . base64_encode($blob);
}

function getProducts($conn) {
    $type_filter = $_GET['type'] ?? '';
    $search = $_GET['search'] ?? '';

    $where = "WHERE lp.status = 'Active' AND lp.stock > 0";
    $params = [];
    $types = '';

    if ($type_filter && $type_filter !== 'All Types') {
        $where .= " AND lp.product_type = ?";
        $params[] = $type_filter;
        $types .= 's';
    }
    if ($search) {
        $where .= " AND lp.product_name LIKE ?";
        $params[] = '%' . $search . '%';
        $types .= 's';
    }

    $sql = "SELECT lp.product_id, lp.product_name, lp.product_type, lp.product_description,
                   lp.price, lp.stock, lp.unit, lp.status,
                   lp.product_image, lp.product_image_mime_type,
                   COALESCE(f.farmer_fullname, 'Smart Farm Coop') AS supplier
            FROM livestock_products lp
            LEFT JOIN farmers f ON lp.farmer_id = f.farmer_id
            $where
            ORDER BY lp.product_name ASC";

    $stmt = $conn->prepare($sql);
    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $row['price'] = (float)$row['price'];
        $row['stock'] = (int)$row['stock'];
        $row['product_image_url'] = buildImageDataUrl($row['product_image'] ?? null, $row['product_image_mime_type'] ?? '');
        unset($row['product_image']);
        $products[] = $row;
    }
    $stmt->close();

    echo json_encode(['success' => true, 'products' => $products]);
}

function getMyReservations($conn, $client_id) {
    $sql = "SELECT r.reservation_id, r.quantity, r.unit_price, r.total_price,
                   r.preferred_date, r.notes, r.status, r.admin_notes, r.created_at,
                   lp.product_name, lp.product_type, lp.unit
            FROM livestock_reservations r
            JOIN livestock_products lp ON r.product_id = lp.product_id
            WHERE r.client_id = ?
            ORDER BY r.created_at DESC";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $client_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $row['total_price'] = (float)$row['total_price'];
        $row['unit_price'] = (float)$row['unit_price'];
        $row['quantity'] = (int)$row['quantity'];
        $reservations[] = $row;
    }
    $stmt->close();

    echo json_encode(['success' => true, 'reservations' => $reservations]);
}

function submitReservation($conn, $client_id, $client_user_id) {
    $product_id   = (int)($_POST['product_id'] ?? 0);
    $quantity     = (int)($_POST['quantity'] ?? 1);
    $preferred_date = $_POST['preferred_date'] ?? '';
    $notes        = trim($_POST['notes'] ?? '');

    // Validate
    if ($product_id <= 0 || $quantity <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product or quantity']);
        return;
    }
    if ($quantity > 100) {
        echo json_encode(['success' => false, 'message' => 'Quantity too large']);
        return;
    }
    if ($preferred_date && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $preferred_date)) {
        echo json_encode(['success' => false, 'message' => 'Invalid date format']);
        return;
    }
    if (strlen($notes) > 500) {
        echo json_encode(['success' => false, 'message' => 'Notes too long (max 500 chars)']);
        return;
    }

    // Fetch product
    $stmt = $conn->prepare("SELECT product_id, product_name, price, stock, status FROM livestock_products WHERE product_id = ? AND status = 'Active' LIMIT 1");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) {
        echo json_encode(['success' => false, 'message' => 'Product not found or unavailable']);
        return;
    }
    if ($quantity > $product['stock']) {
        echo json_encode(['success' => false, 'message' => 'Requested quantity exceeds available stock (' . $product['stock'] . ')']);
        return;
    }

    $unit_price  = (float)$product['price'];
    $total_price = $unit_price * $quantity;
    $pref_date_val = $preferred_date ?: null;

    $conn->begin_transaction();

    // Re-check stock inside transaction to prevent race conditions
    $lock_stmt = $conn->prepare("SELECT stock FROM livestock_products WHERE product_id = ? AND status = 'Active' LIMIT 1 FOR UPDATE");
    $lock_stmt->bind_param('i', $product_id);
    $lock_stmt->execute();
    $locked = $lock_stmt->get_result()->fetch_assoc();
    $lock_stmt->close();

    if (!$locked || (int)$locked['stock'] < $quantity) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Not enough stock available']);
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO livestock_reservations (client_id, product_id, quantity, unit_price, total_price, preferred_date, notes, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')"
    );
    $stmt->bind_param('iiiddss', $client_id, $product_id, $quantity, $unit_price, $total_price, $pref_date_val, $notes);

    if (!$stmt->execute()) {
        $stmt->close();
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Failed to submit reservation']);
        return;
    }
    $reservation_id = $stmt->insert_id;
    $stmt->close();

    // Deduct stock immediately on reservation
    $deduct_stmt = $conn->prepare("UPDATE livestock_products SET stock = stock - ? WHERE product_id = ? AND stock >= ?");
    $deduct_stmt->bind_param('iii', $quantity, $product_id, $quantity);
    $deduct_stmt->execute();
    $deducted = $deduct_stmt->affected_rows;
    $deduct_stmt->close();

    if ($deducted <= 0) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Not enough stock available']);
        return;
    }

    $conn->commit();

    $product_name = (string)($product['product_name'] ?? 'Product');
        pushUserNotification(
            $conn,
            $client_user_id,
            'Reservation submitted',
            'Your reservation for ' . $product_name . ' was submitted successfully.',
            'reservation_submitted',
            $reservation_id
        );

        pushNotificationToRole(
            $conn,
            'admin',
            'New product reservation',
            'A client submitted a reservation request for ' . $product_name . '.',
            'reservation_submission',
            $reservation_id
        );

        echo json_encode(['success' => true, 'message' => 'Reservation submitted successfully! The admin will confirm your request.', 'reservation_id' => $reservation_id]);
}

function cancelReservation($conn, $client_id, $client_user_id) {
    $reservation_id = (int)($_POST['reservation_id'] ?? 0);
    if ($reservation_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid reservation']);
        return;
    }

    // Only allow cancelling own pending/confirmed reservations
    $stmt = $conn->prepare(
        "SELECT r.quantity, r.product_id FROM livestock_reservations r
         WHERE reservation_id = ? AND client_id = ? AND status IN ('pending','confirmed') LIMIT 1"
    );
    $stmt->bind_param('ii', $reservation_id, $client_id);
    $stmt->execute();
    $res_row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$res_row) {
        echo json_encode(['success' => false, 'message' => 'Cannot cancel this reservation']);
        return;
    }

    $stmt = $conn->prepare(
        "UPDATE livestock_reservations SET status = 'cancelled'
         WHERE reservation_id = ? AND client_id = ? AND status IN ('pending','confirmed')"
    );
    $stmt->bind_param('ii', $reservation_id, $client_id);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();

    if ($affected > 0) {
        // Restore stock on cancellation
        $restore_stmt = $conn->prepare("UPDATE livestock_products SET stock = stock + ? WHERE product_id = ?");
        $restore_stmt->bind_param('ii', $res_row['quantity'], $res_row['product_id']);
        $restore_stmt->execute();
        $restore_stmt->close();
        pushUserNotification(
            $conn,
            $client_user_id,
            'Reservation cancelled',
            'Your reservation was cancelled successfully.',
            'reservation_cancelled',
            $reservation_id
        );

        pushNotificationToRole(
            $conn,
            'admin',
            'Reservation cancelled',
            'A client cancelled a reservation request.',
            'reservation_cancelled',
            $reservation_id
        );

        echo json_encode(['success' => true, 'message' => 'Reservation cancelled']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Cannot cancel this reservation']);
    }
}
