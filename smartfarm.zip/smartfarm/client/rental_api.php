<?php
require_once '../config.php';

header('Content-Type: application/json');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if (!isset($_SESSION['user_id']) || $sessionRole !== 'client') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

if (!ensureClientRentalTable($conn)) {
    echo json_encode(['success' => false, 'message' => 'Unable to initialize rental tables']);
    exit;
}

if (!ensureRentalImageColumns($conn)) {
    echo json_encode(['success' => false, 'message' => 'Unable to initialize rental image columns']);
    exit;
}

$user_id = (int)($_SESSION['user_id'] ?? 0);
$client_stmt = $conn->prepare(
    "SELECT client_id, client_fullname, client_is_verified, client_id_verification_status
     FROM clients
     WHERE user_id = ?
     LIMIT 1"
);
if (!$client_stmt) {
    echo json_encode(['success' => false, 'message' => 'Unable to validate client profile']);
    exit;
}

$client_stmt->bind_param('i', $user_id);
$client_stmt->execute();
$client_row = $client_stmt->get_result()->fetch_assoc();
$client_stmt->close();

if (!$client_row) {
    echo json_encode(['success' => false, 'message' => 'Client profile not found']);
    exit;
}

$is_client_verified = ((int)($client_row['client_is_verified'] ?? 0) === 1)
    && (strtolower((string)($client_row['client_id_verification_status'] ?? 'pending')) === 'approved');

if (!$is_client_verified) {
    echo json_encode(['success' => false, 'message' => 'Your account is pending admin approval.']);
    exit;
}

$client_name = trim((string)($client_row['client_fullname'] ?? ''));
$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    switch ($action) {
        case 'get_available':
            getAvailableMachinery($conn);
            break;
        case 'get_my_rentals':
            getMyRentals($conn, $client_name);
            break;
        case 'submit_rentals':
            submitRentals($conn, $client_name, $user_id);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Throwable $e) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}

function ensureClientRentalTable(mysqli $conn): bool {
    $sql = "CREATE TABLE IF NOT EXISTS machinery_rentals (
      rental_id INT NOT NULL AUTO_INCREMENT,
      rental_code VARCHAR(20) NOT NULL,
      equipment_name VARCHAR(255) NOT NULL,
      owner_name VARCHAR(255) NOT NULL,
    machinery_image LONGBLOB NULL,
    machinery_image_name VARCHAR(255) NULL,
    machinery_image_mime_type VARCHAR(50) NULL,
      renter_name VARCHAR(255) NOT NULL,
      start_date DATE NOT NULL,
      end_date DATE NOT NULL,
      total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
      rental_status ENUM('pending','approved','in-rental','returned','cancelled') NOT NULL DEFAULT 'pending',
      payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
      payment_marked_at DATETIME NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (rental_id),
      UNIQUE KEY uniq_rental_code (rental_code),
      KEY idx_rental_status (rental_status),
      KEY idx_payment_status (payment_status),
      KEY idx_start_date (start_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    return (bool)$conn->query($sql);
}

function ensureRentalImageColumns(mysqli $conn): bool {
    $queries = [
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image LONGBLOB NULL",
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_name VARCHAR(255) NULL",
        "ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_mime_type VARCHAR(50) NULL"
    ];

    foreach ($queries as $sql) {
        if (!$conn->query($sql)) {
            return false;
        }
    }

    return true;
}

function buildImageDataUrl($blob, $mime): string {
    if ($blob === null || $blob === '' || $mime === null || $mime === '') {
        return '';
    }

    return 'data:' . $mime . ';base64,' . base64_encode($blob);
}

function getAvailableMachinery(mysqli $conn): void {
    $search = trim((string)($_GET['search'] ?? ''));

        $sql = "SELECT rental_id, equipment_name, owner_name, total_cost, rental_status,
                                     machinery_image, machinery_image_mime_type
            FROM machinery_rentals
            WHERE (renter_name = '' OR renter_name IS NULL)
              AND rental_status IN ('pending', 'approved')";

    if ($search !== '') {
        $sql .= " AND (equipment_name LIKE ? OR owner_name LIKE ?)";
    }

    $sql .= " ORDER BY created_at DESC, rental_id DESC";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Unable to load machinery']);
        return;
    }

    if ($search !== '') {
        $search_like = '%' . $search . '%';
        $stmt->bind_param('ss', $search_like, $search_like);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['rental_id'] = (int)$row['rental_id'];
        $row['daily_rate'] = (float)($row['total_cost'] ?? 0);
        $row['rental_status'] = (string)($row['rental_status'] ?? 'pending');
        $row['machinery_image_url'] = buildImageDataUrl($row['machinery_image'] ?? null, $row['machinery_image_mime_type'] ?? '');
        unset($row['machinery_image']);
        $rows[] = $row;
    }

    $stmt->close();
    echo json_encode(['success' => true, 'items' => $rows]);
}

function getMyRentals(mysqli $conn, string $client_name): void {
    if ($client_name === '') {
        echo json_encode(['success' => true, 'rentals' => []]);
        return;
    }

    $stmt = $conn->prepare(
        "SELECT rental_id, rental_code, equipment_name, owner_name, start_date, end_date, total_cost, rental_status, payment_status, created_at
         FROM machinery_rentals
         WHERE renter_name = ?
         ORDER BY created_at DESC, rental_id DESC"
    );

    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Unable to load your rentals']);
        return;
    }

    $stmt->bind_param('s', $client_name);
    $stmt->execute();
    $result = $stmt->get_result();

    $rows = [];
    while ($row = $result->fetch_assoc()) {
        $row['rental_id'] = (int)$row['rental_id'];
        $row['total_cost'] = (float)$row['total_cost'];
        $rows[] = $row;
    }

    $stmt->close();
    echo json_encode(['success' => true, 'rentals' => $rows]);
}

function submitRentals(mysqli $conn, string $client_name, int $client_user_id): void {
    if ($client_name === '') {
        echo json_encode(['success' => false, 'message' => 'Client profile is incomplete']);
        return;
    }

    $raw = file_get_contents('php://input');
    $payload = json_decode($raw, true);

    if (!is_array($payload) || !isset($payload['items']) || !is_array($payload['items'])) {
        echo json_encode(['success' => false, 'message' => 'Invalid request payload']);
        return;
    }

    $items = $payload['items'];
    if (count($items) === 0) {
        echo json_encode(['success' => false, 'message' => 'No rental items submitted']);
        return;
    }

    $conn->begin_transaction();

    $next_id_result = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS next_id FROM machinery_rentals FOR UPDATE");
    $next_id = 1;
    if ($next_id_result) {
        $next_row = $next_id_result->fetch_assoc();
        $next_id = (int)($next_row['next_id'] ?? 1);
    }

    $insert_stmt = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, renter_name, start_date, end_date, total_cost, rental_status, payment_status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'unpaid')"
    );

    if (!$insert_stmt) {
        $conn->rollback();
        echo json_encode(['success' => false, 'message' => 'Unable to prepare rental request']);
        return;
    }

    $inserted = 0;
    $overlap_conflicts = [];

    foreach ($items as $item) {
        $listing_id = max(0, (int)($item['listing_id'] ?? 0));
        $equipment_name = trim((string)($item['name'] ?? ''));
        $owner_name = trim((string)($item['owner'] ?? ''));
        $start_date = trim((string)($item['start_date'] ?? ''));
        $end_date = trim((string)($item['end_date'] ?? ''));
        $daily_rate = (float)($item['daily_rate'] ?? 0);
        $quantity = max(1, (int)($item['quantity'] ?? 1));
        $machinery_image = null;
        $machinery_image_name = null;
        $machinery_image_mime = null;

        if ($listing_id > 0) {
            $source_stmt = $conn->prepare(
                "SELECT equipment_name, owner_name, total_cost, machinery_image, machinery_image_name, machinery_image_mime_type
                 FROM machinery_rentals
                 WHERE rental_id = ?
                   AND (renter_name = '' OR renter_name IS NULL)
                   AND rental_status IN ('pending', 'approved')
                 LIMIT 1"
            );
            if ($source_stmt) {
                $source_stmt->bind_param('i', $listing_id);
                $source_stmt->execute();
                $source_row = $source_stmt->get_result()->fetch_assoc();
                $source_stmt->close();

                if ($source_row) {
                    $equipment_name = trim((string)($source_row['equipment_name'] ?? $equipment_name));
                    $owner_name = trim((string)($source_row['owner_name'] ?? $owner_name));
                    $daily_rate = (float)($source_row['total_cost'] ?? $daily_rate);
                    $machinery_image = $source_row['machinery_image'] ?? null;
                    $machinery_image_name = $source_row['machinery_image_name'] ?? null;
                    $machinery_image_mime = $source_row['machinery_image_mime_type'] ?? null;
                }
            }
        }

        if ($equipment_name === '' || $owner_name === '' || $start_date === '' || $end_date === '' || $daily_rate <= 0) {
            continue;
        }

        $start_ts = strtotime($start_date);
        $end_ts = strtotime($end_date);
        if (!$start_ts || !$end_ts || $end_ts < $start_ts) {
            continue;
        }

        // Prevent overlapping reservations for the same machine and owner.
        $overlap_stmt = $conn->prepare(
            "SELECT rental_id
             FROM machinery_rentals
             WHERE equipment_name = ?
               AND owner_name = ?
               AND COALESCE(TRIM(renter_name), '') <> ''
               AND rental_status IN ('pending','approved','in-rental')
               AND NOT (end_date < ? OR start_date > ?)
             LIMIT 1"
        );
        if ($overlap_stmt) {
            $overlap_stmt->bind_param('ssss', $equipment_name, $owner_name, $start_date, $end_date);
            $overlap_stmt->execute();
            $overlap_row = $overlap_stmt->get_result()->fetch_assoc();
            $overlap_stmt->close();

            if ($overlap_row) {
                $overlap_conflicts[] = $equipment_name . ' (' . $owner_name . ')';
                continue;
            }
        }

        $days = (int)floor(($end_ts - $start_ts) / 86400) + 1;
        if ($days < 1) {
            $days = 1;
        }

        $total_cost = $daily_rate * $quantity * $days;
        $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
        $next_id++;

        $insert_stmt->bind_param('sssssssssd', $rental_code, $equipment_name, $owner_name, $machinery_image, $machinery_image_name, $machinery_image_mime, $client_name, $start_date, $end_date, $total_cost);

        if ($insert_stmt->execute()) {
            $inserted++;
        }
    }

    $insert_stmt->close();

    if ($inserted > 0) {
        $conn->commit();
        $message = 'Rental request submitted';
        if (!empty($overlap_conflicts)) {
            $message .= '. Some items were skipped due to date overlap: ' . implode(', ', array_unique($overlap_conflicts));
        }

        pushUserNotification(
            $conn,
            $client_user_id,
            'Rental request submitted',
            'Your machinery rental request was submitted successfully. Requested item count: ' . $inserted . '.',
            'rental_submitted',
            null
        );

        pushNotificationToRole(
            $conn,
            'admin',
            'New machinery rental request',
            $client_name . ' submitted a machinery rental request (' . $inserted . ' item' . ($inserted === 1 ? '' : 's') . ').',
            'rental_submission',
            null
        );

        echo json_encode(['success' => true, 'message' => $message, 'inserted' => $inserted]);
    } else {
        $conn->rollback();
        if (!empty($overlap_conflicts)) {
            echo json_encode(['success' => false, 'message' => 'No rentals were submitted because of date overlap with existing bookings.']);
            return;
        }
        echo json_encode(['success' => false, 'message' => 'No valid rental items to submit']);
    }
}
