﻿<?php
require '../config.php';
$session_role = $_SESSION['user_role'] ?? '';
if (!isset($_SESSION['user_id']) || $session_role !== 'client') {
  header('Location: ../login.php');
  exit;
}

$client_name = $_SESSION['user_fullname'] ?? 'Client';
$client_user_id = (int)($_SESSION['user_id'] ?? 0);
$client_id = 0;
$client_notifications = [];
$client_unread_count = 0;
$requested_section = $_GET['section'] ?? 'overview';
$client_view_origin = (string)($_GET['origin'] ?? 'overview');
$client_view_payload_encoded = (string)($_GET['view_payload'] ?? '');
$client_view_payload = [];
$client_form_payload_encoded = (string)($_GET['form_payload'] ?? '');
$client_form_payload = [];
$client_view_back_section = in_array($client_view_origin, ['bids', 'rentals', 'livestock'], true)
  ? $client_view_origin
  : 'overview';

if ($client_view_payload_encoded !== '') {
  $decoded_payload_json = rawurldecode($client_view_payload_encoded);
  $decoded_payload = json_decode($decoded_payload_json, true);
  if (is_array($decoded_payload)) {
    $client_view_payload = $decoded_payload;
  }
}

if ($client_form_payload_encoded !== '') {
  $decoded_form_payload_json = rawurldecode($client_form_payload_encoded);
  $decoded_form_payload = json_decode($decoded_form_payload_json, true);
  if (is_array($decoded_form_payload)) {
    $client_form_payload = $decoded_form_payload;
  }
}

$overview_active_bids = 0;
$overview_upcoming_rentals = 0;
$overview_available_products = 0;
$overview_incoming_events = [];

$client_profile = [
  'email' => (string)($_SESSION['user_email'] ?? '-'),
  'address' => '-',
  'contact' => '-',
  'id_type' => '-',
  'verification_status' => 'pending',
  'verification_notes' => '',
  'is_verified' => 0,
  'member_since' => '-'
];
$is_client_verified_access = false;

$client_notify_table = $conn->query("SHOW TABLES LIKE 'user_notifications'");
if ($client_notify_table && $client_notify_table->num_rows > 0 && $client_user_id > 0) {
  $client_notify_stmt = $conn->prepare(
    "SELECT notification_title, notification_message, created_at, is_read
     FROM user_notifications
     WHERE user_id = ?
     ORDER BY created_at DESC
     LIMIT 15"
  );
  if ($client_notify_stmt) {
    $client_notify_stmt->bind_param('i', $client_user_id);
    $client_notify_stmt->execute();
    $client_notify_result = $client_notify_stmt->get_result();
    if ($client_notify_result) {
      while ($notify_row = $client_notify_result->fetch_assoc()) {
        $created_stamp = strtotime((string)($notify_row['created_at'] ?? ''));
        $client_notifications[] = [
          'title' => (string)($notify_row['notification_title'] ?? 'Notification'),
          'message' => (string)($notify_row['notification_message'] ?? ''),
          'created_label' => $created_stamp ? date('M d, Y h:i A', $created_stamp) : '',
          'is_read' => (int)($notify_row['is_read'] ?? 0) === 1
        ];
        if ((int)($notify_row['is_read'] ?? 0) === 0) {
          $client_unread_count++;
        }
      }
    }
    $client_notify_stmt->close();
  }
}

if ($client_user_id > 0) {
  $client_stmt = $conn->prepare(
    "SELECT
      c.client_id,
      c.client_fullname,
      c.client_contact_number,
      c.client_address,
      c.client_id_type,
      c.client_id_verification_status,
      c.client_id_verification_notes,
      c.client_is_verified,
      c.client_created_at,
      COALESCE(u.email, '') AS client_email
    FROM clients c
    LEFT JOIN users u ON u.user_id = c.user_id
    WHERE c.user_id = ?
    LIMIT 1"
  );

  if ($client_stmt) {
    $client_stmt->bind_param('i', $client_user_id);
    $client_stmt->execute();
    $client_result = $client_stmt->get_result();
    if ($client_result && $client_result->num_rows > 0) {
      $client_row = $client_result->fetch_assoc();
      $client_id = (int)($client_row['client_id'] ?? 0);
      $client_name = (string)($client_row['client_fullname'] ?? $client_name);
      $client_profile['email'] = (string)($client_row['client_email'] ?? $client_profile['email']);
      $client_profile['address'] = (string)($client_row['client_address'] ?? '-');
      $client_profile['contact'] = (string)($client_row['client_contact_number'] ?? '-');
      $client_profile['id_type'] = (string)($client_row['client_id_type'] ?? '-');
      $client_profile['verification_status'] = strtolower((string)($client_row['client_id_verification_status'] ?? 'pending'));
      $client_profile['verification_notes'] = trim((string)($client_row['client_id_verification_notes'] ?? ''));
      $client_profile['is_verified'] = (int)($client_row['client_is_verified'] ?? 0);

      $member_stamp = !empty($client_row['client_created_at']) ? strtotime((string)$client_row['client_created_at']) : false;
      if ($member_stamp) {
        $client_profile['member_since'] = date('F Y', $member_stamp);
      }

      $is_client_verified_access = ((int)($client_profile['is_verified'] ?? 0) === 1)
        && (($client_profile['verification_status'] ?? '') === 'approved');
    }
    $client_stmt->close();
  }
}

$allowed_sections = $is_client_verified_access
  ? ['overview', 'bids', 'my-bids', 'rentals', 'machinery-reservations', 'livestock', 'livestock-reservations', 'item-view', 'bid-form', 'rental-form', 'livestock-form', 'favorites', 'profile']
  : ['profile'];

$active_section = in_array($requested_section, $allowed_sections, true)
  ? $requested_section
  : ($is_client_verified_access ? 'overview' : 'profile');

$verification_status_text = ucfirst((string)($client_profile['verification_status'] ?? 'pending'));
$client_badge_text = $is_client_verified_access ? 'Verified Client' : ($verification_status_text . ' Verification');
$client_badge_class = $is_client_verified_access ? 'verified' : ((($client_profile['verification_status'] ?? '') === 'rejected') ? 'rejected' : 'pending');
$client_verification_notes_text = trim((string)($client_profile['verification_notes'] ?? ''));
$client_verification_notes_text = $client_verification_notes_text !== ''
  ? $client_verification_notes_text
  : 'No additional admin notes yet. Please wait while your documents are reviewed.';

function dashboardImageDataUrl($blob, $mime): string {
  if ($blob === null || $blob === '' || $mime === null || $mime === '') {
    return '';
  }

  return 'data:' . $mime . ';base64,' . base64_encode($blob);
}

$today = date('F j, Y');
$machinery_catalog = [];

$crops_table = $conn->query("SHOW TABLES LIKE 'crops'");
if ($crops_table && $crops_table->num_rows > 0) {
  $count_crops_stmt = $conn->prepare(
    "SELECT COUNT(*) AS total
     FROM crops
     WHERE starting_price > 0
       AND bidding_end_date > NOW()"
  );
  if ($count_crops_stmt) {
    $count_crops_stmt->execute();
    $count_crops_result = $count_crops_stmt->get_result();
    if ($count_crops_result) {
      $overview_active_bids = (int)($count_crops_result->fetch_assoc()['total'] ?? 0);
    }
    $count_crops_stmt->close();
  }
}

$products_table = $conn->query("SHOW TABLES LIKE 'livestock_products'");
if ($products_table && $products_table->num_rows > 0) {
  $count_products_stmt = $conn->prepare(
    "SELECT COUNT(*) AS total
     FROM livestock_products
     WHERE status = 'Active'
       AND stock > 0"
  );
  if ($count_products_stmt) {
    $count_products_stmt->execute();
    $count_products_result = $count_products_stmt->get_result();
    if ($count_products_result) {
      $overview_available_products = (int)($count_products_result->fetch_assoc()['total'] ?? 0);
    }
    $count_products_stmt->close();
  }
}

$rentals_table = $conn->query("SHOW TABLES LIKE 'machinery_rentals'");
if ($rentals_table && $rentals_table->num_rows > 0) {
  if ($client_name !== '') {
    $count_rentals_stmt = $conn->prepare(
      "SELECT COUNT(*) AS total
       FROM machinery_rentals
       WHERE renter_name = ?
         AND end_date >= CURDATE()
         AND rental_status IN ('pending', 'approved', 'in-rental')"
    );
    if ($count_rentals_stmt) {
      $count_rentals_stmt->bind_param('s', $client_name);
      $count_rentals_stmt->execute();
      $count_rentals_result = $count_rentals_stmt->get_result();
      if ($count_rentals_result) {
        $overview_upcoming_rentals = (int)($count_rentals_result->fetch_assoc()['total'] ?? 0);
      }
      $count_rentals_stmt->close();
    }
  }

  $machinery_stmt = $conn->prepare(
    "SELECT rental_id, equipment_name, owner_name, total_cost, rental_status,
            machinery_image, machinery_image_mime_type
     FROM machinery_rentals
     WHERE (renter_name = '' OR renter_name IS NULL)
       AND rental_status IN ('pending', 'approved')
     ORDER BY created_at DESC, rental_id DESC"
  );
  if ($machinery_stmt) {
    $machinery_stmt->execute();
    $machinery_result = $machinery_stmt->get_result();
    if ($machinery_result) {
      while ($machinery_row = $machinery_result->fetch_assoc()) {
        $machine_name = (string)($machinery_row['equipment_name'] ?? 'Machinery');

        $status = (string)($machinery_row['rental_status'] ?? 'pending');
        $availability = $status === 'approved' ? 'Available now' : 'Ready for booking';
        $image_url = dashboardImageDataUrl($machinery_row['machinery_image'] ?? null, $machinery_row['machinery_image_mime_type'] ?? '');

        $machinery_catalog[] = [
          'listing_id' => (int)($machinery_row['rental_id'] ?? 0),
          'name' => $machine_name,
          'owner' => (string)($machinery_row['owner_name'] ?? '-'),
          'daily_rate' => (float)($machinery_row['total_cost'] ?? 0),
          'image_url' => $image_url,
          'availability' => $availability
        ];
      }
    }
    $machinery_stmt->close();
  }
}

$schedule_table_check = $conn->query("SHOW TABLES LIKE 'scheduled_activities'");
if ($schedule_table_check && $schedule_table_check->num_rows > 0) {
  $incoming_events_stmt = $conn->prepare(
    "SELECT title, category, activity_date, activity_time, location
     FROM scheduled_activities
     WHERE target_client = 1
       AND activity_date >= CURDATE()
     ORDER BY activity_date ASC, activity_time ASC, activity_id ASC
     LIMIT 5"
  );

  if ($incoming_events_stmt) {
    $incoming_events_stmt->execute();
    $incoming_events_result = $incoming_events_stmt->get_result();
    if ($incoming_events_result) {
      $today_midnight = strtotime(date('Y-m-d'));
      while ($event_row = $incoming_events_result->fetch_assoc()) {
        $event_date = (string)($event_row['activity_date'] ?? '');
        $event_time = (string)($event_row['activity_time'] ?? '');
        $event_ts = strtotime(trim($event_date . ' ' . ($event_time !== '' ? $event_time : '00:00:00')));
        if (!$event_ts) {
          continue;
        }

        $event_midnight = strtotime(date('Y-m-d', $event_ts));
        $days_until = (int)(($event_midnight - $today_midnight) / 86400);

        $time_label = 'Upcoming';
        if ($days_until <= 0) {
          $time_label = 'Today';
        } elseif ($days_until === 1) {
          $time_label = 'Tomorrow';
        } else {
          $time_label = 'In ' . $days_until . ' days';
        }

        $urgency_rank = 3;
        if ($days_until <= 0) {
          $urgency_rank = 0;
        } elseif ($days_until === 1) {
          $urgency_rank = 1;
        } elseif ($days_until <= 7) {
          $urgency_rank = 2;
        }

        $detail_parts = [];
        $detail_parts[] = date('M d, Y', $event_ts);
        if ($event_time !== '') {
          $detail_parts[] = date('h:i A', strtotime($event_time));
        }
        $location = trim((string)($event_row['location'] ?? ''));
        if ($location !== '') {
          $detail_parts[] = $location;
        }

        $overview_incoming_events[] = [
          'ts' => $event_ts,
          'urgency_rank' => $urgency_rank,
          'title' => (string)($event_row['title'] ?? 'Scheduled activity'),
          'subtitle' => !empty($detail_parts) ? implode(' | ', $detail_parts) : 'Scheduled activity for clients',
          'state_label' => (string)($event_row['category'] ?? 'Activity'),
          'state_class' => '',
          'time_label' => $time_label
        ];
      }
    }
    $incoming_events_stmt->close();
  }
}

if (!empty($overview_incoming_events)) {
  // Only keep activities scheduled after today (future only)
  $now = strtotime(date('Y-m-d'));
  $future_events = array_filter($overview_incoming_events, function($event) use ($now) {
    return isset($event['ts']) && $event['ts'] > $now;
  });
  usort($future_events, static function ($left, $right) {
    $leftRank = (int)($left['urgency_rank'] ?? 3);
    $rightRank = (int)($right['urgency_rank'] ?? 3);
    if ($leftRank !== $rightRank) {
      return $leftRank <=> $rightRank;
    }
    $leftTs = (int)($left['ts'] ?? 0);
    $rightTs = (int)($right['ts'] ?? 0);
    return $leftTs <=> $rightTs;
  });
  $overview_incoming_events = array_slice($future_events, 0, 3);
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Smart Farm Client Dashboard</title>
  <link rel="stylesheet" type="text/css" href="../css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    body {
    }
    html {
      scroll-behavior: smooth;
    }

    body.client {
      background: linear-gradient(135deg, #f5f5f5 0%, #e8f5e9 50%, #f0f7f3 100%);
    }

    body.client .admin-top-nav {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 50%, #41753e 100%);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.25);
    }

    body.client .admin-sidebar {
      background: linear-gradient(135deg, rgba(40, 167, 69, 0.08), rgba(40, 167, 69, 0.05));
      border-right: 2px solid rgba(40, 167, 69, 0.15);
      width: 240px;
      min-width: 240px;
    }

    body.client .nav-category,
    body.client .nav-item.active,
    body.client .nav-item:hover {
      color: #1b5a2a;
    }

    body.client .nav-item.active {
      background: rgba(40, 167, 69, 0.14);
      border-left-color: #1b5a2a;
    }

    .client-main {
      flex: 1;
      padding: 2rem;
      overflow-y: auto;
      overflow-x: hidden;
      height: calc(100vh - 70px);
      width: 100%;
    }

    .client-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .client-title h1 {
      font-size: 1.8rem;
      color: #1b5a2a;
      margin-bottom: 0.35rem;
    }

    .client-title p {
      color: #5b6b5b;
      font-size: 0.95rem;
    }

    .client-badge {
      background: rgba(40, 167, 69, 0.12);
      color: #1b5a2a;
      border: 1px solid rgba(40, 167, 69, 0.25);
      padding: 0.4rem 0.8rem;
      border-radius: 999px;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .client-badge.pending {
      background: #fff7e0;
      color: #a16207;
      border-color: #fde68a;
    }

    .client-badge.rejected {
      background: #fef2f2;
      color: #b91c1c;
      border-color: #fecaca;
    }

    .overview-summary-grid {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .overview-summary-card {
      background: #ffffff;
      border: 1px solid rgba(27, 90, 42, 0.16);
      border-radius: 12px;
      padding: 1rem 1.1rem;
      min-height: 78px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.8rem;
      cursor: pointer;
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.08);
      transition: box-shadow 0.2s ease, transform 0.2s ease;
    }

    .overview-summary-card:hover {
      transform: translateY(-1px);
      box-shadow: 0 8px 18px rgba(27, 90, 42, 0.12);
    }

    .overview-summary-left {
      display: flex;
      align-items: center;
      gap: 0.75rem;
      flex: 1;
      min-width: 0;
    }

    .overview-summary-left > div:last-child {
      min-width: 0;
    }

    .overview-summary-icon {
      width: 42px;
      height: 42px;
      border-radius: 10px;
      background: rgba(40, 167, 69, 0.12);
      color: #1b5a2a;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.1rem;
      flex-shrink: 0;
    }

    .overview-summary-label {
      color: #5b6b5b;
      font-size: 0.78rem;
      font-weight: 700;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      line-height: 1.2;
      margin: 0;
    }

    .overview-summary-value {
      color: #1b5a2a;
      font-size: 1.1rem;
      font-weight: 700;
      line-height: 1.25;
      margin: 0.2rem 0 0;
    }

    .overview-summary-arrow {
      color: #3f6f4f;
      font-size: 0.95rem;
      opacity: 0.8;
      flex-shrink: 0;
      align-self: center;
    }

    .overview-alert-head {
      display: flex;
      align-items: baseline;
      gap: 0.6rem;
      margin-bottom: 1rem;
    }

    .overview-alert-head i {
      color: #1b5a2a;
      font-size: 0.95rem;
      line-height: 1;
      position: relative;
      top: -1px;
    }

    .overview-alert-head h2 {
      margin: 0;
      color: #1b5a2a;
      font-size: 1.02rem;
      line-height: 1.15;
    }

    .overview-alert-list {
      display: flex;
      flex-direction: column;
      gap: 0.65rem;
    }

    .overview-alert-item {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
      padding: 0.8rem 0.95rem;
      border-radius: 9px;
      border: 1px solid #d6e6da;
      background: #f8fcf9;
    }

    .overview-alert-item.warning {
      border-color: #f3d2a5;
      background: #fff8ed;
    }

    .overview-alert-item strong {
      color: #1b5a2a;
      display: block;
      font-size: 0.92rem;
      margin-bottom: 0.15rem;
    }

    .overview-alert-item small {
      display: block;
      font-size: 0.76rem;
      color: #5b6b5b;
    }

    .overview-alert-meta {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      justify-content: flex-start;
      text-align: right;
      min-width: 120px;
      flex-shrink: 0;
    }

    .overview-time {
      font-size: 0.72rem;
      color: #8c2f1b;
      font-weight: 700;
      margin-top: 0.2rem;
    }

    .stat-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 1rem;
      margin-bottom: 1.5rem;
    }

    .stat-card {
      background: #fff;
      border-radius: 12px;
      padding: 1rem 1.25rem;
      box-shadow: 0 10px 30px rgba(27, 90, 42, 0.12);
      border: 1px solid rgba(40, 167, 69, 0.18);
    }

    .stat-card h3 {
      font-size: 0.9rem;
      color: #5b6b5b;
      margin-bottom: 0.4rem;
    }

    .stat-card .stat-value {
      font-size: 1.6rem;
      color: #1b5a2a;
      font-weight: 700;
    }

    .stat-card .stat-note {
      font-size: 0.8rem;
      color: #6b776b;
      margin-top: 0.4rem;
    }

    .section-grid {
      display: grid;
      grid-template-columns: 2fr 1fr;
      gap: 1.5rem;
      margin-bottom: 1.5rem;
    }

    .panel {
      background: #fff;
      border-radius: 12px;
      padding: 1.25rem;
      box-shadow: 0 12px 30px rgba(27, 90, 42, 0.1);
      border: 1px solid rgba(40, 167, 69, 0.16);
    }

    .panel.rental-container {
      padding: 1.25rem 1.25rem 1.5rem;
    }

    .panel h2 {
      font-size: 1.1rem;
      color: #1b5a2a;
      margin-bottom: 0.8rem;
    }

    .panel p {
      color: #5b6b5b;
      font-size: 0.9rem;
      line-height: 1.6;
    }

    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.75rem;
      margin-bottom: 0.8rem;
      flex-wrap: wrap;
    }

    .section-header h1 {
      color: #14532d;
      font-size: 1.4rem;
      margin: 0;
      font-weight: 700;
    }

    .catalog-view-back-btn {
      width: 34px;
      height: 34px;
      border-radius: 10px;
      border: 1px solid #c7ded0;
      background: #ffffff;
      color: #1b5a2a;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      text-decoration: none;
      transition: transform 0.2s ease, background 0.2s ease, border-color 0.2s ease;
    }

    .catalog-view-back-btn:hover {
      background: #eef8f1;
      border-color: #b8dcc8;
      transform: translateY(-1px);
      text-decoration: none;
    }

    .seed-filter-toolbar {
      display: flex;
      gap: 1rem;
      margin: 0 0 1rem 0;
      width: 100%;
      box-sizing: border-box;
      align-items: stretch;
    }

    .filter-input,
    .filter-select {
      width: 100%;
      padding: 0.5rem 0.75rem;
      border: 1px solid #d1e7d8;
      border-radius: 8px;
      background: #fff;
      color: #1b5a2a;
      font-size: 0.9rem;
      outline: none;
      transition: border-color 0.2s ease, box-shadow 0.2s ease;
    }

    .filter-input {
      flex: 1 1 auto;
      min-width: 0;
    }

    .filter-select {
      flex: 0 0 320px;
      max-width: 320px;
    }

    .filter-input:focus,
    .filter-select:focus {
      border-color: #8bbfa0;
      box-shadow: 0 0 0 3px rgba(139, 191, 160, 0.16);
    }

    .action-btn {
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      padding: 0.6rem 1rem;
      border-radius: 8px;
      border: none;
      background: #28a745;
      color: #fff;
      text-decoration: none;
      font-weight: 600;
      cursor: pointer;
      font-size: 0.9rem;
    }

    .action-btn.secondary {
      background: #e8f5e9;
      color: #1b5a2a;
      border: 1px solid #cde9d3;
    }

    .action-btn.small {
      padding: 0.4rem 0.75rem;
      font-size: 0.85rem;
    }

    .quick-actions {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 0.75rem;
      margin-top: 1rem;
    }

    .quick-action {
      border: none;
      border-radius: 10px;
      padding: 0.85rem;
      color: #ffffff;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.6rem;
      font-weight: 600;
      cursor: pointer;
      background: rgba(40, 167, 69, 0.1);
      transition: all 0.2s ease;
      font-size: 0.9rem;
    }

    .quick-action:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.25);
    }

    .quick-action i {
      font-size: 1.1rem;
    }

    .client-section {
      display: none;
    }

    .client-section.active {
      display: block;
    }

    .table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 0.75rem;
      font-size: 0.9rem;
    }

    .table th,
    .table td {
      text-align: left;
      padding: 0.75rem;
      border-bottom: 1px solid #e5e7eb;
    }

    .pill {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      padding: 0.2rem 0.6rem;
      border-radius: 999px;
      font-size: 0.78rem;
      font-weight: 600;
      background: rgba(40, 167, 69, 0.15);
      color: #1b5a2a;
    }

    .pill.pending {
      background: #fef9c3;
      color: #a16207;
    }

    .pill.info {
      background: rgba(27, 90, 42, 0.1);
      color: #1b5a2a;
    }

    .profile-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
    }

    .profile-item {
      background: #f8fafc;
      border-radius: 10px;
      padding: 0.9rem;
      border: 1px solid #e2e8f0;
    }

    .profile-item span {
      display: block;
      color: #64748b;
      font-size: 0.8rem;
      margin-bottom: 0.35rem;
    }

    .profile-item strong {
      color: #1b5a2a;
      font-size: 0.95rem;
    }

    .action-form {
      margin-top: 1rem;
      padding: 1rem;
      border-radius: 12px;
      border: 1px solid rgba(40, 167, 69, 0.16);
      background: rgba(40, 167, 69, 0.06);
    }

    .action-form h3 {
      font-size: 1rem;
      color: #1b5a2a;
      margin-bottom: 0.75rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: repeat(3, minmax(0, 1fr));
      gap: 0.75rem;
      margin-bottom: 0.75rem;
    }

    .form-field label {
      display: block;
      font-size: 0.8rem;
      color: #5b6b5b;
      margin-bottom: 0.35rem;
      font-weight: 600;
    }

    .form-field input,
    .form-field select {
      width: 100%;
      padding: 0.6rem 0.75rem;
      border: 1px solid rgba(27, 90, 42, 0.25);
      border-radius: 8px;
      font-size: 0.9rem;
      outline: none;
      transition: border-color 0.2s, box-shadow 0.2s;
    }

    .form-field input:focus,
    .form-field select:focus {
      border-color: #28a745;
      box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }

    .form-actions {
      display: flex;
      justify-content: flex-end;
      gap: 0.5rem;
    }

    .form-actions button {
      border: none;
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #fff;
      padding: 0.6rem 1rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
    }

    .form-actions button.secondary {
      background: #ffffff;
      color: #1b5a2a;
      border: 1px solid rgba(27, 90, 42, 0.2);
    }

    .rental-shop {
      display: block;
      margin-top: 0;
    }

    .rental-section {
      background: transparent;
      border-radius: 0;
      border: none;
      padding: 0;
    }

    .rental-section h3 {
      color: #1b5a2a;
      font-size: 1.1rem;
      margin: 0 0 1rem 0;
      font-weight: 700;
    }

    .rental-section h3 {
      color: #1b5a2a;
      font-size: 1.1rem;
      margin: 0 0 1rem 0;
      font-weight: 700;
    }

    /* Rental Modal */
    .rental-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 10000;
      align-items: center;
      justify-content: center;
    }

    .rental-modal.active {
      display: flex;
    }

    .rental-modal-content {
      background: #fff;
      border-radius: 12px;
      padding: 1.5rem;
      width: 90%;
      max-width: 500px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-height: 85vh;
      overflow-y: auto;
    }

    .rental-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.75rem;
      border-bottom: 2px solid rgba(40, 167, 69, 0.15);
    }

    .rental-modal-header h3 {
      color: #1b5a2a;
      font-size: 1.1rem;
      margin: 0;
      font-weight: 700;
    }

    .rental-modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #6b776b;
      cursor: pointer;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: background 0.2s;
    }

    .rental-modal-close:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    .rental-modal-body {
      margin-bottom: 1.25rem;
    }

    .rental-modal-body .table {
      margin-top: 0;
      font-size: 0.85rem;
    }

    .rental-modal-body .table th,
    .rental-modal-body .table td {
      padding: 0.6rem;
    }

    .rental-modal-machine {
      background: linear-gradient(135deg, rgba(40, 167, 69, 0.1), rgba(40, 167, 69, 0.05));
      padding: 0.75rem;
      border-radius: 8px;
      margin-bottom: 1rem;
      color: #1b5a2a;
      font-weight: 600;
    }

    .rental-modal-actions {
      display: flex;
      gap: 0.75rem;
      justify-content: flex-end;
    }

    .modal-btn {
      padding: 0.65rem 1.25rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      border: none;
      font-size: 0.9rem;
    }

    .modal-btn-cancel {
      background: #fff;
      color: #1b5a2a;
      border: 1px solid rgba(27, 90, 42, 0.2);
    }

    .modal-btn-cancel:hover {
      background: rgba(40, 167, 69, 0.08);
    }

    .modal-btn-confirm {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #fff;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.25);
    }

    .modal-btn-confirm:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.3);
    }

    .catalog-view-title {
      margin: 0;
      color: #1b5a2a;
      font-size: 1.1rem;
      font-weight: 700;
    }

    .catalog-view-subtitle {
      margin-top: 0.2rem;
      color: #5f735f;
      font-size: 0.85rem;
      font-weight: 600;
    }

    .catalog-view-grid {
      display: grid;
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 0.7rem;
      margin-top: 0.9rem;
    }

    .catalog-view-item {
      border: 1px solid #d7e7de;
      background: #f8fcf9;
      border-radius: 10px;
      padding: 0.65rem 0.75rem;
    }

    .catalog-view-item span {
      display: block;
      color: #5e7b66;
      font-size: 0.74rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .catalog-view-item strong {
      display: block;
      margin-top: 0.2rem;
      color: #14532d;
      font-size: 0.95rem;
      line-height: 1.3;
      word-break: break-word;
    }

    .catalog-view-note {
      margin-top: 0.9rem;
      border: 1px dashed #c7ded0;
      border-radius: 10px;
      padding: 0.7rem 0.75rem;
      background: #fbfefc;
      color: #46614f;
      font-size: 0.84rem;
      line-height: 1.45;
    }

    .date-controls {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.75rem;
      margin-bottom: 0.75rem;
    }

    .note-control {
      margin-top: 0.5rem;
    }

    .catalog-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
      gap: 0.85rem;
      align-items: start !important;
    }

    .catalog-card {
      border: 1px solid #cfe4d7;
      border-radius: 14px;
      background: #ffffff;
      padding: 0.85rem;
      display: grid;
      gap: 0.55rem;
      align-content: start;
      box-shadow: 0 8px 22px rgba(20, 84, 46, 0.08);
      transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
      width: 100%;
      max-width: 315px;
      justify-self: center;
      align-self: start !important;
      height: fit-content !important;
      min-height: unset !important;
    }

    .catalog-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 14px 28px rgba(20, 84, 46, 0.12);
      border-color: #a8d3bb;
    }

    .catalog-thumb {
      height: 88px;
      border-radius: 12px;
      background: linear-gradient(145deg, #e7f3ea 0%, #d8eadf 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #1f6b3c;
      font-size: 2rem;
    }

    .catalog-thumb img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      border-radius: 12px;
      display: block;
    }

    .catalog-chip {
      display: inline-flex;
      align-items: center;
      gap: 0.35rem;
      padding: 0.2rem 0.55rem;
      border-radius: 999px;
      font-size: 0.72rem;
      font-weight: 600;
      background: rgba(40, 167, 69, 0.14);
      color: #1b5a2a;
    }

    .catalog-card h4 {
      color: #1b5a2a;
      font-size: 1rem;
      font-weight: 700;
      margin: 0;
      word-wrap: break-word;
      flex: 1;
      line-height: 1.3;
    }

    .catalog-header {
      display: flex;
      align-items: flex-start;
      gap: 0.55rem;
      justify-content: space-between;
    }

    .catalog-title-wrap {
      display: grid;
      gap: 0.15rem;
      min-width: 0;
      flex: 1;
    }

    .catalog-unit {
      color: #5b6f61;
      font-size: 0.74rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.03em;
    }

    .favorite-btn {
      background: none;
      border: none;
      cursor: pointer;
      font-size: 1.3rem;
      color: #1b5a2a;
      padding: 0.25rem;
      transition: all 0.2s;
      flex-shrink: 0;
    }

    .favorite-btn:hover {
      transform: scale(1.2);
    }

    .favorite-btn.favorited {
      color: #dc3545;
    }

    .favorite-btn.favorited i {
      font-weight: 900;
    }

    .catalog-meta {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 0.6rem;
      color: #4f6f58;
      font-size: 0.82rem;
      line-height: 1.35;
    }

    .catalog-stock {
      border: 1px solid #b8dcc8;
      border-radius: 10px;
      background: #f7fcf9;
      padding: 0.45rem 0.6rem;
      text-align: center;
    }

    .catalog-stock-label {
      display: block;
      color: #567160;
      font-size: 0.74rem;
      font-weight: 700;
      letter-spacing: 0.03em;
      text-transform: uppercase;
    }

    .catalog-stock-value {
      display: block;
      color: #14532d;
      font-size: 1.02rem;
      font-weight: 800;
      margin-top: 0.2rem;
      line-height: 1.2;
    }

    .catalog-qty-wrap {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.45rem;
      margin-top: 0.45rem;
      color: #4f6f58;
      font-size: 0.78rem;
      font-weight: 600;
    }

    .catalog-actions {
      display: grid;
      grid-template-columns: 44px 1fr;
      align-items: center;
      gap: 0.45rem;
      width: 100%;
    }

    .catalog-view-btn {
      width: 44px;
      min-width: 44px;
      height: 36px;
      border-radius: 10px;
      border: 1px solid #9ecfb0;
      background: #ffffff;
      color: #166534;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 0.95rem;
      text-decoration: none !important;
      transition: background 0.2s ease, border-color 0.2s ease, transform 0.2s ease;
    }

    .catalog-view-btn:hover {
      background: #f2fbf5;
      border-color: #79ba95;
      transform: translateY(-1px);
      text-decoration: none !important;
    }

    .catalog-view-btn:focus,
    .catalog-view-btn:active,
    .catalog-view-btn:visited {
      text-decoration: none !important;
    }

    .catalog-view-btn i {
      text-decoration: none !important;
    }

    .catalog-qty {
      width: 60px;
      padding: 0.5rem 0.4rem;
      border-radius: 8px;
      border: 1px solid rgba(27, 90, 42, 0.2);
      text-align: center;
      font-weight: 600;
      font-size: 0.9rem;
    }

    .catalog-add-btn {
      border: none;
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #fff;
      padding: 0.45rem 0.9rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s, box-shadow 0.2s;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.2);
      font-size: 0.8rem;
      width: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.4rem;
      min-height: 36px;
      text-decoration: none !important;
    }

    .catalog-add-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.3);
    }

    .catalog-add-btn:active {
      transform: translateY(0);
    }

    #section-bids .catalog-card,
    #section-rentals .catalog-card,
    #section-livestock .catalog-card {
      min-height: 0;
    }

    .reservation-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .reservation-header h3 {
      color: #1b5a2a;
      font-size: 1.05rem;
      margin: 0;
      font-weight: 700;
    }

    .reservation-count {
      background: rgba(40, 167, 69, 0.12);
      color: #1b5a2a;
      border-radius: 999px;
      padding: 0.2rem 0.6rem;
      font-size: 0.8rem;
    }

    .reservation-list {
      display: grid;
      gap: 0.6rem;
      max-height: 400px;
      overflow-y: auto;
      margin-bottom: 1rem;
    }

    .reservation-item {
      border: 1px solid rgba(40, 167, 69, 0.2);
      border-radius: 8px;
      padding: 0.75rem;
      display: grid;
      grid-template-columns: 1fr auto;
      gap: 0.5rem;
      background: linear-gradient(135deg, rgba(248, 250, 252, 0.8), rgba(255, 255, 255, 0.9));
      align-items: center;
    }

    .reservation-item strong {
      color: #1b5a2a;
      font-size: 0.9rem;
    }

    .reservation-item span {
      color: #6b776b;
      font-size: 0.78rem;
    }

    .reservation-item-actions {
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }

    .reservation-qty {
      width: 60px;
      padding: 0.35rem 0.45rem;
      border-radius: 8px;
      border: 1px solid rgba(27, 90, 42, 0.2);
      text-align: center;
      font-weight: 600;
    }

    .reservation-remove-btn {
      border: none;
      background: rgba(220, 53, 69, 0.12);
      color: #b4232a;
      border-radius: 8px;
      padding: 0.4rem 0.6rem;
      cursor: pointer;
      font-weight: 600;
      font-size: 0.8rem;
      transition: background 0.2s;
    }

    .reservation-remove-btn:hover {
      background: rgba(220, 53, 69, 0.2);
    }

    .reservation-empty {
      color: #6b776b;
      font-size: 0.85rem;
      text-align: center;
      padding: 2rem 1rem;
      background: linear-gradient(135deg, rgba(248, 250, 252, 0.5), rgba(255, 255, 255, 0.5));
      border-radius: 8px;
      border: 2px dashed rgba(40, 167, 69, 0.25);
    }

    .reservation-summary {
      background: linear-gradient(135deg, rgba(40, 167, 69, 0.06), rgba(40, 167, 69, 0.03));
      border-radius: 8px;
      padding: 0.9rem;
      display: grid;
      gap: 0.5rem;
      font-size: 0.82rem;
      color: #5b6b5b;
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      gap: 0.5rem;
    }

    .summary-row strong {
      color: #1b5a2a;
      font-weight: 700;
    }

    .reservation-actions {
      display: grid;
      gap: 0.5rem;
    }

    /* Quick Actions Below Cards */
    .rental-quick-actions {
      display: flex;
      gap: 0.5rem;
      margin-top: 1rem;
    }

    .quick-action-btn {
      background: #fff;
      border: 2px solid rgba(40, 167, 69, 0.2);
      border-radius: 8px;
      padding: 0.5rem 0.75rem;
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 0.4rem;
      cursor: pointer;
      transition: all 0.3s;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.06);
      flex: 1;
    }

    .quick-action-btn:hover {
      background: linear-gradient(135deg, rgba(40, 167, 69, 0.08), rgba(40, 167, 69, 0.04));
      border-color: rgba(40, 167, 69, 0.4);
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.12);
    }

    .quick-action-btn i {
      font-size: 1rem;
      color: #1b5a2a;
    }

    .quick-action-btn span {
      color: #1b5a2a;
      font-weight: 600;
      font-size: 0.75rem;
    }

    .reservation-clear-btn {
      border: 1px solid rgba(27, 90, 42, 0.2);
      background: #fff;
      color: #1b5a2a;
      padding: 0.55rem 1rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s, border-color 0.2s;
    }

    .reservation-clear-btn:hover {
      background: rgba(40, 167, 69, 0.08);
      border-color: rgba(27, 90, 42, 0.3);
    }

    .checkout-btn {
      border: none;
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #fff;
      padding: 0.7rem 1rem;
      border-radius: 8px;
      font-weight: 700;
      cursor: pointer;
      font-size: 0.95rem;
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.25);
      transition: transform 0.2s;
    }

    .checkout-btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(27, 90, 42, 0.3);
    }

    .checkout-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
      transform: none;
    }

    /* Crop Card Styles */
    .crop-card {
      height: 480px;
      display: flex;
      flex-direction: column;
    }

    .bid-btn {
      margin-top: auto;
    }

    /* Machinery Card Styles */
    .machinery-card {
      height: 380px;
      display: flex;
      flex-direction: column;
    }

    .machinery-card .catalog-price-section {
      margin-top: 0.2rem;
      margin-bottom: 0.3rem;
    }

    .crop-details {
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 0.8rem;
    }

    .crop-description {
      color: #5b6b5b;
      font-size: 0.85rem;
      line-height: 1.5;
      margin: 0;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .crop-info-grid {
      display: grid;
      gap: 0.6rem;
    }

    .crop-info-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      color: #5b6b5b;
      font-size: 0.85rem;
      background: rgba(40, 167, 69, 0.08);
      padding: 0.5rem 0.7rem;
      border-radius: 8px;
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .crop-info-item i {
      color: #1b5a2a;
      font-size: 0.9rem;
    }

    .crop-info-item span {
      font-weight: 600;
      color: #1b5a2a;
    }

    .crop-price-section {
      background: linear-gradient(135deg, rgba(27, 90, 42, 0.08), rgba(40, 167, 69, 0.05));
      border-radius: 10px;
      padding: 0.4rem;
      border: 1px solid rgba(40, 167, 69, 0.2);
      text-align: center;
    }

    .crop-price-label {
      font-size: 0.65rem;
      color: #5b6b5b;
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 0.5px;
      margin-bottom: 0.1rem;
    }

    .crop-price {
      font-size: 1.1rem;
      color: #1b5a2a;
      font-weight: 700;
      margin-bottom: 0.1rem;
    }

    .crop-price-note {
      font-size: 0.65rem;
      color: #6b776b;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 0.3rem;
    }

    .crop-price-note i {
      color: #28a745;
    }

    .bid-btn {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      transition: all 0.3s ease;
    }

    .bid-btn:hover {
      background: linear-gradient(135deg, #143d1e 0%, #218838 100%);
      transform: translateY(-2px);
      box-shadow: 0 6px 16px rgba(27, 90, 42, 0.35);
    }

    /* Bidding Modal Styles */
    .bidding-info {
      background: rgba(40, 167, 69, 0.08);
      border-radius: 10px;
      padding: 1rem;
      margin-top: 1rem;
      border: 1px solid rgba(40, 167, 69, 0.2);
    }

    .bidding-info-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 0.5rem 0;
    }

    .bidding-info-row:not(:last-child) {
      border-bottom: 1px solid rgba(40, 167, 69, 0.15);
    }

    .bidding-info-row span {
      color: #5b6b5b;
      font-size: 0.9rem;
    }

    .bidding-info-row strong {
      color: #1b5a2a;
      font-size: 1.1rem;
      font-weight: 700;
    }

    /* Hero Banner Styles */
    .bidding-hero {
      background: linear-gradient(135deg, #f0f7f3 0%, #e8f5e9 100%);
      border-radius: 12px;
      padding: 1.5rem 1.75rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.08);
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .hero-content {
      max-width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
      margin-bottom: 1.25rem;
    }

    .hero-header {
      flex: 1;
      text-align: center;
    }

    .hero-title {
      font-size: 1.4rem;
      color: #1b5a2a;
      font-weight: 700;
      margin-bottom: 0.5rem;
      text-align: center;
    }

    .hero-subtitle {
      font-size: 0.9rem;
      color: #5b6b5b;
      text-align: center;
      margin-bottom: 0;
    }

    .hero-actions {
      display: flex;
      justify-content: center;
      gap: 0.75rem;
      margin-top: 1rem;
    }

    .view-bids-btn {
      background: #ffffff;
      border: 1px solid rgba(40, 167, 69, 0.25);
      color: #1b5a2a;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      font-size: 0.85rem;
    }

    .view-bids-btn:hover {
      background: rgba(40, 167, 69, 0.08);
      border-color: rgba(40, 167, 69, 0.35);
    }

    .view-bids-btn i {
      font-size: 0.9rem;
    }

    .hero-search-bar {
      display: grid;
      grid-template-columns: 2fr 1.2fr 1.2fr auto;
      gap: 0.5rem;
      background: #ffffff;
      padding: 0.5rem;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.1);
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .hero-search-input,
    .hero-search-select {
      border: 1px solid rgba(40, 167, 69, 0.2);
      padding: 0.6rem 0.85rem;
      border-radius: 8px;
      font-size: 0.85rem;
      background: #ffffff;
      color: #1b5a2a;
      font-weight: 500;
      outline: none;
      transition: all 0.2s;
    }

    .hero-search-input:focus,
    .hero-search-select:focus {
      border-color: #28a745;
      box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }

    .hero-search-input::placeholder {
      color: #8b9a8b;
    }

    .hero-search-btn {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #ffffff;
      border: none;
      padding: 0.6rem 1.25rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      box-shadow: 0 2px 6px rgba(27, 90, 42, 0.2);
      white-space: nowrap;
      font-size: 0.85rem;
    }

    .hero-search-btn:hover {
      box-shadow: 0 4px 10px rgba(27, 90, 42, 0.25);
    }

    .hero-search-btn i {
      margin-right: 0.4rem;
    }

    /* Panel Header Flex */
    .panel-header-flex {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1rem;
    }

    .panel-header-flex h2 {
      margin-bottom: 0.25rem;
    }

    .panel-header-flex p {
      margin: 0;
      font-size: 0.9rem;
    }

    .sort-controls {
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }

    .sort-select {
      padding: 0.6rem 1rem;
      border: 1px solid rgba(40, 167, 69, 0.25);
      border-radius: 8px;
      font-size: 0.9rem;
      color: #1b5a2a;
      background: #ffffff;
      font-weight: 600;
      cursor: pointer;
      outline: none;
      transition: all 0.2s;
    }

    .sort-select:hover {
      border-color: #28a745;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.1);
    }

    /* Favorites Section Styles */
    .stat-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 2.5rem;
      height: 2.5rem;
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #ffffff;
      border-radius: 50%;
      font-weight: 700;
      font-size: 1.2rem;
    }

    .favorites-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 1.5rem;
      margin-top: 1.5rem;
    }

    .favorite-item {
      background: #ffffff;
      border: 1px solid rgba(40, 167, 69, 0.15);
      border-radius: 12px;
      padding: 1rem;
      display: flex;
      flex-direction: column;
      gap: 0.8rem;
      transition: all 0.2s;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.08);
    }

    .favorite-item:hover {
      border-color: rgba(40, 167, 69, 0.3);
      box-shadow: 0 4px 12px rgba(27, 90, 42, 0.15);
      transform: translateY(-2px);
    }

    .favorite-item-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 0.5rem;
    }

    .favorite-item-info h3 {
      margin: 0 0 0.2rem 0;
      color: #1b5a2a;
      font-size: 1rem;
    }

    .favorite-item-category {
      display: inline-block;
      background: rgba(40, 167, 69, 0.1);
      color: #1b5a2a;
      font-size: 0.7rem;
      font-weight: 600;
      padding: 0.3rem 0.6rem;
      border-radius: 6px;
      text-transform: uppercase;
    }

    .favorite-item-remove {
      background: none;
      border: none;
      color: #dc3545;
      font-size: 1.2rem;
      cursor: pointer;
      padding: 0.25rem;
      transition: all 0.2s;
      flex-shrink: 0;
    }

    .favorite-item-remove:hover {
      transform: scale(1.15);
      color: #c82333;
    }

    .favorite-item-details {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.8rem;
    }

    .favorite-item-detail {
      font-size: 0.85rem;
      color: #5b6b5b;
    }

    .favorite-item-detail span {
      display: block;
      font-weight: 600;
      color: #1b5a2a;
      margin-top: 0.2rem;
    }

    .favorite-item-price {
      background: linear-gradient(135deg, rgba(27, 90, 42, 0.08), rgba(40, 167, 69, 0.05));
      border-radius: 10px;
      padding: 0.8rem;
      border: 1px solid rgba(40, 167, 69, 0.2);
      text-align: center;
    }

    .favorite-item-price-label {
      font-size: 0.7rem;
      color: #5b6b5b;
      text-transform: uppercase;
      font-weight: 600;
    }

    .favorite-item-price-amount {
      font-size: 1.2rem;
      color: #1b5a2a;
      font-weight: 700;
      margin-top: 0.2rem;
    }

    .favorite-item-status {
      font-size: 0.74rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
      padding: 0.2rem 0.5rem;
      border-radius: 999px;
      border: 1px solid rgba(40, 167, 69, 0.28);
      color: #1b5a2a;
      background: rgba(40, 167, 69, 0.08);
    }

    .favorite-item-status.unavailable {
      border-color: rgba(220, 53, 69, 0.28);
      color: #9f1f2d;
      background: rgba(220, 53, 69, 0.1);
    }

    .favorite-item-actions {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 0.6rem;
    }

    .favorite-item-action {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 0.45rem;
      border-radius: 9px;
      border: 1px solid rgba(27, 90, 42, 0.2);
      background: #f3f8f4;
      color: #1b5a2a;
      min-height: 2.2rem;
      padding: 0.45rem 0.65rem;
      font-size: 0.82rem;
      font-weight: 700;
      text-decoration: none;
      cursor: pointer;
      transition: all 0.2s;
    }

    .favorite-item-action:hover {
      transform: translateY(-1px);
      border-color: rgba(40, 167, 69, 0.45);
      background: #ebf5ee;
    }

    .favorite-item-action.primary {
      border-color: #1f7f3e;
      background: linear-gradient(135deg, #1f7f3e 0%, #29a24d 100%);
      color: #ffffff;
    }

    .favorite-item-action.primary:hover {
      filter: brightness(1.05);
    }

    .favorite-item-action.disabled,
    .favorite-item-action:disabled {
      border-color: rgba(125, 140, 130, 0.28);
      background: #eef2ef;
      color: #7f8f84;
      cursor: not-allowed;
      pointer-events: none;
      transform: none;
    }

    /* My Bids Modal Styles */
    .my-bids-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 10000;
      align-items: center;
      justify-content: center;
    }

    .my-bids-modal.active {
      display: flex;
    }

    /* Rental Hero Banner Styles */
    .rental-hero {
      background: linear-gradient(135deg, #f0f7f3 0%, #e8f5e9 100%);
      border-radius: 12px;
      padding: 1.5rem 1.75rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.08);
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .rental-hero-content {
      max-width: 100%;
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 1rem;
      margin-bottom: 1.25rem;
    }

    .rental-hero-header {
      flex: 1;
      text-align: center;
    }

    .rental-hero-title {
      font-size: 1.4rem;
      color: #1b5a2a;
      font-weight: 700;
      margin-bottom: 0.5rem;
      text-align: center;
    }

    .rental-hero-subtitle {
      font-size: 0.9rem;
      color: #5b6b5b;
      text-align: center;
      margin-bottom: 0;
    }

    .view-reservation-btn {
      background: #ffffff;
      border: 1px solid rgba(40, 167, 69, 0.25);
      color: #1b5a2a;
      padding: 0.5rem 1rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      gap: 0.4rem;
      font-size: 0.85rem;
      white-space: nowrap;
      flex-shrink: 0;
    }

    .view-reservation-btn:hover {
      background: rgba(40, 167, 69, 0.08);
      border-color: rgba(40, 167, 69, 0.35);
    }

    .view-reservation-btn i {
      font-size: 0.9rem;
    }

    .rental-search-bar {
      display: grid;
      grid-template-columns: 2fr 1.2fr auto;
      gap: 0.5rem;
      background: #ffffff;
      padding: 0.5rem;
      border-radius: 10px;
      box-shadow: 0 2px 8px rgba(27, 90, 42, 0.1);
      border: 1px solid rgba(40, 167, 69, 0.15);
    }

    .rental-search-input,
    .rental-search-select {
      border: 1px solid rgba(40, 167, 69, 0.2);
      padding: 0.6rem 0.85rem;
      border-radius: 8px;
      font-size: 0.85rem;
      background: #ffffff;
      color: #1b5a2a;
      font-weight: 500;
      outline: none;
      transition: all 0.2s;
    }

    .rental-search-input:focus,
    .rental-search-select:focus {
      border-color: #28a745;
      box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.1);
    }

    .rental-search-input::placeholder {
      color: #8b9a8b;
    }

    .rental-search-btn {
      background: linear-gradient(135deg, #1b5a2a 0%, #28a745 100%);
      color: #ffffff;
      border: none;
      padding: 0.6rem 1.25rem;
      border-radius: 8px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s ease;
      box-shadow: 0 2px 6px rgba(27, 90, 42, 0.2);
      white-space: nowrap;
      font-size: 0.85rem;
    }

    .rental-search-btn:hover {
      box-shadow: 0 4px 10px rgba(27, 90, 42, 0.25);
    }

    .rental-search-btn i {
      margin-right: 0.4rem;
    }

    /* Reservation Modal */
    .reservation-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 10000;
      align-items: center;
      justify-content: center;
    }

    .reservation-modal.active {
      display: flex;
    }

    .reservation-modal-content {
      background: #fff;
      border-radius: 12px;
      padding: 1.5rem;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-height: 85vh;
      overflow-y: auto;
    }

    .reservation-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.75rem;
      border-bottom: 2px solid rgba(40, 167, 69, 0.15);
    }

    .reservation-modal-header h2 {
      color: #1b5a2a;
      font-size: 1.3rem;
      margin: 0;
      font-weight: 700;
    }

    .reservation-modal-header span {
      background: rgba(40, 167, 69, 0.12);
      color: #1b5a2a;
      border-radius: 999px;
      padding: 0.3rem 0.8rem;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .reservation-modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #6b776b;
      cursor: pointer;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: background 0.2s;
    }

    .reservation-modal-close:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    /* Reservation Modal */
    .reservation-modal {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 10000;
      align-items: center;
      justify-content: center;
    }

    .reservation-modal.active {
      display: flex;
    }

    .reservation-modal-content {
      background: #fff;
      border-radius: 12px;
      padding: 1.5rem;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-height: 85vh;
      overflow-y: auto;
    }

    .reservation-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.75rem;
      border-bottom: 2px solid rgba(40, 167, 69, 0.15);
    }

    .reservation-modal-header h2 {
      color: #1b5a2a;
      font-size: 1.3rem;
      margin: 0;
      font-weight: 700;
    }

    .reservation-modal-header span {
      background: rgba(40, 167, 69, 0.12);
      color: #1b5a2a;
      border-radius: 999px;
      padding: 0.3rem 0.8rem;
      font-size: 0.75rem;
      font-weight: 600;
    }

    .reservation-modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #6b776b;
      cursor: pointer;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: background 0.2s;
    }

    .reservation-modal-close:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    .my-bids-modal-content {
      background: #fff;
      border-radius: 12px;
      padding: 1.5rem;
      width: 90%;
      max-width: 700px;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-height: 85vh;
      overflow-y: auto;
    }

    .my-bids-modal-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 1.25rem;
      padding-bottom: 0.75rem;
      border-bottom: 2px solid rgba(40, 167, 69, 0.15);
    }

    .my-bids-modal-header h2 {
      color: #1b5a2a;
      font-size: 1.3rem;
      margin: 0;
      font-weight: 700;
    }

    .my-bids-modal-close {
      background: none;
      border: none;
      font-size: 1.5rem;
      color: #6b776b;
      cursor: pointer;
      padding: 0;
      width: 30px;
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: background 0.2s;
    }

    .my-bids-modal-close:hover {
      background: rgba(0, 0, 0, 0.05);
    }

    @media (max-width: 1100px) {
      .overview-summary-grid {
        grid-template-columns: 1fr;
      }

      .stat-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }

      .section-grid {
        grid-template-columns: 1fr;
      }

      .catalog-grid {
        grid-template-columns: repeat(3, minmax(0, 1fr));
      }

      .favorites-grid {
        grid-template-columns: repeat(2, 1fr);
      }

      .hero-search-bar {
        grid-template-columns: 1fr 1fr;
      }

      .hero-search-btn {
        grid-column: 1 / -1;
      }

      .seed-filter-toolbar {
        flex-direction: column;
        gap: 0.8rem;
      }

      .filter-select {
        flex: 1 1 auto;
        max-width: none;
      }
    }

    @media (max-width: 720px) {
      .stat-grid {
        grid-template-columns: 1fr;
      }

      .overview-alert-item {
        flex-direction: column;
        align-items: flex-start;
      }

      .overview-alert-meta {
        text-align: left;
      }

      .profile-grid {
        grid-template-columns: 1fr;
      }

      .form-row {
        grid-template-columns: 1fr;
      }

      .date-controls {
        grid-template-columns: 1fr;
      }

      .catalog-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 1rem;
      }

      .favorites-grid {
        grid-template-columns: 1fr;
      }

      .catalog-card {
        padding: 1rem;
        gap: 0.6rem;
      }



      .reservation-actions {
        grid-template-columns: 1fr;
      }

      .rental-quick-actions {
        flex-direction: column;
      }

      .hero-title {
        font-size: 1.8rem;
      }

      .hero-subtitle {
        font-size: 0.95rem;
      }

      .bidding-hero {
        padding: 2rem 1.25rem;
      }

      .hero-search-bar {
        grid-template-columns: 1fr;
      }

      .panel-header-flex {
        flex-direction: column;
        align-items: flex-start;
        gap: 1rem;
      }

      .sort-controls {
        width: 100%;
      }

      .sort-select {
        width: 100%;
      }

      .section-header {
        flex-direction: column;
        align-items: flex-start;
      }

      .catalog-view-grid {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body class="client">

  <div class="admin-top-nav" style="display: flex; align-items: center; justify-content: space-between; padding-right: 2.5rem;">
    <div class="admin-logo" style="display: flex; align-items: center; gap: 0.7rem;">
      <img src="../images/smartfarm_logo.png" alt="Smart Farm Logo">
      <span>Smart Farm</span>
    </div>
    <!-- Notification Bell Button -->
    <div class="topbar-actions" style="display: flex; align-items: center; gap: 1.2rem; position: relative;">
      <button type="button" id="clientNotifBellBtn" class="notif-bell-btn" aria-label="Notifications" style="background: none; border: none; position: relative; font-size: 1.45rem; color: #fff; cursor: pointer;">
        <i class="fas fa-bell"></i>
        <?php if ($client_unread_count > 0): ?>
        <span class="notif-badge" style="position: absolute; top: -7px; right: -7px; background: #dc3545; color: #fff; border-radius: 50%; font-size: 0.72rem; min-width: 18px; height: 18px; display: flex; align-items: center; justify-content: center; padding: 0 5px; font-weight: 700; border: 2px solid #fff; z-index: 2;">
          <?php echo (int)$client_unread_count; ?>
        </span>
        <?php endif; ?>
      </button>
      <!-- Notification Dropdown -->
      <div id="clientNotifDropdown" class="notif-dropdown" style="display: none; position: absolute; right: 0; top: 120%; min-width: 340px; background: #fff; border-radius: 12px; box-shadow: 0 8px 32px rgba(27,90,42,0.18); border: 1px solid #cde9d3; z-index: 1000;">
        <div style="padding: 1rem 1.1rem 0.5rem 1.1rem; border-bottom: 1px solid #e5e7eb; display: flex; align-items: center; justify-content: space-between;">
          <span style="font-weight: 700; color: #1b5a2a; font-size: 1rem;">Notifications</span>
          <button type="button" onclick="markClientNotificationsRead()" style="background: none; border: none; color: #28a745; font-size: 0.9rem; font-weight: 600; cursor: pointer;">Mark all read</button>
        </div>
        <div style="max-height: 340px; overflow-y: auto;">
          <?php if (!empty($client_notifications)): ?>
            <?php foreach ($client_notifications as $i => $notif): ?>
              <div style="padding: 0.85rem 1.1rem; background: <?php echo !$notif['is_read'] ? '#e8f5e9' : '#fff'; ?>; display: flex; flex-direction: column; gap: 0.18rem;">
                <span style="font-weight: 700; color: #14532d; font-size: 0.97rem;"><i class="fas fa-bell" style="margin-right:0.4rem;"></i><?php echo htmlspecialchars($notif['title']); ?></span>
                <span style="color: #4b6357; font-size: 0.89rem;"> <?php echo htmlspecialchars($notif['message']); ?></span>
                <span style="color: #6b776b; font-size: 0.78rem; margin-top: 0.1rem;"><i class="far fa-clock"></i> <?php echo htmlspecialchars($notif['created_label']); ?></span>
              </div>
              <?php if ($i < count($client_notifications) - 1): ?>
                <div style="border-bottom: 1.5px solid #cde9d3; margin: 0 1.1rem;"></div>
              <?php endif; ?>
            <?php endforeach; ?>
          <?php else: ?>
            <div style="padding: 1.2rem; text-align: center; color: #6b7280; font-size: 0.97rem;">No notifications yet.</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
  <script>
    // Notification Bell Dropdown Toggle
    const notifBellBtn = document.getElementById('clientNotifBellBtn');
    const notifDropdown = document.getElementById('clientNotifDropdown');
    if (notifBellBtn && notifDropdown) {
      notifBellBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        notifDropdown.style.display = notifDropdown.style.display === 'block' ? 'none' : 'block';
      });
      document.addEventListener('click', function(e) {
        if (!notifDropdown.contains(e.target) && e.target !== notifBellBtn) {
          notifDropdown.style.display = 'none';
        }
      });
    }
    // Mark notifications as read (AJAX)
    function markClientNotificationsRead() {
      fetch('../mark_notifications_read.php', { method: 'POST', credentials: 'same-origin' })
        .then(() => { window.location.reload(); });
    }
  </script>

  <div class="admin-container">
    <aside class="admin-sidebar">
      <nav class="admin-nav">
        <h3 class="nav-title">Client Menu</h3>
        <?php if ($is_client_verified_access): ?>
        <a href="dashboard.php?section=overview" class="nav-item<?php echo $active_section === 'overview' ? ' active' : ''; ?>" data-section="overview" onclick="showSection('overview'); return false;">
          <i class="fas fa-chart-line"></i>
          <span>Home</span>
        </a>
        <a href="dashboard.php?section=bids" class="nav-item<?php echo $active_section === 'bids' ? ' active' : ''; ?>" data-section="bids" onclick="showSection('bids'); return false;">
          <i class="fas fa-gavel"></i>
          <span>Bids</span>
        </a>
        <a href="dashboard.php?section=rentals" class="nav-item<?php echo $active_section === 'rentals' ? ' active' : ''; ?>" data-section="rentals" onclick="showSection('rentals'); return false;">
          <i class="fas fa-tractor"></i>
          <span>Rentals</span>
        </a>
        <a href="dashboard.php?section=livestock" class="nav-item<?php echo in_array($active_section, ['livestock', 'livestock-reservations', 'livestock-form'], true) ? ' active' : ''; ?>" data-section="livestock" onclick="showSection('livestock'); return false;">
          <i class="fas fa-cow"></i>
          <span>Livestock</span>
        </a>
        <a href="dashboard.php?section=favorites" class="nav-item<?php echo $active_section === 'favorites' ? ' active' : ''; ?>" data-section="favorites" onclick="showSection('favorites'); return false;">
          <i class="fas fa-heart"></i>
          <span>Favorites</span>
        </a>
        <?php else: ?>
        <a href="#" class="nav-item active" data-section="profile" onclick="showSection('profile'); return false;">
          <i class="fas fa-user"></i>
          <span>Profile</span>
        </a>
        <?php endif; ?>
        <div class="admin-profile" data-user-id="<?php echo htmlspecialchars($_SESSION['user_id'] ?? ''); ?>">
          <button type="button" class="admin-profile-trigger" id="adminProfileTrigger" aria-haspopup="true" aria-expanded="false">
            <span class="admin-profile-avatar">
              <i class="fas fa-user-circle"></i>
            </span>
            <span class="admin-profile-info">
              <span class="admin-profile-name">
                <?php echo htmlspecialchars($client_name); ?>
              </span>
              <span class="admin-profile-meta"><?php echo htmlspecialchars($client_badge_text); ?></span>
            </span>
            <i class="fas fa-chevron-down admin-profile-caret"></i>
          </button>
          <div class="admin-profile-dropdown" id="adminProfileDropdown" aria-hidden="true">
            <!-- View Profile button removed -->
            <button type="button" class="admin-profile-action admin-profile-logout" onclick="window.location.href='../logout.php'">
              <i class="fas fa-sign-out-alt"></i>
              Logout
            </button>
          </div>
        </div>
      </nav>
    </aside>

    <main class="client-main">
      <?php if ($is_client_verified_access): ?>
      <section id="section-overview" class="client-section<?php echo $active_section === 'overview' ? ' active' : ''; ?>">
        <!-- Welcome Section -->
        <div class="client-header">
          <div class="client-title">
            <h1>Welcome, <?php echo htmlspecialchars($client_name); ?></h1>
            <p>As of <?php echo htmlspecialchars($today); ?></p>
          </div>
          <div class="client-badge <?php echo htmlspecialchars($client_badge_class); ?>"><?php echo htmlspecialchars($client_badge_text); ?></div>
        </div>

        <!-- Quick Access Cards -->
        <div class="overview-summary-grid">
          <div class="overview-summary-card" onclick="showSection('bids')">
            <div class="overview-summary-left">
              <div class="overview-summary-icon">
                <i class="fas fa-gavel"></i>
              </div>
              <div>
                <div class="overview-summary-label">Bidding Opportunities</div>
                <div class="overview-summary-value"><?php echo (int)$overview_active_bids; ?> Active Listings</div>
              </div>
            </div>
            <i class="fas fa-arrow-right overview-summary-arrow"></i>
          </div>

          <div class="overview-summary-card" onclick="showSection('rentals')">
            <div class="overview-summary-left">
              <div class="overview-summary-icon">
                <i class="fas fa-tractor"></i>
              </div>
              <div>
                <div class="overview-summary-label">Equipment Rentals</div>
                <div class="overview-summary-value"><?php echo (int)$overview_upcoming_rentals; ?> Upcoming Reservations</div>
              </div>
            </div>
            <i class="fas fa-arrow-right overview-summary-arrow"></i>
          </div>

          <div class="overview-summary-card" onclick="showSection('livestock')">
            <div class="overview-summary-left">
              <div class="overview-summary-icon">
                <i class="fas fa-cow"></i>
              </div>
              <div>
                <div class="overview-summary-label">Livestock Catalog</div>
                <div class="overview-summary-value"><?php echo (int)$overview_available_products; ?> Available Items</div>
              </div>
            </div>
            <i class="fas fa-arrow-right overview-summary-arrow"></i>
          </div>
        </div>

        <div class="panel">
          <div class="overview-alert-head">
            <i class="fas fa-calendar-check"></i>
            <h2>Upcoming Activities</h2>
          </div>
          <div class="overview-alert-list">
            <?php if (!empty($overview_incoming_events)): ?>
              <?php foreach ($overview_incoming_events as $event_item): ?>
              <div class="overview-alert-item">
                <div>
                  <strong><?php echo htmlspecialchars((string)$event_item['title']); ?></strong>
                  <small><?php echo htmlspecialchars((string)$event_item['subtitle']); ?></small>
                </div>
                <div class="overview-alert-meta">
                  <span class="pill<?php echo htmlspecialchars((string)$event_item['state_class']); ?>"><?php echo htmlspecialchars((string)$event_item['state_label']); ?></span>
                  <div class="overview-time"><?php echo htmlspecialchars((string)$event_item['time_label']); ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            <?php else: ?>
              <div class="overview-alert-item">
                <div>
                  <strong>No scheduled activities yet</strong>
                  <small>Admin-scheduled activities for clients will appear here.</small>
                </div>
                <div class="overview-alert-meta">
                  <span class="pill">No Events</span>
                </div>
              </div>
            <?php endif; ?>
          </div>
        </div>
      </section>

      <!-- Livestock & Products Section -->
      <section id="section-livestock" class="client-section<?php echo $active_section === 'livestock' ? ' active' : ''; ?>">
        <div class="section-header">
          <h1>Livestock</h1>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button type="button" class="action-btn small secondary" onclick="window.location.href='dashboard.php?section=livestock-reservations'">
              <i class="fas fa-list"></i> View Reserved Livestock
            </button>
          </div>
        </div>

        <div class="seed-filter-toolbar">
          <input
            type="text"
            id="lpClientSearch"
            class="filter-input"
            placeholder="Search available livestock..."
            oninput="lpClientLoadProducts()"
          >
          
        </div>

        <div class="panel">
          <div id="lpClientGrid" class="catalog-grid">
            <div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;"><i class="fas fa-spinner fa-spin"></i> Loading products...</div>
          </div>
          <div id="lpClientGridEmpty" style="text-align: center; padding: 2rem; color: #5b6b5b; display: none;">
            <i class="fas fa-search" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
            <p style="font-size: 1rem; margin: 0.5rem 0;">No products found</p>
            <p style="font-size: 0.9rem; margin: 0;">Try adjusting your search or category filter to find available products</p>
          </div>
        </div>

      </section>

      <section id="section-livestock-reservations" class="client-section<?php echo $active_section === 'livestock-reservations' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=livestock" aria-label="Back to Livestock & Products">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>My Livestock Reservations</h1>
          </div>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button class="action-btn small secondary" type="button" onclick="lpLoadMyReservations()"><i class="fas fa-rotate-right"></i> Refresh</button>
          </div>
        </div>

        <div class="panel">
          <table class="table">
            <thead>
              <tr>
                <th>#</th>
                <th>Product</th>
                <th>Qty</th>
                <th>Total</th>
                <th>Pickup Date</th>
                <th>Status</th>
                <th>Admin Note</th>
                <th>Requested</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody id="lpMyReservationsBody">
              <tr>
                <td colspan="9" style="text-align:center;color:#6b7280;">Loading reservations...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>


      <section id="section-bids" class="client-section<?php echo $active_section === 'bids' ? ' active' : ''; ?>">
        <div class="section-header">
          <h1>Crop Bidding</h1>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <a class="action-btn small secondary" href="dashboard.php?section=my-bids">
              <i class="fas fa-list"></i> View My Bids
            </a>
          </div>
        </div>

        <div class="seed-filter-toolbar">
          <input
            type="text"
            id="clientBidsSearch"
            class="filter-input"
            placeholder="Search available crops..."
            oninput="filterBidsCatalogCards()"
          >
          <select id="clientBidsFilter" class="filter-select" onchange="filterBidsCatalogCards()">
            <option value="">All Price Ranges</option>
            <option value="0-1000">Under ₱1,000</option>
            <option value="1000-5000">₱1,000 - ₱5,000</option>
            <option value="5000-10000">₱5,000 - ₱10,000</option>
            <option value="10000-plus">₱10,000+</option>
          </select>
        </div>

        <div class="panel">
          <div id="cropsGrid" class="catalog-grid">
            <div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;">
              <i class="fas fa-spinner fa-spin"></i> Loading ongoing crop biddings...
            </div>
          </div>
          <div id="cropsGridEmpty" style="text-align: center; padding: 2rem; color: #5b6b5b; display: none;">
            <i class="fas fa-search" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
            <p style="font-size: 1rem; margin: 0.5rem 0;">No crops found</p>
            <p style="font-size: 0.9rem; margin: 0;">Try adjusting your search or price filter to find available crops</p>
          </div>
        </div>
      </section>

      <section id="section-my-bids" class="client-section<?php echo $active_section === 'my-bids' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=bids" aria-label="Back to Bids">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>My Bids</h1>
          </div>
        </div>
        <div class="panel">
          <p style="color:#5b6b5b;margin:0 0 1rem 0;">Track your active and past bids.</p>
          <table class="table" id="myBidsTable">
            <thead>
              <tr>
                <th>Crop</th>
                <th>Your Bid</th>
                <th>Current Price</th>
                <th>Status</th>
                <th>Ends</th>
              </tr>
            </thead>
            <tbody id="myBidsTableBody">
              <tr>
                <td colspan="5" style="text-align:center;color:#6b7280;">Loading your bids...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section id="section-rentals" class="client-section<?php echo $active_section === 'rentals' ? ' active' : ''; ?>">
        <div class="section-header">
          <h1>Machinery Rentals</h1>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <a class="action-btn small secondary" href="dashboard.php?section=machinery-reservations">
              <i class="fas fa-list"></i> View Reservation
            </a>
          </div>
        </div>

        <div class="seed-filter-toolbar">
          <input
            type="text"
            id="clientRentalSearch"
            class="filter-input"
            placeholder="Search available machinery..."
            oninput="filterRentalCatalogCards()"
          >
        </div>
        
        <div class="panel">
          <div id="machineryGrid" class="catalog-grid">
            <?php if (empty($machinery_catalog)): ?>
            <div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;">
              <i class="fas fa-tractor" style="opacity:0.35;margin-right:0.4rem;"></i>
              No available machinery listings yet.
            </div>
            <?php else: ?>
                <?php foreach ($machinery_catalog as $index => $machine): ?>
                  <?php
                    $machine_name_lower = strtolower((string)$machine['name']);
                    $machine_type_key = 'other';
                    if (strpos($machine_name_lower, 'tractor') !== false) {
                      $machine_type_key = 'tractor';
                    } elseif (strpos($machine_name_lower, 'sprayer') !== false) {
                      $machine_type_key = 'sprayer';
                    } elseif (strpos($machine_name_lower, 'harvester') !== false) {
                      $machine_type_key = 'harvester';
                    } elseif (strpos($machine_name_lower, 'seeder') !== false) {
                      $machine_type_key = 'seeder';
                    } elseif (strpos($machine_name_lower, 'pump') !== false) {
                      $machine_type_key = 'pump';
                    }
                    $machine_view_payload = rawurlencode(json_encode([
                      'title' => (string)$machine['name'],
                      'subtitle' => 'Machinery Details',
                      'fields' => [
                        ['label' => 'Equipment', 'value' => (string)$machine['name']],
                        ['label' => 'Availability', 'value' => (string)$machine['availability']],
                        ['label' => 'Owner', 'value' => (string)$machine['owner']],
                        ['label' => 'Daily Rate', 'value' => 'PHP ' . number_format((float)$machine['daily_rate'], 2)]
                      ],
                      'note' => 'Use Reserve to continue to the rental form page.'
                    ], JSON_UNESCAPED_UNICODE));
                    $machine_form_payload = rawurlencode(json_encode([
                      'listing_id' => (int)$machine['listing_id'],
                      'name' => (string)$machine['name'],
                      'owner' => (string)$machine['owner'],
                      'daily_rate' => (float)$machine['daily_rate']
                    ], JSON_UNESCAPED_UNICODE));
                  ?>
                  <div
                    class="catalog-card machinery-card"
                    data-item-id="<?php echo (int)$machine['listing_id']; ?>"
                    data-machine="<?php echo htmlspecialchars($machine['name']); ?>"
                    data-search="<?php echo htmlspecialchars(strtolower(((string)$machine['name']) . ' ' . ((string)$machine['owner']) . ' ' . ((string)$machine['availability'])), ENT_QUOTES, 'UTF-8'); ?>"
                    data-type="<?php echo htmlspecialchars($machine_type_key, ENT_QUOTES, 'UTF-8'); ?>"
                  >
                    <div class="catalog-thumb">
                      <?php if (!empty($machine['image_url'])): ?>
                      <img src="<?php echo htmlspecialchars((string)$machine['image_url'], ENT_QUOTES, 'UTF-8'); ?>" alt="<?php echo htmlspecialchars($machine['name']); ?>">
                      <?php else: ?>
                      <i class="fas fa-tractor"></i>
                      <?php endif; ?>
                    </div>
                    <div class="catalog-header">
                      <div class="catalog-title-wrap">
                        <h4><?php echo htmlspecialchars($machine['name']); ?></h4>
                        <span class="catalog-unit">Equipment Rental</span>
                      </div>
                      <button type="button" class="favorite-btn" title="Add to favorites" aria-label="Add to favorites">
                        <i class="far fa-heart"></i>
                      </button>
                    </div>
                    <div class="catalog-meta">
                      <span class="catalog-chip"><i class="fas fa-circle-check"></i> Ready to reserve</span>
                      <span><?php echo htmlspecialchars($machine['availability']); ?></span>
                    </div>
                    <div class="catalog-stock">
                      <span class="catalog-stock-label">Daily Rate</span>
                      <span class="catalog-stock-value crop-price">₱<?php echo number_format((float)$machine['daily_rate'], 2); ?></span>
                    </div>
                    <div class="catalog-actions">
                      <a class="catalog-add-btn wide-reserve-btn" href="dashboard.php?section=rental-form&origin=rentals&form_payload=<?php echo htmlspecialchars($machine_form_payload, ENT_QUOTES, 'UTF-8'); ?>"><i class="fas fa-calendar-check"></i> Reserve</a>
                    <style>
                      /* Make Reserve button full width for machinery cards */
                      .catalog-card.machinery-card .catalog-actions {
                        display: flex;
                        width: 100%;
                        padding: 0;
                        margin: 0;
                      }
                      .catalog-card.machinery-card .catalog-add-btn.wide-reserve-btn {
                        width: 100%;
                        justify-content: center;
                        display: flex;
                        font-size: 1rem;
                        padding: 0.8rem 0;
                        border-radius: 12px;
                        margin: 0;
                        box-sizing: border-box;
                      }
                    </style>
                    </div>
                  </div>
                <?php endforeach; ?>
                  </div>
          <div id="machineryGridEmpty" style="text-align: center; padding: 2rem; color: #5b6b5b; display: none;">
            <i class="fas fa-search" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
            <p style="font-size: 1rem; margin: 0.5rem 0;">No machinery found</p>
            <p style="font-size: 0.9rem; margin: 0;">Try adjusting your search or type filter to find available machinery</p>
          </div>
                <?php endif; ?>
        </div>
      </section>

      <section id="section-machinery-reservations" class="client-section<?php echo $active_section === 'machinery-reservations' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=rentals" aria-label="Back to Rentals">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>My Machinery Reservations</h1>
          </div>
          <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
            <button type="button" class="action-btn small secondary" onclick="loadMyMachineryRentals()"><i class="fas fa-rotate-right"></i> Refresh</button>
          </div>
        </div>
        <div class="panel">
          <table class="table">
            <thead>
              <tr>
                <th>Equipment</th>
                <th>Qty</th>
                <th>Schedule</th>
                <th>Status</th>
                <th>Reference</th>
              </tr>
            </thead>
            <tbody id="rentalsTableBody">
              <tr>
                <td colspan="5" style="text-align:center;color:#6b7280;">Loading rentals...</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <section id="section-item-view" class="client-section<?php echo $active_section === 'item-view' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=<?php echo htmlspecialchars($client_view_back_section, ENT_QUOTES, 'UTF-8'); ?>" aria-label="Back">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Details View</h1>
          </div>
        </div>

        <div class="panel">
          <?php
            $item_view_title = (string)($client_view_payload['title'] ?? 'Item Details');
            $item_view_subtitle = (string)($client_view_payload['subtitle'] ?? 'View information');
            $item_view_note = trim((string)($client_view_payload['note'] ?? ''));
            $item_view_fields = isset($client_view_payload['fields']) && is_array($client_view_payload['fields'])
              ? $client_view_payload['fields']
              : [];
          ?>

          <h2 style="margin:0;color:#1b5a2a;font-size:1.1rem;"><?php echo htmlspecialchars($item_view_title, ENT_QUOTES, 'UTF-8'); ?></h2>
          <p style="margin-top:0.25rem;"><?php echo htmlspecialchars($item_view_subtitle, ENT_QUOTES, 'UTF-8'); ?></p>

          <?php if (!empty($item_view_fields)): ?>
          <div class="catalog-view-grid" style="margin-top:0.9rem;">
            <?php foreach ($item_view_fields as $view_field): ?>
              <?php
                $field_label = isset($view_field['label']) ? (string)$view_field['label'] : 'Detail';
                $field_value = isset($view_field['value']) ? (string)$view_field['value'] : 'N/A';
              ?>
              <div class="catalog-view-item">
                <span><?php echo htmlspecialchars($field_label, ENT_QUOTES, 'UTF-8'); ?></span>
                <strong><?php echo htmlspecialchars($field_value, ENT_QUOTES, 'UTF-8'); ?></strong>
              </div>
            <?php endforeach; ?>
          </div>
          <?php else: ?>
          <div style="margin-top:0.9rem;padding:1rem;border:1px dashed #c7ded0;border-radius:10px;background:#fbfefc;color:#46614f;">
            No item details available.
          </div>
          <?php endif; ?>

          <?php if ($item_view_note !== ''): ?>
          <div class="catalog-view-note"><?php echo nl2br(htmlspecialchars($item_view_note, ENT_QUOTES, 'UTF-8')); ?></div>
          <?php endif; ?>
        </div>
      </section>

      <section id="section-bid-form" class="client-section<?php echo $active_section === 'bid-form' ? ' active' : ''; ?>">
        <?php
          $bid_form_crop_id = (int)($client_form_payload['crop_id'] ?? 0);
          $bid_form_crop_name = (string)($client_form_payload['crop_name'] ?? 'Crop');
          $bid_form_current_price = (float)($client_form_payload['current_price'] ?? 0);
          // Determine minimum bid logic
          $bid_form_bid_count = isset($client_form_payload['bid_count']) ? (int)$client_form_payload['bid_count'] : 0;
          if ($bid_form_bid_count > 0) {
            $bid_form_min_bid = $bid_form_current_price + 0.01;
          } else {
            $bid_form_min_bid = $bid_form_current_price;
          }
        ?>
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=bids" aria-label="Back to Bids">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Place Bid</h1>
          </div>
        </div>
        <div class="panel">
          <h2 style="margin:0;color:#1b5a2a;"><?php echo htmlspecialchars($bid_form_crop_name, ENT_QUOTES, 'UTF-8'); ?></h2>
          <p style="margin-top:0.25rem;">Submit your bid using the form below.</p>
          <form id="pageBidForm" class="action-form" style="margin-top:0.8rem;">
            <input type="hidden" id="pageBidCropId" value="<?php echo (int)$bid_form_crop_id; ?>">
            <div class="form-row">
              <div class="form-field">
                <label>Current Price</label>
                <input type="text" value="₱<?php echo number_format($bid_form_current_price, 2); ?>" readonly>
              </div>
              <div class="form-field">
                <label>Minimum Bid</label>
                <input type="text" value="₱<?php echo number_format($bid_form_min_bid, 2); ?>" readonly>
              </div>
              <div class="form-field">
                <label for="pageBidAmount">Your Bid Amount (₱)</label>
                <input type="number" id="pageBidAmount" step="0.01" min="<?php echo htmlspecialchars(number_format($bid_form_min_bid, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" placeholder="Enter bid amount" required>
              </div>
            </div>
            <div class="form-actions">
              <a class="action-btn small secondary" href="dashboard.php?section=bids"><i class="fas fa-times"></i> Cancel</a>
              <button type="submit" class="action-btn small"><i class="fas fa-gavel"></i> Submit Bid</button>
            </div>
          </form>
        </div>
      </section>

      <section id="section-rental-form" class="client-section<?php echo $active_section === 'rental-form' ? ' active' : ''; ?>">
        <?php
          $rental_form_listing_id = (int)($client_form_payload['listing_id'] ?? 0);
          $rental_form_name = (string)($client_form_payload['name'] ?? 'Machinery');
          $rental_form_owner = (string)($client_form_payload['owner'] ?? '-');
          $rental_form_daily_rate = (float)($client_form_payload['daily_rate'] ?? 0);
        ?>
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=rentals" aria-label="Back to Rentals">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Reserve Machinery</h1>
          </div>
        </div>
        <div class="panel">
          <h2 style="margin:0;color:#1b5a2a;"><?php echo htmlspecialchars($rental_form_name, ENT_QUOTES, 'UTF-8'); ?></h2>
          <p style="margin-top:0.25rem;">Owner: <?php echo htmlspecialchars($rental_form_owner, ENT_QUOTES, 'UTF-8'); ?> | Daily Rate: ₱<?php echo number_format($rental_form_daily_rate, 2); ?></p>
          <form id="pageRentalForm" class="action-form" style="margin-top:0.8rem;">
            <input type="hidden" id="pageRentalListingId" value="<?php echo (int)$rental_form_listing_id; ?>">
            <input type="hidden" id="pageRentalName" value="<?php echo htmlspecialchars($rental_form_name, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" id="pageRentalOwner" value="<?php echo htmlspecialchars($rental_form_owner, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" id="pageRentalDailyRate" value="<?php echo htmlspecialchars(number_format($rental_form_daily_rate, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">
            <div class="form-row">
              <div class="form-field">
                <label for="pageRentalStartDate">Start Date <span style="font-weight:400;color:#6b7280;font-size:0.85em;">(first day of rental)</span></label>
                <input type="date" id="pageRentalStartDate" required>
              </div>
              <div class="form-field">
                <label for="pageRentalEndDate">End Date <span style="font-weight:400;color:#6b7280;font-size:0.85em;">(last day of rental)</span></label>
                <input type="date" id="pageRentalEndDate" required>
              </div>
            </div>
            <div class="form-row">
              <div class="form-field">
                <label for="pageRentalNote">Special Notes (optional)</label>
                <input type="text" id="pageRentalNote" placeholder="e.g., urgent delivery needed">
              </div>
            </div>
            <div class="form-actions">
              <a class="action-btn small secondary" href="dashboard.php?section=rentals"><i class="fas fa-times"></i> Cancel</a>
              <button type="submit" class="action-btn small"><i class="fas fa-calendar-check"></i> Submit Rental Request</button>
            </div>
          </form>
        </div>
      </section>

      <section id="section-livestock-form" class="client-section<?php echo $active_section === 'livestock-form' ? ' active' : ''; ?>">
        <?php
          $lp_form_product_id = (int)($client_form_payload['product_id'] ?? 0);
          $lp_form_name = (string)($client_form_payload['product_name'] ?? 'Product');
          $lp_form_unit = (string)($client_form_payload['unit'] ?? 'unit');
          $lp_form_price = (float)($client_form_payload['price'] ?? 0);
          $lp_form_stock = (int)($client_form_payload['stock'] ?? 0);
        ?>
        <div class="section-header" style="align-items:center;">
          <div style="display:flex;align-items:center;gap:0.65rem;">
            <a class="catalog-view-back-btn" href="dashboard.php?section=livestock" aria-label="Back to Livestock">
              <i class="fas fa-arrow-left"></i>
            </a>
            <h1>Reserve Product</h1>
          </div>
        </div>
        <div class="panel">
          <h2 style="margin:0;color:#1b5a2a;"><?php echo htmlspecialchars($lp_form_name, ENT_QUOTES, 'UTF-8'); ?></h2>
          <p style="margin-top:0.25rem;">Price: ₱<?php echo number_format($lp_form_price, 2); ?> / <?php echo htmlspecialchars($lp_form_unit, ENT_QUOTES, 'UTF-8'); ?> | Stock: <?php echo (int)$lp_form_stock; ?></p>
          <form id="pageLivestockForm" class="action-form" style="margin-top:0.8rem;">
            <input type="hidden" id="pageLpProductId" value="<?php echo (int)$lp_form_product_id; ?>">
            <input type="hidden" id="pageLpPrice" value="<?php echo htmlspecialchars(number_format($lp_form_price, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" id="pageLpStock" value="<?php echo (int)$lp_form_stock; ?>">
            <div class="form-row">
              <div class="form-field">
                <label for="pageLpQty">Quantity</label>
                <input type="number" id="pageLpQty" min="1" max="<?php echo (int)$lp_form_stock; ?>" value="1" required>
              </div>
              <div class="form-field">
                <label for="pageLpDate">Preferred Pickup Date</label>
                <input type="date" id="pageLpDate">
              </div>
              <div class="form-field">
                <label for="pageLpNotes">Notes (optional)</label>
                <input type="text" id="pageLpNotes" maxlength="500" placeholder="e.g., morning pickup preferred">
              </div>
            </div>
            <div class="form-actions">
              <a class="action-btn small secondary" href="dashboard.php?section=livestock"><i class="fas fa-times"></i> Cancel</a>
              <button type="submit" class="action-btn small"><i class="fas fa-calendar-check"></i> Submit Reservation</button>
            </div>
          </form>
        </div>
      </section>

      <section id="section-favorites" class="client-section<?php echo $active_section === 'favorites' ? ' active' : ''; ?>">
        <div class="section-header" style="align-items:center;">
          <h1 id="favoritesTitle">Favorites</h1>
        </div>
        <div class="panel">

          <div id="favoritesContainer" style="display: none;">
            <div id="favoritesList" class="favorites-grid">
              <!-- Favorites will be populated here dynamically -->
            </div>
          </div>

          <div id="favoritesEmpty" style="text-align: center; padding: 2rem; color: #5b6b5b;">
            <i class="fas fa-heart" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem;"></i>
            <p style="font-size: 1rem; margin: 0.5rem 0;">No favorites yet</p>
            <p style="font-size: 0.9rem; margin: 0;">Click the heart icon on crops, machinery, or products to add them to your favorites</p>
          </div>
        </div>
      </section>

      <?php endif; ?>

      <section id="section-profile" class="client-section<?php echo $active_section === 'profile' ? ' active' : ''; ?>">
        <div class="panel">
          <h2>Profile</h2>
          <?php if (!$is_client_verified_access): ?>
          <p>Your account is pending admin verification. Access to bids, rentals, livestock products, and favorites is locked until approval.</p>
          <div style="margin-top:1rem;padding:1rem;border-radius:10px;border:1px solid #f3d08a;background:#fff8e6;color:#7a5a16;line-height:1.55;">
            <strong style="display:block;margin-bottom:0.35rem;">Verification in progress</strong>
            <div>Status: <?php echo htmlspecialchars($verification_status_text); ?></div>
            <div style="margin-top:0.3rem;">Admin notes: <?php echo htmlspecialchars($client_verification_notes_text); ?></div>
          </div>
          <?php else: ?>
          <p>Update your contact information to speed up approvals and rentals.</p>
          <?php endif; ?>
          <div class="profile-grid">
            <div class="profile-item">
              <span>Full Name</span>
              <strong><?php echo htmlspecialchars($client_name); ?></strong>
            </div>
            <div class="profile-item">
              <span>Member Since</span>
              <strong><?php echo htmlspecialchars((string)$client_profile['member_since']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Contact</span>
              <strong><?php echo htmlspecialchars((string)$client_profile['contact']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Address</span>
              <strong><?php echo htmlspecialchars((string)$client_profile['address']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Email</span>
              <strong><?php echo htmlspecialchars((string)$client_profile['email']); ?></strong>
            </div>
            <div class="profile-item">
              <span>ID Type</span>
              <strong><?php echo htmlspecialchars((string)$client_profile['id_type']); ?></strong>
            </div>
            <div class="profile-item">
              <span>Verification Status</span>
              <strong><?php echo htmlspecialchars($verification_status_text); ?></strong>
            </div>
          </div>

          <?php if (!$is_client_verified_access): ?>
          <div style="display:flex;gap:0.6rem;margin-top:1rem;flex-wrap:wrap;">
            <button type="button" onclick="window.location.reload()" style="border:1px solid rgba(27,90,42,0.2);background:#fff;color:#1b5a2a;padding:0.55rem 0.9rem;border-radius:8px;cursor:pointer;font-weight:600;">Refresh Status</button>
            <button type="button" onclick="window.location.href='../logout.php'" style="border:none;background:linear-gradient(135deg,#1b5a2a 0%,#28a745 100%);color:#fff;padding:0.55rem 0.9rem;border-radius:8px;cursor:pointer;font-weight:600;">Logout</button>
          </div>
          <?php endif; ?>
        </div>
      </section>
    </main>
  </div>

  <script>
    const clientAllowedSections = <?php echo json_encode(array_values($allowed_sections)); ?>;
    const initialClientSection = <?php echo json_encode($active_section); ?>;

    // Initialize navigation
    document.addEventListener('DOMContentLoaded', function() {
      // Attach click handler to profile menu item
      const profileMenu = document.querySelector('.admin-profile-dropdown .admin-profile-action');
      if (profileMenu) {
        profileMenu.addEventListener('click', function(e) {
          e.preventDefault();
          const section = this.getAttribute('data-section');
          if (section) {
            showSection(section);
          }
        });
      }

      showSection(initialClientSection);
    });

    function formatPhp(amount) {
      const value = Number(amount) || 0;
      return 'PHP ' + value.toLocaleString('en-PH');
    }

    function formatDate(value) {
      if (!value) return '';
      const date = new Date(value + 'T00:00:00');
      if (Number.isNaN(date.getTime())) return value;
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    }

    const BIDDING_API = 'bidding_api.php';
    const RENTAL_API = 'rental_api.php';
    let lpProductsLoading = false;

    const pageBidForm = document.getElementById('pageBidForm');
    if (pageBidForm) {
      pageBidForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const cropId = parseInt(document.getElementById('pageBidCropId')?.value || '0', 10) || 0;
        const bidAmountInput = document.getElementById('pageBidAmount');
        const bidAmount = bidAmountInput ? parseFloat(bidAmountInput.value) : 0;

        if (!cropId || !bidAmount || Number.isNaN(bidAmount)) {
          alert('Please enter a valid bid amount.');
          return;
        }

        const submitBtn = pageBidForm.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Submitting...';
        }

        fetch(BIDDING_API + '?action=place_bid', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ crop_id: cropId, bid_amount: bidAmount })
        })
          .then((response) => response.json())
          .then((data) => {
            if (!data.success) {
              alert(data.message || 'Unable to place bid.');
              return;
            }
            alert('Bid placed successfully.');
            window.location.href = 'dashboard.php?section=bids';
          })
          .catch(() => {
            alert('Connection error while placing bid.');
          })
          .finally(() => {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = '<i class="fas fa-gavel"></i> Submit Bid';
            }
          });
      });
    }

    // Set min dates for rental date pickers
    (function() {
      const today = new Date().toISOString().split('T')[0];
      const startEl = document.getElementById('pageRentalStartDate');
      const endEl   = document.getElementById('pageRentalEndDate');
      if (startEl) {
        startEl.min = today;
        startEl.addEventListener('change', () => {
          if (endEl) {
            endEl.min = startEl.value || today;
            if (endEl.value && endEl.value < startEl.value) endEl.value = startEl.value;
          }
        });
      }
      if (endEl) endEl.min = today;
    })();

    const pageRentalForm = document.getElementById('pageRentalForm');
    if (pageRentalForm) {
      pageRentalForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const listingId = parseInt(document.getElementById('pageRentalListingId')?.value || '0', 10) || 0;
        const name = document.getElementById('pageRentalName')?.value || '';
        const owner = document.getElementById('pageRentalOwner')?.value || '';
        const dailyRate = parseFloat(document.getElementById('pageRentalDailyRate')?.value || '0') || 0;
        const startDate = document.getElementById('pageRentalStartDate')?.value || '';
        const endDate = document.getElementById('pageRentalEndDate')?.value || '';
        const note = document.getElementById('pageRentalNote')?.value || '';

        if (!listingId || !startDate || !endDate) {
          alert('Please complete all required rental fields.');
          return;
        }
        if (endDate < startDate) {
          alert('End Date cannot be before Start Date. Please check your selected dates.');
          return;
        }

        const submitBtn = pageRentalForm.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Submitting...';
        }

        fetch(RENTAL_API + '?action=submit_rentals', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            items: [{
              listing_id: listingId,
              name,
              owner,
              quantity: 1,
              daily_rate: dailyRate,
              start_date: startDate,
              end_date: endDate,
              note
            }]
          })
        })
          .then((response) => response.json())
          .then((data) => {
            if (!data.success) {
              alert(data.message || 'Unable to submit rental request.');
              return;
            }
            alert('Rental request submitted successfully.');
            window.location.href = 'dashboard.php?section=rentals';
          })
          .catch(() => {
            alert('Connection error while submitting rental request.');
          })
          .finally(() => {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = '<i class="fas fa-calendar-check"></i> Submit Rental Request';
            }
          });
      });
    }

    const pageLivestockForm = document.getElementById('pageLivestockForm');
    if (pageLivestockForm) {
      pageLivestockForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const productId = parseInt(document.getElementById('pageLpProductId')?.value || '0', 10) || 0;
        const qty = parseInt(document.getElementById('pageLpQty')?.value || '0', 10) || 0;
        const stock = parseInt(document.getElementById('pageLpStock')?.value || '0', 10) || 0;
        const date = document.getElementById('pageLpDate')?.value || '';
        const notes = document.getElementById('pageLpNotes')?.value || '';

        if (!productId || qty < 1) {
          alert('Please enter a valid quantity.');
          return;
        }
        if (stock > 0 && qty > stock) {
          alert('Quantity exceeds available stock.');
          return;
        }

        const submitBtn = pageLivestockForm.querySelector('button[type="submit"]');
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Submitting...';
        }

        const fd = new FormData();
        fd.append('action', 'submit_reservation');
        fd.append('product_id', String(productId));
        fd.append('quantity', String(qty));
        fd.append('preferred_date', date);
        fd.append('notes', notes);

        fetch('livestock_api.php', { method: 'POST', body: fd })
          .then((response) => response.json())
          .then((data) => {
            if (!data.success) {
              alert(data.message || 'Unable to submit reservation.');
              return;
            }
            alert('Reservation submitted successfully.');
            window.location.href = 'dashboard.php?section=livestock';
          })
          .catch(() => {
            alert('Connection error while submitting reservation.');
          })
          .finally(() => {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = '<i class="fas fa-calendar-check"></i> Submit Reservation';
            }
          });
      });
    }

    // Reservation and bidding forms now use dedicated page sections.

    // Favorites Management
    const FAVORITES_STORAGE_KEY = 'smartfarm_client_favorites_v1';
    const favoritesData = [];

    function sourceSectionByCategory(category) {
      if (category === 'Crop') return 'bids';
      if (category === 'Product') return 'livestock';
      return 'rentals';
    }

    function favoriteDefaultActionLabel(category) {
      return category === 'Crop' ? 'Place Bid' : 'Reserve';
    }

    function buildFavoriteViewHref(item) {
      if (item.viewHref) return item.viewHref;

      const fallbackPayload = {
        title: String(item.name || 'Saved Favorite'),
        subtitle: `${String(item.category || 'Item')} Favorite Details`,
        fields: [
          { label: 'Category', value: String(item.category || 'Item') },
          { label: String(item.priceLabel || 'Price'), value: String(item.price || '₱0.00') },
          { label: 'Summary', value: String(item.quantity || 'N/A') }
        ],
        note: String(item.details || 'Saved from your favorites list.')
      };
      const origin = item.sourceSection || sourceSectionByCategory(item.category);
      return `dashboard.php?section=item-view&origin=${encodeURIComponent(origin)}&view_payload=${encodeURIComponent(JSON.stringify(fallbackPayload))}`;
    }

    function refreshFavoriteItemAvailability(item, cropIndex, productIndex, machineryIndex) {
      const id = Number(item.itemId || 0);
      const category = String(item.category || '');

      if (category === 'Crop') {
        const crop = id > 0 ? cropIndex.get(id) : null;
        item.available = !!crop;
        if (crop) {
          const currentPrice = Number(crop.current_price || crop.starting_price || 0);
          const cropViewPayload = encodeURIComponent(JSON.stringify({
            title: String(crop.crop_name || item.name || 'Crop'),
            subtitle: 'Crop Listing Details',
            fields: [
              { label: 'Unit', value: String(crop.crop_unit || 'N/A') },
              { label: 'Farmer', value: String(crop.farmer_fullname || 'Farmer') },
              { label: 'Current Price', value: `PHP ${currentPrice.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` },
              { label: 'Bids', value: `${Number(crop.bid_count || 0)} bid${Number(crop.bid_count || 0) === 1 ? '' : 's'}` }
            ],
            note: String(crop.crop_description || item.details || 'No description provided.')
          }));
          const cropFormPayload = encodeURIComponent(JSON.stringify({
            crop_id: Number(crop.crop_id || id),
            crop_name: String(crop.crop_name || item.name || 'Crop'),
            current_price: currentPrice
          }));
          item.name = String(crop.crop_name || item.name || 'Crop');
          item.viewHref = `dashboard.php?section=item-view&origin=bids&view_payload=${cropViewPayload}`;
          item.actionHref = `dashboard.php?section=bid-form&origin=bids&form_payload=${cropFormPayload}`;
          item.actionLabel = 'Place Bid';
          item.sourceSection = 'bids';
        }
        return;
      }

      if (category === 'Product') {
        const product = id > 0 ? productIndex.get(id) : null;
        item.available = !!product && Number(product.stock || 0) > 0;
        if (product) {
          const productViewPayload = encodeURIComponent(JSON.stringify({
            title: String(product.product_name || item.name || 'Product'),
            subtitle: 'Product Details',
            fields: [
              { label: 'Type', value: String(product.product_type || 'N/A') },
              { label: 'Unit', value: String(product.unit || 'unit') },
              { label: 'Price', value: '₱' + Number(product.price || 0).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) },
              { label: 'Available Stock', value: `${Number(product.stock || 0)} ${String(product.unit || '')}`.trim() }
            ],
            note: String(product.product_description || item.details || 'No description provided.')
          }));
          const productFormPayload = encodeURIComponent(JSON.stringify({
            product_id: Number(product.product_id || id),
            product_name: String(product.product_name || item.name || 'Product'),
            price: Number(product.price || 0),
            stock: Number(product.stock || 0),
            unit: String(product.unit || 'unit')
          }));
          item.name = String(product.product_name || item.name || 'Product');
          item.viewHref = `dashboard.php?section=item-view&origin=livestock&view_payload=${productViewPayload}`;
          item.actionHref = `dashboard.php?section=livestock-form&origin=livestock&form_payload=${productFormPayload}`;
          item.actionLabel = 'Reserve';
          item.sourceSection = 'livestock';
        }
        return;
      }

      const machinery = id > 0 ? machineryIndex.get(id) : null;
      item.available = !!machinery;
      if (machinery) {
        item.viewHref = machinery.viewHref || item.viewHref;
        item.actionHref = machinery.actionHref || item.actionHref;
        item.actionLabel = 'Reserve';
        item.sourceSection = 'rentals';
      }
    }

    function refreshFavoritesAvailability() {
      const hasCropFavorites = favoritesData.some((item) => item.category === 'Crop');
      const hasProductFavorites = favoritesData.some((item) => item.category === 'Product');

      const cropRequest = hasCropFavorites
        ? fetch(BIDDING_API + '?action=get_crops').then((res) => res.json()).catch(() => ({ success: false, crops: [] }))
        : Promise.resolve({ success: false, crops: [] });

      const productRequest = hasProductFavorites
        ? fetch('livestock_api.php?action=get_products').then((res) => res.json()).catch(() => ({ success: false, products: [] }))
        : Promise.resolve({ success: false, products: [] });

      Promise.all([cropRequest, productRequest]).then(([cropData, productData]) => {
        const cropIndex = new Map();
        const productIndex = new Map();
        const machineryIndex = new Map();

        if (cropData && cropData.success && Array.isArray(cropData.crops)) {
          cropData.crops.forEach((crop) => {
            cropIndex.set(Number(crop.crop_id || 0), crop);
          });
        }

        if (productData && productData.success && Array.isArray(productData.products)) {
          productData.products.forEach((product) => {
            productIndex.set(Number(product.product_id || 0), product);
          });
        }

        document.querySelectorAll('#machineryGrid .catalog-card.machinery-card').forEach((card) => {
          const listingId = Number(card.getAttribute('data-item-id') || '0');
          if (!listingId) return;
          machineryIndex.set(listingId, {
            viewHref: card.querySelector('.catalog-view-btn')?.getAttribute('href') || '',
            actionHref: card.querySelector('.catalog-add-btn')?.getAttribute('href') || ''
          });
        });

        favoritesData.forEach((item) => {
          refreshFavoriteItemAvailability(item, cropIndex, productIndex, machineryIndex);
        });

        updateFavoritesDisplay();
      });
    }

    function makeFavoriteKey(name, category) {
      return `${String(category || '').trim().toLowerCase()}::${String(name || '').trim().toLowerCase()}`;
    }

    function isFavorite(name, category) {
      const key = makeFavoriteKey(name, category);
      return favoritesData.some((item) => makeFavoriteKey(item.name, item.category) === key);
    }

    function detectCardCategory(card) {
      if (!card) return 'Machinery';
      if (card.classList.contains('crop-card')) return 'Crop';
      if (card.classList.contains('product-card') || card.dataset.category === 'product') return 'Product';
      return 'Machinery';
    }

    function syncFavoriteButtons() {
      const allHearts = document.querySelectorAll('.favorite-btn');
      allHearts.forEach((heart) => {
        const card = heart.closest('.catalog-card');
        if (!card) return;

        const title = card.querySelector('h4')?.textContent || 'Unknown';
        const category = detectCardCategory(card);
        const icon = heart.querySelector('i');
        const favorited = isFavorite(title, category);

        heart.classList.toggle('favorited', favorited);
        if (icon) {
          icon.classList.toggle('fas', favorited);
          icon.classList.toggle('far', !favorited);
        }
      });
    }

    function saveFavorites() {
      try {
        localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favoritesData));
      } catch (error) {
        // Ignore storage issues and keep in-memory favorites working.
      }
    }

    function loadFavorites() {
      try {
        const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
        if (!raw) return;

        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return;

        parsed.forEach((item) => {
          if (!item || typeof item !== 'object') return;
          const name = String(item.name || '').trim();
          const category = String(item.category || '').trim();
          if (!name || !category) return;

          if (!isFavorite(name, category)) {
            favoritesData.push({
              name,
              category,
              sourceSection: String(item.sourceSection || sourceSectionByCategory(category)),
              itemId: Number(item.itemId || 0),
              viewHref: String(item.viewHref || ''),
              actionHref: String(item.actionHref || ''),
              actionLabel: String(item.actionLabel || favoriteDefaultActionLabel(category)),
              available: item.available === false ? false : true,
              quantity: String(item.quantity || ''),
              details: String(item.details || ''),
              priceLabel: String(item.priceLabel || 'Price'),
              price: String(item.price || '₱0.00')
            });
          }
        });
      } catch (error) {
        // Ignore invalid storage payloads.
      }
    }

    function updateFavoritesDisplay() {
      const container = document.getElementById('favoritesContainer');
      const emptyState = document.getElementById('favoritesEmpty');
      const list = document.getElementById('favoritesList');
      const title = document.getElementById('favoritesTitle');
      const statCount = document.getElementById('favoritesStatCount');

      // Update stat card
      if (statCount) {
        statCount.textContent = favoritesData.length;
      }

      if (favoritesData.length === 0) {
        container.style.display = 'none';
        emptyState.style.display = 'block';
        title.textContent = 'Favorites';
      } else {
        container.style.display = 'block';
        emptyState.style.display = 'none';
        title.textContent = `Favorites (${favoritesData.length})`;

        list.innerHTML = favoritesData.map((item, index) => `
          <div class="favorite-item">
            <div class="favorite-item-header">
              <div class="favorite-item-info">
                <h3>${item.name}</h3>
                <span class="favorite-item-category">${item.category}</span>
              </div>
              <span class="favorite-item-status${item.available === false ? ' unavailable' : ''}">${item.available === false ? 'Unavailable' : 'Available'}</span>
              <button type="button" class="favorite-item-remove" onclick="removeFavorite(${index})" title="Remove from favorites">
                <i class="fas fa-heart"></i>
              </button>
            </div>
            <div class="favorite-item-details">
              <div class="favorite-item-detail">
                <span>${item.quantity}</span>
              </div>
              <div class="favorite-item-detail">
                <span>${item.details}</span>
              </div>
            </div>
            <div class="favorite-item-price">
              <div class="favorite-item-price-label">${item.priceLabel}</div>
              <div class="favorite-item-price-amount">${item.price}</div>
            </div>
            <div class="favorite-item-actions">
              <a class="favorite-item-action" href="${buildFavoriteViewHref(item)}">
                <i class="fas fa-eye"></i> View Details
              </a>
              ${item.available === false || !item.actionHref
                ? `<button type="button" class="favorite-item-action primary disabled" disabled><i class="fas fa-ban"></i> Not Available</button>`
                : `<a class="favorite-item-action primary" href="${item.actionHref}"><i class="fas fa-calendar-check"></i> ${item.actionLabel || favoriteDefaultActionLabel(item.category)}</a>`}
            </div>
          </div>
        `).join('');
      }

      saveFavorites();
      syncFavoriteButtons();
    }

    function removeFavorite(index) {
      if (index < 0 || index >= favoritesData.length) return;
      favoritesData.splice(index, 1);
      updateFavoritesDisplay();
    }

    window.removeFavorite = removeFavorite;

    // Favorite button functionality
    document.addEventListener('click', (e) => {
      if (e.target.closest('.favorite-btn')) {
        const favoriteBtn = e.target.closest('.favorite-btn');
        const card = favoriteBtn.closest('.catalog-card');
        if (!card) return;
        
        favoriteBtn.classList.toggle('favorited');
        
        // Toggle between outline and filled heart
        const icon = favoriteBtn.querySelector('i');
        if (favoriteBtn.classList.contains('favorited')) {
          icon.classList.remove('far');
          icon.classList.add('fas');
          
          // Get item details and add to favorites
          const title = card.querySelector('h4')?.textContent || 'Unknown';
          const category = detectCardCategory(card);
          if (isFavorite(title, category)) {
            updateFavoritesDisplay();
            return;
          }

          const isCrop = category === 'Crop';
          const isProduct = category === 'Product';
          
          let quantity = '';
          let details = '';
          let priceLabel = '';
          let price = '';
          
          if (isCrop) {
            quantity = card.querySelector('.catalog-stock-value')?.textContent || '';
            details = card.querySelector('.catalog-meta span:last-child')?.textContent || 'Crop';
            priceLabel = card.querySelector('.catalog-stock-label')?.textContent || 'Price';
            price = card.querySelector('.crop-price')?.textContent || '₱0.00';
          } else if (isProduct) {
            quantity = card.querySelector('.catalog-stock-value')?.textContent || '';
            details = card.querySelector('.catalog-meta span:last-child')?.textContent || 'Product';
            priceLabel = card.querySelector('.catalog-stock-label')?.textContent || 'Price';
            price = card.querySelector('.crop-price')?.textContent || '₱0.00';
          } else {
            quantity = card.querySelector('.catalog-stock-label')?.textContent || 'Daily Rate';
            details = card.querySelectorAll('.catalog-meta span')[1]?.textContent || 'Equipment';
            priceLabel = 'Rental Fee';
            price = card.querySelector('.crop-price')?.textContent || '₱0.00';
          }
          
          favoritesData.push({
            name: title,
            category: category,
            sourceSection: sourceSectionByCategory(category),
            itemId: Number(card.getAttribute('data-item-id') || '0'),
            viewHref: card.querySelector('.catalog-view-btn')?.getAttribute('href') || '',
            actionHref: card.querySelector('.catalog-add-btn')?.getAttribute('href') || '',
            actionLabel: (card.querySelector('.catalog-add-btn')?.textContent || '').replace(/\s+/g, ' ').trim() || favoriteDefaultActionLabel(category),
            available: !!card.querySelector('.catalog-add-btn'),
            quantity: quantity,
            details: details,
            priceLabel: priceLabel,
            price: price
          });
        } else {
          icon.classList.remove('fas');
          icon.classList.add('far');

          // Remove from favorites
          const title = card.querySelector('h4')?.textContent || 'Unknown';
          const category = detectCardCategory(card);
          const index = favoritesData.findIndex(item => makeFavoriteKey(item.name, item.category) === makeFavoriteKey(title, category));
          if (index > -1) {
            favoritesData.splice(index, 1);
          }
        }
        
        updateFavoritesDisplay();
      }
    }, true);

    loadFavorites();
    updateFavoritesDisplay();
    refreshFavoritesAvailability();

    // Reservation cart modal flow removed; page forms now handle submissions.

    function rentalStatusPill(status) {
      const key = String(status || '').toLowerCase();
      if (key === 'approved') return '<span class="pill">Approved</span>';
      if (key === 'in-rental') return '<span class="pill info">In Use</span>';
      if (key === 'returned') return '<span class="pill">Returned</span>';
      if (key === 'cancelled') return '<span class="pill pending">Cancelled</span>';
      return '<span class="pill pending">Pending</span>';
    }

    function loadMyMachineryRentals() {
      const rentalsTableBody = document.getElementById('rentalsTableBody');
      if (!rentalsTableBody) return;

      rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">Loading rentals...</td></tr>';

      fetch(RENTAL_API + '?action=get_my_rentals')
        .then((response) => response.json())
        .then((data) => {
          if (!data.success || !Array.isArray(data.rentals) || data.rentals.length === 0) {
            rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">No machinery rentals yet.</td></tr>';
            return;
          }

          rentalsTableBody.innerHTML = data.rentals.map((row) => {
            const start = formatDate(row.start_date);
            const end = formatDate(row.end_date);
            const schedule = start && end ? `${start} - ${end}` : 'Date pending';
            return `
              <tr>
                <td>${row.equipment_name || 'Machinery'}</td>
                <td>1</td>
                <td>${schedule}</td>
                <td>${rentalStatusPill(row.rental_status)}</td>
                <td>${row.rental_code || '#'}</td>
              </tr>
            `;
          }).join('');
        })
        .catch(() => {
          rentalsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#dc3545;">Could not load rentals.</td></tr>';
        });
    }

    function showSection(section) {
      if (!Array.isArray(clientAllowedSections) || clientAllowedSections.indexOf(section) === -1) {
        section = 'profile';
      }

      if (window.history && window.history.replaceState) {
        const nextUrl = new URL(window.location.href);
        nextUrl.searchParams.set('section', section);
        nextUrl.searchParams.delete('origin');
        nextUrl.searchParams.delete('view_payload');
        nextUrl.searchParams.delete('form_payload');
        nextUrl.hash = '';
        window.history.replaceState({}, '', nextUrl.toString());
      }

      document.querySelectorAll('.client-section').forEach((el) => {
        el.classList.remove('active');
      });
      let target = document.getElementById('section-' + section);
      if (!target) {
        section = 'profile';
        target = document.getElementById('section-profile');
      }
      if (target) target.classList.add('active');

      document.querySelectorAll('.admin-sidebar .nav-item').forEach((el) => {
        el.classList.remove('active');
      });
      const navMap = {
        'item-view': <?php echo json_encode($client_view_back_section); ?>,
        'bid-form': 'bids',
        'my-bids': 'bids',
        'rental-form': 'rentals',
        'machinery-reservations': 'rentals',
        'livestock-reservations': 'livestock',
        'livestock-form': 'livestock'
      };
      const navSection = Object.prototype.hasOwnProperty.call(navMap, section)
        ? navMap[section]
        : section;
      const activeNav = document.querySelector('.admin-sidebar .nav-item[data-section="' + navSection + '"]');
      if (activeNav) activeNav.classList.add('active');
      syncFavoriteButtons();

      if (section === 'bids') {
        loadAvailableCrops();
        loadMyBids();
      }

      if (section === 'my-bids') {
        loadMyBids();
      }

      if (section === 'rentals') {
        loadMyMachineryRentals();
      }

      if (section === 'machinery-reservations') {
        loadMyMachineryRentals();
      }

      if (section === 'livestock') {
        lpClientLoadProducts();
      }

      if (section === 'livestock-reservations') {
        lpLoadMyReservations();
      }

      if (section === 'favorites') {
        refreshFavoritesAvailability();
      }
    }

    function toggleNotifyDropdown(e) {
      e.stopPropagation();
      const dropdown = document.getElementById('notifyDropdown');
      if (!dropdown) return;
      const opening = !dropdown.classList.contains('active');
      dropdown.classList.toggle('active');
      if (opening) {
        fetch('../mark_notifications_read.php', { method: 'POST', credentials: 'same-origin' })
          .then(r => r.json())
          .then(data => {
            if (data.ok && data.updated > 0) {
              const badge = document.querySelector('.admin-notify-btn .badge');
              if (badge) badge.remove();
            }
          })
          .catch(() => {});
      }
    }

    function toggleProfileDropdown(e) {
      e.stopPropagation();
      const dropdown = document.getElementById('adminProfileDropdown');
      const trigger = document.getElementById('adminProfileTrigger');
      const profileBox = trigger ? trigger.closest('.admin-profile') : null;
      if (!dropdown || !trigger) return;
      const isOpen = dropdown.classList.toggle('active');
      if (profileBox) profileBox.classList.toggle('open', isOpen);
      dropdown.setAttribute('aria-hidden', String(!isOpen));
      trigger.setAttribute('aria-expanded', String(isOpen));
    }

    document.addEventListener('click', function(event) {
      const notifyDropdown = document.getElementById('notifyDropdown');
      const adminUserMenu = document.querySelector('.admin-user-menu');
      const profileDropdown = document.getElementById('adminProfileDropdown');
      const profileTrigger = document.getElementById('adminProfileTrigger');
      const profileBox = profileTrigger ? profileTrigger.closest('.admin-profile') : null;

      if (adminUserMenu && !adminUserMenu.contains(event.target)) {
        if (notifyDropdown && notifyDropdown.classList.contains('active')) notifyDropdown.classList.remove('active');
      }

      if (profileBox && !profileBox.contains(event.target)) {
        if (profileDropdown && profileDropdown.classList.contains('active')) {
          profileDropdown.classList.remove('active');
          profileDropdown.setAttribute('aria-hidden', 'true');
        }
        if (profileBox) profileBox.classList.remove('open');
        if (profileTrigger) profileTrigger.setAttribute('aria-expanded', 'false');
      }
    });

    const profileTrigger = document.getElementById('adminProfileTrigger');
    if (profileTrigger) {
      profileTrigger.addEventListener('click', toggleProfileDropdown);
    }

    function loadAvailableCrops() {
      const cropsGrid = document.getElementById('cropsGrid');
      if (!cropsGrid) return;

            cropsGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;"><i class="fas fa-spinner fa-spin"></i> Loading ongoing crop biddings...</div>';

      fetch(BIDDING_API + '?action=get_crops')
        .then((response) => response.json())
        .then((data) => {
          if (!data.success || !Array.isArray(data.crops) || data.crops.length === 0) {
            cropsGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;">No ongoing crop biddings found.</div>';
            return;
          }

          cropsGrid.innerHTML = data.crops.map((crop) => {
            const currentPrice = Number(crop.current_price || crop.starting_price || 0);
            const bidCount = Number(crop.bid_count || 0);
            const endDate = crop.bidding_end_date ? formatDate(crop.bidding_end_date.slice(0, 10)) : 'TBD';
            const farmer = crop.farmer_fullname || 'Farmer';
            const description = String(crop.crop_description || 'No description provided.');
            const priceLabel = bidCount > 0 ? 'Current Price' : 'Starting Price';
            const cropSearch = `${String(crop.crop_name || '')} ${String(farmer || '')}`.toLowerCase().replace(/"/g, '&quot;');
            const endTs = crop.bidding_end_date ? new Date(crop.bidding_end_date).getTime() : 0;
            const isEndingSoon = endTs > 0 && (endTs - Date.now()) <= (3 * 24 * 60 * 60 * 1000);
            const stockState = isEndingSoon ? 'ending-soon' : 'active';
            const cropViewPayload = encodeURIComponent(JSON.stringify({
              title: String(crop.crop_name || 'Crop'),
              subtitle: 'Crop Listing Details',
              fields: [
                { label: 'Unit', value: String(crop.crop_unit || 'N/A') },
                { label: 'Farmer', value: farmer },
                { label: priceLabel, value: `PHP ${currentPrice.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` },
                { label: 'Bids', value: `${bidCount} bid${bidCount === 1 ? '' : 's'}` },
                { label: 'Ends', value: endDate },
                { label: 'Status', value: 'Open for bidding' }
              ],
              note: description
            }));
            const cropViewHref = `dashboard.php?section=item-view&origin=bids&view_payload=${cropViewPayload}`;
            const cropFormPayload = encodeURIComponent(JSON.stringify({
              crop_id: Number(crop.crop_id || 0),
              crop_name: String(crop.crop_name || 'Crop'),
              current_price: currentPrice,
              bid_count: bidCount
            }));
            const cropFormHref = `dashboard.php?section=bid-form&origin=bids&form_payload=${cropFormPayload}`;

            return `
              <div class="catalog-card crop-card" data-item-id="${Number(crop.crop_id || 0)}" data-search="${cropSearch}" data-stock="${stockState}">
                <div class="catalog-thumb"><i class="fas fa-seedling"></i></div>
                <div class="catalog-header">
                  <div class="catalog-title-wrap">
                    <h4>${crop.crop_name || 'Crop'}</h4>
                    <span class="catalog-unit">${crop.crop_unit || 'Crop Lot'}</span>
                  </div>
                  <button type="button" class="favorite-btn" title="Add to favorites" aria-label="Add to favorites">
                    <i class="far fa-heart"></i>
                  </button>
                </div>
                <div class="catalog-meta">
                  <span class="catalog-chip"><i class="fas fa-circle-check"></i> Open for bidding</span>
                  <span>${farmer}</span>
                </div>
                <div class="catalog-stock">
                  <span class="catalog-stock-label">${priceLabel}</span>
                  <span class="catalog-stock-value crop-price">₱${currentPrice.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  <div style="margin-top:0.35rem;font-size:0.78rem;color:#4f6f58;"><i class="fas fa-gavel"></i> ${bidCount} bid${bidCount === 1 ? '' : 's'} • Ends ${endDate}</div>
                </div>
                <div class="catalog-actions">
                  <a class="catalog-add-btn wide-bid-btn" href="${cropFormHref}"><i class="fas fa-gavel"></i> Place Bid</a>
                  <style>
                    .catalog-card.crop-card .catalog-actions {
                      display: flex;
                      width: 100%;
                      padding: 0;
                      margin: 0;
                    }
                    .catalog-card.crop-card .catalog-add-btn.wide-bid-btn {
                      width: 100%;
                      justify-content: center;
                      display: flex;
                      font-size: 1rem;
                      padding: 0.8rem 0;
                      border-radius: 12px;
                      margin: 0;
                      box-sizing: border-box;
                    }
                  </style>
                </div>
              </div>
            `;
          }).join('');
          filterBidsCatalogCards();
          syncFavoriteButtons();
        })
        .catch(() => {
          cropsGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#dc3545;">Could not load crop listings. Please refresh.</div>';
        });
    }

    function filterBidsCatalogCards() {
      const search = (document.getElementById('clientBidsSearch')?.value || '').trim().toLowerCase();
      const priceFilter = document.getElementById('clientBidsFilter')?.value || '';
      const cards = document.querySelectorAll('#cropsGrid .catalog-card[data-search]');
      let visibleCount = 0;

      cards.forEach((card) => {
        const text = (card.getAttribute('data-search') || '').toLowerCase();
        const currentPrice = Number(card.getAttribute('data-price') || '0');
        const matchSearch = search === '' || text.includes(search);
        let matchPrice = true;

        switch (priceFilter) {
          case '0-1000':
            matchPrice = currentPrice < 1000;
            break;
          case '1000-5000':
            matchPrice = currentPrice >= 1000 && currentPrice < 5000;
            break;
          case '5000-10000':
            matchPrice = currentPrice >= 5000 && currentPrice < 10000;
            break;
          case '10000-plus':
            matchPrice = currentPrice >= 10000;
            break;
          default:
            matchPrice = true;
        }

        const isVisible = matchSearch && matchPrice;
        card.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleCount++;
      });

      const emptyContainer = document.getElementById('cropsGridEmpty');
      if (emptyContainer) {
        emptyContainer.style.display = visibleCount === 0 ? '' : 'none';
      }
    }

    function filterRentalCatalogCards() {
      const search = (document.getElementById('clientRentalSearch')?.value || '').trim().toLowerCase();
      const typeFilter = (document.getElementById('clientRentalFilter')?.value || '').trim().toLowerCase();
      const cards = document.querySelectorAll('#machineryGrid .catalog-card[data-search]');
      let visibleCount = 0;

      cards.forEach((card) => {
        const text = (card.getAttribute('data-search') || '').toLowerCase();
        const type = (card.getAttribute('data-type') || '').toLowerCase();
        const matchSearch = search === '' || text.includes(search);
        const matchType = typeFilter === '' || type === typeFilter;
        const isVisible = matchSearch && matchType;
        card.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleCount++;
      });

      const emptyContainer = document.getElementById('machineryGridEmpty');
      if (emptyContainer) {
        emptyContainer.style.display = visibleCount === 0 ? '' : 'none';
      }
    }

    function loadMyBids() {
      const myBidsTableBody = document.getElementById('myBidsTableBody');
      if (!myBidsTableBody) return;

      myBidsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">Loading your bids...</td></tr>';

      fetch(BIDDING_API + '?action=get_my_bids')
        .then((response) => response.json())
        .then((data) => {
          if (!data.success || !Array.isArray(data.bids) || data.bids.length === 0) {
            myBidsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#6b7280;">No bids submitted yet.</td></tr>';
            return;
          }

          myBidsTableBody.innerHTML = data.bids.map((bid) => {
            const yourBid = Number(bid.bid_amount || 0);
            const highest = Number(bid.highest_bid || bid.starting_price || 0);
            const ends = bid.bidding_end_date ? formatDate(bid.bidding_end_date.slice(0, 10)) : 'TBD';
            const statusPill = bid.is_leading
              ? '<span class="pill">Leading</span>'
              : '<span class="pill pending">Outbid</span>';

            return `
              <tr>
                <td>${bid.crop_name || 'Crop'}</td>
                <td>₱${yourBid.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td>₱${highest.toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</td>
                <td>${statusPill}</td>
                <td>${ends}</td>
              </tr>
            `;
          }).join('');
        })
        .catch(() => {
          myBidsTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#dc3545;">Could not load your bids.</td></tr>';
        });
    }

    // My bids and reservations are now dedicated page sections.

    /* ════════════════════════════════════════
       LIVESTOCK & PRODUCTS — CLIENT SIDE
    ════════════════════════════════════════ */
    (function () {
      const LP_API = 'livestock_api.php';
      const LP_LOW_STOCK_THRESHOLD = 20;

      const TYPE_ICONS = {
        'Livestock':      'fa-cow',
        'Dairy Products': 'fa-bottle-water',
        'Farm Products':  'fa-box',
        'Supplies':       'fa-toolbox',
        'Other':          'fa-tag',
      };

      function lpFmt(n) {
        return '₱' + Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }
      function lpEsc(s) {
        return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
      }
      function lpFmtDate(v) {
        if (!v) return '—';
        const d = new Date(v.length === 10 ? v + 'T00:00:00' : v);
        return isNaN(d) ? v : d.toLocaleDateString('en-US', {month:'short',day:'numeric',year:'numeric'});
      }
      function lpResBadge(s) {
        const cls = {pending:'pending',confirmed:'info',ready:'active',completed:'',cancelled:'inactive'};
        const labels = {pending:'Pending',confirmed:'Confirmed',ready:'Ready for Pickup',completed:'Completed',cancelled:'Cancelled'};
        return `<span class="pill ${cls[s]||''}">${labels[s]||s}</span>`;
      }

      window.lpLoadMyReservations = function () {
        const body = document.getElementById('lpMyReservationsBody');
        if (!body) return;

        body.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:1.5rem;color:#6b7280;"><i class="fas fa-spinner fa-spin"></i> Loading reservations...</td></tr>';

        fetch(LP_API + '?action=get_my_reservations')
          .then(r => r.json())
          .then(data => {
            if (!data.success || !Array.isArray(data.reservations) || !data.reservations.length) {
              body.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:1.5rem;color:#6b7280;">You have no reservations yet.</td></tr>';
              return;
            }

            body.innerHTML = data.reservations.map(r => `
              <tr>
                <td>#${Number(r.reservation_id || 0)}</td>
                <td><strong>${lpEsc(r.product_name || 'Product')}</strong><br><small style="color:#6b7280;">${lpEsc(r.product_type || '')}</small></td>
                <td>${Number(r.quantity || 0)} ${lpEsc(r.unit || '')}</td>
                <td>${lpFmt(r.total_price)}</td>
                <td>${lpFmtDate(r.preferred_date)}</td>
                <td>${lpResBadge(r.status)}</td>
                <td style="font-size:0.82rem;color:#5b6b5b;max-width:180px;line-height:1.4;">${lpEsc(r.admin_notes || '—')}</td>
                <td style="font-size:0.82rem;">${lpFmtDate(r.created_at)}</td>
                <td>
                  ${(r.status === 'pending' || r.status === 'confirmed') ? `<button class="modal-btn modal-btn-cancel" style="font-size:0.8rem;padding:0.35rem 0.65rem;" onclick="lpCancelReservation(${Number(r.reservation_id || 0)})">Cancel</button>` : '<span style="color:#9ca3af;">-</span>'}
                </td>
              </tr>
            `).join('');
          })
          .catch(() => {
            body.innerHTML = '<tr><td colspan="9" style="text-align:center;padding:1.5rem;color:#dc3545;">Could not load reservations.</td></tr>';
          });
      };

      window.lpCancelReservation = function (id) {
        if (!confirm('Cancel this reservation?')) return;
        const fd = new FormData();
        fd.append('action', 'cancel_reservation');
        fd.append('reservation_id', id);
        fetch(LP_API, { method: 'POST', body: fd })
          .then(r => r.json())
          .then(data => {
            if (data.success) {
              alert('Reservation cancelled.');
              lpLoadMyReservations();
              return;
            }
            alert('Error: ' + (data.message || 'Unable to cancel reservation.'));
          })
          .catch(() => alert('Connection error.'));
      };

      function lpThumb(imageUrl, productType, productName) {
        const fallbackIcon = TYPE_ICONS[productType] || 'fa-tag';
        if (imageUrl) {
          return `<img src="${lpEsc(imageUrl)}" alt="${lpEsc(productName)}">`;
        }
        return `<i class="fas ${lpEsc(fallbackIcon)}"></i>`;
      }

      /* Load products from API */
      window.lpClientLoadProducts = function () {
        if (lpProductsLoading) return;
        lpProductsLoading = true;
        const search = document.getElementById('lpClientSearch')?.value || '';
        const params = new URLSearchParams({ action: 'get_products', search });
        const grid   = document.getElementById('lpClientGrid');
        if (!grid) {
          lpProductsLoading = false;
          return;
        }
        grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:#6b7280;"><i class="fas fa-spinner fa-spin"></i> Loading...</div>';

        const loadTimeout = new Promise((_, reject) => {
          window.setTimeout(() => reject(new Error('timeout')), 12000);
        });

        Promise.race([
          fetch(LP_API + '?' + params).then(r => r.json()),
          loadTimeout
        ])
          .then(data => {
            const emptyDiv = document.getElementById('lpClientGridEmpty');
            if (!data.success || !data.products.length) {
              grid.innerHTML = '';
              if (emptyDiv) emptyDiv.style.display = '';
              lpProductsLoading = false;
              return;
            }
            if (emptyDiv) emptyDiv.style.display = 'none';
            grid.innerHTML = data.products.map(p => {
              const productTypeNormalized = String(p.product_type || 'other')
                .toLowerCase()
                .replace(/\s+/g, '-');
              const productViewPayload = encodeURIComponent(JSON.stringify({
                title: String(p.product_name || 'Product'),
                subtitle: 'Product Details',
                fields: [
                  { label: 'Type', value: String(p.product_type || 'N/A') },
                  { label: 'Unit', value: String(p.unit || 'unit') },
                  { label: 'Price', value: lpFmt(p.price) },
                  { label: 'Available Stock', value: `${Number(p.stock || 0)} ${String(p.unit || '')}`.trim() },
                  { label: 'Supplier', value: String(p.supplier || 'N/A') },
                  { label: 'Status', value: 'Ready to reserve' }
                ],
                note: String(p.product_description || 'No description provided.')
              }));
              const productViewHref = `dashboard.php?section=item-view&origin=livestock&view_payload=${productViewPayload}`;
              const productFormPayload = encodeURIComponent(JSON.stringify({
                product_id: Number(p.product_id || 0),
                product_name: String(p.product_name || 'Product'),
                price: Number(p.price || 0),
                stock: Number(p.stock || 0),
                unit: String(p.unit || 'unit')
              }));
              const productFormHref = `dashboard.php?section=livestock-form&origin=livestock&form_payload=${productFormPayload}`;
              return `
                <div class="catalog-card product-card" data-item-id="${Number(p.product_id || 0)}" data-category="product" data-search="${lpEsc((String(p.product_name || '') + ' ' + String(p.product_type || '')).toLowerCase())}" data-product-type="${lpEsc(productTypeNormalized)}">
                  <div class="catalog-thumb">${lpThumb(p.product_image_url, p.product_type, p.product_name)}</div>
                  <div class="catalog-header">
                    <div class="catalog-title-wrap">
                      <h4>${lpEsc(p.product_name)}</h4>
                      <span class="catalog-unit">${lpEsc(p.unit || 'unit')}</span>
                    </div>
                    <button type="button" class="favorite-btn" title="Add to favorites" aria-label="Add to favorites">
                      <i class="far fa-heart"></i>
                    </button>
                  </div>
                  <div class="catalog-meta">
                    <span class="catalog-chip"><i class="fas fa-circle-check"></i> Ready to reserve</span>
                    <span>${lpEsc(p.product_type)}</span>
                  </div>
                  <div class="catalog-stock">
                    <span class="catalog-stock-label">Price per ${lpEsc(p.unit)}</span>
                    <span class="catalog-stock-value crop-price">${lpFmt(p.price)}</span>
                  </div>
                  <div class="catalog-actions">
                    <a class="catalog-add-btn" href="${productFormHref}"><i class="fas fa-calendar-check"></i> Reserve</a>
                    <style>
                      .catalog-card.product-card .catalog-actions {
                        display: flex;
                        width: 100%;
                        padding: 0;
                        margin: 0;
                      }
                      .catalog-card.product-card .catalog-add-btn {
                        width: 100%;
                        justify-content: center;
                        display: flex;
                        font-size: 1rem;
                        padding: 0.8rem 0;
                        border-radius: 12px;
                        margin: 0;
                        box-sizing: border-box;
                      }
                    </style>
                  </div>
                </div>`;
            }).join('');
            filterLivestockCatalogCards();
            syncFavoriteButtons();
          })
          .catch(() => {
            grid.innerHTML = '';
            const emptyDiv = document.getElementById('lpClientGridEmpty');
            if (emptyDiv) {
              emptyDiv.innerHTML = '<i class="fas fa-exclamation-circle" style="font-size: 3rem; color: #ddd; margin-bottom: 1rem; display: block;"></i><p style="font-size: 1rem; margin: 0.5rem 0;">Could not load products</p><p style="font-size: 0.9rem; margin: 0;">Please refresh the page and try again</p>';
              emptyDiv.style.display = '';
            }
          })
          .finally(() => {
            lpProductsLoading = false;
          });
      };

      function filterLivestockCatalogCards() {
        const filter = (document.getElementById('lpClientTypeFilter')?.value || '').toLowerCase();
        const search = (document.getElementById('lpClientSearch')?.value || '').trim().toLowerCase();
        const cards = document.querySelectorAll('#lpClientGrid .catalog-card[data-product-type]');
        let visibleCount = 0;

        cards.forEach((card) => {
          const productType = (card.getAttribute('data-product-type') || '').toLowerCase();
          const cardSearch = (card.getAttribute('data-search') || '').toLowerCase();
          const matchFilter = !filter || productType === filter;
          const matchSearch = search === '' || cardSearch.includes(search);
          const show = matchFilter && matchSearch;
          card.style.display = show ? '' : 'none';
          if (show) visibleCount++;
        });

        const emptyContainer = document.getElementById('lpClientGridEmpty');
        if (emptyContainer) {
          emptyContainer.style.display = visibleCount === 0 ? '' : 'none';
        }
      }

      /* Load on section show */
      const origShowSection = window.showSection;
      window.showSection = function (section) {
        origShowSection(section);
        if (document.querySelector('#section-livestock.active')) lpClientLoadProducts();
        if (document.querySelector('#section-livestock-reservations.active')) lpLoadMyReservations();
      };

      /* Also load immediately if livestock section is visible at start */
      if (document.querySelector('#section-livestock.active')) lpClientLoadProducts();
      if (document.querySelector('#section-livestock-reservations.active')) lpLoadMyReservations();
    })();
  </script>
  <div id="sfConfirmModal" class="sf-confirm-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sfConfirmTitle">
    <div class="sf-confirm-dialog" role="document">
      <h2 id="sfConfirmTitle">Confirm Submission</h2>
      <p id="sfConfirmMessage">Are you sure you want to continue?</p>
      <div class="sf-confirm-actions">
        <button type="button" class="btn-secondary" id="sfConfirmCancelBtn">Cancel</button>
        <button type="button" class="btn-primary" id="sfConfirmOkBtn">Continue</button>
      </div>
    </div>
  </div>

  <script>
    (function () {
      const modal = document.getElementById('sfConfirmModal');
      const messageEl = document.getElementById('sfConfirmMessage');
      const confirmBtn = document.getElementById('sfConfirmOkBtn');
      const cancelBtn = document.getElementById('sfConfirmCancelBtn');
      if (!modal || !messageEl || !confirmBtn || !cancelBtn) return;

      let pendingForm = null;
      let pendingSubmitter = null;

      function closeModal() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
      }

      function openModal(message, form, submitter) {
        pendingForm = form;
        pendingSubmitter = submitter || null;
        messageEl.textContent = message;
        modal.classList.add('is-visible');
        modal.setAttribute('aria-hidden', 'false');
        cancelBtn.focus();
      }

      confirmBtn.addEventListener('click', () => {
        if (!pendingForm) {
          closeModal();
          return;
        }

        const form = pendingForm;
        const submitter = pendingSubmitter;
        pendingForm = null;
        pendingSubmitter = null;
        form.dataset.sfConfirmArmed = '1';
        closeModal();

        if (typeof form.requestSubmit === 'function') {
          if (submitter && submitter.form === form) {
            form.requestSubmit(submitter);
          } else {
            form.requestSubmit();
          }
        } else {
          form.submit();
        }
      });

      cancelBtn.addEventListener('click', () => {
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      modal.addEventListener('click', (event) => {
        if (event.target !== modal) return;
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('is-visible')) {
          pendingForm = null;
          pendingSubmitter = null;
          closeModal();
        }
      });

      document.addEventListener('submit', (event) => {
        const form = event.target;
        if (!(form instanceof HTMLFormElement)) return;

        if (form.dataset.sfConfirmArmed === '1') {
          delete form.dataset.sfConfirmArmed;
          return;
        }

        if (form.getAttribute('data-skip-confirm') === 'true') {
          return;
        }

        const submitter = event.submitter || null;
        const message = (submitter && submitter.getAttribute('data-confirm-message'))
          || form.getAttribute('data-confirm-message')
          || 'Are you sure you want to continue with this submission?';

        event.preventDefault();
        event.stopImmediatePropagation();
        openModal(message, form, submitter);
      }, true);
    })();
  </script>
</body>
</html>
