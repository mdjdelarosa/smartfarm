<?php
// SmartFarm Database Configuration
// Secure database connection file


// Session settings (must be set BEFORE session_start)
ini_set('session.use_only_cookies', 1);
ini_set('session.use_strict_mode', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_name('smartfarm_session');
    // Set session cookie params for localhost compatibility
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'domain' => '', // empty for localhost
        'secure' => false, // only true if using HTTPS
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}

// Database credentials (Change these to your InfinityFree credentials)
define('DB_HOST', 'localhost');           // Local XAMPP server
define('DB_USER', 'root');                // Default XAMPP username
define('DB_PASS', '');                    // Default XAMPP password (empty)
define('DB_NAME', 'smartfarm');           // Your local database name

// Gmail SMTP credentials (used by sendSmartFarmEmail() in smtp_mailer.php)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'smartfarmcoop12@gmail.com');
define('SMTP_PASSWORD', 'btrrvmjqqiuexsav'); // Gmail App Password (spaces removed)
define('SMTP_FROM_EMAIL', 'smartfarmcoop12@gmail.com');
define('SMTP_FROM_NAME', 'Smart Farm');

require_once __DIR__ . '/smtp_mailer.php';

// Try to establish database connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Set charset to utf8mb4 for proper encoding
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}

// ============================================
// SECURITY SETTINGS
// ============================================

// Password hashing options (bcrypt)
define('PASSWORD_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_OPTIONS', array(
    'cost' => 12,  // Higher cost = more secure but slower
));

// File upload settings
define('MAX_FILE_SIZE', 10485760);  // 10MB in bytes
define('ALLOWED_MIME_TYPES', array(
    'image/jpeg',
    'image/png',
    'image/gif',
    'application/pdf'
));

// (No duplicate session settings here; all session logic is at the top of the file)

// ============================================
// HELPER FUNCTIONS
// ============================================

/**
 * Hash a password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_ALGO, PASSWORD_OPTIONS);
}

/**
 * Verify a password against a hash
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Sanitize user input
 */
function sanitizeInput($input) {
    global $conn;
    return $conn->real_escape_string(trim($input));
}

/**
 * Validate email format
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate password strength
 * Requirements: Min 8 chars, 1 uppercase, 1 lowercase, 1 number, 1 special char
 */
function isStrongPassword($password) {
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password);
}

/**
 * Check if email already exists
 */
function emailExists($email, $table, $column = 'email') {
    global $conn;
    $email = trim((string)$email);
    $table = trim((string)$table);
    $column = trim((string)$column);

    if ($email === '' || $table === '' || $column === '') {
        return false;
    }

    // Restrict identifiers to safe characters to avoid SQL injection in table/column names.
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $table) || !preg_match('/^[a-zA-Z0-9_]+$/', $column)) {
        return false;
    }

    $query = "SELECT 1 FROM `{$table}` WHERE `{$column}` = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $exists = $result && $result->num_rows > 0;
    $stmt->close();

    return $exists;
}

/**
 * Detect whether the app is running in a local development environment.
 */
function isLocalEnvironment(): bool {
    $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
    return $host === 'localhost' || $host === '127.0.0.1' || str_starts_with($host, 'localhost:') || str_starts_with($host, '127.0.0.1:');
}

/**
 * Normalize a contact number for duplicate checks.
 */
function normalizeContactNumber(string $contactNumber): string {
    return preg_replace('/\D+/', '', trim($contactNumber)) ?? '';
}

/**
 * Check whether a contact number already exists in client or farmer profiles.
 */
function contactNumberExists(string $contactNumber): bool {
    global $conn;

    $normalized = normalizeContactNumber($contactNumber);
    if ($normalized === '') {
        return false;
    }

    $queries = [
        'SELECT 1 FROM clients WHERE REPLACE(REPLACE(REPLACE(client_contact_number, "+", ""), "-", ""), " ", "") = ? LIMIT 1',
        'SELECT 1 FROM farmers WHERE REPLACE(REPLACE(REPLACE(farmer_contact_number, "+", ""), "-", ""), " ", "") = ? LIMIT 1',
    ];

    foreach ($queries as $query) {
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            continue;
        }

        $stmt->bind_param('s', $normalized);
        $stmt->execute();
        $result = $stmt->get_result();
        $exists = $result && $result->num_rows > 0;
        $stmt->close();

        if ($exists) {
            return true;
        }
    }

    return false;
}

/**
 * Detect duplicate or suspicious sign-up data.
 */
function findRegistrationConflicts(string $email, string $contactNumber): array {
    $issues = [];

    if (emailExists($email, 'users', 'email')) {
        $issues[] = 'Email already registered';
    }

    if (contactNumberExists($contactNumber)) {
        $issues[] = 'Contact number already used by another account';
    }

    return $issues;
}

/**
 * Generate a numeric verification code.
 */
function generateVerificationCode(int $length = 6): string {
    $length = max(4, min(8, $length));
    $max = (10 ** $length) - 1;
    return str_pad((string)random_int(0, $max), $length, '0', STR_PAD_LEFT);
}

/**
 * Registration now only collects ONE contact method (email or phone) via
 * the pre-registration verification step — whichever one the user didn't
 * verify with is simply not stored. Relax the NOT NULL constraint on the
 * unused columns so that's a valid state (idempotent; safe to call repeatedly).
 */
function ensureOptionalContactColumns(mysqli $conn): void {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;

    @$conn->query('ALTER TABLE users MODIFY COLUMN email VARCHAR(255) NULL');
    @$conn->query('ALTER TABLE farmers MODIFY COLUMN farmer_contact_number VARCHAR(15) NULL');
    @$conn->query('ALTER TABLE clients MODIFY COLUMN client_contact_number VARCHAR(15) NULL');
}

/**
 * Ensure the verification token table exists.
 */
function ensureAccountVerificationTable(mysqli $conn): bool {
    $sql = "CREATE TABLE IF NOT EXISTS account_verifications (
      verification_id INT NOT NULL AUTO_INCREMENT,
      user_id INT NOT NULL,
      verification_token VARCHAR(64) NOT NULL,
      email_code VARCHAR(10) NOT NULL,
      sms_code VARCHAR(10) NOT NULL,
      email_verified_at DATETIME DEFAULT NULL,
      sms_verified_at DATETIME DEFAULT NULL,
      activated_at DATETIME DEFAULT NULL,
      expires_at DATETIME NOT NULL,
      status ENUM('pending','verified','expired') NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (verification_id),
      UNIQUE KEY uniq_user_id (user_id),
      UNIQUE KEY uniq_verification_token (verification_token),
      KEY idx_status_expires (status, expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    return (bool)$conn->query($sql);
}

/**
 * Create or replace the verification row for a user.
 */
function createAccountVerificationRecord(mysqli $conn, int $userId, string $emailCode, string $smsCode, int $ttlMinutes = 30): array {
    if ($userId <= 0) {
        return ['success' => false, 'message' => 'Invalid user ID'];
    }

    if (!ensureAccountVerificationTable($conn)) {
        return ['success' => false, 'message' => 'Unable to prepare verification storage'];
    }

    $token = generateSessionToken();
    $expiresAt = date('Y-m-d H:i:s', time() + (max(5, $ttlMinutes) * 60));

    $stmt = $conn->prepare(
        'INSERT INTO account_verifications (user_id, verification_token, email_code, sms_code, expires_at, status) VALUES (?, ?, ?, ?, ?, \'pending\')
         ON DUPLICATE KEY UPDATE verification_token = VALUES(verification_token), email_code = VALUES(email_code), sms_code = VALUES(sms_code), expires_at = VALUES(expires_at), status = \'pending\', email_verified_at = NULL, sms_verified_at = NULL, activated_at = NULL, updated_at = CURRENT_TIMESTAMP'
    );
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to prepare verification record'];
    }

    $stmt->bind_param('issss', $userId, $token, $emailCode, $smsCode, $expiresAt);
    $ok = $stmt->execute();
    $stmt->close();

    if (!$ok) {
        return ['success' => false, 'message' => 'Unable to save verification record'];
    }

    return [
        'success' => true,
        'token' => $token,
        'expires_at' => $expiresAt,
        'verification_url' => 'account_verification.php?token=' . rawurlencode($token),
        'email_code' => $emailCode,
        'sms_code' => $smsCode,
    ];
}

/**
 * Fetch a verification record by token.
 */
function getAccountVerificationByToken(mysqli $conn, string $token): ?array {
    if ($token === '' || !ensureAccountVerificationTable($conn)) {
        return null;
    }

    $stmt = $conn->prepare('SELECT * FROM account_verifications WHERE verification_token = ? LIMIT 1');
    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ?: null;
}

/**
 * Fetch the latest verification record for a user.
 */
function getAccountVerificationByUserId(mysqli $conn, int $userId): ?array {
    if ($userId <= 0 || !ensureAccountVerificationTable($conn)) {
        return null;
    }

    $stmt = $conn->prepare('SELECT * FROM account_verifications WHERE user_id = ? LIMIT 1');
    if (!$stmt) {
        return null;
    }

    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result ? $result->fetch_assoc() : null;
    $stmt->close();

    return $row ?: null;
}

/**
 * Validate the submitted email/SMS codes against a verification token and,
 * if both match, mark the account verified and activate the user so they
 * can log in. Admin ID approval (farmer/client verification status) is a
 * separate, later gate — this only unblocks the email/SMS login check.
 */
function completeAccountVerification(mysqli $conn, string $token, string $emailCode, string $smsCode): array {
    $token = trim($token);
    $emailCode = trim($emailCode);
    $smsCode = trim($smsCode);

    if ($token === '') {
        return ['success' => false, 'message' => 'Invalid verification link.'];
    }

    $record = getAccountVerificationByToken($conn, $token);
    if (!$record) {
        return ['success' => false, 'message' => 'Invalid or expired verification link.'];
    }

    if ((string)($record['status'] ?? '') === 'verified') {
        return ['success' => true, 'message' => 'Your account is already verified. You can log in now.'];
    }

    $verificationId = (int)($record['verification_id'] ?? 0);
    $expiresAt = strtotime((string)($record['expires_at'] ?? ''));

    if ($expiresAt === false || $expiresAt < time()) {
        $stmt = $conn->prepare("UPDATE account_verifications SET status = 'expired' WHERE verification_id = ?");
        if ($stmt) {
            $stmt->bind_param('i', $verificationId);
            $stmt->execute();
            $stmt->close();
        }
        return ['success' => false, 'message' => 'This verification link has expired. Please contact the administrator for a new code.'];
    }

    $emailMatches = hash_equals((string)$record['email_code'], $emailCode);
    $smsMatches = hash_equals((string)$record['sms_code'], $smsCode);

    if (!$emailMatches || !$smsMatches) {
        return ['success' => false, 'message' => 'The email code or SMS code you entered is incorrect.'];
    }

    $stmt = $conn->prepare(
        "UPDATE account_verifications
         SET email_verified_at = NOW(), sms_verified_at = NOW(), activated_at = NOW(), status = 'verified'
         WHERE verification_id = ?"
    );
    if (!$stmt) {
        return ['success' => false, 'message' => 'Unable to complete verification. Please try again.'];
    }
    $stmt->bind_param('i', $verificationId);
    $ok = $stmt->execute();
    $stmt->close();

    if (!$ok) {
        return ['success' => false, 'message' => 'Unable to complete verification. Please try again.'];
    }

    $userId = (int)($record['user_id'] ?? 0);
    $activateStmt = $conn->prepare('UPDATE users SET is_active = 1 WHERE user_id = ?');
    if ($activateStmt) {
        $activateStmt->bind_param('i', $userId);
        $activateStmt->execute();
        $activateStmt->close();
    }

    return [
        'success' => true,
        'message' => 'Verification complete! Your account is now active. You can log in — final ID approval by an admin may still be pending.',
    ];
}

/**
 * Record a completed verification for a brand-new account whose email or
 * phone code was already confirmed BEFORE registration (see
 * send_registration_code.php / verify_registration_code.php). This keeps
 * the account_verifications table populated with a 'verified' row so the
 * existing login gate (getAccountVerificationByUserId) passes immediately.
 */
function markAccountVerificationComplete(mysqli $conn, int $userId): bool {
    if ($userId <= 0 || !ensureAccountVerificationTable($conn)) {
        return false;
    }

    $token = generateSessionToken();
    $placeholderCode = generateVerificationCode(6);
    $farExpiry = date('Y-m-d H:i:s', time() + (86400 * 3650));

    $stmt = $conn->prepare(
        "INSERT INTO account_verifications (user_id, verification_token, email_code, sms_code, expires_at, status, email_verified_at, sms_verified_at, activated_at)
         VALUES (?, ?, ?, ?, ?, 'verified', NOW(), NOW(), NOW())
         ON DUPLICATE KEY UPDATE status = 'verified', email_verified_at = NOW(), sms_verified_at = NOW(), activated_at = NOW()"
    );
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('issss', $userId, $token, $placeholderCode, $placeholderCode, $farExpiry);
    $ok = $stmt->execute();
    $stmt->close();

    return $ok;
}

/**
 * Send a confirmation email.
 */
if (!function_exists('sendSmartFarmEmail')) {
    function sendSmartFarmEmail(string $to, string $subject, string $html): bool {
        $to = trim($to);
        if ($to === '') {
            return false;
        }

        $result = smtpSendMail(
            $to,
            $subject,
            $html,
            SMTP_FROM_EMAIL,
            SMTP_FROM_NAME,
            SMTP_HOST,
            SMTP_PORT,
            SMTP_USERNAME,
            SMTP_PASSWORD
        );

        $status = $result['success'] ? 'SENT OK' : ('SEND FAILED: ' . $result['error']);
        @file_put_contents(
            __DIR__ . '/debug/email_outbox.log',
            "[" . date('Y-m-d H:i:s') . "] TO: {$to} | SUBJECT: {$subject} | {$status}\n{$html}\n\n",
            FILE_APPEND
        );

        return $result['success'];
    }
}

/**
 * Send a confirmation SMS.
 */
function sendSmartFarmSms(string $to, string $message): bool {
    $to = trim($to);
    if ($to === '') {
        return false;
    }

    @file_put_contents(__DIR__ . '/debug/sms_outbox.log', "[" . date('Y-m-d H:i:s') . "] TO: {$to} | MESSAGE: {$message}\n", FILE_APPEND);
    return true;
}

/**
 * Generate a unique session token
 */
function generateSessionToken() {
    return bin2hex(random_bytes(32));
}

/**
 * Ensure in-app notifications table exists.
 */
function ensureUserNotificationTable(mysqli $conn): bool {
    $sql = "CREATE TABLE IF NOT EXISTS user_notifications (
      notification_id INT NOT NULL AUTO_INCREMENT,
      user_id INT NOT NULL,
      notification_title VARCHAR(255) NOT NULL,
      notification_message TEXT NOT NULL,
      notification_type VARCHAR(60) NOT NULL DEFAULT 'general',
      related_id INT DEFAULT NULL,
      is_read TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (notification_id),
      KEY idx_user_created (user_id, created_at),
      KEY idx_user_read (user_id, is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    return (bool)$conn->query($sql);
}

/**
 * Insert one notification row.
 */
function pushUserNotification(
    mysqli $conn,
    int $userId,
    string $title,
    string $message,
    string $type = 'general',
    ?int $relatedId = null
): bool {
    if ($userId <= 0 || trim($title) === '' || trim($message) === '') {
        return false;
    }

    if (!ensureUserNotificationTable($conn)) {
        return false;
    }

    $safeType = trim($type) !== '' ? trim($type) : 'general';
    $stmt = $conn->prepare(
        "INSERT INTO user_notifications (user_id, notification_title, notification_message, notification_type, related_id)
         VALUES (?, ?, ?, ?, ?)"
    );
    if (!$stmt) {
        return false;
    }

    $stmt->bind_param('isssi', $userId, $title, $message, $safeType, $relatedId);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

/**
 * Resolve active user IDs for a role.
 */
function getActiveUserIdsByRole(mysqli $conn, string $role): array {
    $role = trim(strtolower($role));
    if (!in_array($role, ['admin', 'farmer', 'client'], true)) {
        return [];
    }

    $stmt = $conn->prepare("SELECT user_id FROM users WHERE role = ? AND is_active = 1");
    if (!$stmt) {
        return [];
    }

    $stmt->bind_param('s', $role);
    $stmt->execute();
    $result = $stmt->get_result();
    $ids = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $id = (int)($row['user_id'] ?? 0);
            if ($id > 0) {
                $ids[] = $id;
            }
        }
    }
    $stmt->close();
    return array_values(array_unique($ids));
}

/**
 * Push one notification to all active users of a role.
 */
function pushNotificationToRole(
    mysqli $conn,
    string $role,
    string $title,
    string $message,
    string $type = 'general',
    ?int $relatedId = null
): int {
    $count = 0;
    $userIds = getActiveUserIdsByRole($conn, $role);
    foreach ($userIds as $uid) {
        if (pushUserNotification($conn, (int)$uid, $title, $message, $type, $relatedId)) {
            $count++;
        }
    }
    return $count;
}

/**
 * Finalize any bidding lots whose end date has passed.
 * - Marks highest bidder's bid as 'won', all others as 'outbid'.
 * - Sets crop status to 'sold' (has bids) or 'expired' (no bids).
 * - Notifies winning clients.
 * Safe to call on every page load; no-ops when nothing is expired.
 */
function finalizeExpiredBiddingLots(mysqli $conn): void {
    $tbl = $conn->query("SHOW TABLES LIKE 'crops'");
    if (!$tbl || $tbl->num_rows === 0) return;

    $has_expired = $conn->query(
        "SELECT crop_id FROM crops
         WHERE starting_price > 0
           AND crop_status = 'available'
           AND bidding_end_date <= NOW()
         LIMIT 1"
    );
    if (!$has_expired || $has_expired->num_rows === 0) return;

    // Mark all bids on expired lots as outbid first
    $conn->query(
        "UPDATE bids b
         INNER JOIN crops c ON c.crop_id = b.crop_id
         SET b.bid_status = 'outbid'
         WHERE c.starting_price > 0
           AND c.crop_status = 'available'
           AND c.bidding_end_date <= NOW()"
    );

    // Elevate the highest bid per lot to 'won'
    $conn->query(
        "UPDATE bids winner
         INNER JOIN (
           SELECT b1.crop_id, b1.bid_id
           FROM bids b1
           INNER JOIN crops c ON c.crop_id = b1.crop_id
           WHERE c.starting_price > 0
             AND c.crop_status = 'available'
             AND c.bidding_end_date <= NOW()
             AND b1.bid_id = (
               SELECT b2.bid_id FROM bids b2
               WHERE b2.crop_id = b1.crop_id
               ORDER BY b2.bid_amount DESC, b2.created_at ASC, b2.bid_id ASC
               LIMIT 1
             )
         ) w ON w.bid_id = winner.bid_id
         SET winner.bid_status = 'won'"
    );

    // Notify winning clients before marking crop sold
    $winners = $conn->query(
        "SELECT b.bid_id, b.bid_amount, b.crop_id,
                c.crop_name, c.crop_unit, c.crop_quantity,
                cl.user_id AS winner_user_id
         FROM bids b
         INNER JOIN crops c ON c.crop_id = b.crop_id
         INNER JOIN clients cl ON cl.client_id = b.client_id
         WHERE b.bid_status = 'won'
           AND c.crop_status = 'available'
           AND c.starting_price > 0
           AND c.bidding_end_date <= NOW()"
    );
    if ($winners) {
        while ($w = $winners->fetch_assoc()) {
            $winner_user_id = (int)($w['winner_user_id'] ?? 0);
            if ($winner_user_id <= 0) continue;
            $crop_name   = (string)($w['crop_name'] ?? 'Crop');
            $bid_amount  = number_format((float)($w['bid_amount'] ?? 0), 2);
            $qty         = number_format((float)($w['crop_quantity'] ?? 0), 2);
            $unit        = (string)($w['crop_unit'] ?? '');
            $crop_id     = (int)($w['crop_id'] ?? 0);
            pushUserNotification(
                $conn,
                $winner_user_id,
                'You won the bid!',
                "Congratulations! Your bid of PHP {$bid_amount} for {$qty} {$unit} of {$crop_name} has been accepted. Please coordinate with the cooperative for pickup.",
                'bid_won',
                $crop_id
            );
        }
    }

    // Set crop status: sold if bids exist, expired if none
    $conn->query(
        "UPDATE crops c
         SET c.crop_status = CASE
           WHEN EXISTS (SELECT 1 FROM bids b WHERE b.crop_id = c.crop_id) THEN 'sold'
           ELSE 'expired'
         END
         WHERE c.starting_price > 0
           AND c.crop_status = 'available'
           AND c.bidding_end_date <= NOW()"
    );

    // Restore inventory for expired lots that had no bids (stock was pre-deducted at creation)
    $conn->query(
        "UPDATE crops source_crop
         INNER JOIN crops lot ON lot.source_crop_id = source_crop.crop_id
         SET source_crop.crop_quantity = source_crop.crop_quantity + lot.crop_quantity
         WHERE lot.crop_status = 'expired'
           AND lot.starting_price > 0
           AND lot.inventory_deducted_on_claim = 1
           AND NOT EXISTS (SELECT 1 FROM bids b WHERE b.crop_id = lot.crop_id)"
    );

    // Mark those lots so we don't restore again on the next run
    $conn->query(
        "UPDATE crops lot
         SET lot.inventory_deducted_on_claim = 0
         WHERE lot.crop_status = 'expired'
           AND lot.starting_price > 0
           AND lot.inventory_deducted_on_claim = 1
           AND NOT EXISTS (SELECT 1 FROM bids b WHERE b.crop_id = lot.crop_id)"
    );
}

/**
 * Ensure crop history table exists.
 */
function ensureCropHistoryTable(mysqli $conn): bool {
    $sql = "CREATE TABLE IF NOT EXISTS crop_history (
        history_id INT NOT NULL AUTO_INCREMENT,
        crop_id INT NOT NULL,
        farmer_id INT DEFAULT NULL,
        changed_by_user_id INT DEFAULT NULL,
        actor_role ENUM('admin','farmer','system') NOT NULL DEFAULT 'system',
        actor_name VARCHAR(255) DEFAULT NULL,
        event_type VARCHAR(80) NOT NULL,
        old_quantity DECIMAL(12,2) DEFAULT NULL,
        new_quantity DECIMAL(12,2) DEFAULT NULL,
        quantity_delta DECIMAL(12,2) DEFAULT NULL,
        crop_name VARCHAR(255) DEFAULT NULL,
        crop_unit VARCHAR(40) DEFAULT NULL,
        remarks TEXT DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (history_id),
        KEY idx_crop_history_crop (crop_id),
        KEY idx_crop_history_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

    return (bool)$conn->query($sql);
}

/**
 * Resolve display name of current actor based on role and user id.
 */
function getActorDisplayName(mysqli $conn, int $user_id, string $role): string {
    if ($user_id <= 0) {
        return ucfirst($role ?: 'System');
    }

    if ($role === 'admin') {
        $stmt = $conn->prepare("SELECT fullname FROM admins WHERE user_id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row && !empty($row['fullname'])) {
                return (string)$row['fullname'];
            }
        }
    }

    if ($role === 'farmer') {
        $stmt = $conn->prepare("SELECT farmer_fullname FROM farmers WHERE user_id = ? LIMIT 1");
        if ($stmt) {
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $stmt->close();
            if ($row && !empty($row['farmer_fullname'])) {
                return (string)$row['farmer_fullname'];
            }
        }
    }

    return ucfirst($role ?: 'User') . ' #' . $user_id;
}

/**
 * Write one event row to crop history table.
 */
function logCropHistoryEvent(mysqli $conn, array $entry): bool {
    $sql = "INSERT INTO crop_history (
        crop_id, farmer_id, changed_by_user_id, actor_role, actor_name, event_type, old_quantity, new_quantity, quantity_delta, crop_name, crop_unit, remarks
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $crop_id = (int)($entry['crop_id'] ?? 0);
    $farmer_id = isset($entry['farmer_id']) ? (int)$entry['farmer_id'] : null;
    $changed_by_user_id = isset($entry['changed_by_user_id']) ? (int)$entry['changed_by_user_id'] : null;
    $actor_role = (string)($entry['actor_role'] ?? 'system');
    $actor_name = (string)($entry['actor_name'] ?? 'System');
    $event_type = (string)($entry['event_type'] ?? 'record_updated');
    $old_quantity = isset($entry['old_quantity']) ? (float)$entry['old_quantity'] : null;
    $new_quantity = isset($entry['new_quantity']) ? (float)$entry['new_quantity'] : null;
    $quantity_delta = isset($entry['quantity_delta']) ? (float)$entry['quantity_delta'] : null;
    $crop_name = (string)($entry['crop_name'] ?? '');
    $crop_unit = (string)($entry['crop_unit'] ?? '');
    $remarks = isset($entry['remarks']) ? (string)$entry['remarks'] : null;

    $stmt = $conn->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param(
        'iiisssdddsss',
        $crop_id,
        $farmer_id,
        $changed_by_user_id,
        $actor_role,
        $actor_name,
        $event_type,
        $old_quantity,
        $new_quantity,
        $quantity_delta,
        $crop_name,
        $crop_unit,
        $remarks
    );
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}

/**
 * Least-squares linear regression over a list of [x, y] point pairs.
 * Returns ['slope' => float, 'intercept' => float], or null when there
 * are fewer than 2 points or all points share the same x (no slope
 * can be determined).
 */
function computeLinearRegression(array $points): ?array {
    $n = count($points);
    if ($n < 2) {
        return null;
    }

    $sumX = 0.0; $sumY = 0.0; $sumXY = 0.0; $sumXX = 0.0;
    $distinctX = [];
    foreach ($points as $point) {
        $x = (float)$point[0];
        $y = (float)$point[1];
        $sumX += $x;
        $sumY += $y;
        $sumXY += $x * $y;
        $sumXX += $x * $x;
        $distinctX[$x] = true;
    }

    if (count($distinctX) < 2) {
        return null;
    }

    $denominator = ($n * $sumXX) - ($sumX * $sumX);
    if (abs($denominator) < 1e-9) {
        return null;
    }

    $slope = (($n * $sumXY) - ($sumX * $sumY)) / $denominator;
    $intercept = ($sumY - ($slope * $sumX)) / $n;

    return ['slope' => $slope, 'intercept' => $intercept];
}

/**
 * Shared seasonal supply curve (1 = neutral, >1 = a harvest-heavy month,
 * <1 = a leaner month) for Philippine crop cycles. This is the single
 * source of truth for both yield and price forecasts: yield forecasts
 * apply it directly (more supply expected), while price forecasts must
 * apply its inverse (more supply historically pushes prices down, and
 * scarcity pushes them up) — see getInverseSeasonalFactor().
 */
function getSeasonalYieldFactor(int $month): float {
    $yield_seasonality_factors = [
        1 => 1.03, 2 => 1.02, 3 => 1.01, 4 => 0.99,
        5 => 0.98, 6 => 0.97, 7 => 0.98, 8 => 1.00,
        9 => 1.01, 10 => 1.02, 11 => 1.03, 12 => 1.04,
    ];

    return $yield_seasonality_factors[$month] ?? 1.0;
}

/**
 * Price moves opposite to expected supply: a high-yield season (factor > 1)
 * should pull price down, and a scarce season (factor < 1) should push it
 * up. Reflecting the yield factor around 1.0 gives that inverse curve
 * without needing a second, disconnected set of magic numbers.
 */
function getInverseSeasonalFactor(float $yield_factor): float {
    return 2.0 - $yield_factor;
}

/**
 * Crop market-price forecast via linear regression on each crop's price
 * history. Shared by admin/forecast-market.php (full page) and
 * admin/forecasting.php (dashboard preview) so the two can never drift
 * out of sync with each other.
 */
function computeMarketForecastRows(mysqli $conn, int $forecastHorizonDays = 30): array {
    $rows = [];

    $table_check = $conn->query("SHOW TABLES LIKE 'crops'");
    if (!$table_check || $table_check->num_rows === 0) {
        return $rows;
    }

    // Price moves opposite to expected supply — see getInverseSeasonalFactor().
    $season_factor = getInverseSeasonalFactor(getSeasonalYieldFactor((int)date('n')));

    // Only genuine inventory listings (starting_price <= 0) carry a real
    // "market price per unit" — bidding lots' starting_price is an auction
    // starting bid, not a per-unit market price, and must not be mixed in.
    $market_query = "
        SELECT
            crop_name,
            COALESCE(NULLIF(crop_unit, ''), 'unit') AS crop_unit,
            created_at,
            market_price_per_unit AS price_value
        FROM crops
        WHERE market_price_per_unit > 0
          AND starting_price <= 0
        ORDER BY crop_name ASC, created_at ASC
    ";

    $price_series = [];
    $market_result = $conn->query($market_query);
    if ($market_result) {
        while ($row = $market_result->fetch_assoc()) {
            $price_value = (float)($row['price_value'] ?? 0);
            if ($price_value <= 0) {
                continue;
            }
            $crop_name = trim((string)($row['crop_name'] ?? 'Crop'));
            $crop_unit = trim((string)($row['crop_unit'] ?? 'unit'));
            $day_index = (int)floor(strtotime((string)$row['created_at']) / 86400);

            if (!isset($price_series[$crop_name])) {
                $price_series[$crop_name] = [];
            }
            $price_series[$crop_name][] = ['x' => $day_index, 'y' => $price_value, 'unit' => $crop_unit];
        }
    }

    foreach ($price_series as $crop_name => $points) {
        $latest_point = end($points);
        $current_price = (float)$latest_point['y'];
        if ($current_price <= 0) {
            continue;
        }

        $regression_points = array_map(static fn($p) => [$p['x'], $p['y']], $points);
        $regression = computeLinearRegression($regression_points);

        if ($regression !== null) {
            $forecast_x = (float)$latest_point['x'] + $forecastHorizonDays;
            $trend_value = $regression['intercept'] + ($regression['slope'] * $forecast_x);
        } else {
            // Only one price observation on record — no trend to regress, hold flat.
            $trend_value = $current_price;
        }

        $forecast_value = max(0.0, $trend_value * $season_factor);
        $delta_pct = $current_price > 0 ? (($forecast_value - $current_price) / $current_price) * 100 : 0;

        $rows[] = [
            'crop_name' => $crop_name,
            'unit' => (string)$latest_point['unit'],
            'current' => round($current_price, 2),
            'forecast' => round($forecast_value, 2),
            'delta_pct' => round($delta_pct, 1),
            'badge_class' => $delta_pct >= 0 ? 'up' : 'down',
        ];
    }

    usort($rows, static fn($a, $b) => $b['current'] <=> $a['current']);

    return $rows;
}

/**
 * Crop yield forecast via linear regression on each crop's cumulative
 * quantity history. Shared by admin/forecast-yield.php (full page) and
 * admin/forecasting.php (dashboard preview) — see computeMarketForecastRows().
 */
function computeYieldForecastRows(mysqli $conn, int $forecastHorizonDays = 30): array {
    $rows = [];

    $crops_check = $conn->query("SHOW TABLES LIKE 'crops'");
    if (!$crops_check || $crops_check->num_rows === 0) {
        return $rows;
    }

    // Yield applies the seasonal supply curve directly — a harvest-heavy
    // month means more expected quantity. (Price forecasts apply the
    // inverse of this same curve — see computeMarketForecastRows().)
    $season_factor = getSeasonalYieldFactor((int)date('n'));

    // Regress each crop's cumulative quantity change over time to get a
    // quantity-per-day trend, then project it across the forecast horizon.
    $crop_growth_map = [];
    $history_check = $conn->query("SHOW TABLES LIKE 'crop_history'");
    if ($history_check && $history_check->num_rows > 0) {
        $growth_query = "
            SELECT crop_name, quantity_delta, created_at
            FROM crop_history
            ORDER BY crop_name ASC, created_at ASC
        ";
        $growth_series = [];
        $growth_result = $conn->query($growth_query);
        if ($growth_result) {
            while ($row = $growth_result->fetch_assoc()) {
                $crop_key = strtolower(trim((string)($row['crop_name'] ?? '')));
                if ($crop_key === '') {
                    continue;
                }
                if (!isset($growth_series[$crop_key])) {
                    $growth_series[$crop_key] = [];
                }
                $growth_series[$crop_key][] = [
                    'day' => (int)floor(strtotime((string)$row['created_at']) / 86400),
                    'delta' => (float)($row['quantity_delta'] ?? 0),
                ];
            }
        }

        foreach ($growth_series as $crop_key => $events) {
            $running_total = 0.0;
            $points = [];
            foreach ($events as $event) {
                $running_total += $event['delta'];
                $points[] = [$event['day'], $running_total];
            }

            $regression = computeLinearRegression($points);
            $crop_growth_map[$crop_key] = $regression !== null ? $regression['slope'] * $forecastHorizonDays : 0.0;
        }
    }

    $yield_query = "
        SELECT crop_name, COALESCE(NULLIF(crop_unit, ''), 'kg') AS crop_unit, SUM(crop_quantity) AS total_qty
        FROM crops
        GROUP BY crop_name, crop_unit
        ORDER BY total_qty DESC
    ";
    $yield_result = $conn->query($yield_query);
    if ($yield_result) {
        while ($row = $yield_result->fetch_assoc()) {
            $crop_name = trim((string)($row['crop_name'] ?? 'Crop'));
            $crop_unit = trim((string)($row['crop_unit'] ?? 'kg'));
            $current_qty = (float)($row['total_qty'] ?? 0);
            if ($current_qty <= 0) {
                continue;
            }

            $projected_gain = $crop_growth_map[strtolower($crop_name)] ?? 0.0;
            // Regression-projected quantity change × season factor
            $expected_qty = max(0.0, ($current_qty + $projected_gain) * $season_factor);
            $growth_pct = $current_qty > 0 ? (($expected_qty - $current_qty) / $current_qty) * 100.0 : 0.0;

            $rows[] = [
                'crop_name' => $crop_name,
                'unit' => $crop_unit,
                'current_qty' => round($current_qty, 2),
                'expected_qty' => round($expected_qty, 2),
                'growth_pct' => round($growth_pct, 1),
                'badge_class' => $growth_pct >= 0 ? 'up' : 'down',
            ];
        }
    }

    return $rows;
}

?>
