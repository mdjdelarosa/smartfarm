<?php
/**
 * AJAX endpoint: mark all unread notifications as read for the current user.
 * Called via fetch() from farmer/client/admin dashboards when the bell dropdown opens.
 * Returns JSON { ok: true } on success, { ok: false, error: "..." } on failure.
 */
require 'config.php';

header('Content-Type: application/json');

// Must be logged in
if (empty($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'error' => 'not authenticated']);
    exit;
}

// Only accept POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'method not allowed']);
    exit;
}

$user_id = (int)$_SESSION['user_id'];

// Quick-check table exists before querying
$table_check = $conn->query("SHOW TABLES LIKE 'user_notifications'");
if (!$table_check || $table_check->num_rows === 0) {
    echo json_encode(['ok' => true, 'updated' => 0]);
    exit;
}

$stmt = $conn->prepare(
    "UPDATE user_notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0"
);
if (!$stmt) {
    echo json_encode(['ok' => false, 'error' => 'prepare failed']);
    exit;
}

$stmt->bind_param('i', $user_id);
if (!$stmt->execute()) {
    $stmt->close();
    echo json_encode(['ok' => false, 'error' => 'execute failed']);
    exit;
}

$affected = $stmt->affected_rows;
$stmt->close();

echo json_encode(['ok' => true, 'updated' => $affected]);
