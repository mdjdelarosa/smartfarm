<?php
require 'config.php';

/*
 * Insert additional bidding transactions to fill Sep 2025 – Apr 2026
 * 18 new lots slotted into gaps between existing ones + April 2026 lots
 * All start_price and winning bids are realistic vs market_price * qty
 *
 * Current inventory BEFORE this script (after first batch deductions):
 *   Palay(1):65  Corn(2):53  Tomato(3):40  Eggplant(4):30  Lettuce(5):22
 *   Chili(6):15  Cucumber(7):27  Carrot(8):38  Onion(9):43  Watermelon(10):70
 *
 * Client IDs: Juan=1, Maria=2, Carlo=3, Angela=4, Mark=5, Christine=6, Joshua=7
 */

$farmer_id = 9;

// [src_crop_id, crop_name, qty, unit, market_price, starting_price, listed_at, ended_at, paid_at, winner_client_id, winner_bid, outbids[]]
$lots = [
    // ── Sep 2025 (slot before existing lot 11) ──────────────────────────────────
    [10, 'Watermelon', 25, 'kg', 30.00,  600.00, '2025-09-02 08:00:00', '2025-09-08 18:00:00', '2025-09-10 10:00:00', 4,  850.00, [[5,  750.00]]],

    // ── Sep 2025 (slot after lot 12 Corn, before lot 13 Tomato) ─────────────────
    [4,  'Eggplant',    8, 'kg', 50.00,  320.00, '2025-09-18 08:00:00', '2025-09-25 18:00:00', '2025-09-27 10:00:00', 7,  520.00, [[3,  470.00]]],

    // ── Oct 2025 (slot after lot 13 Tomato ends Oct 5, before lot 14 Onion Oct 10)
    [5,  'Lettuce',     6, 'kg', 70.00,  360.00, '2025-10-08 08:00:00', '2025-10-14 18:00:00', '2025-10-16 10:00:00', 1,  580.00, [[2,  420.00]]],

    // ── Oct 2025 (slot after lot 14 Onion ends Oct 18, before lot 15 Eggplant Oct 25)
    [8,  'Carrot',      8, 'kg', 55.00,  380.00, '2025-10-22 08:00:00', '2025-10-30 18:00:00', '2025-11-01 10:00:00', 6,  550.00, [[5,  480.00]]],

    // ── Nov 2025 (slot after lot 15 Eggplant ends Nov 3, before lot 16 Carrot Nov 8)
    [7,  'Cucumber',   10, 'kg', 45.00,  380.00, '2025-11-04 08:00:00', '2025-11-12 18:00:00', '2025-11-14 10:00:00', 2,  620.00, [[4,  550.00]]],

    // ── Nov 2025 (slot after lot 16 Carrot ends Nov 15, before lot 17 Chili Nov 25)
    [3,  'Tomato',     12, 'kg', 60.00,  620.00, '2025-11-18 08:00:00', '2025-11-25 18:00:00', '2025-11-27 10:00:00', 3,  900.00, [[1,  800.00], [7, 760.00]]],

    // ── Dec 2025 (slot after lot 17 Chili ends Dec 2, before lot 18 Cucumber Dec 12)
    [2,  'Corn',       10, 'kg', 22.00,  180.00, '2025-12-03 08:00:00', '2025-12-09 18:00:00', '2025-12-11 10:00:00', 4,  280.00, [[6,  240.00]]],

    // ── Dec 2025 (parallel gap, different crop, Dec 11 to Dec 18)
    [9,  'Onion',      10, 'kg', 90.00,  800.00, '2025-12-11 08:00:00', '2025-12-17 18:00:00', '2025-12-19 10:00:00', 5, 1050.00, [[7,  950.00]]],

    // ── Dec 2025 (after lot 18 Cucumber ends Dec 20) ────────────────────────────
    [10, 'Watermelon', 15, 'kg', 30.00,  380.00, '2025-12-22 08:00:00', '2025-12-29 18:00:00', '2025-12-31 10:00:00', 1,  600.00, [[2,  520.00]]],

    // ── Jan 2026 (slot after lot 20 Watermelon ends Jan 22, before lot 21 Palay Jan 30)
    [6,  'Chili',       5, 'kg', 120.00, 500.00, '2026-01-26 08:00:00', '2026-02-02 18:00:00', '2026-02-04 10:00:00', 3,  720.00, [[4,  650.00]]],

    // ── Feb 2026 (after lot 21 Palay ends Feb 5, before lot 22 Corn Feb 13) ─────
    [4,  'Eggplant',    8, 'kg', 50.00,  350.00, '2026-02-07 08:00:00', '2026-02-12 18:00:00', '2026-02-14 10:00:00', 2,  600.00, [[1,  530.00]]],

    // ── Feb 2026 (after lot 22 Corn ends Feb 20, before lot 23 Carrot Mar 2) ────
    [3,  'Tomato',     10, 'kg', 60.00,  520.00, '2026-02-24 08:00:00', '2026-03-01 18:00:00', '2026-03-03 10:00:00', 7,  780.00, [[5,  700.00]]],

    // ── Mar 2026 (after lot 23 Carrot ends Mar 8, before lot 24 Onion Mar 18) ───
    [7,  'Cucumber',    8, 'kg', 45.00,  300.00, '2026-03-11 08:00:00', '2026-03-16 18:00:00', '2026-03-18 10:00:00', 6,  440.00, [[3,  380.00]]],

    // ── Apr 2026 (after lot 24 Onion ends Mar 25 / paid Mar 27) ─────────────────
    [1,  'Palay',      10, 'kg', 25.00,  220.00, '2026-03-28 08:00:00', '2026-04-04 18:00:00', '2026-04-06 10:00:00', 4,  320.00, [[5,  280.00]]],

    [5,  'Lettuce',     6, 'kg', 70.00,  380.00, '2026-04-02 08:00:00', '2026-04-09 18:00:00', '2026-04-11 10:00:00', 6,  540.00, [[7,  480.00]]],

    [2,  'Corn',       12, 'kg', 22.00,  220.00, '2026-04-05 08:00:00', '2026-04-11 18:00:00', '2026-04-13 10:00:00', 7,  360.00, [[1,  300.00]]],

    [8,  'Carrot',     10, 'kg', 55.00,  480.00, '2026-04-07 08:00:00', '2026-04-13 18:00:00', '2026-04-15 10:00:00', 2,  650.00, [[6,  580.00]]],

    [9,  'Onion',      10, 'kg', 90.00,  820.00, '2026-04-09 08:00:00', '2026-04-14 18:00:00', '2026-04-16 10:00:00', 3, 1050.00, [[4,  940.00], [5, 880.00]]],
];

// ─── Inventory deduction check (per source crop, this script) ────────────────
// Palay(1): -10 → 65-10=55 ✓
// Corn(2): -10,-12 → 53-22=31 ✓
// Tomato(3): -12,-10 → 40-22=18 ✓
// Eggplant(4): -8,-8 → 30-16=14 ✓
// Lettuce(5): -6,-6 → 22-12=10 ✓
// Chili(6): -5 → 15-5=10 ✓
// Cucumber(7): -10,-8 → 27-18=9 ✓
// Carrot(8): -8,-10 → 38-18=20 ✓
// Onion(9): -10,-10 → 43-20=23 ✓
// Watermelon(10): -25,-15 → 70-40=30 ✓

$insert_lot = $conn->prepare(
    "INSERT INTO crops (farmer_id, crop_name, crop_quantity, crop_unit, market_price_per_unit, starting_price, source_crop_id, inventory_deducted_on_claim, crop_status, bidding_end_date, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'sold', ?, 'paid', ?, ?, ?)"
);
$insert_bid = $conn->prepare(
    "INSERT INTO bids (crop_id, client_id, bid_amount, bid_status, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);
$deduct_inv = $conn->prepare(
    "UPDATE crops SET crop_quantity = crop_quantity - ? WHERE crop_id = ? AND crop_quantity >= ?"
);

foreach ($lots as $idx => [$src_id, $name, $qty, $unit, $market, $start, $listed, $ended, $paid, $win_client, $win_bid, $outbids]) {
    $conn->begin_transaction();
    try {
        $qty_f    = (float)$qty;
        $market_f = (float)$market;
        $start_f  = (float)$start;

        // 11 ? placeholders: i s d s d d i s s s s
        $insert_lot->bind_param('isdsddissss',
            $farmer_id, $name, $qty_f, $unit, $market_f, $start_f, $src_id,
            $ended, $paid, $listed, $paid
        );
        if (!$insert_lot->execute()) throw new Exception("Lot insert failed: " . $insert_lot->error);
        $lot_id = $conn->insert_id;

        // Deduct source inventory
        $deduct_inv->bind_param('did', $qty_f, $src_id, $qty_f);
        $deduct_inv->execute();
        if ($deduct_inv->affected_rows <= 0) throw new Exception("Insufficient stock for $name (source id=$src_id)");

        // Outbid entries
        $s_outbid  = 'outbid';
        $s_unpaid  = 'unpaid';
        $null_date = null;
        foreach ($outbids as $j => [$ob_client, $ob_amount]) {
            $ob_time     = date('Y-m-d H:i:s', strtotime($listed) + ($j + 1) * 7200);
            $ob_amount_f = (float)$ob_amount;
            $insert_bid->bind_param('iidsssss',
                $lot_id, $ob_client, $ob_amount_f,
                $s_outbid, $s_unpaid, $null_date,
                $ob_time, $ob_time
            );
            if (!$insert_bid->execute()) throw new Exception("Outbid insert failed: " . $insert_bid->error);
        }

        // Winning bid
        $s_won     = 'won';
        $s_paid    = 'paid';
        $win_time  = date('Y-m-d H:i:s', strtotime($ended) - 3600);
        $win_bid_f = (float)$win_bid;
        $insert_bid->bind_param('iidsssss',
            $lot_id, $win_client, $win_bid_f,
            $s_won, $s_paid, $paid,
            $win_time, $paid
        );
        if (!$insert_bid->execute()) throw new Exception("Win bid insert failed: " . $insert_bid->error);

        $conn->commit();
        echo "Lot #$lot_id: $name {$qty}kg × winning bid P$win_bid — paid $paid\n";
    } catch (Exception $e) {
        $conn->rollback();
        echo "FAILED ($name): " . $e->getMessage() . "\n";
    }
}

$insert_lot->close();
$insert_bid->close();
$deduct_inv->close();

echo "\nFinal inventory:\n";
$r = $conn->query("SELECT crop_id, crop_name, crop_quantity FROM crops WHERE starting_price <= 0 ORDER BY crop_id");
while ($row = $r->fetch_assoc()) {
    echo "  [{$row['crop_id']}] {$row['crop_name']}: {$row['crop_quantity']} kg\n";
}

echo "\nTotal bidding lots now: ";
$r = $conn->query("SELECT COUNT(*) AS c FROM crops WHERE starting_price > 0");
echo $r->fetch_assoc()['c'] . "\n";
