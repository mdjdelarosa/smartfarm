<?php
require 'config.php';

$token = sanitizeInput($_GET['token'] ?? $_POST['token'] ?? '');
$message = '';
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_code = sanitizeInput($_POST['email_code'] ?? '');
    $sms_code = sanitizeInput($_POST['sms_code'] ?? '');

    if ($token === '' || $email_code === '' || $sms_code === '') {
        $message = 'Verification token and both codes are required.';
    } else {
        $result = completeAccountVerification($conn, $token, $email_code, $sms_code);
        $success = (bool)($result['success'] ?? false);
        $message = (string)($result['message'] ?? 'Verification completed.');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Account Verification</title>
  <style>
    body { font-family: Arial, sans-serif; background: #f5f8f4; margin: 0; padding: 40px; color: #1c3b28; }
    .card { max-width: 520px; margin: 0 auto; background: #fff; border-radius: 16px; padding: 28px; box-shadow: 0 16px 40px rgba(28,59,40,0.12); }
    h1 { margin-top: 0; }
    .msg { padding: 12px 14px; border-radius: 10px; margin-bottom: 18px; }
    .success { background: #e6f4ea; color: #1f6b33; }
    .error { background: #fdecec; color: #a52a2a; }
    label { display:block; margin: 12px 0 6px; font-weight: 700; }
    input { width: 100%; padding: 12px 14px; border: 1px solid #cfd9d1; border-radius: 10px; box-sizing: border-box; }
    button { margin-top: 18px; width: 100%; padding: 12px 14px; border: 0; border-radius: 10px; background: #2f6b43; color: #fff; font-weight: 700; cursor: pointer; }
    .hint { color: #66756b; font-size: 0.95rem; margin-bottom: 8px; }
  </style>
</head>
<body>
  <div class="card">
    <h1>Account Verification</h1>
    <p class="hint">Enter the email code and SMS code you received. After confirmation, the account stays in the admin review queue.</p>

    <?php if ($message !== ''): ?>
      <div class="msg <?php echo $success ? 'success' : 'error'; ?>"><?php echo htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <form method="post">
      <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
      <label for="email_code">Email Code</label>
      <input type="text" id="email_code" name="email_code" maxlength="8" required>

      <label for="sms_code">SMS Code</label>
      <input type="text" id="sms_code" name="sms_code" maxlength="8" required>

      <button type="submit">Confirm Verification</button>
    </form>
  </div>
</body>
</html>