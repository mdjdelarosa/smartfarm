<?php
// Example: Profit & Dividends Analytics Panel
// You can replace the queries below with your actual business logic and table names.

// --- Sample Data Preparation (Replace with real queries) ---
$months = [];
$profit = [];
$dividends = [];

for ($i = 11; $i >= 0; $i--) {
    $month = date('M Y', strtotime("-$i months"));
    $months[] = $month;
    $profit[] = rand(5000, 20000); // Replace with real profit data
    $dividends[] = rand(1000, 5000); // Replace with real dividends data
}

?>
<section class="admin-section active">
  <div class="section-header">
    <h1>Profit & Dividends Analytics</h1>
    <p>Visualize cooperative profit and dividend trends over the past year.</p>
  </div>
  <div class="dashboard-card">
    <div class="card-header"><h3>Monthly Profit & Dividends</h3></div>
    <canvas id="profitDividendsChart" height="90"></canvas>
  </div>
  <div class="dashboard-card" style="margin-top:2rem;">
    <div class="card-header"><h3>Summary Table</h3></div>
    <div class="filter-bar">
      <div class="sf-filter-field sf-filter-field-search">
        <label class="sf-filter-label" for="profitDividendsSearch">Search</label>
        <input type="text" id="profitDividendsSearch" placeholder="Search month..." class="search-input" oninput="filterTable('profitDividends')">
      </div>
    </div>
    <table class="data-table" id="profitDividendsTable">
      <thead>
        <tr><th>Month</th><th>Profit</th><th>Dividends</th></tr>
      </thead>
      <tbody>
        <?php for ($i = 0; $i < count($months); $i++): ?>
        <tr>
          <td><?php echo htmlspecialchars($months[$i]); ?></td>
          <td>PHP <?php echo number_format($profit[$i], 2); ?></td>
          <td>PHP <?php echo number_format($dividends[$i], 2); ?></td>
        </tr>
        <?php endfor; ?>
      </tbody>
    </table>
  </div>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      if (window.Chart && document.getElementById('profitDividendsChart')) {
        const ctx = document.getElementById('profitDividendsChart').getContext('2d');
        new Chart(ctx, {
          type: 'line',
          data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [
              {
                label: 'Profit',
                data: <?php echo json_encode($profit); ?>,
                borderColor: '#22c55e',
                backgroundColor: 'rgba(34,197,94,0.12)',
                tension: 0.3,
                fill: true,
                pointRadius: 3,
                pointBackgroundColor: '#22c55e',
              },
              {
                label: 'Dividends',
                data: <?php echo json_encode($dividends); ?>,
                borderColor: '#f59e42',
                backgroundColor: 'rgba(245,158,66,0.12)',
                tension: 0.3,
                fill: true,
                pointRadius: 3,
                pointBackgroundColor: '#f59e42',
              }
            ]
          },
          options: {
            responsive: true,
            plugins: {
              legend: { display: true },
              title: { display: false }
            },
            scales: {
              y: { beginAtZero: true, ticks: { callback: value => 'PHP ' + value.toLocaleString() } }
            }
          }
        });
      }
    });
  </script>
</section>
