<!-- Manage Crops Section -->
<?php
$crop_rows = [];
$crops_table_exists = false;

$table_check_result = $conn->query("SHOW TABLES LIKE 'crops'");
if ($table_check_result && $table_check_result->num_rows > 0) {
  $crops_table_exists = true;

  $crop_query = "
    SELECT
      c.crop_id,
      c.crop_name,
      c.crop_description,
      c.crop_quantity,
      c.crop_unit,
      c.market_price_per_unit,
      c.created_at,
      COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
    FROM crops c
    LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
    WHERE c.starting_price <= 0
    ORDER BY c.created_at DESC, c.crop_id DESC
  ";
  $crop_result = $conn->query($crop_query);

  if ($crop_result) {
    while ($row = $crop_result->fetch_assoc()) {
      $crop_rows[] = $row;
    }
  }
}
?>

<section id="section-manage-crops" class="admin-section">
  <div class="section-header">
    <div>
      <h1>Crop Inventory</h1>
      <p style="margin:0.35rem 0 0;color:#5b6a5b;max-width:760px;line-height:1.5;">
        This page shows only inventory crops. Bidding listings are managed separately and do not appear here.
      </p>
    </div>
    <div style="display:flex;gap:0.5rem;align-items:center;">
      <a href="admin_dashboard.php?section=add-crop" class="btn-primary" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;padding:0;min-width:44px;min-height:44px;" data-tooltip="Add crop record">
        <i class="fas fa-plus"></i>
      </a>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="cropSearch">Search</label>
      <input type="text" id="cropSearch" placeholder="Search inventory..." class="search-input" oninput="filterTable('crop')">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="cropStatus">Stock Level</label>
      <select class="filter-select" id="cropStatus" onchange="filterTable('crop')">
        <option value="">All Stock Levels</option>
        <option value="in-stock">In Stock</option>
        <option value="low-stock">Low Stock</option>
        <option value="out-stock">Out of Stock</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="cropGroupBy">Group By</label>
      <select class="filter-select" id="cropGroupBy" onchange="sfSetGroupBy('cropTable', this); filterTable('crop')">
        <option value="">No Grouping</option>
        <option value="2">Stock Level</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="cropTable">
      <thead>
        <tr>
          <th>Crop Name</th>
          <th>Available Quantity</th>
          <th>Stock Level</th>
          <th>Market Price / Unit</th>
          <th class="crop-actions-col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$crops_table_exists): ?>
        <tr>
          <td colspan="5" class="crop-table-empty">Crops table not found. Run crop setup first.</td>
        </tr>
        <?php elseif (empty($crop_rows)): ?>
        <tr>
          <td colspan="5" class="crop-table-empty">No crop records yet. Click <strong>Add Crop</strong> to create one.</td>
        </tr>
        <?php else: ?>
        <?php foreach ($crop_rows as $crop): ?>
        <?php
          $quantity_value = (float)$crop['crop_quantity'];
          if ($quantity_value <= 0) {
            $stock_class = 'out-stock';
            $stock_label = 'Out of Stock';
          } elseif ($quantity_value < 10) {
            $stock_class = 'low-stock';
            $stock_label = 'Low Stock';
          } else {
            $stock_class = 'in-stock';
            $stock_label = 'In Stock';
          }
        ?>
        <tr
          data-crop-id="<?php echo (int)$crop['crop_id']; ?>"
          data-crop-name="<?php echo htmlspecialchars($crop['crop_name'], ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-qty="<?php echo htmlspecialchars((string)$crop['crop_quantity'], ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-unit="<?php echo htmlspecialchars($crop['crop_unit'], ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-market-price="<?php echo htmlspecialchars((string)($crop['market_price_per_unit'] ?? 0), ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-desc="<?php echo htmlspecialchars((string)$crop['crop_description'], ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-owner="<?php echo htmlspecialchars($crop['owner_name'], ENT_QUOTES, 'UTF-8'); ?>"
          data-crop-created="<?php echo htmlspecialchars((string)$crop['created_at'], ENT_QUOTES, 'UTF-8'); ?>"
        >
          <td>
            <div class="crop-table-name">
              <strong><?php echo htmlspecialchars($crop['crop_name']); ?></strong>
            </div>
          </td>
          <td><?php echo number_format($quantity_value, 2); ?> <?php echo htmlspecialchars($crop['crop_unit']); ?></td>
          <td><span class="status <?php echo $stock_class; ?>"><?php echo htmlspecialchars($stock_label); ?></span></td>
          <td>PHP <?php echo number_format((float)($crop['market_price_per_unit'] ?? 0), 2); ?> / <?php echo htmlspecialchars($crop['crop_unit']); ?></td>
          <td class="crop-actions-cell">
            <div class="crop-actions-row">
            <a
              class="btn-small btn-view"
              href="admin_dashboard.php?section=view-crop-history&crop_id=<?php echo (int)$crop['crop_id']; ?>"
              data-tooltip="View crop details"
              style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;"
            >
              <i class="fas fa-clock-rotate-left"></i>
            </a>
            <a
              class="btn-small btn-edit"
              href="admin_dashboard.php?section=edit-crop&crop_id=<?php echo (int)$crop['crop_id']; ?>"
              data-tooltip="Edit crop"
              style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;"
            >
              <i class="fas fa-pen"></i>
            </a>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

