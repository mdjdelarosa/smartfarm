<!-- Dashboard Section -->
<section id="section-dashboard" class="admin-section">
  <div class="section-header">
    <h1>Dashboard</h1>
    <p>Welcome to Smart Farm Admin Panel - Overview of all cooperative activities</p>
  </div>

  <div class="dashboard-stats">
    <div class="stat-card">
      <div class="stat-icon farmers">
        <i class="fas fa-users"></i>
      </div>
      <div class="stat-content">
        <h3>Total Farmers</h3>
        <p class="stat-number"><?php echo $total_farmers; ?></p>
        <small><?php echo $pending_farmers; ?> pending verification</small>
      </div>
    </div>

    <div class="stat-card">
      <div class="stat-icon clients">
        <i class="fas fa-user-tie"></i>
      </div>
      <div class="stat-content">
        <h3>Total Clients</h3>
        <p class="stat-number"><?php echo $total_clients; ?></p>
        <small><?php echo $pending_clients; ?> pending verification</small>
      </div>
    </div>

    <div class="stat-card">
      <div class="stat-icon admins">
        <i class="fas fa-seedling"></i>
      </div>
      <div class="stat-content">
        <h3>Farmer Crop Listings</h3>
        <p class="stat-number"><?php echo $total_crop_listings; ?></p>
        <small><?php echo $open_crop_listings; ?> currently open for bidding</small>
      </div>
    </div>

    <div class="stat-card">
      <div class="stat-icon rental">
        <i class="fas fa-coins"></i>
      </div>
      <div class="stat-content">
        <h3>Monthly Profit</h3>
        <p class="stat-number">PHP <?php echo number_format((float)$dashboard_monthly_transaction_value, 2); ?></p>
        <small>
          Yearly Profit: PHP <?php echo number_format((float)$dashboard_yearly_transaction_value, 2); ?>
        </small>
      </div>
    </div>
  </div>

  <div class="dashboard-grid dashboard-grid-main">
    <div class="dashboard-card dashboard-card-chart">
      <div class="card-header">
        <h3>Transaction Overview</h3>
        <span class="card-subtitle">Monthly bidding, machinery rental, and other income</span>
      </div>
      <div class="chart-controls">
        <div class="chart-nav">
          <button type="button" class="chart-nav-btn" id="incomePrev" aria-label="Previous months">
            <i class="fas fa-chevron-left"></i>
          </button>
        </div>
        <div class="chart-control">
          <input type="month" id="incomeStart" name="incomeStart" value="<?php echo htmlspecialchars($dashboard_income_start_month); ?>">
        </div>
        <div class="chart-nav">
          <button type="button" class="chart-nav-btn" id="incomeNext" aria-label="Next months">
            <i class="fas fa-chevron-right"></i>
          </button>
        </div>
      </div>
      <div class="chart-holder chart-holder-compact">
        <canvas id="incomeChart"></canvas>
      </div>
      <div class="chart-legend chart-legend-spread">
        <span><i class="legend-dot bidding"></i> Bidding</span>
        <span><i class="legend-dot machinery"></i> Machinery</span>
        <span><i class="legend-dot other"></i> Others</span>
      </div>
      <div class="chart-summary">
        <div>
          <span class="summary-label">Best Month</span>
          <span class="summary-value"><?php echo htmlspecialchars($dashboard_best_month_summary); ?></span>
        </div>
        <div>
          <span class="summary-label">Monthly Avg Profit</span>
          <span class="summary-value"><?php echo htmlspecialchars($dashboard_monthly_average_summary); ?></span>
        </div>
        <div>
          <span class="summary-label">Top Profit Source</span>
          <span class="summary-value"><?php echo htmlspecialchars($dashboard_top_source_summary); ?></span>
        </div>
      </div>
    </div>

    <div class="dashboard-card dashboard-card-income">
      <div class="card-header" style="display: flex; align-items: center; gap: 0.7rem;">
        <h3>Dividend Summary</h3>
      </div>
      <div style="display: flex; flex-direction: row; align-items: center; justify-content: space-between; gap: 0.25rem; margin-bottom: 0; margin-top: 0;">
        <div class="dividend-pie-toggle" role="group" aria-label="Dividend period" style="display: flex; gap: 0.5rem;">
          <button type="button" class="dividend-range-btn is-active" data-range="monthly">Monthly</button>
          <button type="button" class="dividend-range-btn" data-range="yearly">Yearly</button>
        </div>
        <span class="dividend-period-badge" id="dividendPeriodBadge" style="background:none;box-shadow:none;padding:0;border:none;">
          <div class="month-pill" id="dividendMonthPickerWrapper">
            <input type="month" id="dividendMonthPicker" />
          </div>
          <div class="month-pill" id="dividendYearPickerWrapper" style="display:none;margin-left:8px;">
            <select id="dividendYearPicker" class="year-pill-select"></select>
          </div>
        </span>
      </div>
      <div class="dividend-pie-panel" style="margin-top: 0; margin-bottom: 0.13rem;">
        <div class="dividend-pie-header" style="margin-bottom: 0.08rem;"></div>
        <div class="dividend-pie-canvas-wrap">
          <canvas id="dividendPieChart"></canvas>
        </div>
        <div class="dividend-pie-legend">
          <span><i class="legend-dot bidding"></i> Farmer Dividend</span>
          <span><i class="legend-dot machinery"></i> Coop Dividend</span>
        </div>
      </div>
      <hr style="margin: 0.5rem 0 0.5rem 0; border: none; border-top: 1.5px solid #cce7d6;" />
      <div class="transaction-report-list" style="margin-bottom: 0.02rem; display: flex; gap: 0.3rem; flex-direction: row; justify-content: center; align-items: stretch;">
        <div class="transaction-report-item" style="padding: 0.45rem 0.7rem 0.35rem 0.7rem; margin: 0; min-width: 120px;">
          <span class="summary-label" id="dividendPerFarmerLabel">Per Farmer</span>
          <span class="summary-value" id="dividendPerFarmerValue">PHP 0.00</span>
        </div>
        <div class="transaction-report-item" style="padding: 0.45rem 0.7rem 0.35rem 0.7rem; margin: 0; min-width: 120px;">
          <span class="summary-label" id="dividendFarmerPoolLabel">Farmer Share</span>
          <span class="summary-value" id="dividendFarmerPoolValue">PHP 0.00</span>
        </div>
        <div class="transaction-report-item" style="padding: 0.45rem 0.7rem 0.35rem 0.7rem; margin: 0; min-width: 120px;">
          <span class="summary-label" id="dividendCoopLabel">Coop Share</span>
          <span class="summary-value" id="dividendCoopValue">PHP 0.00</span>
        </div>
      </div>
      <div class="dividend-total-income" aria-label="Total income summary" style="margin-bottom: 0.05rem;">
        <span class="dividend-total-income-label" id="dividendTotalIncomeLabel">Total Income (Monthly)</span>
        <span class="dividend-total-income-value" id="dividendTotalIncomeValue">PHP 0.00</span>
      </div>
    </div>
  </div>

      <style>
        .dividend-icon-btn {
          background: #f3f8f4;
          border: 1.5px solid #cce7d6;
          color: #15803d;
          font-size: 1.35em;
          padding: 0.18em 0.38em;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          min-width: 36px;
          min-height: 36px;
          box-shadow: none;
          text-decoration: none;
          transition: background 0.15s, color 0.15s, border 0.15s;
          cursor: pointer;
        }
        .dividend-icon-btn:hover, .dividend-icon-btn:focus {
          background: #e6f4ec;
          color: #166534;
          border-color: #22c55e;
          outline: none;
        }
        .dashboard-card-income > .dividend-pie-panel {
          border-top: none !important;
        }
        .month-pill {
          display: inline-block;
          background: #4fb97f;
          border: 2px solid #379963;
          border-radius: 999px;
          padding: 2px 8px 2px 14px;
          box-sizing: border-box;
          box-shadow: none !important;
        }
        .month-pill input[type="month"] {
          background: transparent;
          border: none;
          outline: none;
          font-size: 1.08em;
          color: #fff;
          padding: 2px 0 2px 0;
          width: 105px;
          min-width: 100px;
          max-width: 120px;
          cursor: pointer;
          font-weight: 600;
          letter-spacing: 1px;
          margin-right: 0;
        }
        .year-pill-select {
          background: transparent;
          border: none;
          outline: none;
          font-size: 1.08em;
          color: #fff;
          font-weight: 600;
          letter-spacing: 1px;
          padding: 2px 0 2px 0;
          min-width: 60px;
          max-width: 90px;
          cursor: pointer;
          /* Make arrow white in most browsers */
          appearance: none;
          -webkit-appearance: none;
          -moz-appearance: none;
          background-image: url('data:image/svg+xml;utf8,<svg fill="white" height="20" viewBox="0 0 20 20" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M7 8l3 3 3-3"/></svg>');
          background-repeat: no-repeat;
          background-position: right 8px center;
          background-size: 18px 18px;
        }
        .year-pill-select option {
          color: #166534;
          background: #fff;
        }
        .month-pill#dividendYearPickerWrapper {
          background: #4fb97f;
          border: 2px solid #379963;
        }
        .month-pill input[type="month"]::-webkit-calendar-picker-indicator {
          margin-left: -6px;
        }
        .month-pill input[type="month"]::-webkit-calendar-picker-indicator {
          margin-left: -2px;
        }
        .month-pill input[type="month"]::-webkit-input-placeholder { color: #fff; }
        .month-pill input[type="month"]::-webkit-calendar-picker-indicator {
          filter: invert(100%) brightness(100%) sepia(0%) saturate(0%) hue-rotate(0deg);
          opacity: 1;
          cursor: pointer;
        }
      </style>
      <script>
    (function() {
      const incomeSeries = <?php echo $dashboard_income_series_json; ?>;
      const incomeCanvas = document.getElementById('incomeChart');
      const pieCanvas = document.getElementById('dividendPieChart');
      const pieRangeButtons = Array.from(document.querySelectorAll('.dividend-range-btn'));
      const perFarmerLabel = document.getElementById('dividendPerFarmerLabel');
      const perFarmerValue = document.getElementById('dividendPerFarmerValue');
      const farmerPoolLabel = document.getElementById('dividendFarmerPoolLabel');
      const farmerPoolValue = document.getElementById('dividendFarmerPoolValue');
      const coopLabel = document.getElementById('dividendCoopLabel');
      const coopValue = document.getElementById('dividendCoopValue');
      const totalIncomeLabel = document.getElementById('dividendTotalIncomeLabel');
      const totalIncomeValue = document.getElementById('dividendTotalIncomeValue');
      const periodBadge = document.getElementById('dividendPeriodBadge');
      const monthPicker = document.getElementById('dividendMonthPicker');
      const hasIncomeSeries = Array.isArray(incomeSeries) && incomeSeries.length > 0 && !!incomeCanvas;
      const farmerShareRate = <?php echo json_encode((float)$dashboard_income_farmer_share_rate); ?>;
      const coopShareRate = <?php echo json_encode((float)$dashboard_income_coop_share_rate); ?>;
      const activeFarmerCount = <?php echo json_encode(max(1, ((int)$total_farmers - (int)$pending_farmers))); ?>;
      const dividendPieData = {
        monthly: {
          farmer: <?php echo json_encode(round((float)$dashboard_monthly_farmer_dividend, 2)); ?>,
          coop: <?php echo json_encode(round((float)$dashboard_monthly_coop_dividend, 2)); ?>,
          label: 'Monthly dividend allocation'
        },
        yearly: {
          farmer: <?php echo json_encode(round((float)$dashboard_yearly_farmer_dividend, 2)); ?>,
          coop: <?php echo json_encode(round((float)$dashboard_yearly_coop_dividend, 2)); ?>,
          label: 'Current year dividend allocation'
        }
      };

      // Build month options from incomeSeries
      function getMonthOptions() {
        return incomeSeries.map(item => ({
          value: item.month,
          label: item.label
        }));
      }

      function getDividendDataForMonth(monthKey) {
        const found = incomeSeries.find(item => item.month === monthKey);
        if (!found) return null;
        // Use the sum of all income sources for dividend calculation
        const totalIncome = (found.bidding || 0) + (found.machinery || 0) + (found.others || 0);
        const farmerPool = totalIncome * farmerShareRate;
        const coopPool = totalIncome * coopShareRate;
        const perFarmer = farmerPool / activeFarmerCount;
        return {
          periodLabel: found.label,
          perFarmer,
          farmerPool,
          coop: coopPool,
          totalIncome: totalIncome
        };
      }

      function updateDividendCardsForMonth(monthKey) {
        const cardValues = getDividendDataForMonth(monthKey);
        if (!cardValues) return;
        if (perFarmerLabel) perFarmerLabel.textContent = 'Per Farmer';
        if (farmerPoolLabel) farmerPoolLabel.textContent = 'Farmer Share';
        if (coopLabel) coopLabel.textContent = 'Coop Share';
        if (perFarmerValue) perFarmerValue.textContent = formatPhp(cardValues.perFarmer);
        if (farmerPoolValue) farmerPoolValue.textContent = formatPhp(cardValues.farmerPool);
        if (coopValue) coopValue.textContent = formatPhp(cardValues.coop);
        if (periodBadge) periodBadge.title = cardValues.periodLabel;
        if (totalIncomeLabel) totalIncomeLabel.textContent = 'Total Income (' + cardValues.periodLabel + ')';
        if (totalIncomeValue) totalIncomeValue.textContent = formatPhp(cardValues.totalIncome);
      }

      function getAvailableYears() {
        // Extract unique years from incomeSeries
        const years = Array.from(new Set(incomeSeries.map(item => item.month.substring(0,4))));
        return years.sort();
      }

      function getYearlyDividendData(year) {
        // Sum up all months for the given year
        const months = incomeSeries.filter(item => item.month.startsWith(year));
        let totalIncome = 0, totalFarmer = 0, totalCoop = 0;
        months.forEach(item => {
          totalIncome += (item.bidding || 0) + (item.machinery || 0) + (item.others || 0);
        });
        totalFarmer = totalIncome * farmerShareRate;
        totalCoop = totalIncome * coopShareRate;
        return {
          year,
          perFarmer: totalFarmer / activeFarmerCount,
          farmerPool: totalFarmer,
          coop: totalCoop,
          totalIncome: totalIncome
        };
      }

      function updateDividendCardsYearly(year) {
        const data = getYearlyDividendData(year);
        if (perFarmerLabel) perFarmerLabel.textContent = 'Per Farmer';
        if (farmerPoolLabel) farmerPoolLabel.textContent = 'Farmer Share';
        if (coopLabel) coopLabel.textContent = 'Coop Share';
        if (perFarmerValue) perFarmerValue.textContent = formatPhp(data.perFarmer);
        if (farmerPoolValue) farmerPoolValue.textContent = formatPhp(data.farmerPool);
        if (coopValue) coopValue.textContent = formatPhp(data.coop);
        if (periodBadge) periodBadge.title = 'Yearly';
        if (totalIncomeLabel) totalIncomeLabel.textContent = 'Total Income (' + year + ')';
        if (totalIncomeValue) totalIncomeValue.textContent = formatPhp(data.totalIncome);
      }

      function formatPhp(value) {
        const numeric = Number(value || 0);
        return 'PHP ' + numeric.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      }


      // Setup month picker and event
      function setupMonthPicker() {
        if (!monthPicker) return;
        const months = getMonthOptions();
        if (months.length > 0) {
          monthPicker.min = months[0].value;
          monthPicker.max = months[months.length - 1].value;
        }
        const currentMonth = (new Date()).toISOString().slice(0,7);
        if (months.some(opt => opt.value === currentMonth)) {
          monthPicker.value = currentMonth;
        } else {
          monthPicker.value = months[months.length - 1].value;
        }
        updateDividendCardsForMonth(monthPicker.value);
        monthPicker.addEventListener('change', function() {
          updateDividendCardsForMonth(this.value);
        });
      }

      setupMonthPicker();

      // Toggle between Monthly and Yearly for Dividend Summary
      function setDividendSummaryMode(mode) {
        const monthPickerWrapper = document.getElementById('dividendMonthPickerWrapper');
        const yearPickerWrapper = document.getElementById('dividendYearPickerWrapper');
        const yearPicker = document.getElementById('dividendYearPicker');
        if (mode === 'yearly') {
          if (monthPickerWrapper) monthPickerWrapper.style.display = 'none';
          if (yearPickerWrapper) yearPickerWrapper.style.display = '';
          // Populate year picker
          if (yearPicker) {
            const years = getAvailableYears();
            yearPicker.innerHTML = '';
            years.forEach(y => {
              const opt = document.createElement('option');
              opt.value = y;
              opt.textContent = y;
              yearPicker.appendChild(opt);
            });
            // Default to current year if available
            const currentYear = (new Date()).getFullYear().toString();
            yearPicker.value = years.includes(currentYear) ? currentYear : years[years.length-1];
            updateDividendCardsYearly(yearPicker.value);
            yearPicker.onchange = function() {
              updateDividendCardsYearly(this.value);
            };
          }
        } else {
          if (monthPickerWrapper) monthPickerWrapper.style.display = '';
          if (yearPickerWrapper) yearPickerWrapper.style.display = 'none';
          updateDividendCardsForMonth(monthPicker.value);
        }
      }

      function drawLineChart(canvas, labels, datasets, options) {
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        const width = Math.max(rect.width, 10);
        const height = Math.max(rect.height, 10);

        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, width, height);

        const padding = { top: 20, right: 20, bottom: 28, left: 52 };
        const plotWidth = width - padding.left - padding.right;
        const plotHeight = height - padding.top - padding.bottom;
        const values = datasets.flatMap((set) => set.data);
        const maxVal = Math.max(1, ...(values.length ? values : [0])) * 1.08;
        const minVal = 0;
        const tickCount = options.ticks || 5;
        const xDivisor = Math.max(1, labels.length - 1);

        ctx.strokeStyle = 'rgba(40, 167, 69, 0.12)';
        ctx.lineWidth = 1;
        ctx.font = '12px Arial';
        ctx.fillStyle = '#7c8b7c';

        for (let i = 0; i <= tickCount; i += 1) {
          const y = padding.top + (plotHeight * i) / tickCount;
          ctx.beginPath();
          ctx.moveTo(padding.left, y);
          ctx.lineTo(width - padding.right, y);
          ctx.stroke();

          const value = maxVal - ((maxVal - minVal) * i) / tickCount;
          const label = options.formatY ? options.formatY(value) : Math.round(value).toString();
          ctx.textAlign = 'right';
          ctx.textBaseline = 'middle';
          ctx.fillText(label, padding.left - 10, y);
        }

        labels.forEach((label, index) => {
          const x = padding.left + (plotWidth * index) / xDivisor;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'top';
          ctx.fillText(label, x, height - padding.bottom + 6);
        });

        datasets.forEach((set) => {
          ctx.strokeStyle = set.color;
          ctx.lineWidth = 2;
          ctx.beginPath();

          set.data.forEach((value, index) => {
            const x = padding.left + (plotWidth * index) / xDivisor;
            const ratio = maxVal === minVal ? 0.5 : (value - minVal) / (maxVal - minVal);
            const y = padding.top + plotHeight * (1 - ratio);
            if (index === 0) {
              ctx.moveTo(x, y);
            } else {
              ctx.lineTo(x, y);
            }
          });

          ctx.stroke();

          set.data.forEach((value, index) => {
            const x = padding.left + (plotWidth * index) / xDivisor;
            const ratio = maxVal === minVal ? 0.5 : (value - minVal) / (maxVal - minVal);
            const y = padding.top + plotHeight * (1 - ratio);
            ctx.fillStyle = set.color;
            ctx.beginPath();
            ctx.arc(x, y, 3, 0, Math.PI * 2);
            ctx.fill();
          });
        });
      }

      function buildIncomeData(range) {
        const filtered = incomeSeries.filter((item) => item.month >= range.from && item.month <= range.to);
        return {
          labels: filtered.map((item) => item.label),
          bidding: filtered.map((item) => item.bidding),
          others: filtered.map((item) => item.others),
          machinery: filtered.map((item) => item.machinery)
        };
      }

      function renderChartsWithChartJs(range) {
        const incomeData = buildIncomeData(range);

        const incomeChart = new Chart(incomeCanvas, {
          type: 'line',
          data: {
            labels: incomeData.labels,
            datasets: [
              {
                label: 'Bidding Income',
                data: incomeData.bidding,
                borderColor: '#1e8a43',
                backgroundColor: 'rgba(46, 179, 92, 0.18)',
                tension: 0.35,
                fill: true,
                pointRadius: 3
              },
              {
                label: 'Machinery Rental',
                data: incomeData.machinery,
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.18)',
                tension: 0.35,
                fill: true,
                pointRadius: 3
              },
              {
                label: 'Others Value',
                data: incomeData.others,
                borderColor: '#f39c12',
                backgroundColor: 'rgba(243, 156, 18, 0.18)',
                tension: 0.35,
                fill: true,
                pointRadius: 3
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: { display: false },
              tooltip: {
                callbacks: {
                  label: (ctx) => '₱' + ctx.parsed.y.toLocaleString()
                }
              }
            },
            scales: {
              y: {
                ticks: {
                  callback: (value) => '₱' + (value / 1000) + 'k'
                },
                grid: { color: 'rgba(40, 167, 69, 0.08)' }
              },
              x: { grid: { display: false } }
            }
          }
        });

        return { incomeChart };
      }

      function renderFallbackCharts(range) {
        const incomeData = buildIncomeData(range);

        drawLineChart(incomeCanvas, incomeData.labels, [
          { data: incomeData.bidding, color: '#1e8a43' },
          { data: incomeData.machinery, color: '#3498db' },
          { data: incomeData.others, color: '#f39c12' }
        ], {
          ticks: 5,
          formatY: (value) => '₱' + Math.round(value / 1000) + 'k'
        });
      }

      function drawPieFallback(canvas, farmerValue, coopValue) {
        if (!canvas) {
          return;
        }

        const ctx = canvas.getContext('2d');
        const dpr = window.devicePixelRatio || 1;
        const rect = canvas.getBoundingClientRect();
        const width = Math.max(rect.width, 10);
        const height = Math.max(rect.height, 10);

        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        ctx.clearRect(0, 0, width, height);

        const safeFarmer = Math.max(0, Number(farmerValue || 0));
        const safeCoop = Math.max(0, Number(coopValue || 0));
        const total = safeFarmer + safeCoop;
        const useShareFallback = total <= 0;
        const displayFarmer = useShareFallback ? Math.max(0.01, farmerShareRate) : safeFarmer;
        const displayCoop = useShareFallback ? Math.max(0.01, coopShareRate) : safeCoop;
        const displayTotal = displayFarmer + displayCoop;
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) * 0.36;
        const innerRadius = radius * 0.56;

        const farmerAngle = (displayFarmer / displayTotal) * Math.PI * 2;
        let startAngle = -Math.PI / 2;

        ctx.fillStyle = '#1e8a43';
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, startAngle + farmerAngle);
        ctx.closePath();
        ctx.fill();

        startAngle += farmerAngle;
        ctx.fillStyle = '#3498db';
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.arc(centerX, centerY, radius, startAngle, -Math.PI / 2 + Math.PI * 2);
        ctx.closePath();
        ctx.fill();

        ctx.fillStyle = '#f3f8f4';
        ctx.beginPath();
        ctx.arc(centerX, centerY, innerRadius, 0, Math.PI * 2);
        ctx.fill();
      }

      function setPieRangeButtonState(activeRange) {
        pieRangeButtons.forEach((button) => {
          button.classList.toggle('is-active', button.getAttribute('data-range') === activeRange);
        });
      }

      function renderDividendPieChartWithChartJs(activeRange) {
        if (!pieCanvas || typeof Chart === 'undefined') {
          return null;
        }

        const values = dividendPieData[activeRange] || dividendPieData.monthly;
        const actualFarmer = Math.max(0, Number(values.farmer || 0));
        const actualCoop = Math.max(0, Number(values.coop || 0));
        const actualTotal = actualFarmer + actualCoop;
        const useShareFallback = actualTotal <= 0;
        const chartFarmer = useShareFallback ? Math.max(0.01, farmerShareRate) : actualFarmer;
        const chartCoop = useShareFallback ? Math.max(0.01, coopShareRate) : actualCoop;

        return new Chart(pieCanvas, {
          type: 'doughnut',
          data: {
            labels: ['Farmer Dividend', 'Coop Dividend'],
            datasets: [{
              data: [chartFarmer, chartCoop],
              backgroundColor: ['#1e8a43', '#3498db'],
              borderColor: ['#1e8a43', '#3498db'],
              borderWidth: 1
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '62%',
            plugins: {
              legend: { display: false },
              tooltip: {
                callbacks: {
                  label: (ctx) => {
                    const index = Number(ctx.dataIndex || 0);
                    const actualValue = index === 0 ? actualFarmer : actualCoop;
                    const percentValue = index === 0 ? (farmerShareRate * 100) : (coopShareRate * 100);
                    const displayValue = useShareFallback ? 0 : actualValue;
                    return ctx.label + ': PHP ' + displayValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' (' + percentValue.toFixed(0) + '%)';
                  }
                }
              }
            }
          }
        });
      }

      function renderDividendPieChartFallback(activeRange) {
        const values = dividendPieData[activeRange] || dividendPieData.monthly;
        drawPieFallback(pieCanvas, Number(values.farmer || 0), Number(values.coop || 0));
      }

      const RANGE_MONTHS = 8;

      function monthToIndex(value) {
        const parts = value.split('-');
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        if (Number.isNaN(year) || Number.isNaN(month)) {
          return 0;
        }
        return (year * 12) + month;
      }

      function addMonths(value, monthsToAdd) {
        const parts = value.split('-');
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const date = new Date(year, month, 1);
        date.setMonth(date.getMonth() + monthsToAdd);
        const newYear = date.getFullYear();
        const newMonth = String(date.getMonth() + 1).padStart(2, '0');
        return newYear + '-' + newMonth;
      }

      function normalizeStart(value) {
        if (!hasIncomeSeries) {
          return value || '';
        }
        const minMonth = incomeSeries[0].month;
        const maxMonth = incomeSeries[incomeSeries.length - 1].month;
        const minIndex = monthToIndex(minMonth);
        const maxIndex = monthToIndex(maxMonth);
        const startIndex = monthToIndex(value || minMonth);
        const clampedIndex = Math.min(Math.max(startIndex, minIndex), maxIndex);
        return addMonths(minMonth, clampedIndex - minIndex);
      }

      function setStartValue(value) {
        const startInput = document.getElementById('incomeStart');
        const normalized = normalizeStart(value);
        if (startInput) {
          startInput.value = normalized;
        }
        return normalized;
      }

      function getRange() {
        if (!hasIncomeSeries) {
          return { from: '', to: '' };
        }
        const startInput = document.getElementById('incomeStart');
        const endValue = setStartValue(startInput ? startInput.value : incomeSeries[incomeSeries.length - 1].month);
        const fromValue = addMonths(endValue, -(RANGE_MONTHS - 1));
        const toValue = endValue;
        return { from: fromValue, to: toValue };
      }

      function shiftStartBy(deltaMonths) {
        if (!hasIncomeSeries) {
          return;
        }
        const startInput = document.getElementById('incomeStart');
        const current = startInput ? startInput.value : incomeSeries[0].month;
        const shifted = addMonths(current || incomeSeries[0].month, deltaMonths);
        setStartValue(shifted);
      }

      const startInput = document.getElementById('incomeStart');
      if (hasIncomeSeries && startInput) {
        const minMonth = incomeSeries[0] ? incomeSeries[0].month : startInput.value;
        const maxMonth = incomeSeries[incomeSeries.length - 1] ? incomeSeries[incomeSeries.length - 1].month : startInput.value;
        startInput.min = minMonth;
        startInput.max = maxMonth;
        setStartValue(maxMonth);
      }

      if (typeof Chart !== 'undefined') {
        let charts = hasIncomeSeries ? renderChartsWithChartJs(getRange()) : null;
        let dividendPieChart = renderDividendPieChartWithChartJs('monthly');

        const updatePie = (rangeKey) => {
          const pieRange = dividendPieData[rangeKey] ? rangeKey : 'monthly';
          setPieRangeButtonState(pieRange);
          setDividendSummaryMode(pieRange);
          if (dividendPieChart) {
            dividendPieChart.destroy();
          }
          dividendPieChart = renderDividendPieChartWithChartJs(pieRange);
        };

        updatePie('monthly');

        pieRangeButtons.forEach((button) => {
          button.addEventListener('click', () => {
            updatePie(button.getAttribute('data-range') || 'monthly');
          });
        });

        const refreshCharts = () => {
          if (!hasIncomeSeries) {
            return;
          }
          const range = getRange();
          if (charts && charts.incomeChart) {
            charts.incomeChart.destroy();
          }
          charts = renderChartsWithChartJs(range);
        };

        const prevBtn = document.getElementById('incomePrev');
        const nextBtn = document.getElementById('incomeNext');
        if (hasIncomeSeries && startInput) {
          startInput.addEventListener('change', refreshCharts);
          startInput.addEventListener('input', refreshCharts);
        }
        if (hasIncomeSeries && prevBtn) {
          prevBtn.addEventListener('click', () => {
            shiftStartBy(-1);
            refreshCharts();
          });
        }
        if (hasIncomeSeries && nextBtn) {
          nextBtn.addEventListener('click', () => {
            shiftStartBy(1);
            refreshCharts();
          });
        }
      } else {
        const prevBtn = document.getElementById('incomePrev');
        const nextBtn = document.getElementById('incomeNext');
        let activePieRange = 'monthly';
        const render = () => {
          if (hasIncomeSeries) {
            renderFallbackCharts(getRange());
          }
          renderDividendPieChartFallback(activePieRange);
          updateDividendCards(activePieRange);
        };

        pieRangeButtons.forEach((button) => {
          button.addEventListener('click', () => {
            activePieRange = dividendPieData[button.getAttribute('data-range') || 'monthly'] ? (button.getAttribute('data-range') || 'monthly') : 'monthly';
            setPieRangeButtonState(activePieRange);
            render();
          });
        });

        render();
        window.addEventListener('resize', render);

        if (hasIncomeSeries && startInput) {
          startInput.addEventListener('change', render);
          startInput.addEventListener('input', render);
        }
        if (hasIncomeSeries && prevBtn) {
          prevBtn.addEventListener('click', () => {
            shiftStartBy(-1);
            render();
          });
        }
        if (hasIncomeSeries && nextBtn) {
          nextBtn.addEventListener('click', () => {
            shiftStartBy(1);
            render();
          });
        }
      }
    })();

  </script>
</section>
