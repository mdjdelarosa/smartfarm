<?php
$machinery_utilization_rows = [];
$forecast_horizon_days = 30;

if (isset($conn) && $conn instanceof mysqli) {
  $table_exists = static function (mysqli $db, string $table): bool {
    $safe_table = $db->real_escape_string($table);
    $result = $db->query("SHOW TABLES LIKE '{$safe_table}'");
    return $result && $result->num_rows > 0;
  };

  if ($table_exists($conn, 'machinery_rentals')) {
    $rentals_query = "
      SELECT equipment_name, rental_status, created_at
      FROM machinery_rentals
      ORDER BY equipment_name ASC, created_at ASC
    ";

    $equipment_stats = [];
    $rentals_result = $conn->query($rentals_query);
    if ($rentals_result) {
      while ($row = $rentals_result->fetch_assoc()) {
        $equipment_name = trim((string)($row['equipment_name'] ?? ''));
        if ($equipment_name === '') {
          continue;
        }
        if (!isset($equipment_stats[$equipment_name])) {
          $equipment_stats[$equipment_name] = ['total' => 0, 'active' => 0, 'events' => []];
        }
        $equipment_stats[$equipment_name]['total']++;
        if (in_array((string)($row['rental_status'] ?? ''), ['approved', 'in-rental'], true)) {
          $equipment_stats[$equipment_name]['active']++;
        }
        $equipment_stats[$equipment_name]['events'][] = (int)floor(strtotime((string)$row['created_at']) / 86400);
      }
    }

    foreach ($equipment_stats as $equipment_name => $stats) {
      // Regress the cumulative rental count over time to get a rentals-per-day
      // trend, then project it across the forecast horizon.
      $running_total = 0;
      $points = [];
      foreach ($stats['events'] as $day) {
        $running_total++;
        $points[] = [$day, $running_total];
      }

      $regression = computeLinearRegression($points);
      if ($regression !== null) {
        $forecast_demand = max(0.0, $regression['slope'] * $forecast_horizon_days);
      } else {
        // Not enough spread in the data to fit a trend line — fall back to a
        // flat share of the equipment's total historical rentals.
        $forecast_demand = $stats['total'] > 0 ? $stats['total'] / 2.0 : 0.0;
      }

      $machinery_utilization_rows[] = [
        'label'           => $equipment_name,
        'active'          => (int)$stats['active'],
        'total'           => (int)$stats['total'],
        'utilization_pct' => round($forecast_demand, 1),
      ];
    }

    usort($machinery_utilization_rows, static fn($a, $b) => $b['total'] <=> $a['total']);
  }
}

if (empty($machinery_utilization_rows)) {
  $machinery_utilization_rows = [
    ['label' => 'Tractors', 'active' => 0, 'total' => 0, 'utilization_pct' => 0.0],
    ['label' => 'Harvesters', 'active' => 0, 'total' => 0, 'utilization_pct' => 0.0],
    ['label' => 'Tools', 'active' => 0, 'total' => 0, 'utilization_pct' => 0.0],
  ];
}
?>

<section id="section-forecast-machinery" class="admin-section">
  <div class="section-header" style="display:flex;align-items:center;justify-content:space-between;gap:1rem;">
    <div style="display:flex;align-items:center;gap:0.75rem;">
      <button type="button" class="btn-tertiary" onclick="showSection('forecasting')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Machinery Demand Forecast</h1>
      </div>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="machineryForecastSearch">Search</label>
      <input type="text" id="machineryForecastSearch" placeholder="Search equipment..." class="search-input" oninput="filterTable('machineryForecast')">
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="machineryForecastTable">
      <thead>
        <tr>
          <th>Equipment</th>
          <th>Forecast Demand</th>
          <th>Active / Total</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($machinery_utilization_rows as $util_row): ?>
        <tr>
          <td><?php echo htmlspecialchars((string)$util_row['label']); ?></td>
          <td><?php echo number_format((float)$util_row['utilization_pct'], 1); ?> rentals/period</td>
          <td><?php echo (int)$util_row['active']; ?> / <?php echo (int)$util_row['total']; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
