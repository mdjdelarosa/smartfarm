<?php
$record_type = strtolower(trim((string)($_GET['record_type'] ?? 'request')));
$mode = strtolower(trim((string)($_GET['mode'] ?? 'view')));
$is_edit_mode = ($mode === 'edit');

$seed_row = null;
$request_row = null;
$page_error = '';

if ($record_type === 'stock') {
  $seed_id = (int)($_GET['seed_id'] ?? 0);
  if ($seed_id <= 0) {
    $page_error = 'Invalid seed stock record.';
  } else {
    $seed_stmt = $conn->prepare(
      "SELECT seed_id, seed_name, seed_unit, available_quantity, low_stock_threshold, created_at
       FROM seed_inventory
       WHERE seed_id = ?
       LIMIT 1"
    );
    if ($seed_stmt) {
      $seed_stmt->bind_param('i', $seed_id);
      $seed_stmt->execute();
      $seed_result = $seed_stmt->get_result();
      $seed_row = $seed_result ? $seed_result->fetch_assoc() : null;
      $seed_stmt->close();
    }

    if (!$seed_row) {
      $page_error = 'Seed stock record not found.';
    }
  }
} else {
  $request_id = (int)($_GET['request_id'] ?? 0);
  if ($request_id <= 0) {
    $page_error = 'Invalid seed request record.';
  } else {
    $request_stmt = $conn->prepare(
      "SELECT
         sr.request_id,
         sr.seed_id,
         sr.seed_name,
         sr.quantity_requested,
         COALESCE(NULLIF(TRIM(sr.request_status), ''), 'pending') AS request_status,
         sr.requested_at,
         f.farmer_fullname,
         COALESCE(si.seed_unit, '') AS seed_unit,
         COALESCE(si.available_quantity, 0) AS available_quantity
       FROM seed_requests sr
       LEFT JOIN farmers f ON f.farmer_id = sr.farmer_id
       LEFT JOIN seed_inventory si ON si.seed_id = sr.seed_id
       WHERE sr.request_id = ?
       LIMIT 1"
    );
    if ($request_stmt) {
      $request_stmt->bind_param('i', $request_id);
      $request_stmt->execute();
      $request_result = $request_stmt->get_result();
      $request_row = $request_result ? $request_result->fetch_assoc() : null;
      $request_stmt->close();
    }

    if (!$request_row) {
      $page_error = 'Seed request record not found.';
    }
  }
}

$from_section = trim((string)($_GET['from'] ?? 'distribute-seeds'));
$back_href = 'admin_dashboard.php?section=' . rawurlencode($from_section);
?>

<style>
.sf-seed-header {
  margin-bottom: 16px;
}

.sf-seed-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.sf-seed-meta {
  border: 1px solid #e3e8e3;
  border-radius: 10px;
  background: #f8fbf8;
  color: #4b5d51;
  padding: 0.7rem 0.8rem;
  font-size: 0.9rem;
}

.sf-seed-actions {
  display: flex;
  justify-content: flex-end;
  gap: 0.6rem;
}

.sf-account-shell {
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 14px;
  background: #f7fbf8;
  box-shadow: 0 6px 18px rgba(23, 66, 38, 0.08);
  padding: 18px;
  width: 100%;
  max-width: none !important;
  display: grid;
  gap: 18px;
}

.sf-summary-card {
  background: #ffffff;
  border: 1px solid #d9e7de;
  border-radius: 14px;
  padding: 16px;
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 2fr);
  align-items: start;
  gap: 16px;
  min-width: 0;
}

.sf-summary-main {
  display: grid;
  gap: 10px;
  min-width: 0;
}

.sf-summary-identity {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.sf-avatar {
  width: 46px;
  height: 46px;
  border-radius: 999px;
  background: linear-gradient(135deg, #1f9b58, #088d62);
  color: #fff;
  font-weight: 700;
  font-size: 1.45rem;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.sf-summary-identity h2 {
  margin: 0;
  font-size: 1.1rem;
  color: #184f2f;
  line-height: 1.2;
}

.sf-summary-identity p {
  margin: 2px 0 0;
  color: #5f7565;
  font-size: 0.95rem;
  word-break: break-word;
}

.sf-pill-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.sf-mode-chip {
  display: inline-flex;
  align-items: center;
  font-weight: 700;
  font-size: 0.78rem;
  border-radius: 999px;
  padding: 6px 10px;
  letter-spacing: 0.02em;
}

.sf-mode-chip.view {
  color: #155724;
  background: rgba(40, 167, 69, 0.16);
}

.sf-summary-meta {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  min-width: 0;
}

.sf-summary-meta div {
  border: 1px solid #d8e4dc;
  border-radius: 10px;
  padding: 10px;
  background: #f7fbf8;
  min-width: 0;
}

.sf-summary-meta span {
  display: block;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  color: #607565;
  margin-bottom: 4px;
  font-weight: 700;
}

.sf-summary-meta strong {
  color: #294f37;
  line-height: 1.25;
  word-break: break-word;
}

.sf-content-grid {
  display: grid;
  grid-template-columns: minmax(0, 2fr) minmax(0, 1fr);
  gap: 14px;
  align-items: start;
  min-width: 0;
}

.sf-panel {
  border: 1px solid #cde5d8;
  border-radius: 14px;
  background: #fff;
  padding: 14px;
  min-width: 0;
}

.sf-panel h3 {
  margin: 0 0 8px;
  color: #1d5a34;
}

.sf-action-bar {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: stretch;
  gap: 10px;
  margin-bottom: 14px;
}

.sf-field-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
  min-width: 0;
}

.sf-field-grid-single {
  grid-template-columns: 1fr;
}

.sf-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sf-field label {
  font-size: 0.8rem;
  font-weight: 700;
  color: #45624f;
}

.sf-field-value {
  min-height: 36px;
  border: 1px solid #d9e4dd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #f8fcf9;
  display: block;
  line-height: 1.35;
}

.sf-update-panel {
  display: grid;
  gap: 10px;
  align-content: start;
}

.sf-action-bar {
  display: flex;
  gap: 10px;
  align-items: stretch;
}

.sf-action-bar .btn-primary {
  width: 100%;
  justify-content: center;
}

.sf-inline-view {
  margin-top: 12px;
}

.sf-manage-form {
  border: 1px solid #dce8df;
  border-radius: 12px;
  padding: 12px;
  background: #fbfefd;
  display: grid;
  gap: 10px;
}

.sf-field-input {
  width: 100%;
  border: 1px solid #c7d6cd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #fff;
  font-size: 0.95rem;
  outline: none;
}

.sf-field-input:focus {
  border-color: #00a86b;
  box-shadow: 0 0 0 3px rgba(0, 168, 107, 0.15);
}

.sf-action-buttons {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}

@media (max-width: 1280px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
    align-items: flex-start;
  }

  .sf-summary-meta {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1080px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
  }

  .sf-content-grid {
    grid-template-columns: 1fr;
  }

  .sf-summary-meta {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .sf-field-grid {
    grid-template-columns: 1fr;
  }

  .sf-account-shell {
    padding: 12px;
  }

  .sf-panel {
    padding: 12px;
  }

  .sf-summary-meta div {
    min-width: 100%;
  }

  .sf-action-buttons,
  .sf-action-bar {
    flex-direction: column;
  }
}
</style>

<section id="section-view-seed-record" class="admin-section">
  <div class="section-header sf-seed-header">
    <div class="sf-seed-header-left">
      <a class="btn-tertiary" href="<?php echo htmlspecialchars($back_href); ?>" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;" data-tooltip="Back to Seed Monitor">
        <i class="fas fa-arrow-left"></i>
      </a>
      <div>
        <h1><?php echo $record_type === 'stock' ? 'Edit Seed Stock Listing' : 'Seed Request Details'; ?></h1>
        <?php if ($record_type !== 'stock'): ?>
          <p>Review request details, stock impact, and status updates.</p>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <div class="<?php echo $record_type === 'request' ? '' : 'schedule-modal-card'; ?>" style="width:100%;margin:0;">
    <?php if ($page_error !== ''): ?>
      <div class="alert-error" style="margin:0;">
        <i class="fas fa-triangle-exclamation"></i> <?php echo htmlspecialchars($page_error); ?>
      </div>
    <?php elseif ($record_type === 'stock' && $seed_row): ?>
      <?php
      $seed_created = !empty($seed_row['created_at']) ? date('M d, Y', strtotime((string)$seed_row['created_at'])) : '-';
      ?>
      <div class="schedule-modal-header">
        <div>
          <h3><i class="fas fa-pen" style="color:#22c55e;margin-right:0.4rem;"></i>Update Seed Stock Listing</h3>
          <span class="card-subtitle">Update the stock listing that can be requested again</span>
        </div>
      </div>

      <form class="schedule-form" method="post" action="admin_dashboard.php?section=view-seed-record&record_type=stock&seed_id=<?php echo (int)$seed_row['seed_id']; ?>&from=<?php echo rawurlencode($from_section); ?>">
        <input type="hidden" name="action" value="update_seed_stock">
        <input type="hidden" name="seed_id" value="<?php echo (int)$seed_row['seed_id']; ?>">

        <div class="form-grid">
          <label class="form-field">Seed Type
            <input type="text" name="seed_name" value="<?php echo htmlspecialchars((string)$seed_row['seed_name']); ?>" <?php echo $is_edit_mode ? '' : 'readonly'; ?> style="background:<?php echo $is_edit_mode ? '#fff' : '#f4f7f5'; ?>;">
          </label>

          <label class="form-field">Unit
            <?php if ($is_edit_mode): ?>
              <select name="seed_unit">
                <?php
                $units = ['kg', 'grams', 'packets', 'sacks', 'pcs'];
                $current_unit = (string)($seed_row['seed_unit'] ?? 'kg');
                foreach ($units as $unit_item):
                ?>
                  <option value="<?php echo htmlspecialchars($unit_item); ?>" <?php echo $unit_item === $current_unit ? 'selected' : ''; ?>><?php echo htmlspecialchars($unit_item); ?></option>
                <?php endforeach; ?>
              </select>
            <?php else: ?>
              <input type="text" value="<?php echo htmlspecialchars((string)$seed_row['seed_unit']); ?>" readonly style="background:#f4f7f5;">
              <input type="hidden" name="seed_unit" value="<?php echo htmlspecialchars((string)$seed_row['seed_unit']); ?>">
            <?php endif; ?>
          </label>

          <label class="form-field">Available Quantity
            <input type="number" step="0.01" min="0" name="available_quantity" value="<?php echo htmlspecialchars(number_format((float)$seed_row['available_quantity'], 2, '.', '')); ?>" <?php echo $is_edit_mode ? '' : 'readonly'; ?> style="background:<?php echo $is_edit_mode ? '#fff' : '#f4f7f5'; ?>;">
          </label>

        </div>

        <div class="sf-seed-meta" style="border:none;background:none;padding:0;margin:0;font-size:1rem;box-shadow:none;">
          Created: <?php echo htmlspecialchars($seed_created); ?>
        </div>

        <div class="sf-seed-actions">
          <?php if (!$is_edit_mode): ?>
            <a class="btn-small btn-edit" href="admin_dashboard.php?section=view-seed-record&record_type=stock&seed_id=<?php echo (int)$seed_row['seed_id']; ?>&mode=edit&from=<?php echo rawurlencode($from_section); ?>" style="text-decoration:none;display:inline-flex;align-items:center;">
              <i class="fas fa-pen"></i>&nbsp;Edit
            </a>
          <?php else: ?>
            <a class="btn-secondary" href="admin_dashboard.php?section=view-seed-record&record_type=stock&seed_id=<?php echo (int)$seed_row['seed_id']; ?>&from=<?php echo rawurlencode($from_section); ?>" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;">Cancel</a>
            <button type="submit" class="btn-primary">Save Changes</button>
          <?php endif; ?>
        </div>
      </form>

    <?php elseif ($request_row): ?>
      <?php
      $request_status = strtolower(trim((string)($request_row['request_status'] ?? 'pending')));
      $request_status = $request_status === '' ? 'pending' : $request_status;
      $status_label_map = [
        'pending' => 'Pending Approval',
        'confirmed' => 'Confirmed',
        'completed' => 'Completed',
        'cancelled' => 'Cancelled'
      ];
      $request_date_input = !empty($request_row['requested_at']) ? date('Y-m-d', strtotime((string)$request_row['requested_at'])) : date('Y-m-d');
      $request_created_text = !empty($request_row['requested_at']) ? date('F j, Y h:i A', strtotime((string)$request_row['requested_at'])) : '-';
      $request_date_text = !empty($request_row['requested_at']) ? date('F j, Y', strtotime((string)$request_row['requested_at'])) : '-';
      $seed_unit = (string)($request_row['seed_unit'] ?? '');
      $current_stock_text = number_format((float)($request_row['available_quantity'] ?? 0), 2) . ($seed_unit !== '' ? ' ' . $seed_unit : '');
      $quantity_text = number_format((float)($request_row['quantity_requested'] ?? 0), 2) . ($seed_unit !== '' ? ' ' . $seed_unit : '');
      $request_id_label = '#SEED' . str_pad((string)((int)$request_row['request_id']), 4, '0', STR_PAD_LEFT);
      $farmer_name = trim((string)($request_row['farmer_fullname'] ?? '')) !== '' ? (string)$request_row['farmer_fullname'] : 'Unknown Farmer';
      $seed_name = (string)($request_row['seed_name'] ?? 'Seed Request');
      $avatar_letter = strtoupper(substr($farmer_name, 0, 1));
      ?>

      <div class="sf-account-shell">
        <div class="admin-form">
          <section class="sf-summary-card">
            <div class="sf-summary-main">
              <div class="sf-summary-identity">
                <div class="sf-avatar"><?php echo htmlspecialchars($avatar_letter, ENT_QUOTES, 'UTF-8'); ?></div>
                <div>
                  <h2><?php echo htmlspecialchars($farmer_name, ENT_QUOTES, 'UTF-8'); ?></h2>
                  <p><?php echo htmlspecialchars($seed_name, ENT_QUOTES, 'UTF-8'); ?></p>
                </div>
              </div>

              <div class="sf-pill-row">
                <span class="sf-mode-chip view"><?php echo $is_edit_mode ? 'Editing' : 'Viewing'; ?></span>
              </div>
            </div>

            <div class="sf-summary-meta">
              <div><span>Request</span><strong><?php echo htmlspecialchars($request_id_label, ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div><span>Created</span><strong><?php echo htmlspecialchars($request_created_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div><span>Current Stock</span><strong><?php echo htmlspecialchars($current_stock_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div><span>Quantity</span><strong><?php echo htmlspecialchars($quantity_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
            </div>
          </section>

          <div class="sf-content-grid">
            <section class="sf-panel">
              <h3>Seed Request Information</h3>
              <div class="sf-field-grid">
                <div class="sf-field">
                  <label>Seed Type</label>
                  <span class="sf-field-value"><?php echo htmlspecialchars($seed_name, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="sf-field">
                  <label>Farmer</label>
                  <span class="sf-field-value"><?php echo htmlspecialchars($farmer_name, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="sf-field">
                  <label>Current Stock</label>
                  <span class="sf-field-value"><?php echo htmlspecialchars($current_stock_text, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="sf-field">
                  <label>Requested Quantity</label>
                  <span class="sf-field-value"><?php echo htmlspecialchars($quantity_text, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
                <div class="sf-field">
                  <label>Record Date</label>
                  <span class="sf-field-value"><?php echo htmlspecialchars($request_date_text, ENT_QUOTES, 'UTF-8'); ?></span>
                </div>
              </div>
            </section>

            <section class="sf-panel sf-update-panel">
              <h3>Update Seed Request</h3>

              <?php if (!$is_edit_mode): ?>
                <div class="sf-action-bar">
                  <a class="btn-primary" href="admin_dashboard.php?section=view-seed-record&record_type=request&request_id=<?php echo (int)$request_row['request_id']; ?>&mode=edit&from=<?php echo rawurlencode($from_section); ?>" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;">
                    <i class="fas fa-pen"></i>
                    Edit Request
                  </a>
                </div>

                <div class="sf-inline-view">
                  <div class="sf-field-grid sf-field-grid-single">
                    <div class="sf-field">
                      <label>Status</label>
                      <span class="sf-field-value"><?php echo htmlspecialchars($status_label_map[$request_status] ?? ucfirst($request_status), ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                    <div class="sf-field">
                      <label>Record Date</label>
                      <span class="sf-field-value"><?php echo htmlspecialchars($request_date_text, ENT_QUOTES, 'UTF-8'); ?></span>
                    </div>
                  </div>
                </div>
              <?php else: ?>
                <form method="post" class="sf-manage-form" action="admin_dashboard.php?section=view-seed-record&record_type=request&request_id=<?php echo (int)$request_row['request_id']; ?>&from=<?php echo rawurlencode($from_section); ?>">
                  <input type="hidden" name="action" value="update_seed_distribution">
                  <input type="hidden" name="record_type" value="request">
                  <input type="hidden" name="distribution_id" value="<?php echo (int)$request_row['request_id']; ?>">

                  <div class="sf-field">
                    <label for="seed-request-quantity">Quantity</label>
                    <input id="seed-request-quantity" class="sf-field-input" type="number" step="0.01" min="0.01" name="quantity_distributed" value="<?php echo htmlspecialchars(number_format((float)$request_row['quantity_requested'], 2, '.', '')); ?>">
                  </div>

                  <div class="sf-field">
                    <label for="seed-request-date">Record Date</label>
                    <input id="seed-request-date" class="sf-field-input" type="date" name="distribution_date" value="<?php echo htmlspecialchars($request_date_input); ?>">
                  </div>

                  <div class="sf-field">
                    <label for="seed-request-status">Status</label>
                    <select id="seed-request-status" name="status" class="sf-field-input">
                      <?php foreach ($status_label_map as $status_key => $status_label): ?>
                        <option value="<?php echo htmlspecialchars($status_key); ?>" <?php echo $status_key === $request_status ? 'selected' : ''; ?>><?php echo htmlspecialchars($status_label); ?></option>
                      <?php endforeach; ?>
                    </select>
                  </div>

                  <div class="sf-action-buttons">
                    <a class="btn-tertiary" href="admin_dashboard.php?section=view-seed-record&record_type=request&request_id=<?php echo (int)$request_row['request_id']; ?>&from=<?php echo rawurlencode($from_section); ?>" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;">Cancel</a>
                    <button type="submit" class="btn-primary">Save Changes</button>
                  </div>
                </form>
              <?php endif; ?>
            </section>
          </div>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>
