<?php
$rental_rows = [];
$rental_table_exists = false;
$rental_table_check = $conn->query("SHOW TABLES LIKE 'machinery_rentals'");
if ($rental_table_check && $rental_table_check->num_rows > 0) {
  $rental_table_exists = true;
  $rental_result = $conn->query("
    SELECT rental_id, rental_code, equipment_name, owner_name, renter_name,
           start_date, end_date, total_cost, rental_status, payment_status, payment_marked_at
    FROM machinery_rentals
    ORDER BY start_date DESC, rental_id DESC
  ");
  if ($rental_result) {
    while ($rental_row = $rental_result->fetch_assoc()) {
      $rental_rows[] = $rental_row;
    }
  }
}
?>

<style>
  .rental-action-link {
    text-decoration: none;
  }

  .rental-action-link:hover,
  .rental-action-link:focus {
    text-decoration: none;
  }

  /* Keep the Status column narrow so Action never gets pushed off-screen. */
  #rentalTable th:nth-child(7),
  #rentalTable td:nth-child(7) {
    width: 100px;
    max-width: 100px;
  }

  #rentalTable td:nth-child(7) .status {
    white-space: normal;
    min-width: 0;
    width: 100%;
  }
</style>

<!-- Rental Monitor Section -->
<section id="section-rental-monitor" class="admin-section">
  <div class="section-header">
    <h1>Machinery Rental Monitor</h1>
    <div style="display:flex;gap:0.5rem;">
      <a class="btn-primary" href="admin_dashboard.php?section=add-machinery-listing" data-tooltip="Add machinery" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;"><i class="fas fa-plus"></i></a>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="rentalSearch">Search</label>
      <input type="text" class="search-input" id="rentalSearch" placeholder="Search rental, machine, owner, or renter..." oninput="filterRentalTable()">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="rentalStatus">Status</label>
      <select class="filter-select" id="rentalStatus" onchange="filterRentalTable()">
        <option value="">All Status</option>
        <option value="available">Available</option>
        <option value="pending">Pending Approval</option>
        <option value="approved">Approved</option>
        <option value="in-rental">In Use</option>
        <option value="returned">Returned</option>
        <option value="cancelled">Cancelled</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="rentalPayment">Payment</label>
      <select class="filter-select" id="rentalPayment" onchange="filterRentalTable()">
        <option value="">All Payment</option>
        <option value="paid">Paid</option>
        <option value="unpaid">Unpaid</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="rentalPriceRange">Cost Range</label>
      <select class="filter-select" id="rentalPriceRange" onchange="filterRentalTable()">
        <option value="">All Costs</option>
        <option value="0-1999">PHP 0 - 1,999</option>
        <option value="2000-3999">PHP 2,000 - 3,999</option>
        <option value="4000-6999">PHP 4,000 - 6,999</option>
        <option value="7000-9999">PHP 7,000 - 9,999</option>
        <option value="10000+">PHP 10,000+</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="rentalGroupBy">Group By</label>
      <select class="filter-select" id="rentalGroupBy" onchange="sfSetGroupBy('rentalTable', this); filterRentalTable()">
        <option value="">No Grouping</option>
        <option value="6">Status</option>
        <option value="7">Payment</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="rentalTable">
      <thead>
        <tr>
          <th>Rental ID</th>
          <th>Equipment</th>
          <th>Renter</th>
          <th>Start Date</th>
          <th>End Date</th>
          <th>Cost</th>
          <th>Status</th>
          <th>Payment</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$rental_table_exists): ?>
        <tr>
          <td colspan="9" style="text-align:center;color:#6b776b;">Rental table not found. Reload the page to initialize transaction tables.</td>
        </tr>
        <?php elseif (empty($rental_rows)): ?>
        <tr>
          <td colspan="9" style="text-align:center;color:#6b776b;">No machinery rentals recorded yet.</td>
        </tr>
        <?php else: ?>
        <?php foreach ($rental_rows as $rental): ?>
        <?php
          $display_rental_id = '#REN' . str_pad((string)((int)($rental['rental_id'] ?? 0)), 3, '0', STR_PAD_LEFT);
          $owner_name_raw = (string)($rental['owner_name'] ?? '-');
          $status_key = (string)($rental['rental_status'] ?? 'pending');
          $renter_name_raw = trim((string)($rental['renter_name'] ?? ''));
          $is_transaction_row = $renter_name_raw !== '';
          $display_status_key = (!$is_transaction_row && $status_key === 'pending') ? 'available' : $status_key;
          $status_label_map = [
            'available' => 'Available',
            'pending' => 'Pending Approval',
            'approved' => 'Approved',
            'in-rental' => 'In Use',
            'returned' => 'Returned',
            'cancelled' => 'Cancelled'
          ];
          $status_label = $status_label_map[$display_status_key] ?? ucfirst($display_status_key);
          $payment_is_paid = ((string)($rental['payment_status'] ?? 'unpaid') === 'paid');
          $payment_class = $payment_is_paid ? 'approved' : 'pending';
          $payment_label = $payment_is_paid ? 'Paid' : 'Unpaid';
          $payment_date = !empty($rental['payment_marked_at']) ? date('Y-m-d', strtotime($rental['payment_marked_at'])) : '';
          $start_date_raw = (string)($rental['start_date'] ?? '');
          $end_date_raw = (string)($rental['end_date'] ?? '');

          $action_href = $is_transaction_row
            ? 'admin_dashboard.php?section=view-machinery-rental&rental_id=' . (int)$rental['rental_id'] . '&from=rental-monitor'
            : 'admin_dashboard.php?section=add-machinery-listing&edit_rental_id=' . (int)$rental['rental_id'];
          $action_tooltip = $is_transaction_row ? 'View transaction' : 'Edit listing';
          $action_class = $is_transaction_row ? 'btn-view' : 'btn-edit';
          $action_icon = $is_transaction_row ? 'fa-eye' : 'fa-pen';
        ?>
        <tr data-status="<?php echo htmlspecialchars($display_status_key); ?>" data-payment="<?php echo htmlspecialchars($payment_is_paid ? 'paid' : 'unpaid', ENT_QUOTES, 'UTF-8'); ?>" data-price="<?php echo htmlspecialchars((string)((float)($rental['total_cost'] ?? 0)), ENT_QUOTES, 'UTF-8'); ?>" data-owner="<?php echo htmlspecialchars($owner_name_raw, ENT_QUOTES, 'UTF-8'); ?>">
          <td><?php echo htmlspecialchars($display_rental_id); ?></td>
          <td><strong><?php echo htmlspecialchars((string)($rental['equipment_name'] ?? '-')); ?></strong></td>
          <td><?php echo htmlspecialchars($renter_name_raw !== '' ? $renter_name_raw : '-'); ?></td>
          <td><?php echo $is_transaction_row ? htmlspecialchars($start_date_raw) : '-'; ?></td>
          <td><?php echo $is_transaction_row ? htmlspecialchars($end_date_raw) : '-'; ?></td>
          <td>₱<?php echo number_format((float)($rental['total_cost'] ?? 0), 2); ?></td>
          <td><span class="status <?php echo htmlspecialchars($display_status_key); ?>"><?php echo htmlspecialchars($status_label); ?></span></td>
          <td>
            <?php if ($is_transaction_row): ?>
            <span class="status <?php echo $payment_class; ?>"><?php echo $payment_label; ?></span>
            <?php if ($payment_is_paid && $payment_date !== ''): ?>
            <small style="display:block;color:#6b776b;margin-top:4px;">on <?php echo htmlspecialchars($payment_date); ?></small>
            <?php endif; ?>
            <?php else: ?>-<?php endif; ?>
          </td>
          <td style="white-space:nowrap;">
            <a class="btn-small rental-action-link <?php echo htmlspecialchars($action_class, ENT_QUOTES, 'UTF-8'); ?>" data-tooltip="<?php echo htmlspecialchars($action_tooltip, ENT_QUOTES, 'UTF-8'); ?>" href="<?php echo htmlspecialchars($action_href, ENT_QUOTES, 'UTF-8'); ?>">
              <i class="fas <?php echo htmlspecialchars($action_icon, ENT_QUOTES, 'UTF-8'); ?>"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

