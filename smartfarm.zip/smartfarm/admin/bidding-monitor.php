<!-- Bidding Monitor Section -->
<?php
$bidding_rows = [];
$inventory_crops = [];
$bidding_table_exists = false;

// Handle POST actions for publishing crops to bidding
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $action = $_POST['action'] ?? '';
  
  if ($action === 'create_crop_bidding_lot') {
    // Publish a crop from inventory to bidding
    $source_crop_id = (int)($_POST['source_crop_id'] ?? 0);
    $bid_quantity = (float)($_POST['bid_quantity'] ?? 0);
    $starting_price = (float)($_POST['starting_price'] ?? 0);
    $bidding_end_date = $_POST['bidding_end_date'] ?? '';
    
    $errors = [];
    
    if ($source_crop_id <= 0) {
      $errors[] = 'Invalid crop selected.';
    }
    if ($bid_quantity <= 0) {
      $errors[] = 'Bidding quantity must be greater than zero.';
    }
    if ($starting_price <= 0) {
      $errors[] = 'Starting price must be greater than zero.';
    }
    if (empty($bidding_end_date)) {
      $errors[] = 'Bidding end date is required.';
    }
    
    if (empty($errors)) {
      try {
        $conn->begin_transaction();
        
        // Get the source crop to verify availability
        $verify_stmt = $conn->prepare(
          "SELECT crop_id, crop_quantity, crop_unit, crop_name, farmer_id
           FROM crops
           WHERE crop_id = ? AND starting_price <= 0
           LIMIT 1"
        );
        
        if ($verify_stmt) {
          $verify_stmt->bind_param('i', $source_crop_id);
          $verify_stmt->execute();
          $verify_result = $verify_stmt->get_result();
          $source_crop = $verify_result ? $verify_result->fetch_assoc() : null;
          $verify_stmt->close();
          
          if (!$source_crop) {
            throw new Exception('Crop not found or already published.');
          }
          
          $available_qty = (float)$source_crop['crop_quantity'];
          if ($bid_quantity > $available_qty) {
            throw new Exception('Bidding quantity exceeds available inventory.');
          }
          
          // Update the crop to mark it as published
          $publish_stmt = $conn->prepare(
            "UPDATE crops 
             SET starting_price = ?, 
                 crop_status = 'available', 
                 bidding_end_date = ?,
                 crop_quantity = crop_quantity - ?
             WHERE crop_id = ?"
          );
          
          if (!$publish_stmt) {
            throw new Exception('Failed to prepare publish statement.');
          }
          
          $publish_stmt->bind_param('dsdi', $starting_price, $bidding_end_date, $bid_quantity, $source_crop_id);
          
          if (!$publish_stmt->execute()) {
            throw new Exception('Failed to publish crop: ' . $publish_stmt->error);
          }
          
          $publish_stmt->close();
          
          $conn->commit();
          $_SESSION['success'] = 'Crop published to bidding successfully. Bidding quantity: ' . number_format($bid_quantity, 2) . ' ' . htmlspecialchars($source_crop['crop_unit']);
        } else {
          throw new Exception('Database error.');
        }
      } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = 'Error publishing crop: ' . $e->getMessage();
      }
    } else {
      $_SESSION['error'] = implode(' ', $errors);
    }
    
    header('Location: admin_dashboard.php?section=bidding-monitor');
    exit;
  }
  elseif ($action === 'add_manual_bid_product') {
    // Add a manual crop entry (not from inventory)
    $crop_name = $_POST['crop_name'] ?? '';
    $farmer_name = $_POST['farmer_name'] ?? '';
    $starting_price = (float)($_POST['starting_price'] ?? 0);
    $bid_quantity = (float)($_POST['bid_quantity'] ?? 0);
    $crop_unit = $_POST['crop_unit'] ?? 'kg';
    $bidding_end_date = $_POST['bidding_end_date'] ?? '';
    
    $errors = [];
    
    if (empty($crop_name)) {
      $errors[] = 'Crop name is required.';
    }
    if ($starting_price <= 0) {
      $errors[] = 'Starting price must be greater than zero.';
    }
    if ($bid_quantity <= 0) {
      $errors[] = 'Quantity must be greater than zero.';
    }
    if (empty($bidding_end_date)) {
      $errors[] = 'Bidding end date is required.';
    }
    
    if (empty($errors)) {
      try {
        $conn->begin_transaction();
        
        // Find or create farmer record for manual entry
        $farmer_id = 0;
        if (!empty($farmer_name)) {
          $farmer_check = $conn->prepare(
            "SELECT farmer_id FROM farmers WHERE farmer_fullname = ? LIMIT 1"
          );
          if ($farmer_check) {
            $farmer_check->bind_param('s', $farmer_name);
            $farmer_check->execute();
            $farmer_result = $farmer_check->get_result();
            $farmer_row = $farmer_result ? $farmer_result->fetch_assoc() : null;
            $farmer_check->close();
            $farmer_id = $farmer_row ? (int)$farmer_row['farmer_id'] : 0;
          }
        }
        
        // Insert new crop entry
        $insert_stmt = $conn->prepare(
          "INSERT INTO crops (farmer_id, crop_name, crop_quantity, crop_unit, starting_price, crop_status, bidding_end_date)
           VALUES (?, ?, ?, ?, ?, 'available', ?)"
        );
        
        if (!$insert_stmt) {
          throw new Exception('Failed to prepare insert statement.');
        }
        
        $insert_stmt->bind_param('isdsds', $farmer_id, $crop_name, $bid_quantity, $crop_unit, $starting_price, $bidding_end_date);
        
        if (!$insert_stmt->execute()) {
          throw new Exception('Failed to add crop: ' . $insert_stmt->error);
        }
        
        $insert_stmt->close();
        
        $conn->commit();
        $_SESSION['success'] = 'Manual crop added to bidding successfully.';
      } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error'] = 'Error adding crop: ' . $e->getMessage();
      }
    } else {
      $_SESSION['error'] = implode(' ', $errors);
    }
    
    header('Location: admin_dashboard.php?section=bidding-monitor');
    exit;
  }
}

$table_check = $conn->query("SHOW TABLES LIKE 'crops'");
if ($table_check && $table_check->num_rows > 0) {
  $bidding_table_exists = true;
  finalizeExpiredBiddingLots($conn);
  $bidding_query = "
    SELECT
      c.crop_id,
      c.crop_name,
      c.crop_quantity,
      c.crop_unit,
      c.starting_price,
      c.crop_status,
      c.payment_status,
      c.payment_marked_at,
      c.bidding_end_date,
      c.created_at,
      b.bid_id,
      b.bid_amount,
      b.bid_status,
      COALESCE(f.farmer_fullname, 'Admin Entry') AS farmer_name,
      COALESCE(cl.client_fullname, 'No bids yet') AS client_name,
      COALESCE(bs.highest_bid, c.starting_price) AS highest_bid,
      COALESCE(bs.bid_count, 0) AS bid_count
    FROM crops c
    LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
    LEFT JOIN bids b ON b.crop_id = c.crop_id
    LEFT JOIN clients cl ON cl.client_id = b.client_id
    LEFT JOIN (
      SELECT
        crop_id,
        MAX(bid_amount) AS highest_bid,
        COUNT(*) AS bid_count
      FROM bids
      GROUP BY crop_id
    ) bs ON bs.crop_id = c.crop_id
    WHERE c.starting_price > 0
    ORDER BY c.created_at DESC, c.crop_id DESC, b.bid_amount DESC, b.created_at ASC
  ";

  $bidding_result = $conn->query($bidding_query);
  if ($bidding_result) {
    while ($row = $bidding_result->fetch_assoc()) {
      $bidding_rows[] = $row;
    }
  }

  // Load inventory crops (available stock, not yet on bidding) for the "From Manage Crops" modal
  $inv_result = $conn->query("
    SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit,
           COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
    FROM crops c
    LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
    WHERE c.starting_price <= 0 AND c.crop_quantity > 0
    ORDER BY c.crop_name ASC
  ");
  if ($inv_result) {
    while ($inv_row = $inv_result->fetch_assoc()) {
      $inventory_crops[] = $inv_row;
    }
  }
}
?>
<section id="section-bidding-monitor" class="admin-section">
  <div class="section-header">
    <h1>Bidding Transactions Monitor</h1>
    <div style="display:flex;gap:0.5rem;">
      <a class="btn-primary" href="admin_dashboard.php?section=add-bidding-transaction" data-tooltip="Add bidding crop" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;"><i class="fas fa-plus"></i></a>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="biddingSearch">Search</label>
      <input type="text" class="search-input" id="biddingSearch" placeholder="Search bid, crop, or client..." oninput="filterBiddingTable()">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="biddingStatus">Status</label>
      <select class="filter-select" id="biddingStatus" onchange="filterBiddingTable()">
        <option value="">All Status</option>
        <option value="ongoing">Ongoing</option>
        <option value="sold">Sold</option>
        <option value="ended">Ended</option>
        <option value="claimed">Claimed</option>
        <option value="returned">Returned</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="biddingPayment">Payment</label>
      <select class="filter-select" id="biddingPayment" onchange="filterBiddingTable()">
        <option value="">All Payment</option>
        <option value="paid">Paid</option>
        <option value="unpaid">Unpaid</option>
        <option value="none">No Payment Required</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="biddingPriceRange">Price Range</label>
      <select class="filter-select" id="biddingPriceRange" onchange="filterBiddingTable()">
        <option value="">All Prices</option>
        <option value="0-999">PHP 0 - 999</option>
        <option value="1000-1999">PHP 1,000 - 1,999</option>
        <option value="2000-4999">PHP 2,000 - 4,999</option>
        <option value="5000-9999">PHP 5,000 - 9,999</option>
        <option value="10000+">PHP 10,000+</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="biddingGroupBy">Group By</label>
      <select class="filter-select" id="biddingGroupBy" onchange="sfSetGroupBy('biddingTable', this); filterBiddingTable()">
        <option value="">No Grouping</option>
        <option value="5">Status</option>
        <option value="7">Payment</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="biddingTable">
      <thead>
        <tr>
          <th>Bid ID</th>
          <th>Crop</th>
          <th>Client</th>
          <th>User Bid</th>
          <th>Quantity</th>
          <th>Status</th>
          <th>End Date</th>
          <th>Payment</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$bidding_table_exists): ?>
        <tr>
          <td colspan="9" style="text-align:center;color:#6b776b;">Crops table not found. Run bidding tables setup first.</td>
        </tr>
        <?php elseif (empty($bidding_rows)): ?>
        <tr>
          <td colspan="9" style="text-align:center;color:#6b776b;">No bidding lots yet. Create one from Manage Crops.</td>
        </tr>
        <?php else: ?>
        <?php foreach ($bidding_rows as $row): ?>
        <?php
          $transaction_ref = (int)($row['bid_id'] ?? 0);
          $crop_ref = (int)($row['crop_id'] ?? 0);
          $bid_id_label = $transaction_ref > 0
            ? '#BID' . str_pad((string)$transaction_ref, 4, '0', STR_PAD_LEFT)
            : '#BIDC' . str_pad((string)$crop_ref, 4, '0', STR_PAD_LEFT);
          $end_ts = strtotime($row['bidding_end_date']);
          $is_open = ($row['crop_status'] === 'available' && $end_ts && $end_ts > time());

          $is_bid_winner = ((string)($row['bid_status'] ?? '') === 'won');
          $has_bid = ((int)($row['bid_id'] ?? 0) > 0);

          if ((string)$row['crop_status'] === 'claimed' && ($is_bid_winner || !$has_bid)) {
            $stage_text = 'Claimed';
            $stage_class = 'claimed';
          } elseif ((string)$row['crop_status'] === 'sold' && $has_bid && !$is_bid_winner) {
            $stage_text = 'Ended';
            $stage_class = 'ended';
          } elseif ((string)$row['crop_status'] === 'returned') {
            $stage_text = 'Returned';
            $stage_class = 'returned';
          } elseif ($is_open) {
            $stage_text = 'Ongoing';
            $stage_class = 'ongoing';
          } elseif ($row['crop_status'] === 'sold') {
            $stage_text = 'Sold';
            $stage_class = 'sold';
          } elseif ($row['crop_status'] === 'expired') {
            $stage_text = 'Ended';
            $stage_class = 'ended';
          } else {
            $stage_text = 'Ended';
            $stage_class = 'ended';
          }

          $highest_bid = $row['highest_bid'] !== null ? (float)$row['highest_bid'] : (float)$row['starting_price'];
          $client_label = $has_bid ? (string)$row['client_name'] : '-';
          $user_bid_label = $has_bid ? 'PHP ' . number_format((float)($row['bid_amount'] ?? 0), 2) : '-';
          $is_expired_no_bid = ((string)$row['crop_status'] === 'expired' && !$has_bid);
          $is_transaction_row = $has_bid;
          $action_href = $is_transaction_row
            ? 'admin_dashboard.php?section=view-bidding-transaction&crop_id=' . (int)$row['crop_id'] . '&from=bidding-monitor'
            : ($is_expired_no_bid
              ? 'admin_dashboard.php?section=add-bidding-transaction&reopen_crop_id=' . (int)$row['crop_id']
              : 'admin_dashboard.php?section=add-bidding-transaction&edit_crop_id=' . (int)$row['crop_id']);
          $action_tooltip = $is_transaction_row
            ? 'View transaction'
            : ($is_expired_no_bid ? 'Reopen bidding' : 'Edit bidding lot');
          $action_class = $is_transaction_row ? 'btn-view' : 'btn-edit';
          $action_icon = $is_transaction_row
            ? 'fa-eye'
            : ($is_expired_no_bid ? 'fa-refresh' : 'fa-pen');
          
          // Payment status should ONLY show for winning bid when crop is Sold or Claimed
          $payment_is_paid = false;
          $payment_label = '-';
          $payment_badge_class = 'neutral';
          $payment_date_label = '';
          
          $crop_is_finalized = ((string)$row['crop_status'] === 'sold') || ((string)$row['crop_status'] === 'claimed');
          
          if ($is_bid_winner && $crop_is_finalized) {
            // Only show payment status for winning bid when crop is finalized
            $payment_is_paid = ((string)($row['payment_status'] ?? 'unpaid') === 'paid');
            $payment_badge_class = $payment_is_paid ? 'approved' : 'pending';
            $payment_label = $payment_is_paid ? 'Paid' : 'Unpaid';
            $payment_date_label = !empty($row['payment_marked_at']) ? date('Y-m-d', strtotime($row['payment_marked_at'])) : '';
          }
          $payment_filter_key = $payment_label === 'Paid'
            ? 'paid'
            : ($payment_label === 'Unpaid' ? 'unpaid' : 'none');
        ?>
        <tr data-stage="<?php echo htmlspecialchars($stage_class, ENT_QUOTES, 'UTF-8'); ?>" data-payment="<?php echo htmlspecialchars($payment_filter_key, ENT_QUOTES, 'UTF-8'); ?>" data-price="<?php echo htmlspecialchars((string)((float)($row['bid_amount'] ?? 0)), ENT_QUOTES, 'UTF-8'); ?>">
          <td><?php echo htmlspecialchars($bid_id_label); ?></td>
          <td><strong><?php echo htmlspecialchars($row['crop_name']); ?></strong></td>
          <td><?php echo htmlspecialchars($client_label); ?></td>
          <td><?php echo htmlspecialchars($user_bid_label); ?></td>
          <td><?php echo number_format((float)$row['crop_quantity'], 2); ?> <?php echo htmlspecialchars($row['crop_unit']); ?></td>
          <td><span class="status <?php echo $stage_class; ?>"><?php echo $stage_text; ?></span></td>
          <td><?php echo date('Y-m-d', $end_ts ?: time()); ?></td>
          <td>
            <span class="status <?php echo $payment_badge_class; ?>"><?php echo $payment_label; ?></span>
            <?php if ($payment_is_paid && $payment_date_label !== ''): ?>
            <small style="display:block;color:#6b776b;margin-top:4px;">on <?php echo htmlspecialchars($payment_date_label); ?></small>
            <?php endif; ?>
          </td>
          <td style="white-space:nowrap;">
            <a class="btn-small <?php echo htmlspecialchars($action_class, ENT_QUOTES, 'UTF-8'); ?>" type="button" data-tooltip="<?php echo htmlspecialchars($action_tooltip, ENT_QUOTES, 'UTF-8'); ?>" style="text-decoration:none;" href="<?php echo htmlspecialchars($action_href, ENT_QUOTES, 'UTF-8'); ?>">
              <i class="fas <?php echo htmlspecialchars($action_icon, ENT_QUOTES, 'UTF-8'); ?>"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>


