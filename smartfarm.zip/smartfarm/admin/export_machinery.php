<?php
// admin/export_machinery.php
// Generates a CSV for all machinery
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="machinery.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'machinery_id', 'name', 'type', 'condition', 'rate', 'status', 'owner', 'created_at', 'updated_at', 'image', 'image_name', 'image_mime_type'
]);

$q = $conn->query("SELECT machinery_id, name, type, `condition`, rate, status, owner, created_at, updated_at, image, image_name, image_mime_type FROM machinery");
if ($q) {
    while ($row = $q->fetch_assoc()) {
        fputcsv($out, $row);
    }
}
fclose($out);
exit;
