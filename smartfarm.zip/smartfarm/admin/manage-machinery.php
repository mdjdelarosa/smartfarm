<!-- Manage Machinery Section -->
<section id="section-manage-machinery" class="admin-section">
  <div class="section-header">
    <h1>Manage Machinery</h1>
    <button class="btn-primary" onclick="openAddMachineryModal()" data-tooltip="Add Equipment"><i class="fas fa-plus"></i></button>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="machinerySearch">Search</label>
      <input type="text" placeholder="Search by equipment name..." class="search-input" id="machinerySearch" oninput="filterTable('machinery')">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="machineryStatus">Status</label>
      <select class="filter-select" id="machineryStatus" onchange="filterTable('machinery')">
        <option value="">All Status</option>
        <option value="available">Available</option>
        <option value="in-rental">In Use</option>
        <option value="maintenance">Maintenance</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="machineryGroupBy">Group By</label>
      <select class="filter-select" id="machineryGroupBy" onchange="sfSetGroupBy('machineryTable', this); filterTable('machinery')">
        <option value="">No Grouping</option>
        <option value="6">Status</option>
        <option value="3">Type</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="machineryTable">
      <thead>
        <tr>
          <th>Equipment ID</th>
          <th>Equipment Name</th>
          <th>Owner</th>
          <th>Type</th>
          <th>Condition</th>
          <th>Daily Rate</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>#EQP001</td>
          <td>Tractor (John Deere 2030)</td>
          <td>Juan Santos</td>
          <td>Tractor</td>
          <td>Excellent</td>
          <td>₱4,000</td>
          <td><span class="status available">Available</span></td>
          <td>
            <button class="btn-small btn-edit" data-tooltip="Edit"><i class="fas fa-edit"></i></button>
            <button class="btn-small btn-delete" data-tooltip="Delete"><i class="fas fa-trash"></i></button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</section>
