<?php
$yield_forecast_rows = (isset($conn) && $conn instanceof mysqli)
  ? computeYieldForecastRows($conn)
  : [];
?>

<section id="section-forecast-yield" class="admin-section">
  <div class="section-header" style="display:flex;align-items:center;justify-content:space-between;gap:1rem;">
    <div style="display:flex;align-items:center;gap:0.75rem;">
      <button type="button" class="btn-tertiary" onclick="showSection('forecasting')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>All Crop Yield Forecast</h1>
      </div>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="yieldForecastSearch">Search</label>
      <input type="text" id="yieldForecastSearch" placeholder="Search crop..." class="search-input" oninput="filterTable('yieldForecast')">
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="yieldForecastTable">
      <thead>
        <tr>
          <th>Crop</th>
          <th>Current Quantity</th>
          <th>Expected Quantity</th>
          <th>Growth</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($yield_forecast_rows)): ?>
        <tr>
          <td colspan="4" style="text-align:center;color:#6b776b;">No yield forecast rows available.</td>
        </tr>
        <?php else: ?>
        <?php foreach ($yield_forecast_rows as $yield_row): ?>
        <tr>
          <td><?php echo htmlspecialchars((string)$yield_row['crop_name']); ?></td>
          <td><?php echo number_format((float)$yield_row['current_qty'], 2); ?> <?php echo htmlspecialchars((string)$yield_row['unit']); ?></td>
          <td><?php echo number_format((float)$yield_row['expected_qty'], 2); ?> <?php echo htmlspecialchars((string)$yield_row['unit']); ?></td>
          <td><span class="market-badge <?php echo htmlspecialchars((string)$yield_row['badge_class']); ?>"><?php echo ((float)$yield_row['growth_pct'] >= 0 ? '+' : '') . number_format((float)$yield_row['growth_pct'], 1); ?>%</span></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
