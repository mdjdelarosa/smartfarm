<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../admin_dashboard.php');
    exit;
}

$user_id = (int)($_POST['user_id'] ?? 0);
$role = sanitizeInput($_POST['role'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$from = sanitizeInput($_POST['from'] ?? 'manage-admins');
$allowed_from_sections = ['manage-admins', 'verify-farmers', 'verify-clients', 'view-admin', 'dashboard'];
if (!in_array($from, $allowed_from_sections, true)) {
    $from = 'manage-admins';
}

$view_account_redirect = '../admin_dashboard.php?section=view-account&user_id=' . $user_id . '&from=' . rawurlencode($from);

if ($user_id <= 0 || !in_array($role, ['admin','farmer','client'])) {
    $_SESSION['error'] = 'Invalid request';
    header('Location: ../admin_dashboard.php');
    exit;
}

try {
    $conn->begin_transaction();

    // check email duplicate (exclude current user)
    $chk = $conn->prepare('SELECT user_id FROM users WHERE email = ? AND user_id <> ? LIMIT 1 FOR UPDATE');
    $chk->bind_param('si', $email, $user_id);
    $chk->execute();
    $chk->store_result();
    if ($chk->num_rows > 0) {
        $chk->close();
        throw new Exception('Email already used by another account');
    }
    $chk->close();

    // update users.email
    $up = $conn->prepare('UPDATE users SET email = ? WHERE user_id = ?');
    $up->bind_param('si', $email, $user_id);
    $up->execute();
    $up->close();

    if ($role === 'admin') {
        $fullname = sanitizeInput($_POST['fullname'] ?? '');
        $stmt = $conn->prepare('UPDATE admins SET fullname = ? WHERE user_id = ?');
        $stmt->bind_param('si', $fullname, $user_id);
        $stmt->execute();
        $stmt->close();
    } elseif ($role === 'farmer') {
        $farmer_fullname = sanitizeInput($_POST['farmer_fullname'] ?? '');
        $farmer_contact = sanitizeInput($_POST['farmer_contact_number'] ?? '');
        $farmer_address = sanitizeInput($_POST['farmer_address'] ?? '');
        $farmer_farm_name = sanitizeInput($_POST['farmer_farm_name'] ?? '');
        $farm_address = sanitizeInput($_POST['farm_address'] ?? '');

        $stmt = $conn->prepare('UPDATE farmers SET farmer_fullname = ?, farmer_contact_number = ?, farmer_address = ?, farmer_farm_name = ?, farm_address = ? WHERE user_id = ?');
        $stmt->bind_param('sssssi', $farmer_fullname, $farmer_contact, $farmer_address, $farmer_farm_name, $farm_address, $user_id);
        $stmt->execute();
        $stmt->close();

    } elseif ($role === 'client') {
        $client_fullname = sanitizeInput($_POST['client_fullname'] ?? '');
        $client_contact = sanitizeInput($_POST['client_contact_number'] ?? '');
        $client_address = sanitizeInput($_POST['client_address'] ?? '');

        $stmt = $conn->prepare('UPDATE clients SET client_fullname = ?, client_contact_number = ?, client_address = ? WHERE user_id = ?');
        $stmt->bind_param('sssi', $client_fullname, $client_contact, $client_address, $user_id);
        $stmt->execute();
        $stmt->close();
    }

    $conn->commit();
    $_SESSION['success'] = 'Account updated successfully';
    header('Location: ' . $view_account_redirect);
    exit;

} catch (Exception $e) {
    $conn->rollback();
    $_SESSION['error'] = 'Update failed: ' . $e->getMessage();
    header('Location: ' . $view_account_redirect);
    exit;
}

?>
