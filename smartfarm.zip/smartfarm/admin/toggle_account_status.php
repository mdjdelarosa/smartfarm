<?php
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: manage-accounts.php');
    exit;
}

$user_id = intval($_POST['user_id'] ?? 0);
$action = $_POST['action'] ?? '';

if ($user_id <= 0 || !in_array($action, ['activate', 'deactivate'])) {
    header('Location: manage-accounts.php');
    exit;
}

$newValue = ($action === 'activate') ? 1 : 0;

$stmt = $conn->prepare('UPDATE users SET is_active = ? WHERE user_id = ?');
if ($stmt) {
    $stmt->bind_param('ii', $newValue, $user_id);
    $stmt->execute();
    $stmt->close();
}

header('Location: manage-accounts.php');
exit;

?>
