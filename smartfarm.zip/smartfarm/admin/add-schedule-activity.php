<?php
$selected_date_input = trim((string)($_GET['selected_date'] ?? ''));
$selected_date_stamp = strtotime($selected_date_input);
$selected_date = $selected_date_stamp ? date('Y-m-d', $selected_date_stamp) : date('Y-m-d');
$today_date = date('Y-m-d');
?>

<style>
#section-add-schedule-activity .sf-add-header {
  margin-bottom: 16px;
}

#section-add-schedule-activity .sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

#section-add-schedule-activity .schedule-modal-card {
  width: min(980px, 100%);
  margin: 0;
}

@keyframes spin { 100% { transform: rotate(360deg); } }
</style>

<section id="section-add-schedule-activity" class="admin-section active">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('schedule')" data-tooltip="Back to schedule">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1>Add Activity</h1>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3><i class="fas fa-calendar-plus" style="color:#22c55e;margin-right:0.4rem;"></i>Schedule and Notify</h3>
      </div>
    </div>

    <form class="schedule-form" id="scheduleFormPage" action="admin_dashboard.php?section=add-schedule-activity" method="post">
      <input type="hidden" name="action" value="publish_schedule_activity">

      <div class="form-grid">
        <label class="form-field">
          <span>Activity Title</span>
          <input type="text" name="activityTitle" required>
        </label>
        <label class="form-field" id="categoryField" style="display:flex;flex-direction:column;gap:0.3rem;">
          <span>Category</span>
          <div style="display:flex;gap:0.5rem;align-items:center;">
            <select name="activityCategory" id="activityCategorySelect" style="flex:1;min-width:0;">
              <option value="Distribution">Distribution</option>
              <option value="Training">Training</option>
              <option value="Assembly">Assembly</option>
              <option value="Maintenance">Maintenance</option>
              <option value="Briefing">Briefing</option>
              <option value="__other__">Other (custom)...</option>
            </select>
            <input type="text" name="customCategory" id="customCategoryInput" placeholder="Enter custom category" style="display:none;flex:1;min-width:0;" />
          </div>
        </label>
        <label class="form-field">
          <span>Date</span>
          <input type="date" name="activityDate" min="<?php echo htmlspecialchars($today_date, ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars($selected_date, ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>
        <label class="form-field">
          <span>Time</span>
          <input type="time" name="activityTime" id="activityTimeInput" value="09:00" step="60" required>
        </label>
        <label class="form-field">
          <span>Location</span>
          <input type="text" name="activityLocation" required>
          <div class="field-hint" style="font-size:0.87em;color:#8ca08c;margin-top:0.18rem;padding-left:2px;letter-spacing:0.01em;">&#9432; <span style="font-style:italic;">e.g. Street, Barangay, City, Province, ZIP code</span></div>
        </label>
        <label class="form-field">
          <span>Coordinator</span>
          <input type="text" name="activityCoordinator" required>
        </label>
      </div>


      <div class="form-field">
        <span>Message</span>
        <textarea rows="4" name="activityMessage" placeholder="Enter the activity details to notify participants."></textarea>
      </div>

      <div class="form-field" style="margin-bottom:0.7rem;">
        <span style="font-weight:600;">Target Audience</span>
        <div class="choice-group">
          <label><input type="checkbox" name="audience[]" value="farmer" checked> Farmers</label>
          <label><input type="checkbox" name="audience[]" value="client" checked> Clients</label>
        </div>
      </div>
      <hr style="border:none;border-top:1px solid #e0e0e0;margin:1.2rem 0 0.7rem 0;">
      <p class="schedule-helper">Publishing sends a notification to selected members.</p>

      <div class="form-actions form-actions-inline">
        <button type="button" class="btn-secondary" onclick="showSection('schedule')">Cancel</button>
        <button type="submit" class="btn-primary">Publish & Notify</button>
      </div>
    </form>
  </div>
</section>

<!-- Loading Spinner Overlay for Form -->
<div id="scheduleFormLoadingOverlay" style="position:fixed;z-index:9999;top:0;left:0;width:100vw;height:100vh;background:rgba(30,40,40,0.72);display:none;align-items:center;justify-content:center;transition:opacity 0.3s;">
  <div style="display:flex;flex-direction:column;align-items:center;gap:14px;">
    <div class="spinner" style="width:54px;height:54px;border:7px solid #b6e2c7;border-top:7px solid #22c55e;border-radius:50%;animation:spin 1s linear infinite;"></div>
    <span style="color:#e6f9ed;font-size:1.18em;font-weight:600;">Publishing activity...</span>
  </div>
</div>

<script>
  // Custom category logic
  document.addEventListener('DOMContentLoaded', function() {
    const select = document.getElementById('activityCategorySelect');
    const customInput = document.getElementById('customCategoryInput');
    const form = document.getElementById('scheduleFormPage');
    if (!select || !customInput || !form) return;
    select.addEventListener('change', function() {
      if (select.value === '__other__') {
        customInput.style.display = '';
        customInput.required = true;
      } else {
        customInput.style.display = 'none';
        customInput.required = false;
      }
    });
    form.addEventListener('submit', function(e) {
      if (select.value === '__other__' && customInput.value.trim() !== '') {
        // Replace select value with custom input before submit
        const hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = 'activityCategory';
        hidden.value = customInput.value.trim();
        form.appendChild(hidden);
        select.disabled = true;
      }
    });
  });
  (function() {
    const form = document.getElementById('scheduleFormPage');
    if (!form) return;
    const dateInput = form.querySelector('input[name="activityDate"]');
    const timeInput = form.querySelector('#activityTimeInput');
    let lastValidTime = String(timeInput ? (timeInput.value || '') : '').trim();

    function twoDigit(value) {
      return String(value).padStart(2, '0');
    }

    function getTodayDateKey() {
      const now = new Date();
      return `${now.getFullYear()}-${twoDigit(now.getMonth() + 1)}-${twoDigit(now.getDate())}`;
    }

    function getCurrentTimeKey() {
      const now = new Date();
      return `${twoDigit(now.getHours())}:${twoDigit(now.getMinutes())}`;
    }

    function roundUpToMinute(value) {
      const parts = String(value || '').split(':');
      if (parts.length < 2) return '00:00';
      const hour = parseInt(parts[0], 10);
      const minute = parseInt(parts[1], 10);
      if (Number.isNaN(hour) || Number.isNaN(minute)) return '00:00';

      let totalMinutes = (hour * 60) + minute;
      totalMinutes = Math.ceil(totalMinutes / 1) * 1;
      if (totalMinutes > 1439) totalMinutes = 1439;

      const outHour = Math.floor(totalMinutes / 60);
      const outMinute = totalMinutes % 60;
      return `${twoDigit(outHour)}:${twoDigit(outMinute)}`;
    }

    function applyDateTimeRestrictions() {
      if (!dateInput || !timeInput) return;

      const todayKey = getTodayDateKey();
      const selectedDate = String(dateInput.value || '').trim();
      const selectedTime = String(timeInput.value || '').trim();
      const minAllowedToday = roundUpToMinute(getCurrentTimeKey());

      dateInput.min = todayKey;

      if (selectedDate === todayKey) {
        timeInput.min = minAllowedToday;
        if (selectedTime !== '' && selectedTime < minAllowedToday) {
          timeInput.value = minAllowedToday;
          lastValidTime = minAllowedToday;
        } else if (selectedTime !== '') {
          lastValidTime = selectedTime;
        }
      } else {
        timeInput.removeAttribute('min');
        if (selectedTime !== '') {
          lastValidTime = selectedTime;
        }
      }
    }

    function enforceCurrentTimeSelection() {
      if (!dateInput || !timeInput) return;

      const todayKey = getTodayDateKey();
      const selectedDate = String(dateInput.value || '').trim();
      const selectedTime = String(timeInput.value || '').trim();
      if (selectedDate !== todayKey || selectedTime === '') return;

      const minAllowedToday = roundUpToMinute(getCurrentTimeKey());
      if (selectedTime < minAllowedToday) {
        timeInput.value = minAllowedToday;
        lastValidTime = minAllowedToday;
      } else {
        lastValidTime = selectedTime;
      }
    }

    if (dateInput) {
      dateInput.addEventListener('change', applyDateTimeRestrictions);
      dateInput.addEventListener('input', applyDateTimeRestrictions);
    }

    if (timeInput) {
      timeInput.addEventListener('focus', applyDateTimeRestrictions);
      timeInput.addEventListener('click', applyDateTimeRestrictions);
      timeInput.addEventListener('input', enforceCurrentTimeSelection);
      timeInput.addEventListener('change', enforceCurrentTimeSelection);
      timeInput.addEventListener('keydown', applyDateTimeRestrictions);
      timeInput.addEventListener('keydown', (event) => {
        const todayKey = getTodayDateKey();
        const selectedDate = String(dateInput ? (dateInput.value || '') : '').trim();
        if (selectedDate !== todayKey) return;

        const minAllowedToday = roundUpToMinute(getCurrentTimeKey());
        const currentTime = String(timeInput.value || '').trim();
        if ((event.key === 'ArrowDown' || event.key === 'PageDown') && currentTime !== '' && currentTime <= minAllowedToday) {
          event.preventDefault();
          timeInput.value = minAllowedToday;
          lastValidTime = minAllowedToday;
        }
      });
      timeInput.addEventListener('blur', () => {
        if (String(timeInput.value || '').trim() === '' && lastValidTime !== '') {
          timeInput.value = lastValidTime;
        }
        enforceCurrentTimeSelection();
      });
    }

    applyDateTimeRestrictions();
    window.setInterval(() => {
      applyDateTimeRestrictions();
      enforceCurrentTimeSelection();
    }, 1000);

    form.addEventListener('submit', (event) => {
      const selectedAudience = form.querySelectorAll('input[name="audience[]"]:checked');
      if (selectedAudience.length === 0) {
        event.preventDefault();
        alert('Select at least one target audience.');
        return;
      }

      if (dateInput && timeInput) {
        const dateValue = String(dateInput.value || '').trim();
        const timeValue = String(timeInput.value || '').trim();
        if (dateValue !== '' && timeValue !== '') {
          const selectedStamp = new Date(dateValue + 'T' + timeValue + ':00').getTime();
          const nowStamp = Date.now();
          if (!Number.isNaN(selectedStamp) && selectedStamp < nowStamp) {
            event.preventDefault();
            alert('Activity date and time must not be in the past.');
          }
        }
      }
    });
  })();
</script>
