<?php
$card_preview_limit = 3;

// Same computation the dedicated forecast-market.php / forecast-yield.php
// pages use — shared via config.php so this preview can never drift out
// of sync with what "View All" actually shows.
$market_forecast_rows = (isset($conn) && $conn instanceof mysqli)
  ? computeMarketForecastRows($conn)
  : [];
$yield_forecast_rows = (isset($conn) && $conn instanceof mysqli)
  ? computeYieldForecastRows($conn)
  : [];

if (empty($market_forecast_rows)) {
  $market_forecast_rows = [
    ['crop_name' => 'Rice', 'unit' => 'kg', 'current' => 1450, 'forecast' => 1505, 'delta_pct' => 3.8, 'badge_class' => 'up'],
    ['crop_name' => 'Corn', 'unit' => 'kg', 'current' => 1150, 'forecast' => 1188, 'delta_pct' => 3.3, 'badge_class' => 'up'],
    ['crop_name' => 'Vegetables', 'unit' => 'kg', 'current' => 600, 'forecast' => 624, 'delta_pct' => 4.0, 'badge_class' => 'up'],
  ];
}

if (empty($yield_forecast_rows)) {
  $yield_forecast_rows = [
    ['crop_name' => 'Rice', 'unit' => 'kg', 'current_qty' => 2400, 'expected_qty' => 2500, 'growth_pct' => 5.0, 'badge_class' => 'up'],
    ['crop_name' => 'Corn', 'unit' => 'kg', 'current_qty' => 1730, 'expected_qty' => 1800, 'growth_pct' => 4.0, 'badge_class' => 'up'],
  ];
}

$clamp_value = static function (float $value, float $min, float $max): float {
  return max($min, min($max, $value));
};

$max_expected_qty = 1.0;
foreach ($yield_forecast_rows as $yield_row) {
  $max_expected_qty = max($max_expected_qty, (float)($yield_row['expected_qty'] ?? 0));
}
foreach ($yield_forecast_rows as &$yield_row) {
  $progress_ratio = ((float)$yield_row['expected_qty'] / max($max_expected_qty, 1.0)) * 100;
  $yield_row['progress_width'] = round($clamp_value($progress_ratio, 25, 100), 1);
}
unset($yield_row);

$market_forecast_display_rows = array_slice($market_forecast_rows, 0, $card_preview_limit);
$yield_forecast_display_rows = array_slice($yield_forecast_rows, 0, $card_preview_limit);
?>

<!-- Forecasting Section -->
<section id="section-forecasting" class="admin-section">
  <div class="section-header">
    <h1>Forecasting</h1>
    <p>Compare realized income against projections and review upcoming market price forecasts.</p>
  </div>

  <div class="analytics-grid">
    <div class="analytics-card analytics-card-wide">
      <h3>Cooperative Profit Forecast</h3>
      <div class="chart-controls">
        <div class="chart-nav">
          <button type="button" class="chart-nav-btn" id="forecastPrev" aria-label="Previous months">
            <i class="fas fa-chevron-left"></i>
          </button>
        </div>
        <div class="chart-control">
          <input type="month" id="forecastStart" name="forecastStart" value="<?php echo htmlspecialchars(date('Y-m')); ?>">
        </div>
        <div class="chart-nav">
          <button type="button" class="chart-nav-btn" id="forecastNext" aria-label="Next months">
            <i class="fas fa-chevron-right"></i>
          </button>
        </div>
      </div>
      <div class="forecast-chart">
        <canvas id="incomeForecastChart"></canvas>
      </div>
      <div class="income-legend">
        <span><i class="legend-dot available"></i> Actual</span>
        <span><i class="legend-dot pending"></i> Forecast</span>
      </div>
    </div>

    <div style="grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:2rem;">
    <div class="analytics-card">
      <div class="card-header card-header-actions">
        <h3>Market Price Forecast</h3>
        <a href="admin_dashboard.php?section=forecast-market" class="btn-secondary card-view-all-btn" style="text-decoration:none;">View All</a>
      </div>
      <div class="market-forecast">
        <?php foreach ($market_forecast_display_rows as $market_row): ?>
        <div class="market-row">
          <div>
            <span class="market-crop"><?php echo htmlspecialchars((string)$market_row['crop_name']); ?></span>
            <span class="market-range">PHP <?php echo number_format((float)$market_row['current'], 2); ?> -> PHP <?php echo number_format((float)$market_row['forecast'], 2); ?> / <?php echo htmlspecialchars((string)($market_row['unit'] ?? 'unit')); ?></span>
          </div>
          <span class="market-badge <?php echo htmlspecialchars((string)$market_row['badge_class']); ?>"><?php echo ((float)$market_row['delta_pct'] >= 0 ? '+' : '') . number_format((float)$market_row['delta_pct'], 1); ?>%</span>
        </div>
        <?php endforeach; ?>
      </div>
      
    </div>

    <div class="analytics-card">
      <div class="card-header card-header-actions">
        <h3>Crop Yield Forecast</h3>
        <a href="admin_dashboard.php?section=forecast-yield" class="btn-secondary card-view-all-btn" style="text-decoration:none;">View All</a>
      </div>
      <?php foreach ($yield_forecast_display_rows as $yield_row): ?>
      <div class="forecast-item">
        <span class="crop-name"><?php echo htmlspecialchars((string)$yield_row['crop_name']); ?></span>
        <div class="forecast-bar">
          <div class="forecast-progress" style="width: <?php echo number_format((float)$yield_row['progress_width'], 1); ?>%;"></div>
        </div>
        <span class="forecast-value">Expected: <?php echo number_format((float)$yield_row['expected_qty'], 2); ?> <?php echo htmlspecialchars((string)$yield_row['unit']); ?> (<?php echo ((float)$yield_row['growth_pct'] >= 0 ? '+' : '') . number_format((float)$yield_row['growth_pct'], 1); ?>%)</span>
      </div>
      <?php endforeach; ?>
    </div>
    </div><!-- end 2-col wrapper -->

  </div>

</section>

<script>
  (function() {
    const incomeCanvas = document.getElementById('incomeForecastChart');
    if (!incomeCanvas) return;

    const incomeSeriesRaw = <?php echo $dashboard_income_series_json ?? '[]'; ?>;
    const fallbackBaseline = Math.max(150, (<?php echo (int)$total_farmers; ?> * 40) + (<?php echo (int)$total_clients; ?> * 25));
    const RANGE_MONTHS = 8;
    const FUTURE_MONTHS = 6;
    const MOVING_AVG_WINDOW = 3;

    function toNumber(value) {
      const num = Number(value);
      return Number.isFinite(num) ? num : 0;
    }

    function formatMonthLabel(monthKey) {
      const date = new Date(monthKey + '-01T00:00:00');
      if (Number.isNaN(date.getTime())) {
        return monthKey;
      }
      return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
    }

    function toMoneyK(value) {
      return Math.round(value * 100) / 100;
    }

    function clamp(value, min, max) {
      return Math.min(Math.max(value, min), max);
    }

    function monthToIndex(value) {
      const parts = value.split('-');
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      if (Number.isNaN(year) || Number.isNaN(month)) {
        return 0;
      }
      return (year * 12) + month;
    }

    function addMonths(value, monthsToAdd) {
      const parts = value.split('-');
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const date = new Date(year, month, 1);
      date.setMonth(date.getMonth() + monthsToAdd);
      const newYear = date.getFullYear();
      const newMonth = String(date.getMonth() + 1).padStart(2, '0');
      return newYear + '-' + newMonth;
    }

    function getCurrentMonthKey() {
      const now = new Date();
      return now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0');
    }

    function buildSourceSeries() {
      if (!Array.isArray(incomeSeriesRaw) || incomeSeriesRaw.length === 0) {
        const currentMonth = new Date();
        const startMonth = currentMonth.getFullYear() + '-' + String(currentMonth.getMonth() + 1).padStart(2, '0');
        return [
          {
            month: startMonth,
            label: formatMonthLabel(startMonth),
            actual: toMoneyK(fallbackBaseline)
          }
        ];
      }

      return incomeSeriesRaw
        .map((item) => {
          const month = String(item.month || '');
          const label = String(item.label || formatMonthLabel(month));
          const total = toNumber(item.bidding) + toNumber(item.others) + toNumber(item.machinery);
          return {
            month,
            label,
            actual: toMoneyK(total)
          };
        })
        .filter((item) => /^\d{4}-\d{2}$/.test(item.month))
        .sort((a, b) => a.month.localeCompare(b.month));
    }

    function buildSeasonalityMap(series) {
      const positiveValues = series.map((item) => item.actual).filter((value) => value > 0);
      const globalAverage = positiveValues.length > 0
        ? positiveValues.reduce((sum, value) => sum + value, 0) / positiveValues.length
        : fallbackBaseline;

      const monthBuckets = {};
      series.forEach((item) => {
        if (item.actual <= 0) {
          return;
        }
        const monthNum = parseInt(item.month.split('-')[1], 10);
        if (!monthBuckets[monthNum]) {
          monthBuckets[monthNum] = [];
        }
        monthBuckets[monthNum].push(item.actual);
      });

      const seasonality = {};
      for (let monthNum = 1; monthNum <= 12; monthNum += 1) {
        const bucket = monthBuckets[monthNum] || [];
        if (bucket.length === 0) {
          seasonality[monthNum] = 1;
          continue;
        }
        const monthAvg = bucket.reduce((sum, value) => sum + value, 0) / bucket.length;
        seasonality[monthNum] = clamp(monthAvg / Math.max(globalAverage, 1), 0.85, 1.15);
      }

      return seasonality;
    }

    function estimateNextValue(previousValues, seasonFactor, baseline) {
      const validHistory = previousValues.filter((value) => Number.isFinite(value) && value > 0);
      const len = validHistory.length;
      let movingAverage = baseline;

      if (len >= MOVING_AVG_WINDOW) {
        const recent = validHistory.slice(-MOVING_AVG_WINDOW);
        movingAverage = recent.reduce((sum, value) => sum + value, 0) / MOVING_AVG_WINDOW;
      } else if (len > 0) {
        // Sparse-data fallback: pad missing months with baseline so forecasting still works.
        const sumHistory = validHistory.reduce((sum, value) => sum + value, 0);
        const missingSlots = MOVING_AVG_WINDOW - len;
        movingAverage = (sumHistory + (baseline * missingSlots)) / MOVING_AVG_WINDOW;
      }

      return toMoneyK(Math.max(0, movingAverage));
    }

    function buildForecastSeries() {
      const sourceSeries = buildSourceSeries();
      const seasonalityMap = buildSeasonalityMap(sourceSeries);
      const positiveValues = sourceSeries.map((item) => item.actual).filter((value) => value > 0);
      const baseline = positiveValues.length > 0
        ? positiveValues.reduce((sum, value) => sum + value, 0) / positiveValues.length
        : fallbackBaseline;

      const forecastSeries = [];
      const rollingValues = [];

      sourceSeries.forEach((item) => {
        const monthNum = parseInt(item.month.split('-')[1], 10);
        const seasonFactor = seasonalityMap[monthNum] || 1;
        const forecastValue = estimateNextValue(rollingValues, seasonFactor, baseline);

        forecastSeries.push({
          month: item.month,
          label: item.label,
          actual: item.actual,
          forecast: forecastValue,
          isFuture: false
        });

        rollingValues.push(item.actual > 0 ? item.actual : forecastValue);
      });

      let futureMonth = addMonths(sourceSeries[sourceSeries.length - 1].month, 1);
      for (let i = 0; i < FUTURE_MONTHS; i += 1) {
        const monthNum = parseInt(futureMonth.split('-')[1], 10);
        const seasonFactor = seasonalityMap[monthNum] || 1;
        const forecastValue = estimateNextValue(rollingValues, seasonFactor, baseline);

        forecastSeries.push({
          month: futureMonth,
          label: formatMonthLabel(futureMonth),
          actual: null,
          forecast: forecastValue,
          isFuture: true
        });

        rollingValues.push(forecastValue);
        futureMonth = addMonths(futureMonth, 1);
      }

      return forecastSeries;
    }

    const forecastSeries = buildForecastSeries();
    if (!Array.isArray(forecastSeries) || forecastSeries.length === 0) {
      return;
    }

    function normalizeStart(value) {
      const minMonth = forecastSeries[0].month;
      const maxMonth = forecastSeries[forecastSeries.length - 1].month;
      const minIndex = monthToIndex(minMonth);
      const maxIndex = monthToIndex(maxMonth);
      const startIndex = monthToIndex(value || minMonth);
      const clampedIndex = Math.min(Math.max(startIndex, minIndex), maxIndex);
      return addMonths(minMonth, clampedIndex - minIndex);
    }

    function setStartValue(value) {
      const startInput = document.getElementById('forecastStart');
      const normalized = normalizeStart(value);
      if (startInput) {
        startInput.value = normalized;
      }
      return normalized;
    }

    function getRange() {
      const startInput = document.getElementById('forecastStart');
      const endValue = setStartValue(startInput ? startInput.value : getCurrentMonthKey());
      const fromValue = addMonths(endValue, -(RANGE_MONTHS - 1));
      const toValue = endValue;
      return { from: fromValue, to: toValue };
    }

    function buildForecastData(range) {
      const filtered = forecastSeries.filter((item) => item.month >= range.from && item.month <= range.to);
      return {
        labels: filtered.map((item) => item.label),
        actual: filtered.map((item) => (item.actual === null ? null : item.actual)),
        forecast: filtered.map((item) => item.forecast)
      };
    }

    const startInput = document.getElementById('forecastStart');
    if (startInput) {
      const minMonth = forecastSeries[0].month;
      const maxMonth = forecastSeries[forecastSeries.length - 1].month;
      startInput.min = minMonth;
      startInput.max = maxMonth;
      setStartValue(getCurrentMonthKey());
    }

    if (typeof Chart === 'undefined') {
      return;
    }

    const forecastData = buildForecastData(getRange());

    const incomeChart = new Chart(incomeCanvas, {
      type: 'line',
      data: {
        labels: forecastData.labels,
        datasets: [
          {
            label: 'Actual',
            data: forecastData.actual,
            borderColor: '#2f8f5b',
            backgroundColor: 'rgba(47, 143, 91, 0.12)',
            tension: 0.35,
            fill: true,
            pointRadius: 3,
            spanGaps: false
          },
          {
            label: 'Forecast',
            data: forecastData.forecast,
            borderColor: '#f39c12',
            backgroundColor: 'rgba(243, 156, 18, 0.12)',
            tension: 0.35,
            fill: true,
            borderDash: [6, 4],
            pointRadius: 3
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: (ctx) => 'PHP ' + Number(ctx.parsed.y || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })
            }
          }
        },
        scales: {
          y: {
            ticks: {
              callback: (value) => 'PHP ' + Number(value).toLocaleString()
            },
            grid: { color: 'rgba(40, 167, 69, 0.08)' }
          },
          x: { grid: { display: false } }
        }
      }
    });

    function applyForecastRange() {
      const data = buildForecastData(getRange());
      incomeChart.data.labels = data.labels;
      incomeChart.data.datasets[0].data = data.actual;
      incomeChart.data.datasets[1].data = data.forecast;
      incomeChart.update();
    }

    const prevBtn = document.getElementById('forecastPrev');
    const nextBtn = document.getElementById('forecastNext');

    if (startInput) {
      startInput.addEventListener('change', applyForecastRange);
      startInput.addEventListener('input', applyForecastRange);
    }
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        const current = startInput ? startInput.value : forecastSeries[0].month;
        setStartValue(addMonths(current, -1));
        applyForecastRange();
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        const current = startInput ? startInput.value : forecastSeries[0].month;
        setStartValue(addMonths(current, 1));
        applyForecastRange();
      });
    }
  })();
</script>
