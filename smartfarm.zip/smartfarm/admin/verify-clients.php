<?php
$clients_rows = [];
$clients_query = "
  SELECT
    c.client_id,
    c.user_id,
    c.client_fullname,
    COALESCE(u.email, '-') AS client_email,
    COALESCE(u.is_active, 1) AS user_is_active,
    c.client_address,
    c.client_contact_number,
    c.client_id_type,
    c.client_id_verification_status,
    CASE WHEN COALESCE(c.client_id_file_name, '') <> '' THEN 1 ELSE 0 END AS has_id_file
  FROM clients c
  LEFT JOIN users u ON c.user_id = u.user_id
  ORDER BY c.client_id DESC
";
$clients_result = $conn->query($clients_query);
if ($clients_result) {
  while ($client_row = $clients_result->fetch_assoc()) {
    $clients_rows[] = $client_row;
  }
}
?>

<!-- Verify Clients Section -->
<section id="section-verify-clients" class="admin-section">
  <div class="section-header">
    <h1>Client Accounts</h1>
    <div style="display:flex; gap:0.5rem; align-items:center;">
      <button class="btn-secondary" type="button" onclick="goToAddAccountFromClients()" data-tooltip="Add Client Account"><i class="fas fa-user-plus"></i></button>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="clientSearch">Search</label>
      <input type="text" placeholder="Search by name, email..." class="search-input" id="clientSearch" onkeyup="filterTable('client')">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="clientStatus">Status</label>
      <select class="filter-select" id="clientStatus" onchange="filterTable('client')">
        <option value="">All Status</option>
        <option value="active">Active</option>
        <option value="deactivated">Deactivated</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="clientGroupBy">Group By</label>
      <select class="filter-select" id="clientGroupBy" onchange="sfSetGroupBy('clientTable', this); filterTable('client')">
        <option value="">No Grouping</option>
        <option value="4">Status</option>
        <option value="2">Location</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="clientTable">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Location</th>
          <th>Contact</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($clients_rows) > 0): ?>
          <?php foreach ($clients_rows as $client): ?>
            <?php
              $client_user_id = (int)($client['user_id'] ?? 0);
              $is_client_active = (int)($client['user_is_active'] ?? 1) === 1;
              $status = $is_client_active ? 'active' : 'deactivated';
              $status_label = $is_client_active ? 'Active' : 'Deactivated';
              $status_class = $is_client_active ? 'approved' : 'rejected';
              $toggle_type = $is_client_active ? 'deactivate' : 'activate';
              $toggle_icon = $is_client_active ? 'fa-ban' : 'fa-check';
              $toggle_tooltip = $is_client_active ? 'Deactivate Account' : 'Activate Account';
              $toggle_confirm_title = $is_client_active ? 'Deactivate Account' : 'Activate Account';
              $toggle_confirm_message = $is_client_active
                ? 'Are you sure you want to deactivate this client account?'
                : 'Are you sure you want to activate this client account?';
              $client_details_payload = json_encode([
                "id"      => (int)($client["client_id"] ?? 0),
                "user_id" => $client_user_id,
                "name"    => (string)($client["client_fullname"] ?? ""),
                "email"   => (string)($client["client_email"] ?? "-"),
                "address" => (string)($client["client_address"] ?? "-"),
                "contact" => (string)($client["client_contact_number"] ?? "-"),
                "id_type" => (string)($client["client_id_type"] ?? "-"),
                "status"  => $status,
                "has_id"  => (int)($client["has_id_file"] ?? 0) === 1
              ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
            ?>
            <tr>
              <td title="<?php echo htmlspecialchars($client['client_fullname'] ?? '-'); ?>"><?php echo htmlspecialchars($client['client_fullname'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($client['client_email'] ?? '-'); ?>"><?php echo htmlspecialchars($client['client_email'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($client['client_address'] ?? '-'); ?>"><?php echo htmlspecialchars($client['client_address'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($client['client_contact_number'] ?? '-'); ?>"><?php echo htmlspecialchars($client['client_contact_number'] ?? '-'); ?></td>
              <td><span class="status <?php echo $status_class; ?>"><?php echo htmlspecialchars($status_label); ?></span></td>
              <td class="table-actions-cell">
                <div class="table-actions-wrap">
                  <form method="post" style="display:inline;" data-confirm-title="<?php echo htmlspecialchars($toggle_confirm_title); ?>" data-confirm-message="<?php echo htmlspecialchars($toggle_confirm_message); ?>">
                    <input type="hidden" name="action" value="toggle_user_account">
                    <input type="hidden" name="target_role" value="client">
                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars((string)$client_user_id); ?>">
                    <input type="hidden" name="toggle_type" value="<?php echo htmlspecialchars($toggle_type); ?>">
                    <button
                      class="btn-small btn-deactivate"
                      type="submit"
                      data-tooltip="<?php echo htmlspecialchars($toggle_tooltip); ?>"
                      <?php echo $client_user_id > 0 ? '' : 'disabled'; ?>>
                      <i class="fas <?php echo htmlspecialchars($toggle_icon); ?>"></i>
                    </button>
                  </form>
                  <button class="btn-small btn-view" data-tooltip="View Account Details"
                    onclick='openClientAccountDetails(<?php echo $client_details_payload; ?>)'>
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" style="text-align:center; padding:20px; color:#8b968b;">No client records found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<style>
#clientTable {
  table-layout: fixed;
}

#clientTable th,
#clientTable td {
  vertical-align: middle;
}

#clientTable td {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.2;
}

#clientTable td.table-actions-cell {
  overflow: visible;
  text-overflow: clip;
  min-width: 150px;
  padding: 0.5rem;
}

#clientTable .table-actions-wrap {
  display: inline-flex;
  gap: 0.35rem;
  align-items: center;
  flex-wrap: nowrap;
}

.account-details-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  margin-top: 4px;
}
.account-detail-item {
  background: #f7fbf8;
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 10px;
  padding: 10px 14px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.account-detail-item span {
  color: #738173;
  font-size: 0.76rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  font-weight: 700;
}
.account-detail-item strong {
  color: #1c4d2c;
  font-size: 0.95rem;
  word-break: break-word;
}
.id-view-field {
  grid-column: 1 / -1;
}
.id-view-link-wrap {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}
.id-view-link-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 40px;
  padding: 0 16px;
  border-radius: 10px;
  border: 1px solid #c9d8cf;
  background: #f4f7f5;
  color: #244a33;
  font-weight: 700;
  letter-spacing: 0.01em;
  cursor: pointer;
  box-shadow: 0 3px 8px rgba(23, 60, 36, 0.08);
}
.id-view-link-btn:hover {
  background: #ebf2ee;
  border-color: #b8cbbf;
  color: #1f3f2c;
  transform: translateY(-1px);
  box-shadow: 0 6px 14px rgba(23, 60, 36, 0.14);
}
.id-view-link-btn:disabled,
.id-view-link-btn.is-disabled {
  background: #e5ebe7;
  border-color: #d4dfd8;
  color: #8b968f;
  cursor: not-allowed;
  box-shadow: none;
  transform: none;
}
.id-view-note {
  color: #6f816f;
  font-size: 0.82rem;
}
.id-viewer-modal-card {
  width: min(1080px, 96vw);
}
.id-viewer-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 10px;
  flex-wrap: wrap;
}
.id-viewer-controls {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 5px;
  border-radius: 10px;
  border: 1px solid rgba(27, 90, 42, 0.18);
  background: #f4faf5;
}
.id-viewer-control {
  border: 1px solid rgba(27, 90, 42, 0.2);
  background: #ffffff;
  color: #1c4d2c;
  border-radius: 8px;
  min-width: 32px;
  height: 30px;
  padding: 0 10px;
  font-size: 0.82rem;
  font-weight: 700;
  cursor: pointer;
}
.id-viewer-control:hover {
  background: #eaf5ec;
}
.id-viewer-viewport {
  border: 1px solid rgba(27, 90, 42, 0.16);
  border-radius: 12px;
  background: #ffffff;
  overflow: auto;
  height: min(72vh, 780px);
}
.id-viewer-frame {
  width: 100%;
  height: min(72vh, 780px);
  border: 0;
  transform-origin: top left;
  background: #fff;
}
.id-viewer-empty {
  padding: 26px;
  border: 1px dashed rgba(27, 90, 42, 0.24);
  border-radius: 12px;
  text-align: center;
  color: #607262;
  font-size: 0.9rem;
}
.id-viewer-empty[hidden] {
  display: none !important;
}
.verify-modal-actions {
  align-items: center;
  flex-wrap: nowrap;
  gap: 12px !important;
}
.verify-modal-actions form {
  display: inline-flex !important;
}
.verify-action-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 46px;
  padding: 0 22px;
  border-radius: 12px;
  border: 1px solid transparent;
  font-size: 1.02rem;
  font-weight: 700;
  letter-spacing: 0;
  white-space: nowrap;
  box-shadow: none;
  transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease, color 0.2s ease;
}
.verify-action-btn:hover {
  transform: translateY(-1px);
}
.verify-approve-btn {
  background: #10b981;
  color: #ffffff;
  border-color: #10b981;
  box-shadow: 0 8px 18px rgba(5, 150, 105, 0.28);
}
.verify-approve-btn:hover {
  background: #059669;
  border-color: #059669;
  box-shadow: 0 10px 22px rgba(5, 150, 105, 0.34);
}
.verify-reject-btn {
  background: #c94b57;
  color: #ffffff;
  border-color: #c94b57;
  box-shadow: 0 8px 18px rgba(184, 63, 75, 0.26);
}
.verify-reject-btn:hover {
  background: #b83f4b;
  border-color: #b83f4b;
  box-shadow: 0 10px 22px rgba(184, 63, 75, 0.32);
}
@media (max-width: 600px) {
  .account-details-grid { grid-template-columns: 1fr; }
  .id-viewer-toolbar { flex-direction: column; align-items: stretch; }
  .id-viewer-controls { width: 100%; justify-content: space-between; }
  .id-viewer-viewport { height: 62vh; }
  .id-viewer-frame { height: 62vh; }
}
</style>

<div id="clientDetailsModal" class="schedule-modal" onclick="closeClientDetails(event)">
    <div class="schedule-modal-card" style="width:100%;margin:0;">    <input type="hidden" id="cdClientId" value="">
    <input type="hidden" id="cdClientStatus" value="">    <div class="schedule-modal-header">
      <div>
        <h3 id="clientDetailsTitle">Client Details</h3>
        <p style="margin:0;color:#738173;font-size:0.86rem;">Complete profile information for the selected client.</p>
      </div>
      <button type="button" class="schedule-modal-close" onclick="closeClientDetails()"><i class="fas fa-times"></i></button>
    </div>
    <div class="account-details-grid" id="clientDetailsGrid">
      <div class="account-detail-item">
        <span>Full Name</span>
        <strong id="cdName">-</strong>
      </div>
      <div class="account-detail-item">
        <span>Email</span>
        <strong id="cdEmail">-</strong>
      </div>
      <div class="account-detail-item">
        <span>Location</span>
        <strong id="cdAddress">-</strong>
      </div>
      <div class="account-detail-item">
        <span>Contact Number</span>
        <strong id="cdContact">-</strong>
      </div>
      <div class="account-detail-item">
        <span>ID Type</span>
        <strong id="cdIdType">-</strong>
      </div>
      <div class="account-detail-item">
        <span>Verification Status</span>
        <strong id="cdStatus">-</strong>
      </div>
    </div>
    <div class="account-detail-item id-view-field">
      <span>Uploaded ID</span>
      <div class="id-view-link-wrap">
        <button type="button" id="cdViewIdBtn" class="btn-small id-view-link-btn" onclick="openClientIdViewer()" disabled>View ID</button>
        <small id="cdIdViewNote" class="id-view-note">No uploaded ID file.</small>
      </div>
    </div>
      <div class="client-details-footer verify-modal-actions" style="display:flex;gap:0.5rem;justify-content:flex-end;padding-top:1rem;border-top:1px solid #e0e0e0;margin-top:1rem;">
        <button type="button" class="btn-small verify-action-btn verify-reject-btn" id="cdRejectBtn" style="display:none;" onclick="showRejectFormModal('client', document.getElementById('cdClientId').value)" data-tooltip="Reject">Reject</button>
        <form method="post" style="display:inline" id="cdApproveForm" data-confirm-title="Approve Account" data-confirm-message="Are you sure you want to approve this client?">
          <input type="hidden" name="action" value="approve_client">
          <input type="hidden" name="client_id" id="cdApproveFormId" value="">
          <button type="submit" class="btn-small verify-action-btn verify-approve-btn" id="cdApproveBtn" style="display:none;" data-tooltip="Approve">Approve</button>
        </form>
      </div>
    </div>
  </div>

  <div id="clientIdViewerModal" class="schedule-modal" onclick="closeClientIdViewer(event)">
    <div class="schedule-modal-card id-viewer-modal-card">
        <div class="schedule-modal-header" style="width:100%;margin:0;">
        <div>
          <h3>Client ID File</h3>
          <p style="margin:0;color:#738173;font-size:0.86rem;">Full file view with zoom controls.</p>
        </div>
        <button type="button" class="schedule-modal-close" onclick="closeClientIdViewer()"><i class="fas fa-times"></i></button>
      </div>
      <div class="id-viewer-toolbar">
        <small class="id-view-note">Use - and + to adjust the view.</small>
        <div class="id-viewer-controls">
          <button type="button" class="id-viewer-control" onclick="adjustClientIdViewerZoom(-0.1)">-</button>
          <button type="button" class="id-viewer-control" id="cdViewerZoomResetBtn" onclick="resetClientIdViewerZoom()">100%</button>
          <button type="button" class="id-viewer-control" onclick="adjustClientIdViewerZoom(0.1)">+</button>
        </div>
      </div>
      <div id="cdViewerEmpty" class="id-viewer-empty" hidden>No uploaded ID file for this client.</div>
      <div id="cdViewerViewport" class="id-viewer-viewport" hidden>
        <iframe id="cdViewerFrame" class="id-viewer-frame" title="Client ID File Viewer" loading="lazy"></iframe>
      </div>
    </div>
  </div>

<script>
  let clientIdViewerZoom = 1;
  let clientIdViewerUrl = '';

  function applyClientIdViewerZoom() {
    const frame = document.getElementById('cdViewerFrame');
    const viewport = document.getElementById('cdViewerViewport');
    const resetBtn = document.getElementById('cdViewerZoomResetBtn');
    if (!frame || !viewport || !resetBtn) return;

    const zoom = clientIdViewerZoom;
    const baseHeight = viewport.clientHeight || 480;

    frame.style.transform = 'scale(' + zoom + ')';
    frame.style.width = (100 / zoom) + '%';
    frame.style.height = (baseHeight / zoom) + 'px';
    resetBtn.textContent = Math.round(zoom * 100) + '%';
  }

  function adjustClientIdViewerZoom(delta) {
    const next = Math.max(0.5, Math.min(2.5, clientIdViewerZoom + delta));
    clientIdViewerZoom = Math.round(next * 100) / 100;
    applyClientIdViewerZoom();
  }

  function resetClientIdViewerZoom() {
    clientIdViewerZoom = 1;
    applyClientIdViewerZoom();
  }

  function openClientIdViewer() {
    const modal = document.getElementById('clientIdViewerModal');
    const frame = document.getElementById('cdViewerFrame');
    const viewport = document.getElementById('cdViewerViewport');
    const empty = document.getElementById('cdViewerEmpty');
    if (!modal || !frame || !viewport || !empty) return;

    if (!clientIdViewerUrl) {
      viewport.hidden = true;
      empty.hidden = false;
      modal.classList.add('is-visible');
      return;
    }

    frame.src = clientIdViewerUrl;
    viewport.hidden = false;
    empty.hidden = true;
    modal.classList.add('is-visible');
    resetClientIdViewerZoom();
  }

  function closeClientIdViewer(event) {
    const modal = document.getElementById('clientIdViewerModal');
    const frame = document.getElementById('cdViewerFrame');
    if (!modal) return;
    if (!event || event.target === modal) {
      if (frame) {
        frame.removeAttribute('src');
      }
      modal.classList.remove('is-visible');
    }
  }

function openClientDetails(data, clientId) {
  const userId = Number(data && data.user_id ? data.user_id : 0);
  if (!userId) return;
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=verify-clients';
}

function openClientAccountDetails(data) {
  const userId = Number(data && data.user_id ? data.user_id : 0);
  if (!userId) return;
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=verify-clients&action=view';
}

function openClientForApproval(data) {
  const userId = Number(data && data.user_id ? data.user_id : 0);
  if (!userId) return;
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=verify-clients&action=approve';
}

function closeClientDetails(event) {
  const modal = document.getElementById('clientDetailsModal');
  if (!modal) return;
  if (!event || event.target === modal) {
    modal.classList.remove('is-visible');
  }
}

function goToAddAccountFromClients() {
  window.location.href = 'admin_dashboard.php?section=add-account&role=client&from=verify-clients';
}

function openClientRejectModal(clientId, clientName) {
  document.getElementById('clientRejectClientId').value = clientId;
  document.getElementById('clientRejectReason').value = '';
  document.getElementById('clientRejectReasonError').style.display = 'none';
  const subtitle = document.getElementById('clientRejectModalSubtitle');
  if (subtitle && clientName) subtitle.textContent = 'Rejecting: ' + clientName;
  document.getElementById('clientRejectModal').classList.add('is-visible');
}

function closeClientRejectModal(event) {
  const modal = document.getElementById('clientRejectModal');
  if (!modal) return;
  if (!event || event.target === modal) modal.classList.remove('is-visible');
}

function submitClientReject() {
  const reason = document.getElementById('clientRejectReason').value.trim();
  const errEl = document.getElementById('clientRejectReasonError');
  if (!reason) { errEl.style.display = 'block'; return; }
  errEl.style.display = 'none';
  document.getElementById('clientRejectForm').submit();
}
</script>

<!-- Client Reject Modal -->
<div id="clientRejectModal" class="schedule-modal" onclick="closeClientRejectModal(event)">
  <div class="schedule-modal-card" style="width:min(480px,92vw);margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3>Reject Client Account</h3>
        <p id="clientRejectModalSubtitle" style="margin:0;color:#738173;font-size:0.86rem;">Provide a reason for rejection.</p>
      </div>
      <button type="button" class="schedule-modal-close" onclick="closeClientRejectModal()"><i class="fas fa-times"></i></button>
    </div>
    <form method="post" action="admin_dashboard.php" id="clientRejectForm">
      <input type="hidden" name="action" value="reject_client">
      <input type="hidden" name="client_id" id="clientRejectClientId" value="">
      <div style="margin:1rem 0;">
        <label for="clientRejectReason" style="display:block;font-weight:700;font-size:0.9rem;color:#244a33;margin-bottom:6px;">Reason for rejection <span style="color:#c94b57;">*</span></label>
        <textarea id="clientRejectReason" name="reason" rows="4"
          placeholder="e.g. Incomplete documents, invalid ID, etc."
          style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #c9d8cf;border-radius:8px;font-size:0.95rem;resize:vertical;"></textarea>
        <div id="clientRejectReasonError" style="display:none;color:#c94b57;font-size:0.82rem;margin-top:4px;font-weight:600;">Please provide a reason before rejecting.</div>
      </div>
      <div style="display:flex;gap:0.5rem;justify-content:flex-end;padding-top:0.75rem;border-top:1px solid #e0e0e0;">
        <button type="button" class="btn-secondary" onclick="closeClientRejectModal()">Cancel</button>
        <button type="button" class="btn-small btn-reject" onclick="submitClientReject()">Reject</button>
      </div>
    </form>
  </div>
</div>
