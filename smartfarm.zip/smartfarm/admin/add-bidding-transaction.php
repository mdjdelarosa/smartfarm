<?php
$edit_crop_id = (int)($_GET['edit_crop_id'] ?? 0);
$reopen_crop_id = (int)($_GET['reopen_crop_id'] ?? 0);
$is_edit_mode = $edit_crop_id > 0;
$is_reopen_mode = $reopen_crop_id > 0;
$inventory_crops = [];
$inv_result = $conn->query("
  SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit,
         COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
  FROM crops c
  LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
  WHERE c.starting_price <= 0 AND c.crop_quantity > 0
  ORDER BY c.crop_name ASC
");
if ($inv_result) {
  while ($inv_row = $inv_result->fetch_assoc()) {
    $inventory_crops[] = $inv_row;
  }
}

$edit_crop = null;
if ($is_edit_mode || $is_reopen_mode) {
  $crop_id_to_load = $is_reopen_mode ? $reopen_crop_id : $edit_crop_id;
  $edit_stmt = $conn->prepare("
    SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit, c.starting_price, c.bidding_end_date, c.crop_status, c.farmer_id, COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
    FROM crops c
    LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
    WHERE c.crop_id = ? AND c.starting_price > 0
    LIMIT 1
  ");
  if ($edit_stmt) {
    $edit_stmt->bind_param('i', $crop_id_to_load);
    $edit_stmt->execute();
    $edit_crop = $edit_stmt->get_result()->fetch_assoc();
    $edit_stmt->close();
  }
  if (!$edit_crop) {
    $is_edit_mode = false;
    $is_reopen_mode = false;
    $edit_crop_id = 0;
    $reopen_crop_id = 0;
  }
}
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-add-bidding-transaction" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('bidding-monitor')" data-tooltip="Back to monitor">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1><?php echo $is_reopen_mode ? 'Reopen Bidding Crop' : ($is_edit_mode ? 'Edit Bidding Crop' : 'Add Bidding Crop'); ?></h1>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3><i class="fas <?php echo $is_reopen_mode ? 'fa-refresh' : ($is_edit_mode ? 'fa-pen' : 'fa-plus-circle'); ?>" style="color:#22c55e;margin-right:0.4rem;"></i><?php echo $is_reopen_mode ? 'Reopen Expired Bidding Crop' : ($is_edit_mode ? 'Update Bidding Crop' : 'Add Bidding Crop'); ?></h3>
      </div>
    </div>

    <style>
      #section-add-bidding-transaction .bid-source-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0.65rem;
        margin-bottom: 0.7rem;
      }

      #section-add-bidding-transaction .bid-source-btn {
        border: 1px solid #c9d8cf;
        border-radius: 8px;
        background: #f4f7f5;
        color: #244a33;
        font-size: 0.95rem;
        font-weight: 600;
        cursor: pointer;
        padding: 0.75rem;
        box-shadow: 0 3px 8px rgba(23, 60, 36, 0.08);
        transition: background-color 0.2s ease, border-color 0.2s ease, color 0.2s ease, box-shadow 0.2s ease, transform 0.2s ease;
      }

      #section-add-bidding-transaction .bid-source-btn:hover {
        border-color: #b8cbbf;
        background: #ebf2ee;
        color: #1f3f2c;
        box-shadow: 0 6px 14px rgba(23, 60, 36, 0.14);
        transform: translateY(-1px);
      }

      #section-add-bidding-transaction .bid-source-btn.is-active {
        border-color: #16a34a;
        background: #22c55e;
        color: #fff;
        box-shadow: 0 8px 18px rgba(34, 197, 94, 0.24);
      }

      #section-add-bidding-transaction .bid-source-note {
        margin: 0;
        font-size: 0.86rem;
        color: #6b776b;
        padding: 0.45rem 0.1rem 0;
      }

      #section-add-bidding-transaction .bid-source-form {
        display: none;
        margin-top: 1rem;
        padding-top: 0.95rem;
        border-top: 1px solid rgba(27, 90, 42, 0.12);
      }

      @media (max-width: 640px) {
        #section-add-bidding-transaction .bid-source-grid {
          grid-template-columns: 1fr;
        }
      }
    </style>

    <div class="bid-source-grid" <?php echo ($is_edit_mode || $is_reopen_mode) ? 'style="display:none;"' : ''; ?>>
      <button type="button" class="bid-source-btn" id="bidSrcTabCrop" onclick="switchBidSource('crop')">
        <i class="fas fa-seedling" style="margin-right:0.35rem;"></i>From Manage Crops
      </button>
      <button type="button" class="bid-source-btn" id="bidSrcTabManual" onclick="switchBidSource('manual')">
        <i class="fas fa-pen" style="margin-right:0.35rem;"></i>Manual Entry
      </button>
    </div>

    <form id="bidFromCropForm" method="post" action="admin_dashboard.php?section=bidding-monitor" class="schedule-form bid-source-form" <?php echo ($is_edit_mode || $is_reopen_mode) ? 'style="display:block;"' : ''; ?>>
      <input type="hidden" name="_redirect" value="bidding-monitor">
      <input type="hidden" name="action" value="<?php echo $is_reopen_mode ? 'reopen_crop_bidding' : ($is_edit_mode ? 'update_crop_bidding_lot' : 'create_crop_bidding_lot'); ?>">
      <?php if ($is_edit_mode || $is_reopen_mode): ?>
      <input type="hidden" name="crop_id" value="<?php echo (int)($is_reopen_mode ? $reopen_crop_id : $edit_crop_id); ?>">
      <?php endif; ?>

      <div class="form-grid">
        <label class="form-field" style="grid-column:1/-1;">Select Crop from Inventory
          <select name="source_crop_id" id="bscCropSelect" onchange="updateBidCropMax()" required <?php echo ($is_edit_mode || $is_reopen_mode) ? 'disabled' : ''; ?>>
            <option value="">-- choose a crop --</option>
            <?php if (($is_edit_mode || $is_reopen_mode) && $edit_crop): ?>
            <option value="<?php echo (int)$edit_crop['crop_id']; ?>" selected><?php echo htmlspecialchars($edit_crop['crop_name']); ?> - <?php echo htmlspecialchars($edit_crop['owner_name']); ?> (current lot)</option>
            <?php endif; ?>
            <?php foreach ($inventory_crops as $ic): ?>
            <option
              value="<?php echo (int)$ic['crop_id']; ?>"
              data-qty="<?php echo htmlspecialchars((string)$ic['crop_quantity'], ENT_QUOTES); ?>"
              data-unit="<?php echo htmlspecialchars($ic['crop_unit'], ENT_QUOTES); ?>"
            >
              <?php echo htmlspecialchars($ic['crop_name']); ?>
              - <?php echo htmlspecialchars($ic['owner_name']); ?>
              (<?php echo number_format((float)$ic['crop_quantity'], 2); ?> <?php echo htmlspecialchars($ic['crop_unit']); ?> available)
            </option>
            <?php endforeach; ?>
            <?php if (empty($inventory_crops)): ?>
            <option value="" disabled>No inventory crops available</option>
            <?php endif; ?>
          </select>
        </label>


        <label class="form-field">Bidding Quantity (kg)
          <input type="number" name="bid_quantity" id="bscBidQty" min="0.01" step="0.01" placeholder="e.g. 50" value="<?php echo htmlspecialchars((string)($edit_crop['crop_quantity'] ?? ''), ENT_QUOTES); ?>" required>
        </label>

        <label class="form-field">Starting Price (PHP)
          <input type="number" name="starting_price" min="0.01" step="0.01" placeholder="e.g. 5000" value="<?php echo htmlspecialchars((string)($edit_crop['starting_price'] ?? ''), ENT_QUOTES); ?>" required>
        </label>

        <label class="form-field" style="grid-column:1/-1;">Bidding Ends
          <input type="datetime-local" name="bidding_end_date" min="<?php echo date('Y-m-d\\TH:i', strtotime('+1 hour')); ?>" value="<?php echo !empty($edit_crop['bidding_end_date']) ? date('Y-m-d\\TH:i', strtotime((string)$edit_crop['bidding_end_date'])) : ''; ?>" required>
        </label>
      </div>

      <div class="form-actions-inline" style="margin-top:0.5rem;">
        <button type="button" class="btn-secondary" onclick="showSection('bidding-monitor')">Cancel</button>
        <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
          <span><?php echo $is_reopen_mode ? 'Reopen Bidding' : ($is_edit_mode ? 'Save Changes' : 'Add to Bidding'); ?></span>
        </button>
      </div>
    </form>

    <form id="bidManualForm" method="post" action="admin_dashboard.php?section=bidding-monitor" class="schedule-form bid-source-form" <?php echo ($is_edit_mode || $is_reopen_mode) ? 'style="display:none;"' : ''; ?>>
      <input type="hidden" name="action" value="add_manual_bid_product">

      <div class="form-grid">
        <label class="form-field">Crop Name
          <input type="text" name="crop_name" maxlength="255" placeholder="e.g. White Corn" required>
        </label>

        <label class="form-field">Farmer / Owner Name
          <input type="text" name="farmer_name" maxlength="255" placeholder="e.g. Juan Dela Cruz" required>
        </label>

        <label class="form-field">Starting Price (PHP)
          <input type="number" name="starting_price" min="0.01" step="0.01" placeholder="e.g. 5000" required>
        </label>

        <label class="form-field">Quantity
          <input type="number" name="bid_quantity" min="0.01" step="0.01" placeholder="e.g. 50" required>
        </label>

        <label class="form-field">Unit
          <select name="crop_unit" required>
            <option value="kg">kg</option>
            <option value="bags">bags</option>
            <option value="sacks">sacks</option>
            <option value="crates">crates</option>
            <option value="pcs">pcs</option>
            <option value="heads">heads</option>
            <option value="trays">trays</option>
            <option value="ears">ears</option>
            <option value="bundles">bundles</option>
          </select>
        </label>

        <label class="form-field" style="grid-column:1/-1;">Bidding Ends
          <input type="datetime-local" name="bidding_end_date" min="<?php echo date('Y-m-d\\TH:i', strtotime('+1 hour')); ?>" required>
        </label>
      </div>

      <div class="form-actions-inline" style="margin-top:0.5rem;">
        <button type="button" class="btn-secondary" onclick="showSection('bidding-monitor')">Cancel</button>
        <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
          <i class="fas fa-plus"></i>
          <span>Add Crop</span>
        </button>
      </div>
    </form>
  </div>
</section>

<script>
function setBidSourceTabState(active) {
  const tabCrop = document.getElementById('bidSrcTabCrop');
  const tabManual = document.getElementById('bidSrcTabManual');
  if (!tabCrop || !tabManual) return;

  tabCrop.classList.toggle('is-active', active === 'crop');
  tabManual.classList.toggle('is-active', active === 'manual');
}

function switchBidSource(source) {
  const cropForm = document.getElementById('bidFromCropForm');
  const manualForm = document.getElementById('bidManualForm');
  const prompt = document.getElementById('bidSourcePrompt');
  if (!cropForm || !manualForm) return;

  if (source === 'crop') {
    cropForm.style.display = 'block';
    manualForm.style.display = 'none';
    if (prompt) prompt.style.display = 'none';
    setBidSourceTabState('crop');
    updateBidCropMax();
    return;
  }

  if (source === 'manual') {
    cropForm.style.display = 'none';
    manualForm.style.display = 'block';
    if (prompt) prompt.style.display = 'none';
    setBidSourceTabState('manual');
  }
}

function updateBidCropMax() {
  const sel = document.getElementById('bscCropSelect');
  const opt = sel ? sel.options[sel.selectedIndex] : null;
  const qty = opt ? (parseFloat(opt.dataset.qty) || 0) : 0;
  const unit = opt ? (opt.dataset.unit || '') : '';
  const inp = document.getElementById('bscBidQty');
  const lbl = document.getElementById('bscUnitLabel');
  if (inp) {
    inp.max = qty > 0 ? qty : '';
    inp.value = '';
  }
  if (lbl) lbl.textContent = unit ? '(' + unit + ')' : '';
}
</script>