<?php
$farmer_id = (int)($_GET['farmer_id'] ?? 0);

if ($farmer_id <= 0) {
  echo "<section id='section-farmer-seed-history' class='admin-section'>";
  echo "<div class='section-header'><h1>Farmer Seed History</h1></div>";
  echo "<p>Invalid farmer selected.</p>";
  echo "</section>";
  return;
}

$farmer_info = null;
$farmer_stmt = $conn->prepare(
  "SELECT f.farmer_id, f.farmer_fullname, f.farmer_farm_name, COALESCE(u.email, '-') AS farmer_email
   FROM farmers f
   LEFT JOIN users u ON f.user_id = u.user_id
   WHERE f.farmer_id = ?
   LIMIT 1"
);

if ($farmer_stmt) {
  $farmer_stmt->bind_param('i', $farmer_id);
  $farmer_stmt->execute();
  $farmer_result = $farmer_stmt->get_result();
  if ($farmer_result && $farmer_result->num_rows > 0) {
    $farmer_info = $farmer_result->fetch_assoc();
  }
  $farmer_stmt->close();
}

if (!$farmer_info) {
  echo "<section id='section-farmer-seed-history' class='admin-section'>";
  echo "<div class='section-header'><h1>Farmer Seed History</h1></div>";
  echo "<p>Farmer not found.</p>";
  echo "</section>";
  return;
}

$seed_rows = [];
$total_quantity = 0.0;
$last_distribution = '';

$seed_dist_check = $conn->query("SHOW TABLES LIKE 'seed_distributions'");
$seed_inv_check = $conn->query("SHOW TABLES LIKE 'seed_inventory'");
$seed_tables_ready =
  ($seed_dist_check && $seed_dist_check->num_rows > 0) &&
  ($seed_inv_check && $seed_inv_check->num_rows > 0);

if ($seed_tables_ready) {
  $history_stmt = $conn->prepare(
    "SELECT sd.distribution_id, sd.quantity_distributed, sd.distribution_date, sd.status, sd.notes,
            si.seed_name, si.seed_unit
     FROM seed_distributions sd
     JOIN seed_inventory si ON sd.seed_id = si.seed_id
     WHERE sd.farmer_id = ?
     ORDER BY sd.distribution_date DESC, sd.distribution_id DESC"
  );

  if ($history_stmt) {
    $history_stmt->bind_param('i', $farmer_id);
    $history_stmt->execute();
    $history_result = $history_stmt->get_result();

    if ($history_result) {
      while ($history_row = $history_result->fetch_assoc()) {
        $seed_rows[] = $history_row;
        $row_quantity = (float)($history_row['quantity_distributed'] ?? 0);
        $total_quantity += $row_quantity;
        $row_date = (string)($history_row['distribution_date'] ?? '');
        if ($row_date !== '' && ($last_distribution === '' || $row_date > $last_distribution)) {
          $last_distribution = $row_date;
        }
      }
    }

    $history_stmt->close();
  }
}

$last_distribution_label = 'N/A';
if ($last_distribution !== '') {
  $last_distribution_label = date('M d, Y', strtotime($last_distribution));
}
?>

<section id="section-farmer-seed-history" class="admin-section">
  <div class="section-header">
    <div style="display:flex; align-items:center; gap:1rem;">
      <button type="button" class="btn-tertiary" onclick="showSection('verify-farmers')" data-tooltip="Back to Farmer Accounts">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1>Distributed Seeds</h1>
    </div>
  </div>

  <div class="form-container" style="width:100%;margin:0 0 1rem 0;">
    <div style="padding: 1rem 1.25rem; background: rgba(40, 167, 69, 0.05); border-radius: 8px; border-left: 4px solid #28a745;">
      <p style="margin: 0 0 6px;"><strong>Farmer:</strong> <?php echo htmlspecialchars((string)$farmer_info['farmer_fullname']); ?></p>
      <p style="margin: 0 0 6px;"><strong>Farm:</strong> <?php echo htmlspecialchars((string)($farmer_info['farmer_farm_name'] ?? '-')); ?></p>
      <p style="margin: 0;"><strong>Email:</strong> <?php echo htmlspecialchars((string)($farmer_info['farmer_email'] ?? '-')); ?></p>
    </div>
  </div>

  <div class="dashboard-stats" style="margin-bottom: 1rem;">
    <div class="stat-card">
      <div class="stat-content">
        <h3>Total Releases</h3>
        <p class="stat-number"><?php echo count($seed_rows); ?></p>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-content">
        <h3>Total Quantity</h3>
        <p class="stat-number"><?php echo number_format($total_quantity, 2); ?></p>
      </div>
    </div>
    <div class="stat-card">
      <div class="stat-content">
        <h3>Last Distribution</h3>
        <p class="stat-number" style="font-size:1.2rem;"><?php echo htmlspecialchars($last_distribution_label); ?></p>
      </div>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="farmerSeedHistorySearch">Search</label>
      <input type="text" id="farmerSeedHistorySearch" placeholder="Search seed type..." class="search-input" onkeyup="filterTable('farmerSeedHistory')">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="farmerSeedHistoryStatus">Status</label>
      <select class="filter-select" id="farmerSeedHistoryStatus" onchange="filterTable('farmerSeedHistory')">
        <option value="">All Status</option>
        <option value="released">Released</option>
        <option value="received">Received</option>
        <option value="cancelled">Cancelled</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="farmerSeedHistoryGroupBy">Group By</label>
      <select class="filter-select" id="farmerSeedHistoryGroupBy" onchange="sfSetGroupBy('farmerSeedHistoryTable', this); filterTable('farmerSeedHistory')">
        <option value="">No Grouping</option>
        <option value="5">Status</option>
        <option value="1">Seed Type</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="farmerSeedHistoryTable">
      <thead>
        <tr>
          <th>Distribution ID</th>
          <th>Seed Type</th>
          <th>Quantity</th>
          <th>Unit</th>
          <th>Date</th>
          <th>Status</th>
          <th>Notes</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($seed_rows)): ?>
          <?php foreach ($seed_rows as $seed_row): ?>
            <?php
              $status_raw = (string)($seed_row['status'] ?? 'Released');
              $status_class = strtolower($status_raw);
              $distribution_date = (string)($seed_row['distribution_date'] ?? '');
              $distribution_label = $distribution_date !== '' ? date('M d, Y', strtotime($distribution_date)) : '-';
            ?>
            <tr>
              <td>#DIST<?php echo str_pad((string)((int)($seed_row['distribution_id'] ?? 0)), 4, '0', STR_PAD_LEFT); ?></td>
              <td><?php echo htmlspecialchars((string)($seed_row['seed_name'] ?? '-')); ?></td>
              <td><?php echo number_format((float)($seed_row['quantity_distributed'] ?? 0), 2); ?></td>
              <td><?php echo htmlspecialchars((string)($seed_row['seed_unit'] ?? '-')); ?></td>
              <td><?php echo htmlspecialchars($distribution_label); ?></td>
              <td><span class="status <?php echo htmlspecialchars($status_class); ?>"><?php echo htmlspecialchars($status_raw); ?></span></td>
              <td><?php echo htmlspecialchars((string)($seed_row['notes'] ?? '-')); ?></td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" style="text-align:center; padding:20px; color:#8b968b;">No seed distribution records for this farmer yet.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
