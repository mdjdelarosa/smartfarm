<?php
$crop_id = (int)($_GET['crop_id'] ?? $_POST['crop_id'] ?? 0);
$from_param = trim((string)($_GET['from'] ?? $_POST['from'] ?? 'bidding-monitor'));
$success_msg = '';
$error_msg = '';

if ($crop_id <= 0) {
  echo "<section id='section-view-bidding-transaction' class='admin-section'>";
  echo "<div class='section-header'><h1>Bidding Details</h1></div>";
  echo "<p>Invalid bidding transaction.</p>";
  echo "</section>";
  return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array(($_POST['action'] ?? ''), ['update_transaction_from_view', 'update_payment_from_view'], true)) {
  $post_action = (string)($_POST['action'] ?? '');
  $post_crop_id = (int)($_POST['crop_id'] ?? 0);
  $status = strtolower(trim((string)($_POST['status'] ?? '')));
  $payment_status = strtolower(trim((string)($_POST['payment_status'] ?? '')));

  $allowed_status = ['available', 'sold', 'expired', 'claimed', 'returned'];
  $allowed_payment = ['unpaid', 'paid'];

  if ($post_crop_id !== $crop_id || $crop_id <= 0) {
    $error_msg = 'Invalid bidding record selected.';
  } else {
    if ($post_action === 'update_transaction_from_view') {
      if (!in_array($status, $allowed_status, true)) {
        $error_msg = 'Invalid transaction status selected.';
      } else {
        $lot_stmt = $conn->prepare(
          "SELECT crop_status, crop_quantity, source_crop_id, inventory_deducted_on_claim
           FROM crops
           WHERE crop_id = ?
           LIMIT 1"
        );

        if (!$lot_stmt) {
          $error_msg = 'Unable to load bidding transaction details.';
        } else {
          $lot_stmt->bind_param('i', $crop_id);
          $lot_stmt->execute();
          $lot_result = $lot_stmt->get_result();
          $lot_row = $lot_result ? $lot_result->fetch_assoc() : null;
          $lot_stmt->close();

          if (!$lot_row) {
            $error_msg = 'Bidding transaction not found.';
          } else {
            $old_status = strtolower((string)($lot_row['crop_status'] ?? ''));
            $lot_quantity = (float)($lot_row['crop_quantity'] ?? 0);
            $source_crop_id = (int)($lot_row['source_crop_id'] ?? 0);
            $is_deducted = ((int)($lot_row['inventory_deducted_on_claim'] ?? 0) === 1);

            if ($old_status === $status) {
              $success_msg = 'No changes were detected, but the form was submitted successfully.';
            } else {
              $next_deducted_flag = $is_deducted ? 1 : 0;
              $is_claim_transition = ($status === 'claimed' && $source_crop_id > 0 && !$is_deducted);
              $is_return_transition = ($old_status === 'claimed' && $status === 'returned' && $source_crop_id > 0 && $is_deducted);

              $conn->begin_transaction();
              try {
                if ($is_claim_transition) {
                  $deduct_stmt = $conn->prepare(
                    "UPDATE crops
                     SET crop_quantity = crop_quantity - ?
                     WHERE crop_id = ? AND crop_quantity >= ?"
                  );
                  if (!$deduct_stmt) {
                    throw new Exception('Failed to prepare source crop deduction update.');
                  }

                  $deduct_stmt->bind_param('did', $lot_quantity, $source_crop_id, $lot_quantity);
                  if (!$deduct_stmt->execute() || $deduct_stmt->affected_rows === 0) {
                    $deduct_stmt->close();
                    throw new Exception('Unable to mark as claimed because source crop stock is insufficient.');
                  }
                  $deduct_stmt->close();
                  $next_deducted_flag = 1;
                }

                if ($is_return_transition) {
                  $restore_stmt = $conn->prepare(
                    "UPDATE crops
                     SET crop_quantity = crop_quantity + ?
                     WHERE crop_id = ?"
                  );
                  if (!$restore_stmt) {
                    throw new Exception('Failed to prepare source crop restoration update.');
                  }

                  $restore_stmt->bind_param('di', $lot_quantity, $source_crop_id);
                  if (!$restore_stmt->execute() || $restore_stmt->affected_rows === 0) {
                    $restore_stmt->close();
                    throw new Exception('Failed to return quantity to source crop.');
                  }
                  $restore_stmt->close();
                  $next_deducted_flag = 0;
                }

                $update_stmt = $conn->prepare(
                  "UPDATE crops
                   SET crop_status = ?, inventory_deducted_on_claim = ?
                   WHERE crop_id = ?"
                );
                if (!$update_stmt) {
                  throw new Exception('Failed to prepare bidding transaction update.');
                }

                $update_stmt->bind_param('sii', $status, $next_deducted_flag, $crop_id);
                if (!$update_stmt->execute()) {
                  $update_stmt->close();
                  throw new Exception('Failed to update bidding transaction.');
                }
                $update_stmt->close();

                $conn->commit();
                $success_msg = 'Transaction details updated successfully.';
              } catch (Exception $e) {
                $conn->rollback();
                $error_msg = $e->getMessage();
              }
            }
          }
        }
      }
    } elseif ($post_action === 'update_payment_from_view') {
      if (!in_array($payment_status, $allowed_payment, true)) {
        $error_msg = 'Invalid payment status selected.';
      } elseif ($payment_status === 'paid') {
        $payment_marked_at = date('Y-m-d H:i:s');
        $stmt = $conn->prepare(
          "UPDATE crops
           SET payment_status = ?, payment_marked_at = ?
           WHERE crop_id = ?"
        );
        if ($stmt) {
          $stmt->bind_param('ssi', $payment_status, $payment_marked_at, $crop_id);
        }
      } else {
        $stmt = $conn->prepare(
          "UPDATE crops
           SET payment_status = ?, payment_marked_at = NULL
           WHERE crop_id = ?"
        );
        if ($stmt) {
          $stmt->bind_param('si', $payment_status, $crop_id);
        }
      }

      if ($error_msg !== '') {
        // Validation failed.
      } elseif (!isset($stmt) || !$stmt) {
        $error_msg = 'Unable to prepare bidding update.';
      } elseif ($stmt->execute()) {
        $success_msg = 'Payment status updated successfully.';
        if ($stmt->affected_rows === 0) {
          $success_msg = 'No changes were detected, but the form was submitted successfully.';
        }
        $stmt->close();
      } else {
        $error_msg = 'Failed to update bidding transaction.';
        $stmt->close();
      }
    }
  }
}

$stmt = $conn->prepare(
  "SELECT
      c.crop_id,
      c.crop_name,
      c.crop_quantity,
      c.crop_unit,
      c.starting_price,
      c.crop_status,
      COALESCE(c.payment_status, 'unpaid') AS payment_status,
      c.payment_marked_at,
      c.bidding_end_date,
      c.created_at,
      (
        SELECT COALESCE(cl.client_fullname, 'No bids yet')
        FROM bids b2
        LEFT JOIN clients cl ON cl.client_id = b2.client_id
        WHERE b2.crop_id = c.crop_id
        ORDER BY (b2.bid_status = 'won') DESC, b2.bid_amount DESC, b2.created_at ASC, b2.bid_id ASC
        LIMIT 1
      ) AS bidder_client_name,
      (
        SELECT MAX(b.bid_amount)
        FROM bids b
        WHERE b.crop_id = c.crop_id
      ) AS highest_bid,
      (
        SELECT COUNT(*)
        FROM bids b
        WHERE b.crop_id = c.crop_id
      ) AS bid_count
  FROM crops c
   WHERE c.crop_id = ?
   LIMIT 1"
);

$stmt->bind_param('i', $crop_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
  echo "<section id='section-view-bidding-transaction' class='admin-section'>";
  echo "<div class='section-header'><h1>Bidding Details</h1></div>";
  echo "<p>Bidding transaction not found.</p>";
  echo "</section>";
  return;
}

$status_map = [
  'available' => ['label' => 'Ongoing', 'class' => 'pending'],
  'sold' => ['label' => 'Sold', 'class' => 'completed'],
  'expired' => ['label' => 'Ended', 'class' => 'cancelled'],
  'claimed' => ['label' => 'Claimed', 'class' => 'completed'],
  'returned' => ['label' => 'Returned', 'class' => 'returned']
];

$status_key = strtolower((string)$row['crop_status']);
if (!isset($status_map[$status_key])) {
  $status_key = 'expired';
}

$status_label = $status_map[$status_key]['label'];
$payment_key = strtolower((string)$row['payment_status']) === 'paid' ? 'paid' : 'unpaid';
$payment_label = $payment_key === 'paid' ? 'Paid' : 'Unpaid';

$bid_id_label = '#BIDC' . str_pad((string)$crop_id, 4, '0', STR_PAD_LEFT);
$created_at_text = '-';
if (!empty($row['created_at'])) {
  $created_at_text = date('F j, Y h:i A', strtotime((string)$row['created_at']));
}

$bidding_end_text = '-';
if (!empty($row['bidding_end_date'])) {
  $bidding_end_text = date('F j, Y h:i A', strtotime((string)$row['bidding_end_date']));
}

$payment_marked_at_text = '-';
if (!empty($row['payment_marked_at'])) {
  $payment_marked_at_text = date('F j, Y h:i A', strtotime((string)$row['payment_marked_at']));
}

$quantity_text = number_format((float)$row['crop_quantity'], 2) . ' ' . (string)$row['crop_unit'];
$starting_price_text = 'P' . number_format((float)$row['starting_price'], 2);
$highest_bid_amount = $row['highest_bid'] !== null ? (float)$row['highest_bid'] : (float)$row['starting_price'];
$highest_bid_text = 'P' . number_format($highest_bid_amount, 2);
$bid_count_text = (int)$row['bid_count'] . ' bid(s)';
$bidder_name = trim((string)($row['bidder_client_name'] ?? '')) !== '' ? (string)$row['bidder_client_name'] : 'No bids yet';
$avatar_letter = strtoupper(substr($bidder_name, 0, 1));
?>

<section id="section-view-bidding-transaction" class="admin-section">
  <div class="section-header sf-account-header">
    <div class="sf-account-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>')" data-tooltip="Back to list">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Bidding Details</h1>
        <p>Review bidding timeline, bidder info, and payment status.</p>
      </div>
    </div>
  </div>

  <?php if ($success_msg !== ''): ?>
    <div class="alert-success alert-message" style="margin-bottom:10px;">
      <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <?php if ($error_msg !== ''): ?>
    <div class="alert-error alert-message" style="margin-bottom:10px;">
      <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <div class="form-container sf-account-shell" style="width:100%;margin:0;">
    <div id="biddingView" class="admin-form">

      <section class="sf-summary-card">
        <div class="sf-summary-main">
          <div class="sf-summary-identity">
            <div class="sf-avatar"><?php echo htmlspecialchars($avatar_letter, ENT_QUOTES, 'UTF-8'); ?></div>
            <div>
              <h2><?php echo htmlspecialchars($bidder_name, ENT_QUOTES, 'UTF-8'); ?></h2>
              <p><?php echo htmlspecialchars((string)($row['crop_name'] ?: '-'), ENT_QUOTES, 'UTF-8'); ?></p>
            </div>
          </div>

          <div class="sf-pill-row">
            <span id="mode-chip" class="sf-mode-chip view">Viewing</span>
          </div>
        </div>

        <div class="sf-summary-meta">
          <div><span>Bid</span><strong><?php echo htmlspecialchars($bid_id_label, ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div><span>Created</span><strong><?php echo htmlspecialchars($created_at_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div><span>Payment Marked</span><strong><?php echo htmlspecialchars($payment_marked_at_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div><span>Bids</span><strong><?php echo htmlspecialchars($bid_count_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
        </div>
      </section>

      <div class="sf-content-grid">
        <section class="sf-panel">
          <h3>Bidding Information</h3>
          <div class="sf-field-grid">
            <div class="sf-field">
              <label>Crop</label>
              <span class="sf-field-value"><?php echo htmlspecialchars((string)$row['crop_name'], ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Quantity</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($quantity_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Starting Price</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($starting_price_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Highest Bid</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($highest_bid_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Bidding End Date</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($bidding_end_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
          </div>
        </section>

        <section class="sf-panel sf-update-panel">
          <h3>Update Bidding</h3>

          <div class="sf-action-bar">
            <button type="button" class="btn-primary" onclick="openTransactionEditor()">
              <i class="fas fa-pen"></i>
              Update Transaction
            </button>
            <button type="button" class="btn-secondary" onclick="openPaymentEditor()">
              <i class="fas fa-credit-card"></i>
              Update<br>Payment
            </button>
          </div>

          <div id="update-view-readonly" class="sf-inline-view">
            <div class="sf-field-grid sf-field-grid-single">
              <div class="sf-field">
                <label>Transaction Status</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($status_label, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>

              <div class="sf-field">
                <label>Payment Status</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($payment_label, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
            </div>
          </div>

          <div id="update-view-transaction" class="sf-inline-view sf-hidden">
            <div class="sf-inline-head">
              <h4>Transaction Update</h4>
              <button type="button" class="btn-tertiary" onclick="backToUpdateSummary()">Cancel</button>
            </div>
            <form method="post" id="transaction-update-form" class="sf-manage-form">
              <input type="hidden" name="action" value="update_transaction_from_view">
              <input type="hidden" name="crop_id" value="<?php echo (int)$crop_id; ?>">
              <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>">

              <div class="sf-field">
                <label for="transaction-status-input">Transaction Status</label>
                <select id="transaction-status-input" name="status" class="sf-field-input" data-initial="<?php echo htmlspecialchars($status_key, ENT_QUOTES, 'UTF-8'); ?>">
                  <option value="available" <?php echo $status_key === 'available' ? 'selected' : ''; ?>>Ongoing</option>
                  <option value="sold" <?php echo $status_key === 'sold' ? 'selected' : ''; ?>>Sold</option>
                  <option value="expired" <?php echo $status_key === 'expired' ? 'selected' : ''; ?>>Ended</option>
                  <option value="claimed" <?php echo $status_key === 'claimed' ? 'selected' : ''; ?>>Claimed</option>
                  <option value="returned" <?php echo $status_key === 'returned' ? 'selected' : ''; ?>>Returned</option>
                </select>
              </div>

              <button type="submit" class="btn-primary">Save Transaction Update</button>
            </form>
          </div>

          <div id="update-view-payment" class="sf-inline-view sf-hidden">
            <div class="sf-inline-head">
              <h4>Payment Update</h4>
              <button type="button" class="btn-tertiary" onclick="backToUpdateSummary()">Cancel</button>
            </div>
            <form method="post" id="payment-update-form" class="sf-manage-form">
              <input type="hidden" name="action" value="update_payment_from_view">
              <input type="hidden" name="crop_id" value="<?php echo (int)$crop_id; ?>">
              <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>">
              <div class="sf-field">
                <label for="payment-status-input">Payment Status</label>
                <select id="payment-status-input" name="payment_status" class="sf-field-input" data-initial="<?php echo htmlspecialchars($payment_key, ENT_QUOTES, 'UTF-8'); ?>">
                  <option value="unpaid" <?php echo $payment_key === 'unpaid' ? 'selected' : ''; ?>>Unpaid</option>
                  <option value="paid" <?php echo $payment_key === 'paid' ? 'selected' : ''; ?>>Paid</option>
                </select>
              </div>

              <div class="sf-field">
                <label>Current Payment Marked</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($payment_marked_at_text, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>

              <button type="submit" class="btn-primary">Save Payment Update</button>
            </form>
          </div>
        </section>
      </div>
    </div>
  </div>
</section>

<style>
.sf-account-header {
  margin-bottom: 16px;
}

.sf-account-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.sf-account-shell {
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 14px;
  background: #f7fbf8;
  box-shadow: 0 6px 18px rgba(23, 66, 38, 0.08);
  padding: 18px;
  width: 100%;
  max-width: none !important;
  display: grid;
  gap: 18px;
}

.sf-summary-card {
  background: #ffffff;
  border: 1px solid #d9e7de;
  border-radius: 14px;
  padding: 16px;
  display: grid;
  grid-template-columns: minmax(360px, 1fr) minmax(620px, 2fr);
  align-items: start;
  gap: 16px;
}

.sf-summary-main {
  display: grid;
  gap: 10px;
  min-width: 0;
}

.sf-summary-identity {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.sf-avatar {
  width: 46px;
  height: 46px;
  border-radius: 999px;
  background: linear-gradient(135deg, #1f9b58, #088d62);
  color: #fff;
  font-weight: 700;
  font-size: 1.45rem;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.sf-summary-identity h2 {
  margin: 0;
  font-size: 1.1rem;
  color: #184f2f;
  line-height: 1.2;
}

.sf-summary-identity p {
  margin: 2px 0 0;
  color: #5f7565;
  font-size: 0.95rem;
  word-break: break-word;
}

.sf-pill-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.sf-mode-chip {
  display: inline-flex;
  align-items: center;
  font-weight: 700;
  font-size: 0.78rem;
  border-radius: 999px;
  padding: 6px 10px;
  letter-spacing: 0.02em;
}

.sf-mode-chip.view {
  color: #155724;
  background: rgba(40, 167, 69, 0.16);
}

.sf-summary-meta {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
}

.sf-summary-meta div {
  border: 1px solid #d8e4dc;
  border-radius: 10px;
  padding: 10px;
  background: #f7fbf8;
  min-width: 0;
}

.sf-summary-meta span {
  display: block;
  font-size: 0.75rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  color: #607565;
  margin-bottom: 4px;
  font-weight: 700;
}

.sf-summary-meta strong {
  color: #294f37;
  line-height: 1.25;
  word-break: break-word;
}

.sf-content-grid {
  display: grid;
  grid-template-columns: minmax(600px, 2fr) minmax(300px, 1fr);
  gap: 14px;
  align-items: start;
}

.sf-panel {
  border: 1px solid #cde5d8;
  border-radius: 14px;
  background: #fff;
  padding: 14px;
}

.sf-panel h3 {
  margin: 0 0 8px;
  color: #1d5a34;
}

.sf-action-bar {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: stretch;
  gap: 10px;
  margin-bottom: 14px;
}

.sf-field-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.sf-field-grid-single {
  grid-template-columns: 1fr;
}

.sf-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sf-field label {
  font-weight: 700;
  font-size: 0.8rem;
  color: #45624f;
}

.sf-field-value {
  min-height: 36px;
  border: 1px solid #d9e4dd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #f8fcf9;
  display: block;
  line-height: 1.35;
}

.sf-field-input {
  width: 100%;
  border: 1px solid #c7d6cd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #fff;
  outline: none;
}

.sf-field-input:focus {
  border-color: #00a86b;
  box-shadow: 0 0 0 3px rgba(0, 168, 107, 0.15);
}

.sf-inline-view {
  margin-top: 12px;
}

.sf-inline-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
}

.sf-inline-head h4 {
  margin: 0;
  color: #1f5c37;
}

.sf-action-bar button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
}

.sf-manage-form {
  border: 1px solid #dce8df;
  border-radius: 12px;
  padding: 12px;
  background: #fbfefd;
  display: grid;
  gap: 10px;
}

.sf-hidden {
  display: none !important;
}

@media (max-width: 1280px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
    align-items: flex-start;
  }

  .sf-summary-meta {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1080px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
  }

  .sf-content-grid {
    grid-template-columns: 1fr;
  }

  .sf-summary-meta {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .sf-field-grid {
    grid-template-columns: 1fr;
  }

  .sf-account-shell {
    padding: 12px;
  }

  .sf-panel {
    padding: 12px;
  }

  .sf-summary-meta div {
    min-width: 100%;
  }
}
</style>

<script>
function setUpdateView(viewKey) {
  const sections = {
    readonly: document.getElementById('update-view-readonly'),
    transaction: document.getElementById('update-view-transaction'),
    payment: document.getElementById('update-view-payment')
  };

  Object.keys(sections).forEach(function (key) {
    if (sections[key]) {
      sections[key].classList.add('sf-hidden');
    }
  });

  if (sections[viewKey]) {
    sections[viewKey].classList.remove('sf-hidden');
  }
}

function openTransactionEditor() {
  setUpdateView('transaction');
}

function openPaymentEditor() {
  setUpdateView('payment');
}

function backToUpdateSummary() {
  setUpdateView('readonly');
}

function statusLabelMap(value) {
  const map = {
    available: 'Ongoing',
    sold: 'Sold',
    expired: 'Ended',
    claimed: 'Claimed',
    returned: 'Returned'
  };
  return map[value] || value;
}

function paymentLabelMap(value) {
  return value === 'paid' ? 'Paid' : 'Unpaid';
}

document.addEventListener('DOMContentLoaded', function () {
  const transactionForm = document.getElementById('transaction-update-form');
  const paymentForm = document.getElementById('payment-update-form');

  if (transactionForm) {
    transactionForm.addEventListener('submit', function (event) {
      const statusInput = document.getElementById('transaction-status-input');
      const oldStatus = (statusInput?.dataset.initial || '').trim();
      const newStatus = (statusInput?.value || '').trim();

      if (oldStatus === newStatus) {
        event.preventDefault();
        window.alert('No changes detected in Transaction Update.');
        return;
      }

      const message = 'Confirm transaction update:\n- Transaction Status: ' + statusLabelMap(oldStatus) + ' -> ' + statusLabelMap(newStatus);
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  }

  if (paymentForm) {
    paymentForm.addEventListener('submit', function (event) {
      const paymentInput = document.getElementById('payment-status-input');
      const oldPayment = (paymentInput?.dataset.initial || '').trim();
      const newPayment = (paymentInput?.value || '').trim();

      if (oldPayment === newPayment) {
        event.preventDefault();
        window.alert('No changes detected in Payment Update.');
        return;
      }

      const message = 'Confirm payment update:\n- Payment Status: ' + paymentLabelMap(oldPayment) + ' -> ' + paymentLabelMap(newPayment);
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  }

  setUpdateView('readonly');
});
</script>
