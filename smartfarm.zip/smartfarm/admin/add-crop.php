<?php
$farmer_options = [];
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-add-crop" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('manage-crops')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Add Crop Record</h1>
        <p>Adds stock to an existing crop record if the same name and unit already exists.</p>
      </div>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <form method="post" action="admin_dashboard.php?section=manage-crops" class="schedule-form">
      <input type="hidden" name="action" value="add_crop_record">
      <div class="form-grid">
        <label class="form-field">Crop Name
          <input type="text" name="crop_name" maxlength="255" placeholder="e.g. Corn" required>
        </label>

        <label class="form-field">Available Quantity
          <input type="number" name="crop_quantity" min="0.01" step="0.01" placeholder="e.g. 250" required>
        </label>

        <label class="form-field">Market Price per Unit (PHP)
          <input type="number" name="market_price_per_unit" min="0.01" step="0.01" placeholder="e.g. 48.50" required>
        </label>

        <label class="form-field">Unit
          <select name="crop_unit" required>
            <option value="kg">kg</option>
            <option value="g">g</option>
            <option value="ton">ton</option>
          </select>
        </label>

        <label class="form-field" style="grid-column: 1 / -1;">Description
          <textarea name="crop_description" rows="3" maxlength="500" placeholder="Optional crop details"></textarea>
        </label>
      </div>

      <div class="form-actions-inline" style="margin-top:1rem;">
        <button type="button" class="btn-secondary" onclick="showSection('manage-crops')">Cancel</button>
        <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
          <i class="fas fa-plus"></i>
          <span>Save / Add Quantity</span>
        </button>
      </div>
    </form>
  </div>
</section>
