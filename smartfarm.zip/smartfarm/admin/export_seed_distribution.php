<?php
// admin/export_seed_distribution.php
// Generates a CSV for seed distribution records
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="seed_distribution.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'distribution_id', 'farmer_id', 'seed_id', 'seed_name', 'quantity', 'unit', 'distributed_by', 'distributed_at', 'remarks'
]);

$q = $conn->query("SELECT distribution_id, farmer_id, seed_id, seed_name, quantity, unit, distributed_by, distributed_at, remarks FROM seed_distribution");
if ($q) {
    while ($row = $q->fetch_assoc()) {
        fputcsv($out, $row);
    }
}
fclose($out);
exit;
