<?php
require_once __DIR__ . '/../config.php';

$user_id = (int)($_GET['user_id'] ?? 0);
$from_param = $_GET['from'] ?? 'manage-admins';
$action = $_GET['action'] ?? 'view'; // view, edit, approve

if ($user_id <= 0) {
    echo "<p>Invalid user.</p>";
    return;
}

$sql = "SELECT u.user_id, u.email, u.role, u.is_active, u.created_at,
               a.fullname AS admin_fullname,
               f.farmer_id, f.farmer_fullname, f.farmer_contact_number, f.farmer_farm_name,
               f.farmer_address, f.farm_address, f.farmer_id_type, f.farmer_id_file_name,
               f.farmer_id_verification_status,
               c.client_id, c.client_fullname, c.client_contact_number, c.client_address,
               c.client_id_type, c.client_id_file_name, c.client_id_verification_status
        FROM users u
        LEFT JOIN admins a ON u.user_id = a.user_id
        LEFT JOIN farmers f ON u.user_id = f.user_id
        LEFT JOIN clients c ON u.user_id = c.user_id
        WHERE u.user_id = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$res = $stmt->get_result();

if (!$res || $res->num_rows === 0) {
    echo "<p>User not found.</p>";
    exit;
}

$row = $res->fetch_assoc();
$stmt->close();

$displayName = '';
if ($row['role'] === 'admin') {
    $displayName = (string)($row['admin_fullname'] ?? '');
} elseif ($row['role'] === 'farmer') {
    $displayName = (string)($row['farmer_fullname'] ?? '');
} elseif ($row['role'] === 'client') {
    $displayName = (string)($row['client_fullname'] ?? '');
}

$status_label = ((int)$row['is_active'] === 1) ? 'Active' : 'Deactivated';
$status_class = ((int)$row['is_active'] === 1) ? 'approved' : 'rejected';
$joined_date = date('F j, Y', strtotime((string)$row['created_at']));
$role_display = ucfirst((string)$row['role']);

$verification_role = '';
$verification_id = 0;
$verification_status = '';
$verification_status_class = '';
$verification_status_label = '';
$id_type_label = '-';
$id_view_url = '';

if ($row['role'] === 'farmer') {
    $verification_role = 'farmer';
    $verification_id = (int)($row['farmer_id'] ?? 0);
    $verification_status = strtolower((string)($row['farmer_id_verification_status'] ?? 'pending'));
    $id_type_label = (string)($row['farmer_id_type'] ?? '-');
    if ((string)($row['farmer_id_file_name'] ?? '') !== '' && $verification_id > 0) {
        $id_view_url = 'admin/download_id.php?type=farmer&id=' . $verification_id . '&inline=1';
    }
} elseif ($row['role'] === 'client') {
    $verification_role = 'client';
    $verification_id = (int)($row['client_id'] ?? 0);
    $verification_status = strtolower((string)($row['client_id_verification_status'] ?? 'pending'));
    $id_type_label = (string)($row['client_id_type'] ?? '-');
    if ((string)($row['client_id_file_name'] ?? '') !== '' && $verification_id > 0) {
        $id_view_url = 'admin/download_id.php?type=client&id=' . $verification_id . '&inline=1';
    }
}

if (!in_array($verification_status, ['pending', 'approved', 'rejected'], true)) {
    $verification_status = $verification_status === '' ? 'pending' : $verification_status;
}

$verification_status_class = $verification_status !== '' ? $verification_status : 'pending';
$verification_status_label = ucfirst($verification_status_class);
$id_file_status_label = $id_view_url !== '' ? 'On File' : 'Not On File';
$id_file_status_class = $id_view_url !== '' ? 'approved' : 'rejected';

$is_approve_mode = $action === 'approve';
$is_edit_mode = false;
$has_verification = $verification_role !== '';
$can_review = $is_approve_mode && $has_verification && $verification_id > 0 && $verification_status_class === 'pending';

$header_title = 'Account Details';
if ($is_approve_mode) {
  $header_title = 'Account Status';
}

$avatar_seed = trim($displayName) !== '' ? $displayName : (string)$row['email'];
$avatar_letter = strtoupper(substr($avatar_seed, 0, 1));
?>

<section id="section-view-account" class="admin-section">
  <div class="section-header sf-account-header">
    <div class="sf-account-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('<?php echo htmlspecialchars($from_param); ?>')" data-tooltip="Back to list">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1><?php echo htmlspecialchars($header_title); ?></h1>
        <p>View profile details, verification state, and account status.</p>
      </div>
    </div>
  </div>

  <div class="form-container sf-account-shell" style="width:100%;margin:0;">
    <div id="accountForm" class="admin-form">

      <div class="sf-account-grid">
        <aside class="sf-profile-card">
          <div class="sf-avatar"><?php echo htmlspecialchars($avatar_letter); ?></div>
          <h2><?php echo htmlspecialchars($displayName !== '' ? $displayName : 'Unnamed User'); ?></h2>
          <p><?php echo htmlspecialchars($row['email']); ?></p>

          <div class="sf-pill-row">
            <span class="status <?php echo htmlspecialchars($status_class); ?>"><?php echo htmlspecialchars($status_label); ?></span>
          </div>

          <div class="sf-meta-list">
            <div class="sf-meta-item">
              <span>Joined</span>
              <strong><?php echo htmlspecialchars($joined_date); ?></strong>
            </div>
            <div class="sf-meta-item">
              <span>Role</span>
              <strong><?php echo htmlspecialchars($role_display); ?></strong>
            </div>
          </div>
        </aside>

        <div class="sf-main-panels no-verification">
          <section class="sf-panel">
            <div class="sf-panel-head">
              <h3>Account Details</h3>
            </div>

            <div class="sf-field-grid">
              <?php if ($row['role'] === 'admin'): ?>
                <div class="sf-field editable-field">
                  <label>Admin Name</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars($displayName); ?></span>
                  <input type="text" name="fullname" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['admin_fullname']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Email</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['email']); ?></span>
                  <input type="email" name="email" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['email']); ?>" style="display:none;" required>
                </div>
              <?php elseif ($row['role'] === 'farmer'): ?>
                <div class="sf-field editable-field">
                  <label>Farmer Name</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars($displayName); ?></span>
                  <input type="text" name="farmer_fullname" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['farmer_fullname']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Email</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['email']); ?></span>
                  <input type="email" name="email" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['email']); ?>" style="display:none;" required>
                </div>

                <div class="sf-field editable-field">
                  <label>Contact Number</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['farmer_contact_number']); ?></span>
                  <input type="text" name="farmer_contact_number" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['farmer_contact_number']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Home Address</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)($row['farmer_address'] ?? '-')); ?></span>
                  <input type="text" name="farmer_address" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)($row['farmer_address'] ?? '')); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Farm Name</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['farmer_farm_name']); ?></span>
                  <input type="text" name="farmer_farm_name" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['farmer_farm_name']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Farm Address</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)($row['farm_address'] ?? '-')); ?></span>
                  <input type="text" name="farm_address" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)($row['farm_address'] ?? '')); ?>" style="display:none;">
                </div>
              <?php elseif ($row['role'] === 'client'): ?>
                <div class="sf-field editable-field">
                  <label>Client Name</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars($displayName); ?></span>
                  <input type="text" name="client_fullname" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['client_fullname']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Email</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['email']); ?></span>
                  <input type="email" name="email" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['email']); ?>" style="display:none;" required>
                </div>

                <div class="sf-field editable-field">
                  <label>Contact Number</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)$row['client_contact_number']); ?></span>
                  <input type="text" name="client_contact_number" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)$row['client_contact_number']); ?>" style="display:none;">
                </div>

                <div class="sf-field editable-field">
                  <label>Address</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars((string)($row['client_address'] ?? '-')); ?></span>
                  <input type="text" name="client_address" class="edit-value sf-field-input" value="<?php echo htmlspecialchars((string)($row['client_address'] ?? '')); ?>" style="display:none;">
                </div>
              <?php endif; ?>

              <?php if ($has_verification): ?>
                <div class="sf-field">
                  <label>ID Type</label>
                  <span class="display-value sf-field-value"><?php echo htmlspecialchars($id_type_label !== '' ? $id_type_label : '-'); ?></span>
                </div>

                <div class="sf-field">
                  <label>ID File</label>
                  <?php if ($id_view_url !== ''): ?>
                    <a href="<?php echo htmlspecialchars($id_view_url); ?>" target="_blank" rel="noopener" class="btn-secondary sf-id-btn">
                      <i class="fas fa-id-card"></i>
                      View ID File
                    </a>
                  <?php else: ?>
                    <span class="display-value sf-field-value sf-muted">Not uploaded</span>
                  <?php endif; ?>
                </div>
              <?php endif; ?>
            </div>
          </section>
        </div>
      </div>

    </div>
  </div>
</section>

<style>
.sf-account-header {
  margin-bottom: 16px;
}

.sf-account-header-left {
  display: flex;
  align-items: flex-start;
  gap: 14px;
}

.sf-account-subtitle {
  margin: 4px 0 0;
  color: #6f7d71;
  font-size: 0.9rem;
}

.sf-account-shell {
  border: 1px solid rgba(27, 90, 42, 0.1);
  border-radius: 14px;
  background: linear-gradient(180deg, rgba(255, 255, 255, 0.96), rgba(245, 250, 246, 0.96));
  box-shadow: 0 8px 24px rgba(23, 66, 38, 0.08);
  padding: 14px;
  max-width: none;
  width: 100%;
}

.sf-account-grid {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  gap: 14px;
  align-items: stretch;
}

.sf-profile-card {
  background: radial-gradient(circle at top, rgba(0, 168, 107, 0.16), rgba(0, 168, 107, 0.05));
  border: 1px solid rgba(0, 168, 107, 0.18);
  border-radius: 14px;
  padding: 18px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  height: 100%;
}

.sf-avatar {
  width: 58px;
  height: 58px;
  border-radius: 999px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1.45rem;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #00a86b 0%, #0b7d52 100%);
  box-shadow: 0 8px 18px rgba(0, 132, 84, 0.25);
}

.sf-profile-card h2 {
  margin: 0;
  color: #22c55e;
  font-size: 1.18rem;
  line-height: 1.2;
}

.sf-profile-card p {
  margin: 0;
  color: #577160;
  word-break: break-word;
}

.sf-pill-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.sf-meta-list {
  display: grid;
  gap: 10px;
}

.sf-meta-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  border-top: 1px dashed rgba(27, 90, 42, 0.18);
  padding-top: 10px;
}

.sf-meta-item span {
  color: #667a6a;
  font-size: 0.82rem;
}

.sf-meta-item strong {
  color: #204f31;
  font-size: 0.92rem;
  text-align: right;
}

.sf-main-panels {
  display: grid;
  gap: 12px;
  align-items: stretch;
  height: 100%;
}

.sf-main-panels.no-verification {
  grid-template-columns: 1fr;
}

.sf-panel {
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 14px;
  background: #fff;
  padding: 14px;
  height: 100%;
}

.sf-panel-head {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 10px;
  margin-bottom: 14px;
}

.sf-panel-head h3 {
  margin: 0;
  color: #22c55e;
}

.sf-field-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.sf-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sf-field label {
  font-weight: 700;
  font-size: 0.8rem;
  color: #45624f;
}

.sf-field-value {
  min-height: 36px;
  border: 1px solid #d9e4dd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #f8fcf9;
  display: block;
  line-height: 1.35;
}

.sf-field-input {
  width: 100%;
  border: 1px solid #c7d6cd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #fff;
  outline: none;
}

.sf-field-input:focus {
  border-color: #00a86b;
  box-shadow: 0 0 0 3px rgba(0, 168, 107, 0.15);
}

.sf-id-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 7px;
  text-decoration: none;
  min-height: 36px;
  border-radius: 8px;
}

.sf-muted {
  margin: 0;
  color: #6e8071;
}

.sf-review-actions {
  margin-top: 14px;
  padding-top: 14px;
  border-top: 1px solid rgba(27, 90, 42, 0.16);
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.sf-review-actions button,
.sf-footer-actions button {
  gap: 8px;
}

.sf-review-note {
  margin-top: 14px;
  padding: 10px 12px;
  border-radius: 8px;
  font-size: 0.92rem;
  font-weight: 600;
}

.sf-review-note.approved {
  background: rgba(40, 167, 69, 0.16);
  color: #145523;
}

.sf-review-note.rejected {
  background: rgba(220, 53, 69, 0.14);
  color: #6f1b23;
}

.sf-footer-actions {
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid rgba(27, 90, 42, 0.14);
  display: flex;
  align-items: center;
  gap: 10px;
}

@media (max-width: 1080px) {
  .sf-account-grid {
    grid-template-columns: 1fr;
  }

  .sf-main-panels.has-verification {
    grid-template-columns: 1fr;
  }

  .sf-profile-card {
    order: 0;
  }
}

@media (min-width: 1360px) {
  .sf-account-grid {
    grid-template-columns: 240px minmax(0, 1fr);
  }

  .sf-main-panels.has-verification {
    grid-template-columns: minmax(0, 2.1fr) minmax(300px, 1fr);
  }

  .sf-field-grid {
    grid-template-columns: repeat(3, minmax(0, 1fr));
  }
}

@media (max-width: 760px) {
  .sf-field-grid {
    grid-template-columns: 1fr;
  }

  .sf-account-shell {
    padding: 12px;
  }

  .sf-panel,
  .sf-profile-card {
    padding: 12px;
  }

  .sf-footer-actions {
    flex-wrap: wrap;
  }
}
</style>

