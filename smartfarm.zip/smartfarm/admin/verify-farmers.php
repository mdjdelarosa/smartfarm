<?php
$farmers_rows = [];
$seed_history_by_farmer = [];

$farmers_query = "
  SELECT
    f.farmer_id,
    f.user_id,
    f.farmer_fullname,
    COALESCE(u.email, '-') AS farmer_email,
    COALESCE(u.is_active, 1) AS user_is_active,
    f.farmer_farm_name,
    f.farmer_address,
    f.farmer_contact_number,
    f.farmer_id_type,
    f.farmer_id_verification_status,
    CASE WHEN COALESCE(f.farmer_id_file_name, '') <> '' THEN 1 ELSE 0 END AS has_id_file
  FROM farmers f
  LEFT JOIN users u ON f.user_id = u.user_id
  ORDER BY f.farmer_id DESC
";
$farmers_result = $conn->query($farmers_query);
if ($farmers_result) {
  while ($farmer_row = $farmers_result->fetch_assoc()) {
    $farmers_rows[] = $farmer_row;
  }
}

// Seed tables may not exist yet in some environments; check before querying.
$seed_dist_check = $conn->query("SHOW TABLES LIKE 'seed_distributions'");
$seed_inv_check = $conn->query("SHOW TABLES LIKE 'seed_inventory'");
$seed_tables_ready =
  ($seed_dist_check && $seed_dist_check->num_rows > 0) &&
  ($seed_inv_check && $seed_inv_check->num_rows > 0);

if ($seed_tables_ready) {
  $seed_history_query = "
    SELECT
      sd.farmer_id,
      sd.distribution_id,
      sd.quantity_distributed,
      sd.distribution_date,
      sd.status,
      sd.notes,
      si.seed_name,
      si.seed_unit
    FROM seed_distributions sd
    JOIN seed_inventory si ON sd.seed_id = si.seed_id
    ORDER BY sd.distribution_date DESC, sd.distribution_id DESC
  ";
  $seed_history_result = $conn->query($seed_history_query);

  if ($seed_history_result) {
    while ($history_row = $seed_history_result->fetch_assoc()) {
      $farmer_id = (int)($history_row['farmer_id'] ?? 0);
      if ($farmer_id <= 0) {
        continue;
      }

      if (!isset($seed_history_by_farmer[$farmer_id])) {
        $seed_history_by_farmer[$farmer_id] = [];
      }

      $seed_history_by_farmer[$farmer_id][] = [
        'distribution_id' => (int)$history_row['distribution_id'],
        'seed_name' => (string)($history_row['seed_name'] ?? 'Unknown'),
        'quantity_distributed' => (float)($history_row['quantity_distributed'] ?? 0),
        'seed_unit' => (string)($history_row['seed_unit'] ?? ''),
        'distribution_date' => (string)($history_row['distribution_date'] ?? ''),
        'status' => (string)($history_row['status'] ?? 'Released'),
        'notes' => (string)($history_row['notes'] ?? '')
      ];
    }
  }
}

$seed_history_json = json_encode(
  $seed_history_by_farmer,
  JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
);
if ($seed_history_json === false) {
  $seed_history_json = '{}';
}
?>

<!-- Verify Farmers Section -->
<section id="section-verify-farmers" class="admin-section">
  <div class="section-header">
    <h1>Farmer Accounts</h1>
    <div style="display:flex; gap:0.5rem; align-items:center;">
      <button class="btn-secondary" type="button" onclick="goToAddAccountFromFarmers()" data-tooltip="Add Farmer Account"><i class="fas fa-user-plus"></i></button>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="farmerSearch">Search</label>
      <input type="text" placeholder="Search by name, email, or farm..." class="search-input" id="farmerSearch" onkeyup="filterTable('farmer')">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="farmerStatus">Status</label>
      <select class="filter-select" id="farmerStatus" onchange="filterTable('farmer')">
        <option value="">All Status</option>
        <option value="active">Active</option>
        <option value="deactivated">Deactivated</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="farmerGroupBy">Group By</label>
      <select class="filter-select" id="farmerGroupBy" onchange="sfSetGroupBy('farmerTable', this); filterTable('farmer')">
        <option value="">No Grouping</option>
        <option value="5">Status</option>
        <option value="2">Farm Name</option>
        <option value="3">Location</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="farmerTable">
      <thead>
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Farm Name</th>
          <th>Location</th>
          <th>Contact</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($farmers_rows) > 0): ?>
          <?php foreach ($farmers_rows as $farmer): ?>
            <?php
              $farmer_user_id = (int)($farmer['user_id'] ?? 0);
              $is_farmer_active = (int)($farmer['user_is_active'] ?? 1) === 1;
              $status = $is_farmer_active ? 'active' : 'deactivated';
              $status_label = $is_farmer_active ? 'Active' : 'Deactivated';
              $status_class = $is_farmer_active ? 'approved' : 'rejected';
              $toggle_type = $is_farmer_active ? 'deactivate' : 'activate';
              $toggle_icon = $is_farmer_active ? 'fa-ban' : 'fa-check';
              $toggle_tooltip = $is_farmer_active ? 'Deactivate Account' : 'Activate Account';
              $toggle_confirm_title = $is_farmer_active ? 'Deactivate Account' : 'Activate Account';
              $toggle_confirm_message = $is_farmer_active
                ? 'Are you sure you want to deactivate this farmer account?'
                : 'Are you sure you want to activate this farmer account?';
              $farmer_details_payload = json_encode([
                "id"      => (int)($farmer["farmer_id"] ?? 0),
                "user_id" => $farmer_user_id,
                "name"    => (string)($farmer["farmer_fullname"] ?? ""),
                "email"   => (string)($farmer["farmer_email"] ?? "-"),
                "farm"    => (string)($farmer["farmer_farm_name"] ?? "-"),
                "address" => (string)($farmer["farmer_address"] ?? "-"),
                "contact" => (string)($farmer["farmer_contact_number"] ?? "-"),
                "id_type" => (string)($farmer["farmer_id_type"] ?? "-"),
                "status"  => $status,
                "has_id"  => (int)($farmer["has_id_file"] ?? 0) === 1
              ], JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
            ?>
            <tr>
              <td title="<?php echo htmlspecialchars($farmer['farmer_fullname'] ?? '-'); ?>"><?php echo htmlspecialchars($farmer['farmer_fullname'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($farmer['farmer_email'] ?? '-'); ?>"><?php echo htmlspecialchars($farmer['farmer_email'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($farmer['farmer_farm_name'] ?? '-'); ?>"><?php echo htmlspecialchars($farmer['farmer_farm_name'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($farmer['farmer_address'] ?? '-'); ?>"><?php echo htmlspecialchars($farmer['farmer_address'] ?? '-'); ?></td>
              <td title="<?php echo htmlspecialchars($farmer['farmer_contact_number'] ?? '-'); ?>"><?php echo htmlspecialchars($farmer['farmer_contact_number'] ?? '-'); ?></td>
              <td><span class="status <?php echo $status_class; ?>"><?php echo htmlspecialchars($status_label); ?></span></td>
              <td class="table-actions-cell">
                <div class="table-actions-wrap">
                  <form method="post" style="display:inline;" data-confirm-title="<?php echo htmlspecialchars($toggle_confirm_title); ?>" data-confirm-message="<?php echo htmlspecialchars($toggle_confirm_message); ?>">
                    <input type="hidden" name="action" value="toggle_user_account">
                    <input type="hidden" name="target_role" value="farmer">
                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars((string)$farmer_user_id); ?>">
                    <input type="hidden" name="toggle_type" value="<?php echo htmlspecialchars($toggle_type); ?>">
                    <button
                      class="btn-small btn-deactivate"
                      type="submit"
                      data-tooltip="<?php echo htmlspecialchars($toggle_tooltip); ?>"
                      <?php echo $farmer_user_id > 0 ? '' : 'disabled'; ?>>
                      <i class="fas <?php echo htmlspecialchars($toggle_icon); ?>"></i>
                    </button>
                  </form>
                  <button class="btn-small btn-view" data-tooltip="View Account Details"
                    onclick='openFarmerAccountDetails(<?php echo $farmer_details_payload; ?>)'>
                    <i class="fas fa-eye"></i>
                  </button>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" style="text-align:center; padding:20px; color:#8b968b;">No farmer records found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<div id="farmerSeedHistoryModal" class="schedule-modal" onclick="closeFarmerSeedHistory(event)">
  <div class="schedule-modal-card seed-history-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3 id="farmerSeedHistoryTitle">Distributed Seeds</h3>
        <p class="seed-history-subtitle">Seed release history for the selected farmer.</p>
      </div>
      <button type="button" class="schedule-modal-close" onclick="closeFarmerSeedHistory()"><i class="fas fa-times"></i></button>
    </div>

    <div class="seed-history-summary-grid">
      <div class="seed-history-summary-item">
        <span>Total Releases</span>
        <strong id="seedHistoryCount">0</strong>
      </div>
      <div class="seed-history-summary-item">
        <span>Total Quantity</span>
        <strong id="seedHistoryQty">0.00</strong>
      </div>
      <div class="seed-history-summary-item">
        <span>Last Distribution</span>
        <strong id="seedHistoryLastDate">N/A</strong>
      </div>
    </div>

    <div class="table-container" style="margin-top: 14px;">
      <table class="data-table" id="farmerSeedHistoryTable">
        <thead>
          <tr>
            <th>Distribution ID</th>
            <th>Seed Type</th>
            <th>Quantity</th>
            <th>Unit</th>
            <th>Date</th>
            <th>Status</th>
            <th>Notes</th>
          </tr>
        </thead>
        <tbody id="farmerSeedHistoryBody">
          <tr>
            <td colspan="7" style="text-align:center; color:#7a8a7a; padding:20px;">Select a farmer to view seed distributions.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<style>
#farmerTable {
  table-layout: fixed;
}

#farmerTable th,
#farmerTable td {
  vertical-align: middle;
}

#farmerTable td {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  line-height: 1.2;
}

#farmerTable td.table-actions-cell {
  overflow: visible;
  text-overflow: clip;
  min-width: 160px;
  padding: 0.5rem;
}

#farmerTable .table-actions-wrap {
  display: inline-flex;
  gap: 0.35rem;
  align-items: center;
  flex-wrap: nowrap;
}

.btn-seed-history {
  background: #3b82f6;
  color: #fff;
  box-shadow: 0 6px 14px rgba(59, 130, 246, 0.24);
}

.btn-seed-history:hover {
  background: #2563eb;
  box-shadow: 0 8px 18px rgba(37, 99, 235, 0.3);
  transform: translateY(-1px);
}

.seed-history-modal-card {
  width: min(960px, 95vw);
}

.seed-history-subtitle {
  margin: 0;
  color: #738173;
  font-size: 0.86rem;
}

.seed-history-summary-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
}

.seed-history-summary-item {
  background: #f7fbf8;
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 10px;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.seed-history-summary-item span {
  color: #738173;
  font-size: 0.76rem;
  text-transform: uppercase;
  letter-spacing: 0.04em;
  font-weight: 700;
}

.seed-history-summary-item strong {
  color: #1c4d2c;
  font-size: 1rem;
}

.status.released {
  background: #e3f2fd;
  color: #1976d2;
  border-radius: 12px;
  padding: 3px 9px;
  font-size: 12px;
  font-weight: 600;
}

.status.received {
  background: #e8f5e9;
  color: #2e7d32;
  border-radius: 12px;
  padding: 3px 9px;
  font-size: 12px;
  font-weight: 600;
}

.status.cancelled {
  background: #ffebee;
  color: #d32f2f;
  border-radius: 12px;
  padding: 3px 9px;
  font-size: 12px;
  font-weight: 600;
}

@media (max-width: 768px) {
  .seed-history-summary-grid {
    grid-template-columns: 1fr;
  }
}
</style>

  <style>
  .farmer-details-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-top: 4px;
  }
  .farmer-detail-item {
    background: #f7fbf8;
    border: 1px solid rgba(27, 90, 42, 0.12);
    border-radius: 10px;
    padding: 10px 14px;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .farmer-detail-item span {
    color: #738173;
    font-size: 0.76rem;
    text-transform: uppercase;
    letter-spacing: 0.04em;
    font-weight: 700;
  }
  .farmer-detail-item strong {
    color: #1c4d2c;
    font-size: 0.95rem;
    word-break: break-word;
  }
  .id-view-field {
    grid-column: 1 / -1;
  }
  .id-view-link-wrap {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap;
  }
  .id-view-link-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    padding: 0 16px;
    border-radius: 10px;
    border: 1px solid #c9d8cf;
    background: #f4f7f5;
    color: #244a33;
    font-weight: 700;
    letter-spacing: 0.01em;
    cursor: pointer;
    box-shadow: 0 3px 8px rgba(23, 60, 36, 0.08);
  }
  .id-view-link-btn:hover {
    background: #ebf2ee;
    border-color: #b8cbbf;
    color: #1f3f2c;
    transform: translateY(-1px);
    box-shadow: 0 6px 14px rgba(23, 60, 36, 0.14);
  }
  .id-view-link-btn:disabled,
  .id-view-link-btn.is-disabled {
    background: #e5ebe7;
    border-color: #d4dfd8;
    color: #8b968f;
    cursor: not-allowed;
    box-shadow: none;
    transform: none;
  }
  .id-view-note {
    color: #6f816f;
    font-size: 0.82rem;
  }
  .id-viewer-modal-card {
    width: min(1080px, 96vw);
  }
  .id-viewer-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 10px;
    flex-wrap: wrap;
  }
  .id-viewer-controls {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 5px;
    border-radius: 10px;
    border: 1px solid rgba(27, 90, 42, 0.18);
    background: #f4faf5;
  }
  .id-viewer-control {
    border: 1px solid rgba(27, 90, 42, 0.2);
    background: #ffffff;
    color: #1c4d2c;
    border-radius: 8px;
    min-width: 32px;
    height: 30px;
    padding: 0 10px;
    font-size: 0.82rem;
    font-weight: 700;
    cursor: pointer;
  }
  .id-viewer-control:hover {
    background: #eaf5ec;
  }
  .id-viewer-viewport {
    border: 1px solid rgba(27, 90, 42, 0.16);
    border-radius: 12px;
    background: #ffffff;
    overflow: auto;
    height: min(72vh, 780px);
  }
  .id-viewer-frame {
    width: 100%;
    height: min(72vh, 780px);
    border: 0;
    transform-origin: top left;
    background: #fff;
  }
  .id-viewer-empty {
    padding: 26px;
    border: 1px dashed rgba(27, 90, 42, 0.24);
    border-radius: 12px;
    text-align: center;
    color: #607262;
    font-size: 0.9rem;
  }
  .id-viewer-empty[hidden] {
    display: none !important;
  }
  .verify-modal-actions {
    align-items: center;
    flex-wrap: nowrap;
    gap: 12px !important;
  }
  .verify-modal-actions form {
    display: inline-flex !important;
  }
  .verify-action-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 46px;
    padding: 0 22px;
    border-radius: 12px;
    border: 1px solid transparent;
    font-size: 1.02rem;
    font-weight: 700;
    letter-spacing: 0;
    white-space: nowrap;
    box-shadow: none;
    transition: transform 0.2s ease, box-shadow 0.2s ease, background-color 0.2s ease, color 0.2s ease;
  }
  .verify-action-btn:hover {
    transform: translateY(-1px);
  }
  .verify-approve-btn {
    background: #10b981;
    color: #ffffff;
    border-color: #10b981;
    box-shadow: 0 8px 18px rgba(5, 150, 105, 0.28);
  }
  .verify-approve-btn:hover {
    background: #059669;
    border-color: #059669;
    box-shadow: 0 10px 22px rgba(5, 150, 105, 0.34);
  }
  .verify-reject-btn {
    background: #c94b57;
    color: #ffffff;
    border-color: #c94b57;
    box-shadow: 0 8px 18px rgba(184, 63, 75, 0.26);
  }
  .verify-reject-btn:hover {
    background: #b83f4b;
    border-color: #b83f4b;
    box-shadow: 0 10px 22px rgba(184, 63, 75, 0.32);
  }
  @media (max-width: 600px) {
    .farmer-details-grid { grid-template-columns: 1fr; }
    .id-viewer-toolbar { flex-direction: column; align-items: stretch; }
    .id-viewer-controls { width: 100%; justify-content: space-between; }
    .id-viewer-viewport { height: 62vh; }
    .id-viewer-frame { height: 62vh; }
  }
  </style>

  <div id="farmerDetailsModal" class="schedule-modal" onclick="closeFarmerDetails(event)">
    <div class="schedule-modal-card" style="width:100%;margin:0;">      <input type="hidden" id="fdFarmerId" value="">
      <input type="hidden" id="fdFarmerStatus" value="">      <div class="schedule-modal-header">
        <div>
          <h3 id="farmerDetailsTitle">Farmer Details</h3>
          <p class="seed-history-subtitle">Complete profile information for the selected farmer.</p>
        </div>
        <button type="button" class="schedule-modal-close" onclick="closeFarmerDetails()"><i class="fas fa-times"></i></button>
      </div>
      <div class="farmer-details-grid">
        <div class="farmer-detail-item">
          <span>Full Name</span>
          <strong id="fdName">-</strong>
        </div>
        <div class="farmer-detail-item">
          <span>Email</span>
          <strong id="fdEmail">-</strong>
        </div>
        <div class="farmer-detail-item">
          <span>Farm Name</span>
          <strong id="fdFarm">-</strong>
        </div>
        <div class="farmer-detail-item">
          <span>Location</span>
          <strong id="fdAddress">-</strong>
        </div>
        <div class="farmer-detail-item">
          <span>Contact Number</span>
          <strong id="fdContact">-</strong>
        </div>
        <div class="farmer-detail-item">
          <span>ID Type</span>
          <strong id="fdIdType">-</strong>
        </div>
        <div class="farmer-detail-item" style="grid-column:1/-1">
          <span>Verification Status</span>
          <strong id="fdStatus">-</strong>
        </div>
      </div>
      <div class="farmer-detail-item id-view-field">
        <span>Uploaded ID</span>
        <div class="id-view-link-wrap">
          <button type="button" id="fdViewIdBtn" class="btn-small id-view-link-btn" onclick="openFarmerIdViewer()" disabled>View ID</button>
          <small id="fdIdViewNote" class="id-view-note">No uploaded ID file.</small>
        </div>
      </div>
      <div class="schedule-modal-footer verify-modal-actions" style="display:flex;gap:0.5rem;justify-content:flex-end;padding-top:1rem;border-top:1px solid #e0e0e0;margin-top:1rem;">
        <button type="button" class="btn-small verify-action-btn verify-reject-btn" id="fdRejectBtn" style="display:none;" onclick="showRejectFormModal('farmer', document.getElementById('fdFarmerId').value)" data-tooltip="Reject">Reject</button>
        <form method="post" style="display:inline" id="fdApproveForm" data-confirm-title="Approve Account" data-confirm-message="Are you sure you want to approve this farmer?">
          <input type="hidden" name="action" value="approve_farmer">
          <input type="hidden" name="farmer_id" id="fdApproveFormId" value="">
          <button type="submit" class="btn-small verify-action-btn verify-approve-btn" id="fdApproveBtn" style="display:none;" data-tooltip="Approve">Approve</button>
        </form>
      </div>
    </div>

    <div id="farmerIdViewerModal" class="schedule-modal" onclick="closeFarmerIdViewer(event)">
      <div class="schedule-modal-card id-viewer-modal-card" style="width:100%;margin:0;">
        <div class="schedule-modal-header">
          <div>
            <h3>Farmer ID File</h3>
            <p class="seed-history-subtitle">Full file view with zoom controls.</p>
          </div>
          <button type="button" class="schedule-modal-close" onclick="closeFarmerIdViewer()"><i class="fas fa-times"></i></button>
        </div>
        <div class="id-viewer-toolbar">
          <small class="id-view-note">Use - and + to adjust the view.</small>
          <div class="id-viewer-controls">
            <button type="button" class="id-viewer-control" onclick="adjustFarmerIdViewerZoom(-0.1)">-</button>
            <button type="button" class="id-viewer-control" id="fdViewerZoomResetBtn" onclick="resetFarmerIdViewerZoom()">100%</button>
            <button type="button" class="id-viewer-control" onclick="adjustFarmerIdViewerZoom(0.1)">+</button>
          </div>
        </div>
        <div id="fdViewerEmpty" class="id-viewer-empty" hidden>No uploaded ID file for this farmer.</div>
        <div id="fdViewerViewport" class="id-viewer-viewport" hidden>
          <iframe id="fdViewerFrame" class="id-viewer-frame" title="Farmer ID File Viewer" loading="lazy"></iframe>
        </div>
      </div>
    </div>
  </div>

<script>
const farmerSeedHistoryData = <?php echo $seed_history_json; ?>;
  let farmerIdViewerZoom = 1;
  let farmerIdViewerUrl = '';

  function applyFarmerIdViewerZoom() {
    const frame = document.getElementById('fdViewerFrame');
    const viewport = document.getElementById('fdViewerViewport');
    const resetBtn = document.getElementById('fdViewerZoomResetBtn');
    if (!frame || !viewport || !resetBtn) return;

    const zoom = farmerIdViewerZoom;
    const baseHeight = viewport.clientHeight || 480;

    frame.style.transform = 'scale(' + zoom + ')';
    frame.style.width = (100 / zoom) + '%';
    frame.style.height = (baseHeight / zoom) + 'px';
    resetBtn.textContent = Math.round(zoom * 100) + '%';
  }

  function adjustFarmerIdViewerZoom(delta) {
    const next = Math.max(0.5, Math.min(2.5, farmerIdViewerZoom + delta));
    farmerIdViewerZoom = Math.round(next * 100) / 100;
    applyFarmerIdViewerZoom();
  }

  function resetFarmerIdViewerZoom() {
    farmerIdViewerZoom = 1;
    applyFarmerIdViewerZoom();
  }

  function openFarmerIdViewer() {
    const modal = document.getElementById('farmerIdViewerModal');
    const frame = document.getElementById('fdViewerFrame');
    const viewport = document.getElementById('fdViewerViewport');
    const empty = document.getElementById('fdViewerEmpty');
    if (!modal || !frame || !viewport || !empty) return;

    if (!farmerIdViewerUrl) {
      viewport.hidden = true;
      empty.hidden = false;
      modal.classList.add('is-visible');
      return;
    }

    frame.src = farmerIdViewerUrl;
    viewport.hidden = false;
    empty.hidden = true;
    modal.classList.add('is-visible');
    resetFarmerIdViewerZoom();
  }

  function closeFarmerIdViewer(event) {
    const modal = document.getElementById('farmerIdViewerModal');
    const frame = document.getElementById('fdViewerFrame');
    if (!modal) return;
    if (!event || event.target === modal) {
      if (frame) {
        frame.removeAttribute('src');
      }
      modal.classList.remove('is-visible');
    }
  }

function seedHistoryEscapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, function(char) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;'
    };
    return map[char] || char;
  });
}

function formatSeedHistoryDate(dateValue) {
  if (!dateValue) return 'N/A';
  const date = new Date(dateValue + 'T00:00:00');
  if (Number.isNaN(date.getTime())) return dateValue;
  return date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
}

function openFarmerSeedHistory(farmerId) {
  if (!farmerId) return;
  window.location.href = 'admin_dashboard.php?section=farmer-seed-history&farmer_id=' + farmerId + '&from=verify-farmers';
}

function openFarmerAccountDetails(data) {
  const userId = Number(data && data.user_id ? data.user_id : 0);
  if (!userId) return;
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=verify-farmers&action=view';
}

function openFarmerForApproval(data) {
  const userId = Number(data && data.user_id ? data.user_id : 0);
  if (!userId) return;
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=verify-farmers&action=approve';
}

function goToAddAccountFromFarmers() {
  window.location.href = 'admin_dashboard.php?section=add-account&role=farmer&from=verify-farmers';
}

function closeFarmerSeedHistory(event) {
  const modal = document.getElementById('farmerSeedHistoryModal');
  if (!modal) return;
  if (!event || event.target === modal) {
    modal.classList.remove('is-visible');
  }
}

function closeFarmerDetails(event) {
  const modal = document.getElementById('farmerDetailsModal');
  if (!modal) return;
  if (!event || event.target === modal) {
    modal.classList.remove('is-visible');
  }
}

function openFarmerRejectModal(farmerId, farmerName) {
  document.getElementById('farmerRejectFarmerId').value = farmerId;
  document.getElementById('farmerRejectReason').value = '';
  document.getElementById('farmerRejectReasonError').style.display = 'none';
  const subtitle = document.getElementById('farmerRejectModalSubtitle');
  if (subtitle && farmerName) subtitle.textContent = 'Rejecting: ' + farmerName;
  document.getElementById('farmerRejectModal').classList.add('is-visible');
}

function closeFarmerRejectModal(event) {
  const modal = document.getElementById('farmerRejectModal');
  if (!modal) return;
  if (!event || event.target === modal) modal.classList.remove('is-visible');
}

function submitFarmerReject() {
  const reason = document.getElementById('farmerRejectReason').value.trim();
  const errEl = document.getElementById('farmerRejectReasonError');
  if (!reason) { errEl.style.display = 'block'; return; }
  errEl.style.display = 'none';
  document.getElementById('farmerRejectForm').submit();
}
</script>

<!-- Farmer Reject Modal -->
<div id="farmerRejectModal" class="schedule-modal" onclick="closeFarmerRejectModal(event)">
  <div class="schedule-modal-card" style="width:min(480px,92vw);margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3>Reject Farmer Account</h3>
        <p id="farmerRejectModalSubtitle" style="margin:0;color:#738173;font-size:0.86rem;">Provide a reason for rejection.</p>
      </div>
      <button type="button" class="schedule-modal-close" onclick="closeFarmerRejectModal()"><i class="fas fa-times"></i></button>
    </div>
    <form method="post" action="admin_dashboard.php" id="farmerRejectForm">
      <input type="hidden" name="action" value="reject_farmer">
      <input type="hidden" name="farmer_id" id="farmerRejectFarmerId" value="">
      <div style="margin:1rem 0;">
        <label for="farmerRejectReason" style="display:block;font-weight:700;font-size:0.9rem;color:#244a33;margin-bottom:6px;">Reason for rejection <span style="color:#c94b57;">*</span></label>
        <textarea id="farmerRejectReason" name="reason" rows="4"
          placeholder="e.g. Incomplete documents, invalid ID, etc."
          style="width:100%;box-sizing:border-box;padding:10px;border:1px solid #c9d8cf;border-radius:8px;font-size:0.95rem;resize:vertical;"></textarea>
        <div id="farmerRejectReasonError" style="display:none;color:#c94b57;font-size:0.82rem;margin-top:4px;font-weight:600;">Please provide a reason before rejecting.</div>
      </div>
      <div style="display:flex;gap:0.5rem;justify-content:flex-end;padding-top:0.75rem;border-top:1px solid #e0e0e0;">
        <button type="button" class="btn-secondary" onclick="closeFarmerRejectModal()">Cancel</button>
        <button type="button" class="btn-small btn-reject" onclick="submitFarmerReject()">Reject</button>
      </div>
    </form>
  </div>
</div>
