<?php
// Normalize request statuses so every request row always has a usable status.
$seed_req_table_check = $conn->query("SHOW TABLES LIKE 'seed_requests'");
if ($seed_req_table_check && $seed_req_table_check->num_rows > 0) {
  $conn->query("ALTER TABLE seed_requests MODIFY COLUMN request_status VARCHAR(20) NOT NULL DEFAULT 'pending'");
  $conn->query("UPDATE seed_requests SET request_status = 'confirmed' WHERE request_status = 'approved'");
  $conn->query("UPDATE seed_requests SET request_status = 'completed' WHERE request_status = 'fulfilled'");
  $conn->query("UPDATE seed_requests SET request_status = 'cancelled' WHERE request_status = 'rejected'");
  $conn->query("UPDATE seed_requests SET request_status = 'pending' WHERE TRIM(COALESCE(request_status, '')) = ''");
}

// Build one unified list: stock rows without a farmer plus actual seed request rows.
$seed_records = [];

$records_query = "
  SELECT *
  FROM (
    SELECT
      'stock' AS record_type,
      0 AS record_rank,
      si.seed_id,
      NULL AS distribution_id,
      NULL AS farmer_id,
      NULL AS farmer_name,
      si.seed_name,
      si.seed_unit,
      si.available_quantity AS quantity_distributed,
      si.created_at AS distribution_date,
      'stock' AS status,
      CASE
        WHEN si.available_quantity <= 0 THEN 'Out of stock'
        WHEN si.available_quantity <= si.low_stock_threshold THEN 'Low stock'
        ELSE 'Unassigned stock'
      END AS notes,
      si.low_stock_threshold,
      si.available_quantity,
      si.created_at AS created_at
    FROM seed_inventory si
    WHERE si.available_quantity > 0

    UNION ALL

    SELECT
      'request' AS record_type,
      1 AS record_rank,
      sr.seed_id,
      sr.request_id AS distribution_id,
      sr.farmer_id,
      f.farmer_fullname AS farmer_name,
      COALESCE(si.seed_name, sr.seed_name) AS seed_name,
      COALESCE(si.seed_unit, '') AS seed_unit,
      sr.quantity_requested AS quantity_distributed,
      sr.requested_at AS distribution_date,
      COALESCE(NULLIF(TRIM(sr.request_status), ''), 'pending') AS status,
      sr.request_notes AS notes,
      si.low_stock_threshold,
      si.available_quantity,
      sr.requested_at AS created_at
    FROM seed_requests sr
    LEFT JOIN seed_inventory si ON sr.seed_id = si.seed_id
    LEFT JOIN farmers f ON sr.farmer_id = f.farmer_id
  ) AS unified_seed_records
  ORDER BY seed_name ASC, record_rank ASC, distribution_date DESC, distribution_id DESC
";

$records_result = $conn->query($records_query);
if ($records_result) {
  while ($row = $records_result->fetch_assoc()) {
    $seed_records[] = $row;
  }
}

// Build collision-free display IDs for the mixed stock/distribution table.
$reserved_distribution_display_ids = [];
$used_distribution_display_ids = [];
$max_distribution_display_id = 0;
foreach ($seed_records as $record) {
  $distribution_id = (int)($record['distribution_id'] ?? 0);
  if ($distribution_id > 0) {
    $reserved_distribution_display_ids[$distribution_id] = true;
    if ($distribution_id > $max_distribution_display_id) {
      $max_distribution_display_id = $distribution_id;
    }
  }
}
$next_generated_distribution_id = $max_distribution_display_id + 1;
foreach ($seed_records as $idx => $record) {
  $record_type = (string)($record['record_type'] ?? 'distribution');
  $is_stock = ($record_type === 'stock');
  $candidate_id = $is_stock
    ? (int)($record['seed_id'] ?? 0)
    : (int)($record['distribution_id'] ?? 0);

  $can_keep_original = !$is_stock
    && $candidate_id > 0
    && !isset($used_distribution_display_ids[$candidate_id]);

  if (!$can_keep_original) {
    if ($is_stock && $candidate_id > 0 && !isset($reserved_distribution_display_ids[$candidate_id]) && !isset($used_distribution_display_ids[$candidate_id])) {
      // Stock rows can reuse their seed ID only when that number is not reserved by a real distribution ID.
    } else {
      while (isset($used_distribution_display_ids[$next_generated_distribution_id]) || isset($reserved_distribution_display_ids[$next_generated_distribution_id])) {
        $next_generated_distribution_id++;
      }
      $candidate_id = $next_generated_distribution_id;
      $next_generated_distribution_id++;
    }
  }

  if ($candidate_id <= 0) {
    while (isset($used_distribution_display_ids[$next_generated_distribution_id]) || isset($reserved_distribution_display_ids[$next_generated_distribution_id])) {
      $next_generated_distribution_id++;
    }
    $candidate_id = $next_generated_distribution_id;
    $next_generated_distribution_id++;
  }

  $used_distribution_display_ids[$candidate_id] = true;
  $seed_records[$idx]['display_distribution_id'] = $candidate_id;
}

// Fetch farmers for dropdown
$farmers_query = "
  SELECT f.farmer_id, f.farmer_fullname as farmer_name
  FROM farmers f
  ORDER BY f.farmer_fullname
";
$farmers_result = $conn->query($farmers_query);
$farmers = [];
if ($farmers_result) {
  while ($row = $farmers_result->fetch_assoc()) {
    $farmers[] = $row;
  }
}

// Fetch seed inventory
$seeds_query = "
  SELECT seed_id, seed_name, seed_unit, available_quantity, low_stock_threshold
  FROM seed_inventory
  ORDER BY seed_name
";
$seeds_result = $conn->query($seeds_query);
$seeds = [];
if ($seeds_result) {
  while ($row = $seeds_result->fetch_assoc()) {
    $seeds[] = $row;
  }
}
?>

<!-- Distribute Seeds Section -->
<section id="section-distribute-seeds" class="admin-section">
  <div class="section-header sf-add-header" style="display:flex;align-items:center;justify-content:space-between;">
    <div class="sf-add-header-left" style="display:flex;align-items:center;gap:10px;">
      <h1 style="margin:0;">Seed Stock & Requests</h1>
    </div>
    <div style="display:flex; gap:10px; align-items:center;">
      <a class="btn-primary" href="admin_dashboard.php?section=add-seed-stock" id="goToAddSeedStockBtn" data-tooltip="Add Seed Stock" style="display:inline-flex;align-items:center;justify-content:center;">
        <i class="fas fa-plus"></i>
      </a>
    </div>
  </style>
  <style>
    /* Remove underline from the Add Seed Stock plus button */
    #goToAddSeedStockBtn,
    #goToAddSeedStockBtn:visited,
    #goToAddSeedStockBtn:hover,
    #goToAddSeedStockBtn:active {
      text-decoration: none !important;
    }
  </style>


  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="seedSearch">Search</label>
      <input type="text" class="search-input" id="seedSearch" placeholder="Search seed or farmer..." oninput="filterSeedDistributionTable()">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="seedStatus">Status</label>
      <select class="filter-select" id="seedStatus" onchange="filterSeedDistributionTable()">
        <option value="">All Status</option>
        <option value="stock">Stock on Hand</option>
        <option value="stock-low">Low Stock</option>
        <option value="pending">Pending Approval</option>
        <option value="confirmed">Confirmed</option>
        <option value="completed">Completed</option>
        <option value="cancelled">Cancelled</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="seedGroupBy">Group By</label>
      <select class="filter-select" id="seedGroupBy" onchange="sfSetGroupBy('seedDistributionTable', this); filterSeedDistributionTable()">
        <option value="">No Grouping</option>
        <option value="5">Status</option>
        <option value="1">Seed Type</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="seedDistributionTable">
      <thead>
        <tr>
          <th>Record ID</th>
          <th>Seed Type</th>
          <th>Farmer</th>
          <th>Quantity</th>
          <th>Record Date</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (count($seed_records) > 0): ?>
          <?php foreach ($seed_records as $record): ?>
            <?php
              $record_type = (string)($record['record_type'] ?? 'request');
              $is_stock = ($record_type === 'stock');
              $status_raw = $is_stock ? 'stock' : (string)($record['status'] ?? 'released');
              $status_label = $is_stock ? 'Stock on Hand' : ucfirst($status_raw);
              $quantity_value = (float)($record['quantity_distributed'] ?? 0);
              $seed_name = (string)($record['seed_name'] ?? 'Unknown');
              $seed_unit = (string)($record['seed_unit'] ?? '-');
              $seed_id = (int)($record['seed_id'] ?? 0);
              $distribution_id = (int)($record['distribution_id'] ?? 0);
              $display_distribution_id = (int)($record['display_distribution_id'] ?? 0);
              $farmer_name = (string)($record['farmer_name'] ?? '');
              $record_date_raw = (string)($record['distribution_date'] ?? '');
              $record_date_label = $record_date_raw !== '' ? date('M d, Y', strtotime($record_date_raw)) : '-';
              $stock_health_class = 'stock-good';
              if ($quantity_value <= 0) {
                $stock_health_class = 'stock-out';
              } elseif ($record['low_stock_threshold'] !== null && $quantity_value <= (float)$record['low_stock_threshold']) {
                $stock_health_class = 'stock-low';
              }

              if ($is_stock) {
                if ($stock_health_class === 'stock-low') {
                  $status_raw = 'stock-low';
                  $status_label = 'Low Stock';
                } else {
                  $status_raw = 'stock';
                  $status_label = 'Stock on Hand';
                }
              } else {
                $status_raw = strtolower(trim($status_raw));
                if ($status_raw === '') {
                  $status_raw = 'pending';
                }
                $status_label = [
                  'pending' => 'Pending Approval',
                  'confirmed' => 'Confirmed',
                  'completed' => 'Completed',
                  'cancelled' => 'Cancelled'
                ][$status_raw] ?? ucfirst($status_raw);
              }

              $action_href = $is_stock
                ? 'admin_dashboard.php?section=view-seed-record&record_type=stock&seed_id=' . (int)$seed_id . '&mode=edit&from=distribute-seeds'
                : 'admin_dashboard.php?section=view-seed-record&record_type=request&request_id=' . (int)$distribution_id . '&from=distribute-seeds';
              $action_class = $is_stock ? 'btn-edit' : 'btn-view';
              $action_tooltip = $is_stock ? 'Edit stock' : 'View request';
              $action_icon = $is_stock ? 'fa-pen' : 'fa-eye';
            ?>
            <tr
              data-record-type="<?php echo htmlspecialchars($record_type, ENT_QUOTES, 'UTF-8'); ?>"
              data-status="<?php echo htmlspecialchars($status_raw, ENT_QUOTES, 'UTF-8'); ?>"
              data-distribution-id="<?php echo $distribution_id; ?>"
              data-farmer-id="<?php echo (int)($record['farmer_id'] ?? 0); ?>"
              data-seed-id="<?php echo $seed_id; ?>"
              data-quantity="<?php echo htmlspecialchars((string)$quantity_value, ENT_QUOTES, 'UTF-8'); ?>"
              data-distribution-date="<?php echo htmlspecialchars($record_date_raw, ENT_QUOTES, 'UTF-8'); ?>"
              data-notes="<?php echo htmlspecialchars((string)($record['notes'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"
              data-seed-name="<?php echo htmlspecialchars($seed_name, ENT_QUOTES, 'UTF-8'); ?>"
              data-seed-unit="<?php echo htmlspecialchars($seed_unit, ENT_QUOTES, 'UTF-8'); ?>"
              data-seed-qty="<?php echo htmlspecialchars((string)$quantity_value, ENT_QUOTES, 'UTF-8'); ?>"
              data-seed-threshold="<?php echo htmlspecialchars((string)($record['low_stock_threshold'] ?? 0), ENT_QUOTES, 'UTF-8'); ?>"
              data-farmer-name="<?php echo htmlspecialchars($farmer_name, ENT_QUOTES, 'UTF-8'); ?>"
            >
              <td><?php echo '#SEED' . str_pad((string)$display_distribution_id, 4, '0', STR_PAD_LEFT); ?></td>
              <td>
                <strong><?php echo htmlspecialchars($seed_name, ENT_QUOTES, 'UTF-8'); ?></strong>
                <?php if ($is_stock): ?>
                  <span class="stock-badge <?php echo $stock_health_class; ?>" style="margin-left:8px;">Stock</span>
                <?php endif; ?>
              </td>
              <td><?php echo $farmer_name !== '' ? htmlspecialchars($farmer_name, ENT_QUOTES, 'UTF-8') : '-'; ?></td>
              <td><?php echo number_format($quantity_value, 2); ?> <?php echo htmlspecialchars($seed_unit, ENT_QUOTES, 'UTF-8'); ?></td>
              <td><?php echo htmlspecialchars($record_date_label, ENT_QUOTES, 'UTF-8'); ?></td>
              <td>
                <span class="status <?php echo htmlspecialchars($status_raw, ENT_QUOTES, 'UTF-8'); ?>">
                  <?php echo htmlspecialchars($status_label, ENT_QUOTES, 'UTF-8'); ?>
                </span>
              </td>
              <td style="white-space: nowrap;">
                <a
                  class="btn-small <?php echo htmlspecialchars($action_class, ENT_QUOTES, 'UTF-8'); ?>"
                  data-tooltip="<?php echo htmlspecialchars($action_tooltip, ENT_QUOTES, 'UTF-8'); ?>"
                  href="<?php echo htmlspecialchars($action_href, ENT_QUOTES, 'UTF-8'); ?>">
                  <i class="fas <?php echo htmlspecialchars($action_icon, ENT_QUOTES, 'UTF-8'); ?>"></i>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="7" style="text-align: center; color: #999; padding: 20px;">No seed records found</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<!-- Distribution Details Modal (View + Edit) -->
<div id="seedDistributionDetailsModal" class="schedule-modal" onclick="closeSeedDistributionDetailsModal(event)">
  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <h3 id="seedDetailsModalTitle"><i class="fas fa-eye" style="color:#3b82f6; margin-right:0.4rem;"></i>Record Details</h3>
      <button type="button" class="schedule-modal-close" onclick="closeSeedDistributionDetailsModal()"><i class="fas fa-times"></i></button>
    </div>

    <form id="seedDistributionDetailsForm" method="POST" action="admin_dashboard.php" class="schedule-form">
      <input type="hidden" name="action" value="update_seed_distribution">
      <input type="hidden" name="distribution_id" id="detail_distribution_id" value="">
      <input type="hidden" name="record_type" id="detail_record_type" value="request">
      <input type="hidden" id="detail_seed_id" value="">
      <input type="hidden" id="detail_seed_threshold" value="0">

      <div id="seedDetailsModeHint" style="margin-bottom:10px;color:#5f6d63;font-size:0.88rem;"></div>

      <div class="form-grid">
        <div class="form-field">
          <label for="detail_seed_name">Seed Type</label>
          <input type="text" id="detail_seed_name" readonly style="background:#f5f7f5;color:#5f6d63;cursor:not-allowed;">
        </div>

        <div class="form-field">
          <label for="detail_farmer_name">Farmer</label>
          <input type="text" id="detail_farmer_name" readonly style="background:#f5f7f5;color:#5f6d63;cursor:not-allowed;">
        </div>

        <div class="form-field">
          <label for="detail_quantity">Quantity <span style="color:#d32f2f;">*</span></label>
          <div style="display:flex; gap:10px;">
            <input type="number" id="detail_quantity" name="quantity_distributed" step="0.01" min="0.01" required style="flex:1;">
            <span id="detail_unit" style="padding:8px 12px; background:#f0f0f0; border-radius:4px; min-width:50px; display:flex; align-items:center;">kg</span>
          </div>
        </div>

        <div class="form-field">
          <label for="detail_distribution_date">Record Date <span style="color:#d32f2f;">*</span></label>
          <input type="date" id="detail_distribution_date" name="distribution_date" required>
        </div>

        <div class="form-field">
          <label for="detail_status">Status <span style="color:#d32f2f;">*</span></label>
          <select id="detail_status" name="status" required>
            <option value="pending">Pending Approval</option>
            <option value="confirmed">Confirmed</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div style="display:flex; gap:10px; justify-content:flex-end; margin-top:20px;">
        <button type="button" class="btn-secondary" onclick="closeSeedDistributionDetailsModal()">Close</button>
        <button type="button" class="btn-secondary" id="detailEditBtn" onclick="handleSeedDetailEditAction()">Edit</button>
        <button type="submit" class="btn-primary" id="detailSaveBtn" style="display:none;">Save Changes</button>
      </div>
    </form>
  </div>
</div>


<!-- Add Seed Stock Section (matches Add Machinery workflow) -->
<?php if (isset($_GET['section']) && $_GET['section'] === 'add-seed-stock'): ?>
<section id="section-add-seed-stock" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <a href="admin_dashboard.php?section=distribute-seeds" class="btn-tertiary" data-tooltip="Back to Seed Stock & Requests" style="margin-right:10px;">
        <i class="fas fa-arrow-left"></i>
      </a>
      <h1>Add Seed Stock</h1>
    </div>
  </div>
  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <form id="seedStockForm" method="POST" action="admin_dashboard.php?section=distribute-seeds" class="schedule-form">
      <input type="hidden" name="action" value="add_seed_stock">
      <div class="form-grid">
        <div class="form-field">
          <label for="seedStockName">Seed Type <span style="color:#d32f2f;">*</span></label>
          <input type="text" id="seedStockName" name="seed_name" required placeholder="e.g. Rice Seeds - Premium">
        </div>
        <div class="form-field">
          <label for="seedStockUnit">Unit <span style="color:#d32f2f;">*</span></label>
          <select id="seedStockUnit" name="seed_unit" required>
            <option value="kg">kg</option>
            <option value="grams">grams</option>
            <option value="packets">packets</option>
            <option value="sacks">sacks</option>
            <option value="pcs">pcs</option>
          </select>
        </div>
        <div class="form-field">
          <label for="seedStockQty">Available Quantity <span style="color:#d32f2f;">*</span></label>
          <input type="number" id="seedStockQty" name="available_quantity" step="0.01" min="0" required>
        </div>
        <div class="form-field">
          <label for="seedStockThreshold">Low Stock Threshold <span style="color:#d32f2f;">*</span></label>
          <input type="number" id="seedStockThreshold" name="low_stock_threshold" step="0.01" min="0" required>
        </div>
      </div>
      <div class="form-actions-inline" style="margin-top:1rem; display: flex; gap: 10px; justify-content: flex-end;">
        <a href="admin_dashboard.php?section=distribute-seeds" class="btn-secondary">Cancel</a>
        <button type="submit" class="btn-primary" id="seedStockSubmitBtn">Add Seed</button>
      </div>
    </form>
  </div>
</section>
<?php endif; ?>


<!-- Distribute Seeds Form Section (moved from modal) -->
<section id="section-distribute-seeds-form" class="admin-section" style="margin-bottom: 2rem;">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <h1>Distribute Seeds</h1>
      <p>Assign seeds to a farmer from available inventory. All fields are required.</p>
    </div>
  </div>
  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <form id="distributeSeedsForm" method="POST" action="admin_dashboard.php?section=distribute-seeds" class="schedule-form">
      <input type="hidden" name="action" value="distribute_seeds">
      <div class="form-grid">
        <label class="form-field">Farmer <span style="color: #d32f2f;">*</span>
          <select id="dist_farmer" name="farmer_id" required onchange="updateAvailableSeeds()">
            <option value="">-- Select Farmer --</option>
            <?php foreach ($farmers as $farmer): ?>
              <option value="<?php echo $farmer['farmer_id']; ?>"><?php echo htmlspecialchars($farmer['farmer_name']); ?></option>
            <?php endforeach; ?>
          </select>
        </label>

        <label class="form-field">Seed <span style="color: #d32f2f;">*</span>
          <select id="dist_seed" name="seed_id" required onchange="updateMaxQuantity()">
            <option value="">-- Select Seed --</option>
            <?php foreach ($seeds as $seed): ?>
              <option value="<?php echo $seed['seed_id']; ?>" 
                data-qty="<?php echo $seed['available_quantity']; ?>"
                data-unit="<?php echo htmlspecialchars($seed['seed_unit']); ?>"
                <?php echo ($seed['available_quantity'] <= 0) ? 'disabled' : ''; ?>>
                <?php echo htmlspecialchars($seed['seed_name']); ?> 
                (<?php echo number_format($seed['available_quantity'], 2); ?> <?php echo htmlspecialchars($seed['seed_unit']); ?> available)
              </option>
            <?php endforeach; ?>
          </select>
        </label>

        <label class="form-field">Quantity <span style="color: #d32f2f;">*</span>
          <div style="display: flex; gap: 10px;">
            <input type="number" id="dist_quantity" name="quantity_distributed" 
              step="0.01" placeholder="0.00" required min="0" 
              style="flex: 1;">
            <span id="dist_unit" style="padding: 8px 12px; background: #f0f0f0; border-radius: 4px; min-width: 50px; display: flex; align-items: center;">kg</span>
          </div>
          <small id="dist_qty_error" style="color: #d32f2f; display: none; margin-top: 5px;"></small>
        </label>

        <label class="form-field">Distribution Date <span style="color: #d32f2f;">*</span>
          <input type="date" id="dist_date" name="distribution_date" required value="<?php echo date('Y-m-d'); ?>">
        </label>
      </div>
      <div class="form-actions-inline" style="margin-top:1rem; display: flex; gap: 10px; justify-content: flex-end;">
        <button type="reset" class="btn-secondary">Clear</button>
        <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
          <i class="fas fa-seedling"></i>
          <span>Distribute Seeds</span>
        </button>
      </div>
    </form>
  </div>
</section>

<style>
.stock-badge {
  display: inline-block;
  font-size: 12px;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 999px;
}

.stock-badge.stock-good {
  background: #e8f5e9;
  color: #2e7d32;
}

.stock-badge.stock-low {
  background: #fff8e1;
  color: #ef6c00;
}

.stock-badge.stock-out {
  background: #ffebee;
  color: #c62828;
}

.status.released {
  background: #e3f2fd;
  color: #1976d2;
}

.status.pending {
  background: #fff3cd;
  color: #856404;
}

.status.confirmed {
  background: #d4edda;
  color: #155724;
}

.status.completed {
  background: #d4edda;
  color: #155724;
}

.status.cancelled {
  background: #f8d7da;
  color: #721c24;
}

.status.stock-low {
  background: #fff8e1;
  color: #ef6c00;
}

.status.stock {
  background: #e8f5e9;
  color: #2e7d32;
}

.status.returned {
  background: #e8f5e9;
  color: #2e7d32;
}

.status.received {
  background: #e8f5e9;
  color: #388e3c;
}

#section-distribute-seeds .btn-small,
#section-distribute-seeds .btn-small:hover,
#section-distribute-seeds .btn-small:focus {
  text-decoration: none;
}
</style>

<script>
function openSeedStockModal() {
  openSeedStockFormModal('add');
}

function exportSeedRecordsCsv() {
  window.location.href = 'admin_dashboard.php?section=transaction-export-preview&type=seeds&from=distribute-seeds';
}

function openSeedStockFormModal(mode, seedId, seedName, seedUnit, availableQty, threshold) {
  const formModal = document.getElementById('seedStockFormModal');
  const form = document.getElementById('seedStockForm');
  const title = document.getElementById('seedStockFormTitle');
  const actionInput = document.getElementById('seedStockAction');
  const idInput = document.getElementById('seedStockId');
  const nameInput = document.getElementById('seedStockName');
  const unitInput = document.getElementById('seedStockUnit');
  const qtyInput = document.getElementById('seedStockQty');
  const thresholdInput = document.getElementById('seedStockThreshold');
  const submitBtn = document.getElementById('seedStockSubmitBtn');

  if (!formModal || !form) return;

  form.reset();

  if (mode === 'edit') {
    if (title) title.textContent = 'Edit Seed Stock';
    if (actionInput) actionInput.value = 'update_seed_stock';
    if (idInput) idInput.value = String(seedId || '');
    if (nameInput) nameInput.value = seedName || '';
    if (unitInput) unitInput.value = seedUnit || 'kg';
    if (qtyInput) qtyInput.value = Number(availableQty || 0).toFixed(2);
    if (thresholdInput) thresholdInput.value = Number(threshold || 0).toFixed(2);
    if (submitBtn) submitBtn.textContent = 'Save Changes';
  } else {
    if (title) title.textContent = 'Add Seed Stock';
    if (actionInput) actionInput.value = 'add_seed_stock';
    if (idInput) idInput.value = '';
    if (submitBtn) submitBtn.textContent = 'Add Seed';
  }

  formModal.classList.add('is-visible');
}

function closeSeedStockFormModal(event) {
  const formModal = document.getElementById('seedStockFormModal');
  if (!formModal) return;

  if (!event || event.target === formModal) {
    formModal.classList.remove('is-visible');
  }
}



function openSeedDistributionDetailsModal(button) {
  const row = button ? button.closest('tr') : null;
  const modal = document.getElementById('seedDistributionDetailsModal');
  if (!row || !modal) return;

  const recordType = row.dataset.recordType || 'distribution';
  const seedName = row.dataset.seedName || '';
  const farmerName = row.dataset.farmerName || '-';
  const unit = row.dataset.seedUnit || 'kg';
  const detailsTitle = document.getElementById('seedDetailsModalTitle');
  const modeHint = document.getElementById('seedDetailsModeHint');

  const idInput = document.getElementById('detail_distribution_id');
  const recordTypeInput = document.getElementById('detail_record_type');
  const seedIdInput = document.getElementById('detail_seed_id');
  const seedThresholdInput = document.getElementById('detail_seed_threshold');
  const seedInput = document.getElementById('detail_seed_name');
  const farmerInput = document.getElementById('detail_farmer_name');
  const quantityInput = document.getElementById('detail_quantity');
  const dateInput = document.getElementById('detail_distribution_date');
  const statusInput = document.getElementById('detail_status');
  const unitLabel = document.getElementById('detail_unit');
  const editBtn = document.getElementById('detailEditBtn');
  const saveBtn = document.getElementById('detailSaveBtn');
  const statusField = statusInput ? statusInput.closest('.form-field') : null;
  const dateFieldLabel = document.querySelector('label[for="detail_distribution_date"]');

  if (idInput) idInput.value = row.dataset.distributionId || '';
  if (recordTypeInput) recordTypeInput.value = recordType;
  if (seedIdInput) seedIdInput.value = row.dataset.seedId || '';
  if (seedThresholdInput) seedThresholdInput.value = row.dataset.seedThreshold || '0';
  if (seedInput) seedInput.value = seedName;
  if (farmerInput) farmerInput.value = farmerName;
  if (quantityInput) quantityInput.value = Number(row.dataset.quantity || 0).toFixed(2);
  if (dateInput) dateInput.value = row.dataset.distributionDate || '';
  if (statusInput) statusInput.value = String(row.dataset.status || 'pending').toLowerCase();
  if (unitLabel) unitLabel.textContent = unit || 'kg';

  if (recordType === 'stock') {
    if (detailsTitle) detailsTitle.innerHTML = '<i class="fas fa-eye" style="color:#3b82f6; margin-right:0.4rem;"></i>Stock Details';
    if (modeHint) modeHint.textContent = 'View stock record. Use Edit to update this seed stock.';
    if (editBtn) editBtn.textContent = 'Edit Stock';
    if (saveBtn) saveBtn.style.display = 'none';
    if (statusField) statusField.style.display = 'none';
    if (dateFieldLabel) dateFieldLabel.innerHTML = 'Record Date <span style="color:#d32f2f;">*</span>';
    setSeedDetailsEditable(false);
  } else {
    if (detailsTitle) detailsTitle.innerHTML = '<i class="fas fa-eye" style="color:#3b82f6; margin-right:0.4rem;"></i>Seed Request Details';
    if (modeHint) modeHint.textContent = 'Review the request. Click Edit to update status or mark it completed.';
    if (editBtn) editBtn.textContent = 'Edit Request';
    if (saveBtn) saveBtn.style.display = 'none';
    if (statusField) statusField.style.display = '';
    if (dateFieldLabel) dateFieldLabel.innerHTML = 'Record Date <span style="color:#d32f2f;">*</span>';
    setSeedDetailsEditable(false);
  }

  modal.classList.add('is-visible');
}

function setSeedDetailsEditable(editable) {
  const quantityInput = document.getElementById('detail_quantity');
  const dateInput = document.getElementById('detail_distribution_date');
  const statusInput = document.getElementById('detail_status');

  if (quantityInput) quantityInput.disabled = !editable;
  if (dateInput) dateInput.disabled = !editable;
  if (statusInput) statusInput.disabled = !editable;
}

function handleSeedDetailEditAction() {
  const recordType = document.getElementById('detail_record_type')?.value || 'distribution';
  const saveBtn = document.getElementById('detailSaveBtn');
  const editBtn = document.getElementById('detailEditBtn');

  if (recordType === 'stock') {
    const seedId = parseInt(document.getElementById('detail_seed_id')?.value || '0', 10);
    const seedName = document.getElementById('detail_seed_name')?.value || '';
    const seedUnit = document.getElementById('detail_unit')?.textContent || 'kg';
    const seedQty = parseFloat(document.getElementById('detail_quantity')?.value || '0');
    const threshold = parseFloat(document.getElementById('detail_seed_threshold')?.value || '0');

    closeSeedDistributionDetailsModal();
    openSeedStockFormModal('edit', seedId, seedName, seedUnit, seedQty, threshold);
    return;
  }

  setSeedDetailsEditable(true);
  if (saveBtn) saveBtn.style.display = 'inline-flex';
  if (editBtn) editBtn.style.display = 'none';
}

function closeSeedDistributionDetailsModal(event) {
  const modal = document.getElementById('seedDistributionDetailsModal');
  const saveBtn = document.getElementById('detailSaveBtn');
  const editBtn = document.getElementById('detailEditBtn');
  const statusField = document.getElementById('detail_status')?.closest('.form-field');
  if (!modal) return;
  if (!event || event.target === modal) {
    setSeedDetailsEditable(false);
    if (saveBtn) saveBtn.style.display = 'none';
    if (editBtn) editBtn.style.display = 'inline-flex';
    if (statusField) statusField.style.display = '';
    modal.classList.remove('is-visible');
  }
}

function updateAvailableSeeds() {
  // Seeds are already filtered in PHP based on availability
  updateMaxQuantity();
}

function updateMaxQuantity() {
  const seedSelect = document.getElementById('dist_seed');
  const selectedOption = seedSelect.options[seedSelect.selectedIndex];
  const maxQty = parseFloat(selectedOption.getAttribute('data-qty')) || 0;
  const unit = selectedOption.getAttribute('data-unit') || 'kg';
  
  document.getElementById('dist_unit').textContent = unit;
  document.getElementById('dist_quantity').max = maxQty;
  
  // Clear error message
  document.getElementById('dist_qty_error').style.display = 'none';
}

// Validate quantity before submission
document.getElementById('distributeSeedsForm').addEventListener('submit', function(e) {
  const seedSelect = document.getElementById('dist_seed');
  const quantity = parseFloat(document.getElementById('dist_quantity').value);
  const selectedOption = seedSelect.options[seedSelect.selectedIndex];
  const maxQty = parseFloat(selectedOption.getAttribute('data-qty')) || 0;
  
  if (quantity > maxQty) {
    e.preventDefault();
    document.getElementById('dist_qty_error').textContent = `Cannot distribute more than ${maxQty}. Only ${maxQty} available.`;
    document.getElementById('dist_qty_error').style.display = 'block';
  }
});


</script>
