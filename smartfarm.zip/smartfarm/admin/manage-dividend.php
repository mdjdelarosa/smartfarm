<?php
require '../config.php';

// Fetch current dividend percentage (example: from settings table)
$current_farmer_pct = 70; // Default 70%
$current_coop_pct = 30; // Default 30%
$pending_farmer_pct = null;
$pending_coop_pct = null;
$pending_effective_date = null;

// Example: Check for pending change (replace with real DB logic)
// ...

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_farmer_pct = (int)($_POST['farmer_pct'] ?? $current_farmer_pct);
    $new_coop_pct = 100 - $new_farmer_pct;
    $effective_date = $_POST['effective_date'] ?? date('Y-m-d');
    // TODO: Save to DB as pending change, notify admin, etc.
    $pending_farmer_pct = $new_farmer_pct;
    $pending_coop_pct = $new_coop_pct;
    $pending_effective_date = $effective_date;
    $success_msg = "Pending change: $pending_farmer_pct% Farmer / $pending_coop_pct% Coop, effective $pending_effective_date.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Dividend Percentage</title>
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .manage-dividend-card { max-width: 480px; margin: 2.5rem auto; background: #fff; border-radius: 12px; box-shadow: 0 8px 32px rgba(34,197,94,0.10); padding: 2.2rem 2.2rem 2rem 2.2rem; }
    .manage-dividend-card h2 { color: #15803d; margin-bottom: 1.2rem; }
    .manage-dividend-form label { font-weight: 600; color: #14532d; margin-bottom: 0.4rem; display: block; }
    .manage-dividend-form input[type="number"] { width: 80px; padding: 0.4rem 0.7rem; border-radius: 7px; border: 1px solid #cde9d3; font-size: 1.1rem; margin-right: 0.5rem; }
    .manage-dividend-form input[type="date"] { padding: 0.4rem 0.7rem; border-radius: 7px; border: 1px solid #cde9d3; font-size: 1.1rem; }
    .manage-dividend-form .form-row { margin-bottom: 1.2rem; }
    .manage-dividend-form .btn-primary { background: #22c55e; color: #fff; border: none; border-radius: 8px; padding: 0.55rem 1.3rem; font-size: 1.1rem; font-weight: 600; cursor: pointer; transition: background 0.2s; }
    .manage-dividend-form .btn-primary:hover { background: #15803d; }
    .pending-info { background: #f3faf4; border: 1px solid #cde9d3; border-radius: 8px; padding: 1rem; margin-bottom: 1.2rem; color: #166534; }
    .success-msg { color: #15803d; margin-bottom: 1.2rem; font-weight: 600; }
  </style>
</head>
<body>
  <div class="manage-dividend-card">
    <h2><i class="fas fa-percent"></i> Manage Dividend Percentage</h2>
    <?php if (!empty($success_msg)): ?>
      <div class="success-msg"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>
    <?php if ($pending_farmer_pct !== null): ?>
      <div class="pending-info">
        <strong>Pending Change:</strong><br>
        Farmer: <?php echo $pending_farmer_pct; ?>%<br>
        Coop: <?php echo $pending_coop_pct; ?>%<br>
        Effective Date: <?php echo htmlspecialchars($pending_effective_date); ?>
      </div>
    <?php endif; ?>
    <form method="post" class="manage-dividend-form">
      <div class="form-row">
        <label for="farmer_pct">Farmer Dividend Percentage</label>
        <input type="number" id="farmer_pct" name="farmer_pct" min="1" max="99" value="<?php echo $current_farmer_pct; ?>" required> %
        <span style="margin-left:1.2rem; color:#888;">Coop: <span id="coop_pct_label"><?php echo $current_coop_pct; ?></span>%</span>
      </div>
      <div class="form-row">
        <label for="effective_date">Effective Date</label>
        <input type="date" id="effective_date" name="effective_date" value="<?php echo date('Y-m-d'); ?>" required>
      </div>
      <button type="submit" class="btn-primary"><i class="fas fa-save"></i> Apply New Dividend</button>
    </form>
    <div style="margin-top:1.5rem;">
      <a href="dashboard.php" style="color:#15803d;text-decoration:underline;font-weight:600;">&larr; Back to Dashboard</a>
    </div>
  </div>
  <script>
    // Live update Coop %
    document.getElementById('farmer_pct').addEventListener('input', function() {
      let v = parseInt(this.value, 10);
      if (isNaN(v) || v < 1) v = 1;
      if (v > 99) v = 99;
      document.getElementById('coop_pct_label').textContent = 100 - v;
    });
  </script>
</body>
</html>
