<?php
// Simplified Livestock Reservation Monitor
?>

<style>
  .lp-toast {
    position: fixed;
    bottom: 1.5rem;
    right: 1.5rem;
    background: #22c55e;
    color: #fff;
    padding: 0.85rem 1.2rem;
    border-radius: 8px;
    font-size: 0.9rem;
    font-weight: 600;
    box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
    z-index: 2100;
    display: none;
    max-width: 360px;
  }

  .lp-toast.show {
    display: block;
  }

  .lp-toast.error {
    background: #dc3545;
  }

  .lp-modal-info {
    margin-bottom: 1rem;
    padding: 0.85rem;
    border-radius: 8px;
    background: rgba(34, 197, 94, 0.08);
    border: 1px solid rgba(34, 197, 94, 0.2);
    color: #22c55e;
    font-size: 0.9rem;
    line-height: 1.45;
  }

  .lp-modal-info strong {
    color: #16a34a;
  }

  .status.ready {
    background-color: #d1fae5;
    color: #065f46;
  }

  #section-manage-livestock-products .status {
    white-space: nowrap;
  }

  #section-manage-livestock-products #lpTransactionsTable th:last-child,
  #section-manage-livestock-products #lpTransactionsTable td:last-child {
    white-space: nowrap;
  }

  .lp-action-buttons {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    flex-wrap: nowrap;
  }

  .lp-action-buttons a.btn-small,
  .lp-action-buttons a.btn-small:hover,
  .lp-action-buttons a.btn-small:focus {
    text-decoration: none;
  }

  .status.inactive {
    background-color: #e5e7eb;
    color: #374151;
  }

  .status.out-stock {
    background-color: #fee2e2;
    color: #991b1b;
  }

</style>

<section id="section-manage-livestock-products" class="admin-section">
  <div class="section-header">
    <h1>Livestock Monitor</h1>
    <div style="display:flex;gap:0.5rem;">
      <a class="btn-primary" href="admin_dashboard.php?section=add-livestock-product" data-tooltip="Add product" style="text-decoration:none;display:inline-flex;align-items:center;justify-content:center;">
        <i class="fas fa-plus"></i>
      </a>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="lpTxnSearch">Search</label>
      <input
        type="text"
        class="search-input"
        id="lpTxnSearch"
        placeholder="Search reservation, client, or product..."
        oninput="lpLoadTransactions()"
      >
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="lpTxnStatus">Status</label>
      <select class="filter-select" id="lpTxnStatus" onchange="lpLoadTransactions()">
        <option value="">All Status</option>
        <option value="pending">Pending Approval</option>
        <option value="confirmed">Confirmed</option>
        <option value="ready">Ready for Pickup</option>
        <option value="completed">Completed</option>
        <option value="cancelled">Cancelled</option>
        <option value="listed">Available</option>
        <option value="inactive">Inactive Listing</option>
        <option value="out-stock">Out of Stock Listing</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="lpTxnPayment">Payment</label>
      <select class="filter-select" id="lpTxnPayment" onchange="lpLoadTransactions()">
        <option value="">All Payment</option>
        <option value="paid">Paid</option>
        <option value="unpaid">Unpaid</option>
        <option value="na">No Payment Required</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="lpTxnPriceRange">Total Range</label>
      <select class="filter-select" id="lpTxnPriceRange" onchange="lpLoadTransactions()">
        <option value="">All Totals</option>
        <option value="0-999">PHP 0 - 999</option>
        <option value="1000-2999">PHP 1,000 - 2,999</option>
        <option value="3000-4999">PHP 3,000 - 4,999</option>
        <option value="5000-7999">PHP 5,000 - 7,999</option>
        <option value="8000+">PHP 8,000+</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="lpTxnGroupBy">Group By</label>
      <select class="filter-select" id="lpTxnGroupBy" onchange="sfSetGroupBy('lpTransactionsTable', this); lpLoadTransactions()">
        <option value="">No Grouping</option>
        <option value="6">Status</option>
        <option value="7">Payment</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="lpTransactionsTable">
      <thead>
        <tr>
          <th>Record ID</th>
          <th>Product</th>
          <th>Client</th>
          <th>Qty</th>
          <th>Pickup Date</th>
          <th>Total</th>
          <th>Status</th>
          <th>Payment</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody id="lpTransactionsBody">
        <tr>
          <td colspan="9" style="text-align:center;padding:2rem;color:#6b7280;">
            <i class="fas fa-spinner fa-spin"></i> Loading...
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</section>

<div class="lp-toast" id="lpToast"></div>

<script>
(function () {
  const PROC = 'admin/livestock_product_process.php';
  let transactionCache = [];

  function esc(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function fmtPhp(amount) {
    return 'P' + Number(amount || 0).toLocaleString('en-PH', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
  }

  function fmtDate(value) {
    if (!value) return '-';
    const text = String(value).trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(text)) {
      return text.slice(0, 10);
    }

    const d = new Date(text.length === 10 ? text + 'T00:00:00' : text);
    if (Number.isNaN(d.getTime())) return text;

    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return year + '-' + month + '-' + day;
  }

  function productStatusPill(status) {
    const map = {
      'Active': 'active',
      'Inactive': 'inactive',
      'Out of Stock': 'out-stock'
    };
    const cls = map[status] || 'inactive';
    return '<span class="status ' + cls + '">' + esc(status) + '</span>';
  }

  function reservationStatusPill(status) {
    const key = String(status || '').toLowerCase();
    const cls = {
      pending: 'pending',
      confirmed: 'approved',
      ready: 'ready',
      completed: 'completed',
      cancelled: 'cancelled',
      listed: 'active',
      inactive: 'inactive',
      'out-stock': 'out-stock'
    }[key] || 'pending';

    const label = {
      pending: 'Pending Approval',
      confirmed: 'Confirmed',
      ready: 'Ready for Pickup',
      completed: 'Completed',
      cancelled: 'Cancelled',
      listed: 'Available',
      inactive: 'Inactive Listing',
      'out-stock': 'Out of Stock Listing'
    }[key] || key;

    return '<span class="status ' + cls + '">' + esc(label) + '</span>';
  }

  function paymentStatusPill(status) {
    const key = String(status || '').toLowerCase();
    if (key === '' || key === 'na') {
      return '<span style="color:#6b7280;">-</span>';
    }

    const paid = String(status || 'unpaid').toLowerCase() === 'paid';
    return '<span class="status ' + (paid ? 'approved' : 'pending') + '">' + (paid ? 'Paid' : 'Unpaid') + '</span>';
  }


  function toast(message, isError) {
    const el = document.getElementById('lpToast');
    el.textContent = message;
    el.className = 'lp-toast show' + (isError ? ' error' : '');
    clearTimeout(window._lpToastTimer);
    window._lpToastTimer = setTimeout(function () {
      el.classList.remove('show');
    }, 3500);
  }

  function csvEscape(value) {
    const text = String(value ?? '');
    return '"' + text.replace(/"/g, '""') + '"';
  }

  function csvDateForFile() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    return y + m + day + '_' + hh + mm;
  }

  window.lpExportTransactions = function () {
    window.location.href = 'admin_dashboard.php?section=transaction-export-preview&type=livestock&from=manage-livestock-products';
  };

  window.lpLoadTransactions = function () {
    const params = new URLSearchParams({
      action: 'get_reservations',
      search: document.getElementById('lpTxnSearch').value,
      status: document.getElementById('lpTxnStatus').value
    });

    fetch(PROC + '?' + params.toString())
      .then(function (r) { return r.json(); })
      .then(function (data) {
        const tbody = document.getElementById('lpTransactionsBody');
        transactionCache = [];

        if (!data.success) {
          tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#dc3545;">' + esc(data.message || 'Unable to load transactions') + '</td></tr>';
          return;
        }

        const selectedPayment = String(document.getElementById('lpTxnPayment').value || '').toLowerCase();
        const selectedPriceRange = String(document.getElementById('lpTxnPriceRange').value || '').trim();

        const rows = data.reservations.filter(function (r) {
          const hasReservation = Number(r.reservation_id || 0) > 0;
          const paymentKey = hasReservation ? String(r.payment_status || 'unpaid').toLowerCase() : 'na';
          const totalPrice = parseFloat(r.total_price || 0);

          const matchesPayment = selectedPayment === '' || paymentKey === selectedPayment;
          let matchesPriceRange = true;

          if (selectedPriceRange !== '') {
            if (selectedPriceRange.endsWith('+')) {
              const minOnly = parseFloat(selectedPriceRange.replace('+', ''));
              matchesPriceRange = !Number.isNaN(totalPrice) && !Number.isNaN(minOnly) && totalPrice >= minOnly;
            } else {
              const rangeParts = selectedPriceRange.split('-');
              const minRange = parseFloat(rangeParts[0] || '');
              const maxRange = parseFloat(rangeParts[1] || '');
              matchesPriceRange = !Number.isNaN(totalPrice) && !Number.isNaN(minRange) && !Number.isNaN(maxRange)
                && totalPrice >= minRange && totalPrice <= maxRange;
            }
          }

          return matchesPayment && matchesPriceRange;
        });

        transactionCache = rows;

        if (!rows.length) {
          tbody.innerHTML = '<tr><td colspan="9" style="text-align:center;color:#6b7280;padding:2rem;">No livestock or product records found</td></tr>';
          return;
        }

        tbody.innerHTML = rows.map(function (r) {
          const hasReservation = Number(r.reservation_id || 0) > 0;
          const idLabel = hasReservation
            ? '#RES' + String(r.reservation_id).padStart(3, '0')
            : '#PRD' + String(r.product_id || '').padStart(3, '0');
          const quantityText = Number(r.quantity || 0) + ' ' + String(r.unit || '');
          const paymentKey = hasReservation ? String(r.payment_status || 'unpaid').toLowerCase() : 'na';
          const statusHtml = reservationStatusPill(r.status);
          const paymentHtml = paymentStatusPill(paymentKey);

          let actionHtml = '<span style="color:#9ca3af;">-</span>';
          const productId = Number(r.product_id || 0);
          if (productId > 0) {
            const isTransactionRow = hasReservation;
            const actionHref = isTransactionRow
              ? 'admin_dashboard.php?section=view-livestock-reservation&reservation_id=' + Number(r.reservation_id) + '&from=manage-livestock-products'
              : 'admin_dashboard.php?section=add-livestock-product&edit_product_id=' + productId;
            const actionTip = isTransactionRow ? 'View transaction' : 'Edit product';
            const actionClass = isTransactionRow ? 'btn-view' : 'btn-edit';
            const actionIcon = isTransactionRow ? 'fa-eye' : 'fa-pen';
            actionHtml = '' +
              '<a class="btn-small ' + actionClass + '" data-tooltip="' + actionTip + '" href="' + actionHref + '"><i class="fas ' + actionIcon + '"></i></a>';
          }

          return '<tr>' +
            '<td>' + idLabel + '</td>' +
            '<td><strong>' + esc(r.product_name) + '</strong></td>' +
            '<td>' + esc(r.client_fullname || '-') + '</td>' +
            '<td>' + esc(quantityText) + '</td>' +
            '<td>' + fmtDate(r.preferred_date) + '</td>' +
            '<td>' + fmtPhp(r.total_price) + '</td>' +
            '<td>' + statusHtml + '</td>' +
            '<td>' + paymentHtml + '</td>' +
            '<td>' +
              '<div class="lp-action-buttons">' +
                actionHtml +
              '</div>' +
            '</td>' +
          '</tr>';
        }).join('');

        sfResetGroupOrder('lpTransactionsTable');
        sfApplyGroupBy('lpTransactionsTable');

        // Re-detect column types after dynamic rows are rendered.
        if (typeof setupSortableTableDropdowns === 'function') {
          setupSortableTableDropdowns(document.getElementById('section-manage-livestock-products') || document);
        }

      })
      .catch(function () {
        transactionCache = [];
        document.getElementById('lpTransactionsBody').innerHTML = '<tr><td colspan="9" style="text-align:center;color:#dc3545;">Connection error</td></tr>';
      });
  };

  lpLoadTransactions();
})();
</script>
