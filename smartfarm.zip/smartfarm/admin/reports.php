<!-- Reports & Export Section -->
<section id="section-reports" class="admin-section">
  <div class="section-header">
    <h1>Reports &amp; Export</h1>
  </div>
  <div>

    <!-- Controls card -->
    <div style="background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px #0001;margin-bottom:24px;">
      <div style="display:flex;gap:16px;align-items:flex-end;flex-wrap:wrap;">

        <div style="flex:2;min-width:220px;">
          <label for="reportFileSelect" style="font-weight:600;display:block;margin-bottom:6px;">Choose Export File</label>
          <select id="reportFileSelect" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid #cfd8dc;font-size:14px;">
            <option value="">Loading files…</option>
          </select>
        </div>

        <div style="flex:1;min-width:150px;">
          <label for="reportScopeSelect" style="font-weight:600;display:block;margin-bottom:6px;">Period</label>
          <select id="reportScopeSelect" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid #cfd8dc;font-size:14px;">
            <option value="all">All Records</option>
            <option value="month">Specific Month</option>
            <option value="year">Specific Year</option>
          </select>
        </div>

        <div id="reportPeriodMonthWrap" style="flex:1;min-width:160px;display:none;">
          <label for="reportPeriodMonth" style="font-weight:600;display:block;margin-bottom:6px;">Month</label>
          <input type="month" id="reportPeriodMonth" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid #cfd8dc;font-size:14px;">
        </div>

        <div id="reportPeriodYearWrap" style="flex:1;min-width:120px;display:none;">
          <label for="reportPeriodYear" style="font-weight:600;display:block;margin-bottom:6px;">Year</label>
          <select id="reportPeriodYear" style="width:100%;padding:8px 10px;border-radius:6px;border:1px solid #cfd8dc;font-size:14px;"></select>
        </div>

        <div style="flex:0;min-width:90px;padding-bottom:1px;">
          <button id="reportViewBtn" class="btn-primary" style="width:100%;height:38px;" disabled>View</button>
        </div>
      </div>
    </div>

    <!-- Preview card -->
    <div style="background:#fff;border-radius:10px;padding:24px;box-shadow:0 2px 8px #0001;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
        <div id="reportPreviewTitle" style="font-weight:700;font-size:17px;color:#1f2937;">No file opened</div>
        <div style="display:flex;gap:8px;align-items:center;">
          <select id="reportFormatSelect" style="padding:8px 10px;border-radius:6px;border:1px solid #cfd8dc;font-size:14px;">
            <option value="csv">CSV</option>
            <option value="xls">Excel (.xls)</option>
            <option value="pdf">PDF</option>
          </select>
          <button id="reportPrintBtn" class="btn-secondary" data-tooltip="Print" disabled><i class="fas fa-print"></i></button>
          <button id="reportDownloadBtn" class="btn-secondary" data-tooltip="Download" disabled><i class="fas fa-download"></i></button>
        </div>
      </div>
      <div id="reportPreviewPanel"
           style="border:1px dashed #cfd8dc;border-radius:6px;background:#fafafa;min-height:140px;max-height:480px;overflow:auto;display:flex;align-items:center;justify-content:center;">
        <span id="reportPreviewPlaceholder" style="color:#9ca3af;font-size:15px;">Choose a file and click View.</span>
      </div>
      <div id="reportNote" style="color:#b30000;font-weight:600;margin-top:8px;font-size:13px;"></div>
    </div>

  </div>

  <script>
  (function () {
    const fileSelect       = document.getElementById('reportFileSelect');
    const viewBtn          = document.getElementById('reportViewBtn');
    const downloadBtn      = document.getElementById('reportDownloadBtn');
    const printBtn         = document.getElementById('reportPrintBtn');
    const previewPanel     = document.getElementById('reportPreviewPanel');
    const placeholder      = document.getElementById('reportPreviewPlaceholder');
    const titleEl          = document.getElementById('reportPreviewTitle');
    const noteEl           = document.getElementById('reportNote');
    const formatSelect     = document.getElementById('reportFormatSelect');
    const scopeSelect      = document.getElementById('reportScopeSelect');
    const periodMonthWrap  = document.getElementById('reportPeriodMonthWrap');
    const periodMonthInput = document.getElementById('reportPeriodMonth');
    const periodYearWrap   = document.getElementById('reportPeriodYearWrap');
    const periodYearSelect = document.getElementById('reportPeriodYear');

    let currentFile   = '';
    let currentTitle  = '';
    let loadingFiles  = false;

    // ── Period controls setup ───────────────────────────────────────────────
    const today = new Date();
    periodMonthInput.value = today.getFullYear() + '-' + String(today.getMonth() + 1).padStart(2, '0');
    const curYear = today.getFullYear();
    for (let y = curYear; y >= curYear - 9; y--) {
      const opt = document.createElement('option');
      opt.value = String(y);
      opt.textContent = String(y);
      periodYearSelect.appendChild(opt);
    }

    function currentScopeParams() {
      const scope = scopeSelect.value;
      let period = '';
      if (scope === 'month') period = periodMonthInput.value || '';
      else if (scope === 'year') period = periodYearSelect.value || '';
      return { scope, period };
    }

    function buildListUrl() {
      const { scope, period } = currentScopeParams();
      if (scope === 'all' || !period) return 'admin/reports_list_api.php';
      const params = new URLSearchParams({ scope, period });
      return 'admin/reports_list_api.php?' + params.toString();
    }

    function onPeriodChanged() {
      downloadBtn.disabled = true;
      printBtn.disabled = true;
      resetPreview();
      loadFileList(true);
    }

    scopeSelect.addEventListener('change', () => {
      periodMonthWrap.style.display = scopeSelect.value === 'month' ? '' : 'none';
      periodYearWrap.style.display  = scopeSelect.value === 'year' ? '' : 'none';
      onPeriodChanged();
    });
    periodMonthInput.addEventListener('change', onPeriodChanged);
    periodYearSelect.addEventListener('change', onPeriodChanged);

    // ── Load file list (also regenerates CSVs server-side) ─────────────────
    function loadFileList(keepSelection) {
      if (loadingFiles) return;
      loadingFiles = true;
      const prev = currentFile;
      setPreviewLoading('Generating reports…');
      noteEl.textContent = '';
      viewBtn.disabled = true;

      fetch(buildListUrl())
        .then(r => r.json())
        .then(data => {
          loadingFiles = false;
          if (!data || !data.ok) {
            noteEl.textContent = (data && data.error) ? data.error : 'Failed to load report list.';
            fileSelect.innerHTML = '<option value="">Error loading files</option>';
            fileSelect.disabled = true;
            resetPreview();
            return;
          }
          const list = Array.isArray(data.files) ? data.files : [];
          fileSelect.innerHTML = list.length === 0
            ? '<option value="">No reports available</option>'
            : '<option value="">Select a report…</option>';
          list.forEach(item => {
            const opt = document.createElement('option');
            opt.value = item.file;
            opt.textContent = item.title + '  (' + item.rows + ' rows)';
            fileSelect.appendChild(opt);
          });
          fileSelect.disabled = false;

          // Restore previous selection if still present
          if (keepSelection && prev) {
            fileSelect.value = prev;
            if (fileSelect.value === prev) {
              currentFile = prev;
              viewBtn.disabled = false;
            } else {
              currentFile = '';
              resetPreview();
            }
          } else {
            currentFile = '';
            resetPreview();
          }
        })
        .catch(err => {
          loadingFiles = false;
          noteEl.textContent = 'API error: ' + err.message;
          fileSelect.innerHTML = '<option value="">Error</option>';
          resetPreview();
        });
    }

    // ── Preview helpers ─────────────────────────────────────────────────────
    function setPreviewLoading(msg) {
      previewPanel.style.display = 'flex';
      previewPanel.style.alignItems = 'center';
      previewPanel.style.justifyContent = 'center';
      previewPanel.innerHTML = '<span style="color:#6b7280;font-size:15px;">' + msg + '</span>';
    }

    function resetPreview() {
      previewPanel.style.display = 'flex';
      previewPanel.style.alignItems = 'center';
      previewPanel.style.justifyContent = 'center';
      previewPanel.innerHTML = '<span style="color:#9ca3af;font-size:15px;">Choose a file and click View.</span>';
      titleEl.textContent = 'No file opened';
      downloadBtn.disabled = true;
      printBtn.disabled = true;
    }

    // ── CSV → HTML table ────────────────────────────────────────────────────
    function csvToTable(csv) {
      const rows = [];
      let cur = '', inQ = false, row = [];
      for (let i = 0; i < csv.length; i++) {
        const ch = csv[i];
        if (ch === '"') {
          if (inQ && csv[i + 1] === '"') { cur += '"'; i++; }
          else inQ = !inQ;
        } else if (ch === ',' && !inQ) {
          row.push(cur); cur = '';
        } else if ((ch === '\n' || ch === '\r') && !inQ) {
          if (ch === '\r' && csv[i + 1] === '\n') i++;
          row.push(cur); cur = '';
          if (row.some(c => c !== '')) rows.push(row);
          row = [];
        } else { cur += ch; }
      }
      row.push(cur);
      if (row.some(c => c !== '')) rows.push(row);

      if (!rows.length) return '<div style="padding:16px;color:#666;">No data found.</div>';

      const esc = s => s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      let html = '<div style="overflow:auto;max-height:440px;">'
               + '<table class="data-table" style="width:100%;border-collapse:collapse;font-size:13px;">';
      rows.forEach((r, i) => {
        html += '<tr>';
        r.forEach(cell => {
          const tag = i === 0 ? 'th' : 'td';
          const style = i === 0
            ? 'position:sticky;top:0;background:#eef5f0;border:1px solid #d0e0d4;padding:7px 10px;text-align:left;font-weight:700;white-space:nowrap;'
            : 'border:1px solid #e5e7eb;padding:6px 10px;text-align:left;vertical-align:top;white-space:nowrap;';
          html += `<${tag} style="${style}">${esc(cell)}</${tag}>`;
        });
        html += '</tr>';
      });
      html += '</table></div>';
      if (rows.length > 1) {
        html += `<div style="font-size:12px;color:#6b7280;margin-top:6px;">${rows.length - 1} row(s) shown.</div>`;
      }
      return html;
    }

    // ── View ────────────────────────────────────────────────────────────────
    function viewFile() {
      if (!currentFile) return;
      setPreviewLoading('Loading preview…');
      noteEl.textContent = '';

      // Fetch the pre-generated CSV directly
      fetch('exports/reports/' + encodeURIComponent(currentFile) + '?_=' + Date.now())
        .then(r => {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        })
        .then(text => {
          previewPanel.style.display = 'block';
          previewPanel.style.alignItems = '';
          previewPanel.style.justifyContent = '';
          previewPanel.innerHTML = csvToTable(text);
          titleEl.textContent = currentTitle || currentFile;
          downloadBtn.disabled = false;
          printBtn.disabled = false;
        })
        .catch(err => {
          previewPanel.style.display = 'flex';
          previewPanel.innerHTML = '<span style="color:#b30000;">Could not load preview: ' + err.message + '</span>';
          noteEl.textContent = 'Try regenerating the report.';
        });
    }

    // ── Event listeners ─────────────────────────────────────────────────────
    fileSelect.addEventListener('change', () => {
      const opt = fileSelect.options[fileSelect.selectedIndex];
      currentFile  = fileSelect.value;
      currentTitle = opt ? opt.textContent.replace(/\s*\(.*\)$/, '').trim() : '';
      viewBtn.disabled    = !currentFile;
      downloadBtn.disabled = true;
      printBtn.disabled = true;
      if (!currentFile) resetPreview();
    });

    viewBtn.addEventListener('click', () => {
      if (!currentFile) return;
      setPreviewLoading('Loading preview…');
      noteEl.textContent = '';
      viewFile();
    });

    downloadBtn.addEventListener('click', () => {
      if (!currentFile) return;
      const format = formatSelect.value;
      const url = 'admin/reports_list_api.php?download=' + encodeURIComponent(currentFile)
                + '&format=' + encodeURIComponent(format);
      if (format === 'pdf') {
        // PDF has no server-side library — open a print-ready page and let the
        // browser's print dialog "Save as PDF" produce the file.
        window.open(url, '_blank');
      } else {
        window.location.href = url;
      }
    });

    printBtn.addEventListener('click', () => {
      if (!currentFile) return;
      // Reuse the print-ready HTML page (same one PDF export uses) regardless
      // of whatever format is selected in the dropdown.
      const url = 'admin/reports_list_api.php?download=' + encodeURIComponent(currentFile) + '&format=pdf';
      window.open(url, '_blank');
    });

    // ── Init ────────────────────────────────────────────────────────────────
    loadFileList(false);
  })();
  </script>
</section>
