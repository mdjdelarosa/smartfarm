﻿<?php
require_once '../config.php';

header('Content-Type: application/json');

// Must be logged in as admin
$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if ($sessionRole !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    ensureReservationPaymentColumns($conn);
    ensureProductImageColumns($conn);

    switch ($action) {
        case 'add_product':
            addProduct($conn);
            break;
        case 'edit_product':
            editProduct($conn);
            break;
        case 'delete_product':
            deleteProduct($conn);
            break;
        case 'get_product':
            getProduct($conn);
            break;
        case 'get_products':
            getProducts($conn);
            break;
        case 'get_reservations':
            getReservations($conn);
            break;
        case 'update_reservation_status':
            updateReservationStatus($conn);
            break;
        case 'mark_reservation_paid':
            markReservationPaid($conn);
            break;
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Server error']);
}

function ensureReservationPaymentColumns($conn) {
    $table_check = $conn->query("SHOW TABLES LIKE 'livestock_reservations'");
    if (!$table_check || $table_check->num_rows === 0) {
        return;
    }

    $queries = [
        "ALTER TABLE livestock_reservations ADD COLUMN IF NOT EXISTS payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid'",
        "ALTER TABLE livestock_reservations ADD COLUMN IF NOT EXISTS payment_marked_at DATETIME NULL"
    ];

    foreach ($queries as $sql) {
        if (!$conn->query($sql)) {
            throw new Exception('Unable to prepare reservation payment columns.');
        }
    }
}

function ensureProductImageColumns($conn) {
    $table_check = $conn->query("SHOW TABLES LIKE 'livestock_products'");
    if (!$table_check || $table_check->num_rows === 0) {
        return;
    }

    $queries = [
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image LONGBLOB NULL",
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_name VARCHAR(255) NULL",
        "ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_mime_type VARCHAR(50) NULL"
    ];

    foreach ($queries as $sql) {
        if (!$conn->query($sql)) {
            throw new Exception('Unable to prepare product image columns.');
        }
    }
}

function readUploadedImageFile(string $field_name): array {
    if (!isset($_FILES[$field_name]) || !is_array($_FILES[$field_name])) {
        return ['has_file' => false];
    }

    $file = $_FILES[$field_name];
    $error_code = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);

    if ($error_code === UPLOAD_ERR_NO_FILE) {
        return ['has_file' => false];
    }

    if ($error_code !== UPLOAD_ERR_OK) {
        return ['has_file' => true, 'error' => 'Image upload failed. Please try again.'];
    }

    $tmp_name = (string)($file['tmp_name'] ?? '');
    if ($tmp_name === '' || !is_uploaded_file($tmp_name)) {
        return ['has_file' => true, 'error' => 'Invalid uploaded image file.'];
    }

    $file_size = (int)($file['size'] ?? 0);
    $max_size = 5 * 1024 * 1024;
    if ($file_size <= 0 || $file_size > $max_size) {
        return ['has_file' => true, 'error' => 'Image must be 5MB or smaller.'];
    }

    $blob = file_get_contents($tmp_name);
    if ($blob === false) {
        return ['has_file' => true, 'error' => 'Unable to read uploaded image.'];
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = $finfo ? (string)finfo_file($finfo, $tmp_name) : '';
    if ($finfo) {
        finfo_close($finfo);
    }

    $allowed_mime = ['image/jpeg', 'image/png'];
    if (!in_array($mime, $allowed_mime, true)) {
        return ['has_file' => true, 'error' => 'Only JPG and PNG images are allowed.'];
    }

    $image_name = trim((string)($file['name'] ?? ''));
    if ($image_name === '') {
        $image_name = 'product-image';
    }
    if (strlen($image_name) > 255) {
        $image_name = substr($image_name, 0, 255);
    }

    return [
        'has_file' => true,
        'blob' => $blob,
        'name' => $image_name,
        'mime' => $mime
    ];
}

function buildImageDataUrl($blob, $mime): string {
    if ($blob === null || $blob === '' || $mime === null || $mime === '') {
        return '';
    }

    return 'data:' . $mime . ';base64,' . base64_encode($blob);
}

function livestockDefaultUnitForType(string $product_type): string {
    $type = strtolower(trim($product_type));
    if ($type === 'livestock') {
        return 'head';
    }
    if ($type === 'dairy products') {
        return 'liter';
    }
    if ($type === 'farm products') {
        return 'kg';
    }
    if ($type === 'supplies') {
        return 'pack';
    }
    return 'box';
}

function livestockNormalizeUnit(string $unit, string $product_type = ''): string {
    $normalized = strtolower(trim(preg_replace('/\s+/', ' ', $unit)));
    $aliases = [
        'head' => 'head',
        'heads' => 'head',
        'kg' => 'kg',
        'kilogram' => 'kg',
        'kilograms' => 'kg',
        'g' => 'g',
        'gram' => 'g',
        'grams' => 'g',
        'liter' => 'liter',
        'liters' => 'liter',
        'litre' => 'liter',
        'litres' => 'liter',
        'bottle' => 'bottle',
        'bottles' => 'bottle',
        'tray' => 'tray',
        'trays' => 'tray',
        'pack' => 'pack',
        'packs' => 'pack',
        'sack' => 'sack',
        'sacks' => 'sack',
        'box' => 'box',
        'boxes' => 'box',
        'dozen' => 'dozen',
        'dozens' => 'dozen',
    ];

    if ($normalized === '' || in_array($normalized, ['unit', 'piece', 'pieces', 'pc', 'pcs'], true)) {
        return livestockDefaultUnitForType($product_type);
    }

    return $aliases[$normalized] ?? livestockDefaultUnitForType($product_type);
}

function livestockNormalizeProductDisplayName(string $product_name): string {
    return trim(preg_replace('/\s+/', ' ', $product_name));
}

function addProduct($conn) {
    $name        = trim($_POST['product_name'] ?? '');
    $type        = 'Livestock';
    $description = trim($_POST['product_description'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $stock       = (int)($_POST['stock'] ?? 0);
    $unit        = 'head';
    $status      = $_POST['status'] ?? 'Active';
    $farmer_id   = (int)($_POST['farmer_id'] ?? 0);

    $allowed_types   = ['Livestock', 'Dairy Products', 'Farm Products', 'Supplies', 'Other'];
    $allowed_statuses = ['Active', 'Inactive', 'Out of Stock'];
    $allowed_units = ['head', 'kg', 'g', 'liter', 'bottle', 'tray', 'pack', 'sack', 'box', 'dozen'];
    $image_upload = readUploadedImageFile('product_image');

    if (strlen($name) < 2 || strlen($name) > 255) {
        echo json_encode(['success' => false, 'message' => 'Product name must be 2-255 characters']);
        return;
    }
    if (!in_array($type, $allowed_types)) {
        echo json_encode(['success' => false, 'message' => 'Invalid product type']);
        return;
    }
    if ($price < 0) {
        echo json_encode(['success' => false, 'message' => 'Price cannot be negative']);
        return;
    }
    if ($stock < 0) {
        echo json_encode(['success' => false, 'message' => 'Stock cannot be negative']);
        return;
    }
    if (!in_array($status, $allowed_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        return;
    }

    if (!in_array($unit, $allowed_units, true)) {
        $unit = livestockDefaultUnitForType((string)$type);
    }

    if (!empty($image_upload['error'])) {
        echo json_encode(['success' => false, 'message' => $image_upload['error']]);
        return;
    }

    $admin_id = (int)$_SESSION['user_id'];
    // Resolve admin record id
    $stmt = $conn->prepare("SELECT admin_id FROM admins WHERE user_id = ? LIMIT 1");
    $stmt->bind_param('i', $admin_id);
    $stmt->execute();
    $admin_row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $admin_record_id = $admin_row ? (int)$admin_row['admin_id'] : null;

    $farmer_val = $farmer_id > 0 ? $farmer_id : null;
    $product_image_blob = $image_upload['has_file'] ? (string)$image_upload['blob'] : null;
    $product_image_name = $image_upload['has_file'] ? (string)$image_upload['name'] : null;
    $product_image_mime = $image_upload['has_file'] ? (string)$image_upload['mime'] : null;

    $existing_stmt = $conn->prepare(
        "SELECT product_id, stock
         FROM livestock_products
         WHERE LOWER(TRIM(product_name)) = LOWER(TRIM(?))
           AND product_type = ?
           AND unit = ?
         ORDER BY product_id DESC
         LIMIT 1"
    );
    if (!$existing_stmt) {
        echo json_encode(['success' => false, 'message' => 'Failed to check duplicate product record']);
        return;
    }

    $existing_stmt->bind_param('sss', $name, $type, $unit);
    $existing_stmt->execute();
    $existing_result = $existing_stmt->get_result();
    $existing_row = $existing_result ? $existing_result->fetch_assoc() : null;
    $existing_stmt->close();

    if ($existing_row) {
        $product_id = (int)$existing_row['product_id'];
        $new_stock = (int)$existing_row['stock'] + $stock;

        $sql = "UPDATE livestock_products
                SET farmer_id=?, created_by_admin=?, product_name=?, product_type=?, product_description=?, price=?, stock=?, unit=?, status=?";
        $params = [$farmer_val, $admin_record_id, $name, $type, $description, $price, $new_stock, $unit, $status];
        $types = 'iisssdiss';

        if ($image_upload['has_file']) {
            $sql .= ", product_image = ?, product_image_name = ?, product_image_mime_type = ?";
            $params[] = $product_image_blob;
            $params[] = $product_image_name;
            $params[] = $product_image_mime;
            $types .= 'sss';
        }

        $sql .= " WHERE product_id = ?";
        $params[] = $product_id;
        $types .= 'i';

        $update_stmt = $conn->prepare($sql);
        if (!$update_stmt) {
            echo json_encode(['success' => false, 'message' => 'Failed to update existing product']);
            return;
        }

        $update_stmt->bind_param($types, ...$params);
        if ($update_stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Existing product updated. Stock was added instead of creating a duplicate.',
                'product_id' => $product_id
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update existing product']);
        }
        $update_stmt->close();
        return;
    }

    $stmt = $conn->prepare(
        "INSERT INTO livestock_products (farmer_id, created_by_admin, product_name, product_type, product_description, price, stock, unit, status, product_image, product_image_name, product_image_mime_type)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('iisssdisssss', $farmer_val, $admin_record_id, $name, $type, $description, $price, $stock, $unit, $status, $product_image_blob, $product_image_name, $product_image_mime);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product added successfully', 'product_id' => $stmt->insert_id]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to add product']);
    }
    $stmt->close();
}

function editProduct($conn) {
    $product_id  = (int)($_POST['product_id'] ?? 0);
    $name        = trim($_POST['product_name'] ?? '');
    $type        = 'Livestock';
    $description = trim($_POST['product_description'] ?? '');
    $price       = (float)($_POST['price'] ?? 0);
    $stock       = (int)($_POST['stock'] ?? 0);
    $unit        = 'head';
    $status      = $_POST['status'] ?? 'Active';
    $farmer_id   = (int)($_POST['farmer_id'] ?? 0);

    $allowed_types   = ['Livestock', 'Dairy Products', 'Farm Products', 'Supplies', 'Other'];
    $allowed_statuses = ['Active', 'Inactive', 'Out of Stock'];
    $remove_image = (int)($_POST['remove_product_image'] ?? 0) === 1;
    $image_upload = readUploadedImageFile('product_image');

    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
        return;
    }
    if (strlen($name) < 2 || strlen($name) > 255) {
        echo json_encode(['success' => false, 'message' => 'Product name must be 2-255 characters']);
        return;
    }
    if (!in_array($type, $allowed_types)) {
        echo json_encode(['success' => false, 'message' => 'Invalid product type']);
        return;
    }
    if ($price < 0 || $stock < 0) {
        echo json_encode(['success' => false, 'message' => 'Price and stock cannot be negative']);
        return;
    }
    if (!in_array($status, $allowed_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Invalid status']);
        return;
    }
    if (!empty($image_upload['error'])) {
        echo json_encode(['success' => false, 'message' => $image_upload['error']]);
        return;
    }

    if ($remove_image && $image_upload['has_file']) {
        echo json_encode(['success' => false, 'message' => 'Choose either remove image or upload a new image, not both.']);
        return;
    }

    $farmer_val = $farmer_id > 0 ? $farmer_id : null;

    $sql = "UPDATE livestock_products
            SET farmer_id=?, product_name=?, product_type=?, product_description=?, price=?, stock=?, unit=?, status=?";
    $params = [$farmer_val, $name, $type, $description, $price, $stock, $unit, $status];
    $types = 'isssdiss';

    if ($remove_image) {
        $sql .= ", product_image = NULL, product_image_name = NULL, product_image_mime_type = NULL";
    } elseif ($image_upload['has_file']) {
        $sql .= ", product_image = ?, product_image_name = ?, product_image_mime_type = ?";
        $params[] = (string)$image_upload['blob'];
        $params[] = (string)$image_upload['name'];
        $params[] = (string)$image_upload['mime'];
        $types .= 'sss';
    }

    $sql .= " WHERE product_id=?";
    $params[] = $product_id;
    $types .= 'i';

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update product']);
    }
    $stmt->close();
}

function deleteProduct($conn) {
    $product_id = (int)($_POST['product_id'] ?? 0);
    if ($product_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid product ID']);
        return;
    }
    // Check for active/pending reservations
    $stmt = $conn->prepare("SELECT COUNT(*) as cnt FROM livestock_reservations WHERE product_id = ? AND status IN ('pending','confirmed','ready')");
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $cnt = (int)$stmt->get_result()->fetch_assoc()['cnt'];
    $stmt->close();

    if ($cnt > 0) {
        echo json_encode(['success' => false, 'message' => 'Cannot delete: this product has active reservations. Cancel them first.']);
        return;
    }

    $stmt = $conn->prepare("DELETE FROM livestock_products WHERE product_id = ?");
    $stmt->bind_param('i', $product_id);
    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo json_encode(['success' => true, 'message' => 'Product deleted']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
    }
    $stmt->close();
}

function getProduct($conn) {
    $product_id = (int)($_GET['product_id'] ?? 0);
    $stmt = $conn->prepare(
        "SELECT lp.*, COALESCE(f.farmer_fullname, '') AS farmer_name
         FROM livestock_products lp
         LEFT JOIN farmers f ON lp.farmer_id = f.farmer_id
         WHERE lp.product_id = ? LIMIT 1"
    );
    $stmt->bind_param('i', $product_id);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($product) {
        $product['price'] = (float)$product['price'];
        $product['stock'] = (int)$product['stock'];
        $product['product_name'] = livestockNormalizeProductDisplayName((string)($product['product_name'] ?? ''));
        $product['unit'] = livestockNormalizeUnit((string)($product['unit'] ?? ''), (string)($product['product_type'] ?? ''));
        $product['product_image_url'] = buildImageDataUrl($product['product_image'] ?? null, $product['product_image_mime_type'] ?? '');
        unset($product['product_image']);
        echo json_encode(['success' => true, 'product' => $product]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Product not found']);
    }
}

function getProducts($conn) {
    $search = $_GET['search'] ?? '';
    $type   = $_GET['type'] ?? '';
    $status = $_GET['status'] ?? '';

    $where = "WHERE 1=1";
    $params = [];
    $types = '';

    if ($search) {
        $where .= " AND lp.product_name LIKE ?";
        $params[] = '%' . $search . '%';
        $types .= 's';
    }
    if ($type && $type !== 'All Types') {
        $where .= " AND lp.product_type = ?";
        $params[] = $type;
        $types .= 's';
    }
    if ($status && $status !== 'All Statuses') {
        $where .= " AND lp.status = ?";
        $params[] = $status;
        $types .= 's';
    }

    $sql = "SELECT lp.product_id, lp.product_name, lp.product_type, lp.price, lp.stock, lp.unit, lp.status,
                   lp.product_image, lp.product_image_mime_type,
                   COALESCE(f.farmer_fullname, 'Admin') AS supplier
            FROM livestock_products lp
            LEFT JOIN farmers f ON lp.farmer_id = f.farmer_id
            $where
            ORDER BY lp.created_at DESC";

    $stmt = $conn->prepare($sql);
    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    $result = $stmt->get_result();

    $products = [];
    while ($row = $result->fetch_assoc()) {
        $row['price'] = (float)$row['price'];
        $row['stock'] = (int)$row['stock'];
        $row['product_name'] = livestockNormalizeProductDisplayName((string)($row['product_name'] ?? ''));
        $row['unit'] = livestockNormalizeUnit((string)($row['unit'] ?? ''), (string)($row['product_type'] ?? ''));
        $row['product_image_url'] = buildImageDataUrl($row['product_image'] ?? null, $row['product_image_mime_type'] ?? '');
        unset($row['product_image']);
        $products[] = $row;
    }
    $stmt->close();

    echo json_encode(['success' => true, 'products' => $products]);
}

function getReservations($conn) {
    $status = $_GET['status'] ?? '';
    $search = $_GET['search'] ?? '';

    $sql = "SELECT
                'reservation' AS record_type,
                r.reservation_id,
                lp.product_id,
                COALESCE(r.quantity, 0) AS quantity,
                COALESCE(r.unit_price, lp.price) AS unit_price,
                COALESCE(r.total_price, COALESCE(r.quantity, 0) * lp.price) AS total_price,
                r.preferred_date,
                COALESCE(r.notes, '') AS notes,
                COALESCE(r.status, 'pending') AS status,
                COALESCE(r.admin_notes, '') AS admin_notes,
                COALESCE(r.created_at, lp.created_at) AS created_at,
                COALESCE(r.payment_status, 'unpaid') AS payment_status,
                r.payment_marked_at,
                lp.product_name,
                lp.product_type,
                lp.unit,
                COALESCE(c.client_fullname, '') AS client_fullname,
                COALESCE(c.client_contact_number, '') AS client_contact_number
            FROM livestock_reservations r
            INNER JOIN livestock_products lp ON lp.product_id = r.product_id
            LEFT JOIN clients c ON c.client_id = r.client_id

            UNION ALL

            SELECT
                'stock' AS record_type,
                NULL AS reservation_id,
                lp.product_id,
                GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) AS quantity,
                lp.price AS unit_price,
                GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) * lp.price AS total_price,
                NULL AS preferred_date,
                CASE
                    WHEN lp.status = 'Inactive' THEN 'Inactive listing'
                    WHEN lp.status = 'Out of Stock' THEN 'Out of stock listing'
                    ELSE 'Unordered stock'
                END AS notes,
                CASE
                    WHEN lp.status = 'Inactive' THEN 'inactive'
                    WHEN lp.status = 'Out of Stock' OR GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) <= 0 THEN 'out-stock'
                    ELSE 'listed'
                END AS status,
                '' AS admin_notes,
                lp.created_at AS created_at,
                'na' AS payment_status,
                NULL AS payment_marked_at,
                lp.product_name,
                lp.product_type,
                lp.unit,
                '' AS client_fullname,
                '' AS client_contact_number
            FROM livestock_products lp
            LEFT JOIN (
                SELECT
                    product_id,
                    SUM(quantity) AS active_reserved_qty
                FROM livestock_reservations
                WHERE status IN ('pending', 'confirmed', 'ready')
                GROUP BY product_id
            ) a ON a.product_id = lp.product_id
            WHERE GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) > 0

            ORDER BY created_at DESC";

    $result = $conn->query($sql);
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'Failed to load reservation records']);
        return;
    }

    $status = strtolower(trim((string)$status));
    $search = trim((string)$search);

    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $row['total_price'] = (float)($row['total_price'] ?? 0);
        $row['unit_price'] = (float)($row['unit_price'] ?? 0);
        $row['quantity'] = (int)($row['quantity'] ?? 0);
        $row['product_id'] = (int)($row['product_id'] ?? 0);
        $row['reservation_id'] = isset($row['reservation_id']) ? (int)$row['reservation_id'] : 0;
        $row['status'] = strtolower((string)($row['status'] ?? 'listed'));
        $row['payment_status'] = strtolower((string)($row['payment_status'] ?? 'na'));
        $row['product_name'] = livestockNormalizeProductDisplayName((string)($row['product_name'] ?? ''));
        $row['unit'] = livestockNormalizeUnit((string)($row['unit'] ?? ''), (string)($row['product_type'] ?? ''));

        if ($status !== '' && $status !== 'all statuses') {
            $allowed_statuses = ['pending', 'confirmed', 'ready', 'completed', 'cancelled', 'listed', 'inactive', 'out-stock'];
            if (in_array($status, $allowed_statuses, true) && $row['status'] !== $status) {
                continue;
            }
        }

        if ($search !== '') {
            $haystack = strtolower(
                (string)($row['product_name'] ?? '') . ' ' .
                (string)($row['client_fullname'] ?? '') . ' ' .
                (string)($row['notes'] ?? '')
            );
            if (strpos($haystack, strtolower($search)) === false) {
                continue;
            }
        }

        $reservations[] = $row;
    }

    echo json_encode(['success' => true, 'reservations' => $reservations]);
}

function updateReservationStatus($conn) {
    $reservation_id = (int)($_POST['reservation_id'] ?? 0);
    $status         = $_POST['status'] ?? '';
    $payment_status = $_POST['payment_status'] ?? '';
    $admin_notes    = trim($_POST['admin_notes'] ?? '');

    $allowed = ['pending', 'confirmed', 'ready', 'completed', 'cancelled'];
    $allowed_payments = ['unpaid', 'paid'];
    if ($reservation_id <= 0 || !in_array($status, $allowed) || !in_array($payment_status, $allowed_payments)) {
        echo json_encode(['success' => false, 'message' => 'Invalid input']);
        return;
    }
    if (strlen($admin_notes) > 500) {
        echo json_encode(['success' => false, 'message' => 'Admin notes too long']);
        return;
    }

    // Fetch current reservation to know if we're cancelling an active one (need to restore stock)
    $fetch_stmt = $conn->prepare(
        "SELECT quantity, product_id, status AS current_status FROM livestock_reservations WHERE reservation_id = ? LIMIT 1"
    );
    $fetch_stmt->bind_param('i', $reservation_id);
    $fetch_stmt->execute();
    $cur = $fetch_stmt->get_result()->fetch_assoc();
    $fetch_stmt->close();

    if (!$cur) {
        echo json_encode(['success' => false, 'message' => 'Reservation not found']);
        return;
    }

    $payment_marked_at = null;
    if ($payment_status === 'paid') {
        $payment_marked_at = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("UPDATE livestock_reservations SET status=?, payment_status=?, payment_marked_at=?, admin_notes=? WHERE reservation_id=?");
        $stmt->bind_param('ssssi', $status, $payment_status, $payment_marked_at, $admin_notes, $reservation_id);
    } else {
        $stmt = $conn->prepare("UPDATE livestock_reservations SET status=?, payment_status=?, admin_notes=? WHERE reservation_id=?");
        $stmt->bind_param('sssi', $status, $payment_status, $admin_notes, $reservation_id);
    }

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $stmt->close();
        // Restore stock if admin cancels an active (pending/confirmed/ready) reservation
        $was_active = in_array($cur['current_status'], ['pending', 'confirmed', 'ready'], true);
        if ($status === 'cancelled' && $was_active) {
            $restore = $conn->prepare("UPDATE livestock_products SET stock = stock + ? WHERE product_id = ?");
            $restore->bind_param('ii', $cur['quantity'], $cur['product_id']);
            $restore->execute();
            $restore->close();
        }
        echo json_encode(['success' => true, 'message' => 'Reservation updated']);
    } else {
        $stmt->close();
        echo json_encode(['success' => false, 'message' => 'Reservation not found or no change']);
    }
}

function markReservationPaid($conn) {
    $reservation_id = (int)($_POST['reservation_id'] ?? 0);
    if ($reservation_id <= 0) {
        echo json_encode(['success' => false, 'message' => 'Invalid reservation ID']);
        return;
    }

    $stmt = $conn->prepare(
        "UPDATE livestock_reservations
         SET payment_status = 'paid', payment_marked_at = NOW()
         WHERE reservation_id = ?"
    );
    $stmt->bind_param('i', $reservation_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Reservation marked as paid']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Reservation not found or already paid']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update payment status']);
    }

    $stmt->close();
}

