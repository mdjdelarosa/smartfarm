<?php
// admin/export_all_users.php
// Generates a CSV with all Admins, Farmers, and Clients in a unified format
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="all_users.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'user_type', 'user_id', 'fullname', 'contact', 'email', 'created_at', 'updated_at', 'extra_info'
]);

// Admins
$admins = $conn->query("SELECT 'admin' AS user_type, admin_id AS user_id, fullname, '' AS contact, '' AS email, created_at, updated_at, '' AS extra_info FROM admins");
if ($admins) {
    while ($row = $admins->fetch_assoc()) {
        fputcsv($out, $row);
    }
}

// Farmers
$farmers = $conn->query("SELECT 'farmer' AS user_type, farmer_id AS user_id, farmer_fullname AS fullname, farmer_contact_number AS contact, farmer_email AS email, farmer_created_at AS created_at, farmer_updated_at AS updated_at, farmer_address AS extra_info FROM farmers");
if ($farmers) {
    while ($row = $farmers->fetch_assoc()) {
        fputcsv($out, $row);
    }
}

// Clients
$clients = $conn->query("SELECT 'client' AS user_type, client_id AS user_id, client_fullname AS fullname, client_contact_number AS contact, client_email AS email, client_created_at AS created_at, client_updated_at AS updated_at, client_address AS extra_info FROM clients");
if ($clients) {
    while ($row = $clients->fetch_assoc()) {
        fputcsv($out, $row);
    }
}

fclose($out);
exit;
