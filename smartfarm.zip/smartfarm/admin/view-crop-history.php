<?php
$crop_id = (int)($_GET['crop_id'] ?? 0);
$crop_data = null;
$crop_history = [];
$success_msg = '';
$error_msg = '';

if ($crop_id <= 0) {
  echo "<section id='section-view-crop-history' class='admin-section'>";
  echo "<div class='section-header'><h1>Crop History</h1></div>";
  echo "<p>Invalid crop ID.</p>";
  echo "</section>";
  return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (string)($_POST['action'] ?? '') === 'undo_crop_history') {
  $post_crop_id = (int)($_POST['crop_id'] ?? 0);
  $history_id = (int)($_POST['history_id'] ?? 0);

  if ($post_crop_id !== $crop_id || $history_id <= 0) {
    $error_msg = 'Invalid undo request.';
  } else {
    $history_stmt = $conn->prepare(
      "SELECT history_id, event_type, old_quantity, new_quantity, crop_unit
       FROM crop_history
       WHERE history_id = ? AND crop_id = ?
       LIMIT 1"
    );

    if (!$history_stmt) {
      $error_msg = 'Unable to prepare history undo query.';
    } else {
      $history_stmt->bind_param('ii', $history_id, $crop_id);
      $history_stmt->execute();
      $history_result = $history_stmt->get_result();
      $history_row = $history_result ? $history_result->fetch_assoc() : null;
      $history_stmt->close();

      if (!$history_row) {
        $error_msg = 'History entry not found.';
      } elseif ($history_row['old_quantity'] === null) {
        $error_msg = 'This history entry cannot be undone.';
      } elseif ((string)($history_row['event_type'] ?? '') === 'history_undo') {
        $error_msg = 'Undo entries cannot be undone again.';
      } else {
        $crop_state_stmt = $conn->prepare(
          "SELECT crop_quantity, crop_name, crop_unit, farmer_id
           FROM crops
           WHERE crop_id = ?
           LIMIT 1"
        );

        if (!$crop_state_stmt) {
          $error_msg = 'Unable to load crop state for undo.';
        } else {
          $crop_state_stmt->bind_param('i', $crop_id);
          $crop_state_stmt->execute();
          $crop_state_result = $crop_state_stmt->get_result();
          $crop_state_row = $crop_state_result ? $crop_state_result->fetch_assoc() : null;
          $crop_state_stmt->close();

          if (!$crop_state_row) {
            $error_msg = 'Crop record not found while undoing.';
          } else {
            $target_quantity = (float)$history_row['old_quantity'];
            $current_quantity = (float)$crop_state_row['crop_quantity'];

            $conn->begin_transaction();
            try {
              $update_stmt = $conn->prepare("UPDATE crops SET crop_quantity = ? WHERE crop_id = ? LIMIT 1");
              if (!$update_stmt) {
                throw new Exception('Unable to prepare crop update for undo.');
              }

              $update_stmt->bind_param('di', $target_quantity, $crop_id);
              if (!$update_stmt->execute()) {
                $update_stmt->close();
                throw new Exception('Failed to update crop quantity for undo.');
              }
              $update_stmt->close();

              if (function_exists('recordCropHistory')) {
                $actor_id = (int)($_SESSION['user_id'] ?? 0);
                $actor_name = trim((string)($_SESSION['admin_name'] ?? $_SESSION['fullname'] ?? 'Admin'));
                $undo_remarks = 'Undo history #' . (int)$history_id . ' (' . (string)$history_row['event_type'] . ')';

                recordCropHistory(
                  $conn,
                  [
                    'crop_id' => $crop_id,
                    'farmer_id' => isset($crop_state_row['farmer_id']) ? (int)$crop_state_row['farmer_id'] : null,
                    'changed_by_user_id' => $actor_id > 0 ? $actor_id : null,
                    'actor_role' => 'admin',
                    'actor_name' => $actor_name,
                    'event_type' => 'history_undo',
                    'old_quantity' => $current_quantity,
                    'new_quantity' => $target_quantity,
                    'quantity_delta' => ($target_quantity - $current_quantity),
                    'crop_name' => (string)($crop_state_row['crop_name'] ?? ''),
                    'crop_unit' => (string)($crop_state_row['crop_unit'] ?? $history_row['crop_unit'] ?? ''),
                    'remarks' => $undo_remarks,
                  ]
                );
              }

              $conn->commit();
              $success_msg = 'Undo completed. Quantity restored to ' . number_format($target_quantity, 2) . '.';
            } catch (Throwable $e) {
              $conn->rollback();
              $error_msg = $e->getMessage();
            }
          }
        }
      }
    }
  }
}

$crop_query = "
  SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit, c.market_price_per_unit, 
         c.crop_description, c.created_at, c.farmer_id,
         COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name,
         (SELECT COUNT(*) FROM crops live 
          WHERE live.starting_price > 0 
            AND live.crop_status = 'available' 
            AND live.crop_name = c.crop_name 
            AND live.farmer_id = c.farmer_id) AS live_lot_count
  FROM crops c
  LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
  WHERE c.crop_id = ?
  LIMIT 1
";
$crop_stmt = $conn->prepare($crop_query);
if ($crop_stmt) {
  $crop_stmt->bind_param('i', $crop_id);
  $crop_stmt->execute();
  $crop_result = $crop_stmt->get_result();
  $crop_data = $crop_result ? $crop_result->fetch_assoc() : null;
  $crop_stmt->close();
}

if (!$crop_data) {
  echo "<section id='section-view-crop-history' class='admin-section'>";
  echo "<div class='section-header'><h1>Crop History</h1></div>";
  echo "<p>Crop not found.</p>";
  echo "</section>";
  return;
}

$history_query = "
  SELECT history_id, event_type, old_quantity, new_quantity, quantity_delta, crop_unit,
         actor_role, actor_name, remarks, created_at
  FROM crop_history
  WHERE crop_id = ?
  ORDER BY created_at DESC, history_id DESC
";
$history_stmt = $conn->prepare($history_query);
if ($history_stmt) {
  $history_stmt->bind_param('i', $crop_id);
  $history_stmt->execute();
  $history_result = $history_stmt->get_result();
  if ($history_result) {
    while ($row = $history_result->fetch_assoc()) {
      $crop_history[] = $row;
    }
  }
  $history_stmt->close();
}

$quantity_value = (float)$crop_data['crop_quantity'];
if ($quantity_value <= 0) {
  $status_text = 'Out of Stock';
} elseif ($quantity_value < 10) {
  $status_text = 'Low Stock';
} else {
  $status_text = 'In Stock';
}
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.crop-history-shell {
  width: min(1120px, 100%);
  margin: 0;
}

.crop-history-layout {
  display: grid;
  grid-template-columns: 360px 1fr;
  gap: 14px;
}

.crop-summary-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 10px;
}

.history-panel {
  border: 1px solid rgba(27,90,42,0.14);
  border-radius: 10px;
  background: #f9fcfa;
  padding: 12px;
}

.history-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  max-height: 620px;
  overflow: auto;
}

@media (max-width: 980px) {
  .crop-history-layout {
    grid-template-columns: 1fr;
  }
}
</style>

<section id="section-view-crop-history" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('manage-crops')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Crop Record History</h1>
      </div>
    </div>
  </div>

  <?php if ($success_msg !== ''): ?>
    <div class="alert-success alert-message" style="margin-bottom:10px;">
      <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <?php if ($error_msg !== ''): ?>
    <div class="alert-error alert-message" style="margin-bottom:10px;">
      <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <div class="schedule-modal-card crop-history-shell" style="width:100%;margin:0;">
    <div class="crop-history-layout">
      <div class="crop-summary-grid">
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Crop ID</small>
        <strong style="color:#1c4d2c;"><?php echo htmlspecialchars('#CRP' . str_pad((string)$crop_data['crop_id'], 3, '0', STR_PAD_LEFT), ENT_QUOTES); ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Crop Name</small>
        <strong style="color:#1c4d2c;"><?php echo htmlspecialchars($crop_data['crop_name'], ENT_QUOTES); ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Farmer ID</small>
        <strong style="color:#1c4d2c;"><?php echo $crop_data['farmer_id'] ? (int)$crop_data['farmer_id'] : 'Admin'; ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Date Added</small>
        <strong style="color:#1c4d2c;"><?php echo htmlspecialchars($crop_data['created_at'], ENT_QUOTES); ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Current Stock</small>
        <strong style="color:#1c4d2c;"><?php echo number_format($quantity_value, 2); ?> <?php echo htmlspecialchars($crop_data['crop_unit'], ENT_QUOTES); ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Stock Status</small>
        <strong style="color:#1c4d2c;"><?php echo htmlspecialchars($status_text, ENT_QUOTES); ?></strong>
      </div>
      <div style="background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Live Bidding Lots</small>
        <strong style="color:#1c4d2c;"><?php echo (int)$crop_data['live_lot_count']; ?></strong>
      </div>
      <div style="grid-column:1 / -1;background:#f7fbf8;border:1px solid rgba(27,90,42,0.14);border-radius:10px;padding:10px 12px;">
        <small style="display:block;color:#6f816f;font-weight:700;text-transform:uppercase;letter-spacing:0.03em;">Description</small>
        <div style="color:#2a3f2f;line-height:1.45;margin-top:4px;"><?php echo htmlspecialchars($crop_data['crop_description'], ENT_QUOTES) ?: '-'; ?></div>
      </div>
      </div>

    <div class="history-panel">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px;">
        <strong style="color:#3b82f6;">Crop Updates</strong>
        <small style="color:#6f816f;">Undo restores the previous quantity state</small>
      </div>
      <div class="history-list">
        <?php if (empty($crop_history)): ?>
        <div style="color:#6f816f;font-size:0.9rem;padding:10px 12px;border:1px dashed #c9d8cd;border-radius:8px;background:#fff;">No history entries yet for this crop.</div>
        <?php else: ?>
        <?php foreach ($crop_history as $entry): ?>
        <div style="background:#fff;border:1px solid rgba(27,90,42,0.12);border-radius:8px;padding:8px 10px;">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:4px;">
            <div>
              <strong style="color:#22c55e;font-size:0.9rem;"><?php echo htmlspecialchars(str_replace('_', ' ', ucfirst((string)$entry['event_type'])), ENT_QUOTES); ?></strong>
              <div style="margin-top:2px;color:#999;font-size:0.8rem;"><?php echo htmlspecialchars((string)$entry['created_at'], ENT_QUOTES); ?></div>
            </div>
            <?php if ($entry['old_quantity'] !== null && (string)$entry['event_type'] !== 'history_undo'): ?>
            <form method="post" action="admin_dashboard.php?section=view-crop-history&crop_id=<?php echo (int)$crop_id; ?>" style="margin:0;">
              <input type="hidden" name="action" value="undo_crop_history">
              <input type="hidden" name="crop_id" value="<?php echo (int)$crop_id; ?>">
              <input type="hidden" name="history_id" value="<?php echo (int)$entry['history_id']; ?>">
              <button type="submit" class="btn-small btn-edit" style="padding:6px 10px;font-size:0.78rem;line-height:1;">
                <i class="fas fa-rotate-left"></i> Undo
              </button>
            </form>
            <?php endif; ?>
          </div>
          <div style="margin-top:4px;color:#3b5340;font-size:0.84rem;">By: <strong><?php echo htmlspecialchars($entry['actor_name'], ENT_QUOTES); ?></strong> (<?php echo htmlspecialchars(strtoupper($entry['actor_role']), ENT_QUOTES); ?>)</div>
          <?php if ($entry['old_quantity'] !== null || $entry['new_quantity'] !== null): ?>
          <div style="margin-top:4px;color:#2f4633;font-size:0.84rem;">Quantity: <?php echo $entry['old_quantity'] !== null ? number_format((float)$entry['old_quantity'], 2) : '-'; ?> <?php echo htmlspecialchars($entry['crop_unit'], ENT_QUOTES); ?> → <?php echo $entry['new_quantity'] !== null ? number_format((float)$entry['new_quantity'], 2) : '-'; ?> <?php echo htmlspecialchars($entry['crop_unit'], ENT_QUOTES); ?></div>
          <?php endif; ?>
          <?php if (!empty($entry['remarks'])): ?>
          <div style="color:#5c7061;font-size:0.82rem;margin-top:4px;"><?php echo htmlspecialchars($entry['remarks'], ENT_QUOTES); ?></div>
          <?php endif; ?>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </div>
    </div>
  </div>
</section>
