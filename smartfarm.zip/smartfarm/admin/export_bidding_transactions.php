<?php
// admin/export_bidding_transactions.php
// Generates a CSV for all bidding transactions with joined details (matches admin UI)
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="bidding_transactions.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'bid_id', 'crop_id', 'crop_name', 'farmer_name', 'client_id', 'client_name', 'bid_amount', 'bid_status', 'highest_bid', 'bid_count', 'starting_price', 'crop_status', 'bidding_end_date', 'created_at', 'updated_at', 'payment_status', 'payment_marked_at'
]);

$sql = "
SELECT
  b.bid_id,
  c.crop_id,
  c.crop_name,
  COALESCE(f.farmer_fullname, 'Admin Entry') AS farmer_name,
  b.client_id,
  COALESCE(cl.client_fullname, 'No bids yet') AS client_name,
  b.bid_amount,
  b.bid_status,
  COALESCE(bs.highest_bid, c.starting_price) AS highest_bid,
  COALESCE(bs.bid_count, 0) AS bid_count,
  c.starting_price,
  c.crop_status,
  c.bidding_end_date,
  b.created_at,
  b.updated_at,
  b.payment_status,
  b.payment_marked_at
FROM bids b
INNER JOIN crops c ON c.crop_id = b.crop_id
LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
LEFT JOIN clients cl ON cl.client_id = b.client_id
LEFT JOIN (
  SELECT crop_id, MAX(bid_amount) AS highest_bid, COUNT(*) AS bid_count
  FROM bids
  GROUP BY crop_id
) bs ON bs.crop_id = c.crop_id
ORDER BY b.created_at DESC, b.bid_id DESC
";

$q = $conn->query($sql);
if ($q) {
    while ($row = $q->fetch_assoc()) {
        fputcsv($out, $row);
    }
}
fclose($out);
exit;
