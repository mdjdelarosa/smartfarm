<?php
require_once __DIR__ . '/../config.php';
?>

<!-- Manage Accounts Section -->
<section id="section-manage-accounts" class="admin-section">
  <div class="section-header">
    <h1>Manage Accounts</h1>
    <button class="btn-secondary" onclick="showSection('add-account')" data-tooltip="Add Account"><i class="fas fa-user-plus"></i></button>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="searchInput">Search</label>
      <input type="text" placeholder="Search by name, email, or ID..." class="search-input" id="searchInput">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="filterSelect">Role</label>
      <select class="filter-select" id="filterSelect">
        <option value="">All Users</option>
        <option value="farmer">Farmers</option>
        <option value="client">Clients</option>
        <option value="admin">Admin</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="accountsGroupBy">Group By</label>
      <select class="filter-select" id="accountsGroupBy" onchange="sfSetGroupBy('accountsTable', this); applyFilter()">
        <option value="">No Grouping</option>
        <option value="3">Role</option>
        <option value="4">Status</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="accountsTable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Date Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $sql = "SELECT u.user_id, u.email, u.role, u.is_active, u.created_at,
                       a.fullname AS admin_name,
                       f.farmer_fullname,
                       c.client_fullname
                FROM users u
                LEFT JOIN admins a ON u.user_id = a.user_id
                LEFT JOIN farmers f ON u.user_id = f.user_id
                LEFT JOIN clients c ON u.user_id = c.user_id
                ORDER BY u.created_at DESC";

        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $user_id = (int)($row['user_id'] ?? 0);
                $display_user_id = '#USR' . str_pad((string)$user_id, 4, '0', STR_PAD_LEFT);
                $displayName = $row['admin_name'] ?: ($row['farmer_fullname'] ?: ($row['client_fullname'] ?: '—'));
                $roleLabel = ucfirst($row['role']);
                $statusLabel = $row['is_active'] ? 'Active' : 'Inactive';
        ?>
        <tr data-role="<?php echo htmlspecialchars(strtolower($row['role'])); ?>" data-search="<?php echo htmlspecialchars(strtolower($displayName . ' ' . $row['email'] . ' ' . $user_id . ' ' . $display_user_id)); ?>">
          <td><?php echo htmlspecialchars($display_user_id); ?></td>
          <td><?php echo htmlspecialchars($displayName); ?></td>
          <td><?php echo htmlspecialchars($row['email']); ?></td>
          <td><span class="role-badge <?php echo htmlspecialchars(strtolower($row['role'])); ?>"><?php echo htmlspecialchars($roleLabel); ?></span></td>
          <td><span class="status <?php echo $row['is_active'] ? 'active' : 'inactive'; ?>"><?php echo htmlspecialchars($statusLabel); ?></span></td>
          <td><?php echo htmlspecialchars($row['created_at']); ?></td>
          <td>
            <form method="post" action="admin/toggle_account_status.php" style="display:inline;">
              <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
              <input type="hidden" name="action" value="<?php echo $row['is_active'] ? 'deactivate' : 'activate'; ?>">
              <button class="btn-small btn-deactivate" type="submit" data-tooltip="<?php echo $row['is_active'] ? 'Deactivate' : 'Activate'; ?>"><i class="fas <?php echo $row['is_active'] ? 'fa-ban' : 'fa-check'; ?>"></i></button>
            </form>
            <button class="btn-small btn-edit" onclick="viewAccount(<?php echo $user_id; ?>)" data-tooltip="View/Edit"><i class="fas fa-edit"></i></button>
          </td>
        </tr>
        <?php
            }
        } else {
        ?>
        <tr>
          <td colspan="7">No accounts found.</td>
        </tr>
        <?php } ?>
      </tbody>
    </table>
  </div>
</section>

<script>
// Get URL parameters

function viewAccount(userId) {
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=manage-accounts';
}
const urlParams = new URLSearchParams(window.location.search);
const initialFilter = urlParams.get('filter');

// Set initial filter if provided
const filterSelect = document.getElementById('filterSelect');
const searchInput = document.getElementById('searchInput');
const tableRows = document.querySelectorAll('table tbody tr');

if (initialFilter) {
  filterSelect.value = initialFilter;
}

// Filter function
function applyFilter() {
  const filterValue = filterSelect.value.toLowerCase();
  const searchValue = searchInput.value.toLowerCase();

  tableRows.forEach(row => {
    const role = row.getAttribute('data-role');
    const searchText = row.getAttribute('data-search');

    if (!role || !searchText) return;

    // Check role filter
    const roleMatches = filterValue === '' || role === filterValue;

    // Check search filter
    const searchMatches = searchValue === '' || searchText.includes(searchValue);

    // Show/hide row based on both filters
    row.style.display = (roleMatches && searchMatches) ? '' : 'none';
  });

  if (typeof sfApplyGroupBy === 'function') {
    sfApplyGroupBy('accountsTable');
  }
}

// Add event listeners
filterSelect.addEventListener('change', applyFilter);
searchInput.addEventListener('keyup', applyFilter);

// Apply initial filter on page load
applyFilter();
</script>
