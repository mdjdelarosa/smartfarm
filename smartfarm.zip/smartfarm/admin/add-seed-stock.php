</style>
  <style>
  /* Remove underline from the back button on Add Seed Stock */
  .sf-add-header-left > a,
  .sf-add-header-left > a:visited,
  .sf-add-header-left > a:hover,
  .sf-add-header-left > a:active {
    text-decoration: none !important;
  }
  /* Remove underline from the Cancel button */
  .form-actions-inline .btn-secondary,
  .form-actions-inline .btn-secondary:visited,
  .form-actions-inline .btn-secondary:hover,
  .form-actions-inline .btn-secondary:active {
    text-decoration: none !important;
  }
</style>
<?php
// Add Seed Stock Section (matches Add Machinery Listing workflow)
?>
<section id="section-add-seed-stock" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left" style="display:flex;align-items:center;gap:10px;">
      <a href="admin_dashboard.php?section=distribute-seeds" class="btn-tertiary" data-tooltip="Back to Seed Stock & Requests" style="display:inline-flex;align-items:center;justify-content:center;">
        <i class="fas fa-arrow-left"></i>
      </a>
      <h1 style="margin:0;">Add Seed Stock</h1>
    </div>
  </div>
  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <form id="seedStockForm" method="POST" action="admin_dashboard.php?section=distribute-seeds" class="schedule-form">
      <input type="hidden" name="action" value="add_seed_stock">
      <div class="form-grid">
        <div class="form-field">
          <label for="seedStockName">Seed Type <span style="color:#d32f2f;">*</span></label>
          <input type="text" id="seedStockName" name="seed_name" required placeholder="e.g. Rice Seeds - Premium">
        </div>
        <div class="form-field">
          <label for="seedStockUnit">Unit <span style="color:#d32f2f;">*</span></label>
          <select id="seedStockUnit" name="seed_unit" required>
            <option value="kg">kg</option>
            <option value="grams">grams</option>
            <option value="packets">packets</option>
            <option value="sacks">sacks</option>
            <option value="pcs">pcs</option>
          </select>
        </div>
        <div class="form-field">
          <label for="seedStockQty">Available Quantity <span style="color:#d32f2f;">*</span></label>
          <input type="number" id="seedStockQty" name="available_quantity" step="0.01" min="0" required>
        </div>
        <!-- Low Stock Threshold field removed as requested -->
      </div>
      <div class="form-actions-inline" style="margin-top:1rem; display: flex; gap: 10px; justify-content: flex-end;">
        <a href="admin_dashboard.php?section=distribute-seeds" class="btn-secondary">Cancel</a>
        <button type="submit" class="btn-primary" id="seedStockSubmitBtn">Add Seed</button>
      </div>
    </form>
  </div>
</section>
