
<?php
// --- DEBUG: Enable error reporting ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config.php';
// --- DEBUG: Touch file to confirm API execution ---
file_put_contents(__DIR__ . '/../debug/api_touch.txt', date('c') . "\n", FILE_APPEND);
// --- END DEBUG ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
file_put_contents(__DIR__ . '/../debug/session_debug.txt', print_r([
    'session_id' => session_id(),
    'session' => isset($_SESSION) ? $_SESSION : null,
    'cookies' => $_COOKIE,
    'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
    'referer' => $_SERVER['HTTP_REFERER'] ?? '',
    'request_uri' => $_SERVER['REQUEST_URI'] ?? ''
], true), FILE_APPEND);

if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['ok' => false, 'error' => 'Unauthorized access.']);
    exit;
}

function reportsApiJson(array $payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');
    $json = json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE
        | JSON_UNESCAPED_SLASHES
        | JSON_INVALID_UTF8_SUBSTITUTE
        | JSON_PARTIAL_OUTPUT_ON_ERROR
    );

    if ($json === false) {
        http_response_code(500);
        echo '{"ok":false,"error":"Failed to encode API response."}';
        exit;
    }

    echo $json;
    exit;
}

function reportsApiError(string $message, int $status = 400): void {
    reportsApiJson(['ok' => false, 'error' => $message], $status);
}

function reportsApiExportDir(): string {
    $dir = dirname(__DIR__) . '/exports/reports';
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    return $dir;
}

function reportsApiGetTables(mysqli $conn): array {
    $tables = [];
    $res = $conn->query('SHOW TABLES');
    if (!$res) {
        return $tables;
    }

    while ($row = $res->fetch_array(MYSQLI_NUM)) {
        if (!isset($row[0])) {
            continue;
        }
        $table = (string)$row[0];
        if ($table === '') {
            continue;
        }
        $tables[] = $table;
    }

    sort($tables);
    return $tables;
}

function reportsApiGetColumns(mysqli $conn, string $table): array {
    $columns = [];
    $safeTable = str_replace('`', '``', $table);
    $res = $conn->query('SHOW COLUMNS FROM `' . $safeTable . '`');
    if (!$res) {
        return $columns;
    }

    while ($row = $res->fetch_assoc()) {
        if (!isset($row['Field'])) {
            continue;
        }
        $columns[] = (string)$row['Field'];
    }

    return $columns;
}

function reportsApiGetColumnTypeMap(mysqli $conn, string $table): array {
    $typeMap = [];
    $safeTable = str_replace('`', '``', $table);
    $res = $conn->query('SHOW COLUMNS FROM `' . $safeTable . '`');
    if (!$res) {
        return $typeMap;
    }

    while ($row = $res->fetch_assoc()) {
        $name = isset($row['Field']) ? (string)$row['Field'] : '';
        $type = isset($row['Type']) ? strtolower((string)$row['Type']) : '';
        if ($name !== '') {
            $typeMap[$name] = $type;
        }
    }

    return $typeMap;
}

function reportsApiGetDateColumns(array $typeMap): array {
    $columns = [];
    foreach ($typeMap as $name => $type) {
        if (strpos($type, 'date') !== false || strpos($type, 'time') !== false || strpos($type, 'year') !== false) {
            $columns[] = (string)$name;
        }
    }
    return $columns;
}

function reportsApiBuildFilter(mysqli $conn, string $scope, string $period, string $dateColumn, array $typeMap): array {
    $normalizedScope = in_array($scope, ['all', 'month', 'year'], true) ? $scope : 'all';

    if ($normalizedScope === 'all') {
        return [
            'scope' => 'all',
            'period' => '',
            'date_column' => '',
            'where_sql' => '',
            'label' => 'All Records'
        ];
    }

    if ($dateColumn === '' || !isset($typeMap[$dateColumn])) {
        $dateColumns = reportsApiGetDateColumns($typeMap);
        if (empty($dateColumns)) {
            reportsApiError('No date column is available for month/year filtering in this file.', 400);
        }
        $dateColumn = (string)$dateColumns[0];
    }

    $columnType = $typeMap[$dateColumn] ?? '';
    if (strpos($columnType, 'date') === false && strpos($columnType, 'time') === false && strpos($columnType, 'year') === false) {
        reportsApiError('Selected date column cannot be used for month/year filtering.', 400);
    }

    $safeColumn = str_replace('`', '``', $dateColumn);

    if ($normalizedScope === 'month') {
        if (!preg_match('/^\d{4}-\d{2}$/', $period)) {
            reportsApiError('Invalid month format. Use YYYY-MM.', 400);
        }

        $start = $period . '-01';
        $startTs = strtotime($start);
        if ($startTs === false) {
            reportsApiError('Invalid month value.', 400);
        }

        $end = date('Y-m-d', strtotime('+1 month', $startTs));
        $startEsc = $conn->real_escape_string($start);
        $endEsc = $conn->real_escape_string($end);

        return [
            'scope' => 'month',
            'period' => $period,
            'date_column' => $dateColumn,
            'where_sql' => " WHERE `{$safeColumn}` >= '{$startEsc}' AND `{$safeColumn}` < '{$endEsc}' ",
            'label' => 'Month: ' . $period
        ];
    }

    if (!preg_match('/^\d{4}$/', $period)) {
        reportsApiError('Invalid year format. Use YYYY.', 400);
    }

    $yearStart = $period . '-01-01';
    $yearEnd = ((int)$period + 1) . '-01-01';
    $yearStartEsc = $conn->real_escape_string($yearStart);
    $yearEndEsc = $conn->real_escape_string($yearEnd);

    return [
        'scope' => 'year',
        'period' => $period,
        'date_column' => $dateColumn,
        'where_sql' => " WHERE `{$safeColumn}` >= '{$yearStartEsc}' AND `{$safeColumn}` < '{$yearEndEsc}' ",
        'label' => 'Year: ' . $period
    ];
}

function reportsApiGetYearOptions(mysqli $conn, string $table, string $dateColumn): array {
    $years = [];
    if ($dateColumn === '') {
        return $years;
    }

    $safeTable = str_replace('`', '``', $table);
    $safeColumn = str_replace('`', '``', $dateColumn);
    $sql = "SELECT DISTINCT YEAR(`{$safeColumn}`) AS y
            FROM `{$safeTable}`
            WHERE `{$safeColumn}` IS NOT NULL
              AND `{$safeColumn}` <> ''
            ORDER BY y DESC";
    $res = $conn->query($sql);
    if (!$res) {
        return $years;
    }

    while ($row = $res->fetch_assoc()) {
        $y = isset($row['y']) ? (int)$row['y'] : 0;
        if ($y > 0) {
            $years[] = $y;
        }
    }

    return $years;
}

function reportsApiCountRows(mysqli $conn, string $table): int {
    $safeTable = str_replace('`', '``', $table);
    $res = $conn->query('SELECT COUNT(*) AS total_rows FROM `' . $safeTable . '`');
    if (!$res) {
        return 0;
    }
    $row = $res->fetch_assoc();
    return (int)($row['total_rows'] ?? 0);
}

function reportsApiFetchRows(mysqli $conn, string $table, int $limit): array {
    $rows = [];
    $safeTable = str_replace('`', '``', $table);
    $safeLimit = max(1, min($limit, 5000));
    $res = $conn->query('SELECT * FROM `' . $safeTable . '` LIMIT ' . $safeLimit);
    if (!$res) {
        return $rows;
    }

    while ($row = $res->fetch_assoc()) {
        foreach ($row as $key => $value) {
            if (is_null($value)) {
                $row[$key] = '';
            } elseif (is_bool($value)) {
                $row[$key] = $value ? '1' : '0';
            }
        }
        $rows[] = $row;
    }

    return $rows;
}

function reportsApiSafeTableFromFile(string $file, array $tableLookup): ?string {
    if (!preg_match('/^[a-zA-Z0-9_\-]+\.csv$/', $file)) {
        return null;
    }

    $table = pathinfo($file, PATHINFO_FILENAME);
    if ($table === '' || !isset($tableLookup[$table])) {
        return null;
    }

    return $table;
}

function reportsApiBuildCsvFile(mysqli $conn, string $table, string $dir, array $filter): array {
    $safeTable = str_replace('`', '``', $table);
    $file = $table . '.csv';
    $fullPath = $dir . '/' . $file;

    $columns = reportsApiGetColumns($conn, $table);
    $output = fopen($fullPath, 'w');
    if ($output === false) {
        reportsApiError('Failed to create export file.', 500);
    }

    if (!empty($columns)) {
        fputcsv($output, $columns);
    }

    $rowCount = 0;
    $whereSql = (string)($filter['where_sql'] ?? '');
    $res = $conn->query('SELECT * FROM `' . $safeTable . '`' . $whereSql);
    if ($res) {
        while ($row = $res->fetch_assoc()) {
            $csvRow = [];
            foreach ($columns as $column) {
                $value = $row[$column] ?? '';
                if (is_null($value)) {
                    $value = '';
                } elseif (is_bool($value)) {
                    $value = $value ? '1' : '0';
                }
                $csvRow[] = $value;
            }
            fputcsv($output, $csvRow);
            $rowCount++;
        }
    }

    fclose($output);

    return [
        'file' => $file,
        'path' => $fullPath,
        'table' => $table,
        'title' => ucwords(str_replace('_', ' ', $table)),
        'columns' => $columns,
        'rows' => $rowCount,
        'size_bytes' => (int)(@filesize($fullPath) ?: 0),
        'updated_at' => @filemtime($fullPath) ? date('Y-m-d H:i:s', (int)@filemtime($fullPath)) : null,
        'scope' => (string)($filter['scope'] ?? 'all'),
        'period' => (string)($filter['period'] ?? ''),
        'date_column' => (string)($filter['date_column'] ?? ''),
        'scope_label' => (string)($filter['label'] ?? 'All Records')
    ];
}

function reportsApiReadCsvPreview(string $fullPath, int $limit): array {
    $rows = [];
    $columns = [];
    $safeLimit = max(1, min($limit, 2000));

    $fh = fopen($fullPath, 'r');
    if ($fh === false) {
        return ['columns' => [], 'rows' => []];
    }

    $header = fgetcsv($fh);
    if (is_array($header)) {
        $columns = array_map(static function($h) {
            return (string)$h;
        }, $header);
    }

    $count = 0;
    while (($line = fgetcsv($fh)) !== false && $count < $safeLimit) {
        $row = [];
        foreach ($columns as $index => $name) {
            $row[$name] = isset($line[$index]) ? (string)$line[$index] : '';
        }
        $rows[] = $row;
        $count++;
    }

    fclose($fh);
    return ['columns' => $columns, 'rows' => $rows];
}

function reportsApiEscapeHtml(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$action = isset($_GET['action']) ? (string)$_GET['action'] : 'list';
$tables = reportsApiGetTables($conn);
$tableLookup = array_fill_keys($tables, true);
$exportDir = reportsApiExportDir();

if ($action === 'list') {
    $files = [];
    $csvFiles = glob($exportDir . '/*.csv');
    foreach ($csvFiles as $csvPath) {
        $fileName = basename($csvPath);
        $table = pathinfo($fileName, PATHINFO_FILENAME);
        $files[] = [
            'file' => $fileName,
            'table' => $table,
            'title' => ucwords(str_replace('_', ' ', $table)),
            'size_bytes' => (int)(filesize($csvPath) ?: 0),
            'updated_at' => date('Y-m-d H:i:s', (int)filemtime($csvPath))
        ];
    }
    reportsApiJson(['ok' => true, 'files' => $files]);
    exit;
}

// Universal CSV support: allow any CSV file in exports/reports
$file = isset($_GET['file']) ? trim((string)$_GET['file']) : '';
if ($file !== '' && preg_match('/^[a-zA-Z0-9_\-]+\.csv$/', $file)) {
    $csvPath = $exportDir . '/' . $file;
    if (!file_exists($csvPath)) {
        reportsApiError('CSV file not found.', 404);
    }
} else if ($file !== '') {
    reportsApiError('Invalid file selected.', 400);
}

if ($action === 'meta') {
    // Read CSV header for columns
    $columns = [];
    if ($file !== '') {
        $fh = fopen($csvPath, 'r');
        if ($fh !== false) {
            $header = fgetcsv($fh);
            if (is_array($header)) {
                $columns = array_map('strval', $header);
            }
            fclose($fh);
        }
    }
    reportsApiJson([
        'ok' => true,
        'file' => $file,
        'table' => pathinfo($file, PATHINFO_FILENAME),
        'date_columns' => [],
        'years' => [],
        'columns' => $columns
    ]);
    exit;
}

if ($action === 'view') {
    // Preview CSV: show first 20 rows
    $columns = [];
    $rows = [];
    if ($file !== '') {
        $fh = fopen($csvPath, 'r');
        if ($fh !== false) {
            $header = fgetcsv($fh);
            if (is_array($header)) {
                $columns = array_map('strval', $header);
            }
            $count = 0;
            while (($line = fgetcsv($fh)) !== false && $count < 20) {
                $row = [];
                foreach ($columns as $i => $col) {
                    $row[$col] = isset($line[$i]) ? (string)$line[$i] : '';
                }
                $rows[] = $row;
                $count++;
            }
            fclose($fh);
        }
    }
    reportsApiJson([
        'ok' => true,
        'file' => $file,
        'table' => pathinfo($file, PATHINFO_FILENAME),
        'title' => ucwords(str_replace('_', ' ', pathinfo($file, PATHINFO_FILENAME))),
        'total_rows' => count($rows),
        'size_bytes' => (int)(@filesize($csvPath) ?: 0),
        'updated_at' => @filemtime($csvPath) ? date('Y-m-d H:i:s', (int)@filemtime($csvPath)) : null,
        'scope' => 'all',
        'period' => '',
        'date_column' => '',
        'scope_label' => 'All Records',
        'columns' => $columns,
        'rows' => $rows
    ]);
    exit;
}

if ($action === 'document') {
    // Render CSV as full printable HTML page
    if ($file === '' || !isset($csvPath) || !file_exists($csvPath)) {
        http_response_code(400);
        echo '<!doctype html><html><body>No file specified or file not found.</body></html>';
        exit;
    }
    $csvInfo = [
        'title'       => ucwords(str_replace('_', ' ', pathinfo($file, PATHINFO_FILENAME))),
        'path'        => $csvPath,
        'file'        => $file,
        'scope_label' => 'All Records',
        'rows'        => 0,
    ];
    header('Content-Type: text/html; charset=UTF-8');
    echo '<!doctype html><html><head><meta charset="UTF-8">';
    echo '<title>' . reportsApiEscapeHtml(ucwords(str_replace('_', ' ', pathinfo($file, PATHINFO_FILENAME)))) . '</title>';
    echo '<style>'
      . 'body{font-family:Arial,sans-serif;margin:0;padding:16px;color:#1f2937;background:#fff;}'
            . '.title{font-size:24px;line-height:1.2;font-weight:700;color:#1f4d34;margin:0 0 8px;}'
      . '.meta{font-size:13px;color:#556b5d;margin-bottom:12px;}'
      . '.table-wrap{width:100%;overflow:auto;border:1px solid #d6e1d8;border-radius:6px;}'
      . 'table{border-collapse:collapse;min-width:100%;font-size:12px;}'
      . 'th,td{border:1px solid #e0e7e2;padding:8px;text-align:left;vertical-align:top;white-space:nowrap;}'
      . 'th{position:sticky;top:0;background:#eef5f0;font-weight:700;z-index:1;}'
      . '.empty{padding:16px;color:#6b7280;font-style:italic;}'
            . '@media print{'
            . '@page{size:8.5in 11in;margin:10mm;}'
            . 'body{padding:0;font-size:10px;}'
            . '.meta{margin:0 0 8px;font-size:10px;}'
            . '.table-wrap{overflow:visible;border:0;border-radius:0;}'
            . 'table{width:100%;min-width:0;table-layout:fixed;font-size:9px;}'
            . 'th,td{white-space:normal;word-break:break-word;padding:4px 5px;}'
            . 'th{position:static;}'
            . 'thead{display:table-header-group;}'
            . 'tr,td,th{page-break-inside:avoid;}'
            . '}'
      . '</style></head><body>';

        echo '<h1 class="title">' . reportsApiEscapeHtml($csvInfo['title']) . '</h1>';
    $fh = fopen($csvInfo['path'], 'r');
    if ($fh === false) {
        echo '<p class="empty">Unable to open file.</p></body></html>';
        exit;
    }

    $header = fgetcsv($fh);
    if (!is_array($header) || empty($header)) {
        fclose($fh);
        echo '<p class="empty">File has no columns.</p></body></html>';
        exit;
    }

    echo '<div class="table-wrap"><table><thead><tr>';
    foreach ($header as $name) {
        echo '<th>' . reportsApiEscapeHtml((string)$name) . '</th>';
    }
    echo '</tr></thead><tbody>';

    $rowCount = 0;
    while (($line = fgetcsv($fh)) !== false) {
        $rowCount++;
        echo '<tr>';
        foreach ($header as $idx => $unused) {
            $cell = isset($line[$idx]) ? (string)$line[$idx] : '';
            echo '<td>' . reportsApiEscapeHtml($cell) . '</td>';
        }
        echo '</tr>';
    }

    if ($rowCount === 0) {
        echo '<tr><td colspan="' . count($header) . '">No rows found.</td></tr>';
    }

    echo '</tbody></table></div>';
    echo '<div class="meta" style="margin-top:10px;">File: ' . reportsApiEscapeHtml($csvInfo['file'])
            . ' | ' . reportsApiEscapeHtml($csvInfo['scope_label'])
      . ' | Rows: ' . number_format((int)$csvInfo['rows'])
      . ' | Updated: ' . reportsApiEscapeHtml((string)($csvInfo['updated_at'] ?? 'N/A'))
      . '</div>';
    echo '</body></html>';
    fclose($fh);
    exit;
}

if ($action === 'download') {
    $csvInfo = reportsApiBuildCsvFile($conn, $table, $exportDir, $filter);
    $filename = $csvInfo['file'];

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    $output = fopen('php://output', 'w');
    if ($output === false) {
        reportsApiError('Failed to stream CSV file.', 500);
    }

    fputcsv($output, [(string)$csvInfo['title']]);
    fputcsv($output, []);

    $fh = fopen($csvInfo['path'], 'r');
    if ($fh === false) {
        fclose($output);
        reportsApiError('Failed to open generated CSV file.', 500);
    }

    while (($line = fgetcsv($fh)) !== false) {
        fputcsv($output, $line);
    }

    fputcsv($output, []);
    fputcsv($output, [
        'File',
        (string)$csvInfo['file'],
        'Scope',
        (string)$csvInfo['scope_label'],
        'Rows',
        (string)(int)$csvInfo['rows'],
        'Updated',
        (string)($csvInfo['updated_at'] ?? 'N/A')
    ]);

    fclose($fh);
    fclose($output);
    exit;
}

reportsApiError('Unsupported action.', 400);
