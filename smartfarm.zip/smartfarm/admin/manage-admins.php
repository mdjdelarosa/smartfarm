<?php
require_once __DIR__ . '/../config.php';

$admin_rows = [];
$admin_query = "
  SELECT
    u.user_id,
    u.email,
    u.is_active,
    u.created_at,
    a.fullname
  FROM users u
  INNER JOIN admins a ON a.user_id = u.user_id
  ORDER BY u.created_at DESC
";
$admin_result = $conn->query($admin_query);
if ($admin_result) {
  while ($admin_row = $admin_result->fetch_assoc()) {
    $admin_rows[] = $admin_row;
  }
}

$current_admin_id = (int)($_SESSION['user_id'] ?? 0);
?>

<section id="section-manage-admins" class="admin-section">
  <div class="section-header">
    <h1>Manage Admin Accounts</h1>
    <button class="btn-secondary" onclick="showSection('add-admin')" data-tooltip="Add Admin"><i class="fas fa-user-plus"></i></button>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="adminSearchInput">Search</label>
      <input type="text" placeholder="Search by name, email, or ID..." class="search-input" id="adminSearchInput">
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="adminStatusFilter">Status</label>
      <select class="filter-select" id="adminStatusFilter">
        <option value="">All Status</option>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>
    <div class="sf-filter-field sf-filter-field-select">
      <label class="sf-filter-label" for="adminGroupBy">Group By</label>
      <select class="filter-select" id="adminGroupBy" onchange="sfSetGroupBy('adminAccountsTable', this); applyAdminFilters()">
        <option value="">No Grouping</option>
        <option value="3">Status</option>
      </select>
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="adminAccountsTable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Status</th>
          <th>Date Created</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($admin_rows)): ?>
          <?php foreach ($admin_rows as $admin): ?>
            <?php
              $admin_user_id = (int)($admin['user_id'] ?? 0);
              $admin_name = (string)($admin['fullname'] ?? 'Unknown Admin');
              $admin_email = (string)($admin['email'] ?? '-');
              $is_active = (int)($admin['is_active'] ?? 0) === 1;
              $is_current_admin = $admin_user_id === $current_admin_id;
              $status_label = $is_active ? 'Active' : 'Inactive';
              $status_class = $is_active ? 'active' : 'inactive';
              $display_admin_id = '#ADM' . str_pad((string)$admin_user_id, 4, '0', STR_PAD_LEFT);
              $toggle_action = $is_active ? 'deactivate' : 'activate';
              $toggle_icon = $is_active ? 'fa-ban' : 'fa-check';
              $toggle_tooltip = $is_current_admin && $is_active
                ? 'Current account cannot be deactivated'
                : ($is_active ? 'Deactivate' : 'Activate');
              $created_at = (string)($admin['created_at'] ?? '-');
              $search_blob = strtolower($admin_user_id . ' ' . $display_admin_id . ' ' . $admin_name . ' ' . $admin_email);
            ?>
            <tr data-status="<?php echo htmlspecialchars($status_class); ?>" data-search="<?php echo htmlspecialchars($search_blob); ?>">
              <td><?php echo htmlspecialchars($display_admin_id); ?></td>
              <td><?php echo htmlspecialchars($admin_name); ?></td>
              <td><?php echo htmlspecialchars($admin_email); ?></td>
              <td><span class="status <?php echo htmlspecialchars($status_class); ?>"><?php echo htmlspecialchars($status_label); ?></span></td>
              <td><?php echo htmlspecialchars($created_at); ?></td>
              <td>
                <form method="post" style="display:inline;">
                  <input type="hidden" name="action" value="toggle_admin_account">
                  <input type="hidden" name="user_id" value="<?php echo htmlspecialchars((string)$admin_user_id); ?>">
                  <input type="hidden" name="toggle_type" value="<?php echo htmlspecialchars($toggle_action); ?>">
                  <button
                    class="btn-small btn-deactivate"
                    type="submit"
                    data-tooltip="<?php echo htmlspecialchars($toggle_tooltip); ?>"
                    <?php echo ($is_current_admin && $is_active) ? 'disabled' : ''; ?>
                  >
                    <i class="fas <?php echo htmlspecialchars($toggle_icon); ?>"></i>
                  </button>
                </form>
                <button class="btn-small btn-edit" type="button" onclick="editAdminAccount(<?php echo htmlspecialchars((string)$admin_user_id); ?>)" data-tooltip="Edit">
                  <i class="fas fa-edit"></i>
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="6" style="text-align:center; padding:20px; color:#8b968b;">No admin accounts found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</section>

<script>
function viewAdminAccount(userId) {
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=manage-admins';
}

function editAdminAccount(userId) {
  window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=manage-admins&action=edit';
}

const adminSearchInput = document.getElementById('adminSearchInput');
const adminStatusFilter = document.getElementById('adminStatusFilter');
const adminRows = document.querySelectorAll('#adminAccountsTable tbody tr');

function applyAdminFilters() {
  if (!adminRows.length || !adminSearchInput || !adminStatusFilter) return;

  const searchValue = adminSearchInput.value.toLowerCase().trim();
  const statusValue = adminStatusFilter.value.toLowerCase();

  adminRows.forEach((row) => {
    const rowSearch = (row.getAttribute('data-search') || '').toLowerCase();
    const rowStatus = (row.getAttribute('data-status') || '').toLowerCase();

    if (rowSearch === '' && rowStatus === '') {
      return;
    }

    const matchesSearch = searchValue === '' || rowSearch.includes(searchValue);
    const matchesStatus = statusValue === '' || rowStatus === statusValue;
    row.style.display = (matchesSearch && matchesStatus) ? '' : 'none';
  });

  if (typeof sfApplyGroupBy === 'function') {
    sfApplyGroupBy('adminAccountsTable');
  }
}

if (adminSearchInput && adminStatusFilter) {
  adminSearchInput.addEventListener('keyup', applyAdminFilters);
  adminStatusFilter.addEventListener('change', applyAdminFilters);
  applyAdminFilters();
}
</script>
