<?php
$schedule_activities = [];
$schedule_table_check = $conn->query("SHOW TABLES LIKE 'scheduled_activities'");
if ($schedule_table_check && $schedule_table_check->num_rows > 0) {
  $schedule_query = "
    SELECT activity_id, title, category, activity_date, activity_time, location
    FROM scheduled_activities
    WHERE activity_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
      AND activity_date <= DATE_ADD(CURDATE(), INTERVAL 24 MONTH)
    ORDER BY activity_date ASC, activity_time ASC
    LIMIT 600
  ";
  $schedule_result = $conn->query($schedule_query);
  if ($schedule_result) {
    while ($activity_row = $schedule_result->fetch_assoc()) {
      $schedule_activities[] = [
        'id' => (int)($activity_row['activity_id'] ?? 0),
        'title' => (string)($activity_row['title'] ?? ''),
        'category' => (string)($activity_row['category'] ?? 'General'),
        'date' => (string)($activity_row['activity_date'] ?? ''),
        'time' => (string)($activity_row['activity_time'] ?? ''),
        'location' => (string)($activity_row['location'] ?? '')
      ];
    }
  }
}

$schedule_activities_json = json_encode($schedule_activities, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
if ($schedule_activities_json === false) {
  $schedule_activities_json = '[]';
}
?>

<!-- Schedule of Activities Section -->
<section id="section-schedule" class="admin-section">
  <div class="section-header">
    <h1>Schedule of Activities</h1>
    <p>Upcoming cooperative activities for farmers and clients</p>
  </div>

  <div class="schedule-layout">
    <div class="dashboard-card schedule-calendar-card">
      <div class="card-header card-header-actions">
        <h3>Activity Calendar</h3>
        <div class="calendar-nav">
          <button type="button" class="calendar-nav-btn" id="calPrevBtn" aria-label="Previous month"><i class="fas fa-chevron-left"></i></button>
          <span id="calendarMonthLabel"></span>
          <button type="button" class="calendar-nav-btn" id="calNextBtn" aria-label="Next month"><i class="fas fa-chevron-right"></i></button>
          <button type="button" class="calendar-nav-today" id="calTodayBtn">Today</button>
        </div>
      </div>
        <div class="calendar">
          <div class="calendar-weekdays">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>
          <div class="calendar-grid" id="calendarGrid"></div>
          <div class="calendar-legend">
            <span><i class="legend-dot calendar-dot-event"></i> Activity</span>
            <span><i class="legend-dot calendar-dot-today"></i> Today</span>
          </div>
        </div>
    </div>

    <div class="schedule-side">
      <div class="dashboard-card">
        <div class="card-header card-header-actions">
          <div>
            <h3>Upcoming Schedule</h3>
            <span class="card-subtitle" id="scheduleListLabel">Next 30 days</span>
          </div>
          <button type="button" class="btn-primary schedule-add-btn" id="openSchedulePage">
            <i class="fas fa-plus"></i>
            Add Activity
          </button>
        </div>
        <div class="schedule-list" id="scheduleList"></div>
      </div>
    </div>
  </div>

  <script>
    (function() {
      const scheduleList = document.getElementById('scheduleList');
      const calendarGrid = document.getElementById('calendarGrid');
      const calendarLabel = document.getElementById('calendarMonthLabel');
      const openSchedulePageBtn = document.getElementById('openSchedulePage');
      const scheduleListLabel = document.getElementById('scheduleListLabel');

      if (!scheduleList || !calendarGrid || !calendarLabel) return;

      let selectedDate = '';
      window.scheduleSelectedDate = '';
      const today = new Date();
      let currentYear = today.getFullYear();
      let currentMonth = today.getMonth();

      const activities = <?php echo $schedule_activities_json; ?>;

      function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function(char) {
          const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
          };
          return map[char] || char;
        });
      }

      function toDateKey(value) {
        if (!value) return '';
        const date = new Date(value + 'T00:00:00');
        if (Number.isNaN(date.getTime())) return '';
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
      }

      function getTagLabel(dateKey) {
        const target = new Date(dateKey + 'T00:00:00');
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (Number.isNaN(target.getTime())) return 'Upcoming';
        const diffDays = Math.round((target.getTime() - today.getTime()) / 86400000);
        if (diffDays === 0) return 'Today';
        if (diffDays === 1) return 'Tomorrow';
        if (diffDays > 1 && diffDays <= 7) return 'This Week';
        if (diffDays < 0) return 'Past';
        return 'Upcoming';
      }

      function formatDate(value) {
        const date = new Date(value + 'T00:00:00');
        if (Number.isNaN(date.getTime())) return value;
        const options = { month: 'short', day: '2-digit', year: 'numeric' };
        return date.toLocaleDateString('en-US', options);
      }

      function formatTime(value) {
        const parts = String(value || '').split(':');
        if (parts.length < 2) return value;
        const date = new Date(2026, 1, 1, parseInt(parts[0], 10), parseInt(parts[1], 10));
        if (Number.isNaN(date.getTime())) return value;
        return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
      }

      function updateScheduleLabel() {
        if (!scheduleListLabel) return;
        if (!selectedDate) {
          scheduleListLabel.textContent = 'Next 30 days';
          return;
        }
        scheduleListLabel.textContent = `Activities for ${formatDate(selectedDate)}`;
      }

      function renderScheduleList() {
        const sorted = [...activities].sort((a, b) => {
          const aStamp = `${a.date || ''} ${a.time || ''}`;
          const bStamp = `${b.date || ''} ${b.time || ''}`;
          return aStamp.localeCompare(bStamp);
        });
        const filtered = selectedDate
          ? sorted.filter((item) => item.date === selectedDate)
          : sorted.filter((item) => (item.date || '') >= toDateKey(new Date().toISOString().slice(0, 10))).slice(0, 6);

        updateScheduleLabel();

        if (!filtered.length) {
          scheduleList.innerHTML = `
            <div class="schedule-item">
              <div class="schedule-main">
                <span class="schedule-title">No activities yet</span>
                <span class="schedule-meta">Select another day or add an activity.</span>
              </div>
              <span class="schedule-tag">Empty</span>
            </div>
          `;
          return;
        }

        scheduleList.innerHTML = filtered.map((item) => {
          const tag = getTagLabel(item.date || '');
          return `
            <div class="schedule-item">
              <div class="schedule-main">
                <span class="schedule-title">${escapeHtml(item.title || 'Untitled Activity')}</span>
                <span class="schedule-meta">${formatDate(item.date || '')} · ${formatTime(item.time || '')} · ${escapeHtml(item.location || '-')}</span>
              </div>
              <span class="schedule-tag schedule-tag-week">${escapeHtml(tag)}</span>
            </div>
          `;
        }).join('');
      }

      function renderCalendar(year, month) {
        currentYear = year;
        currentMonth = month;
        const firstDay = new Date(year, month, 1);
        const startDay = firstDay.getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const daysInPrev = new Date(year, month, 0).getDate();
        const today = new Date();
        const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;

        calendarLabel.textContent = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

        const eventDays = new Set();
        const monthKey = `${year}-${String(month + 1).padStart(2, '0')}`;
        activities.forEach((item) => {
          const dateKey = toDateKey(item.date || '');
          if (dateKey.startsWith(monthKey)) {
            eventDays.add(dateKey);
          }
        });

        const cells = [];
        for (let i = 0; i < startDay; i += 1) {
          cells.push({
            day: daysInPrev - startDay + i + 1,
            muted: true,
            dateKey: ''
          });
        }

        for (let day = 1; day <= daysInMonth; day += 1) {
          const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          cells.push({
            day,
            muted: false,
            dateKey
          });
        }

        while (cells.length % 7 !== 0) {
          const nextDay = cells.length - (startDay + daysInMonth) + 1;
          cells.push({ day: nextDay, muted: true, dateKey: '' });
        }

        calendarGrid.innerHTML = cells.map((cell) => {
          const classes = ['calendar-day'];
          if (cell.muted) classes.push('is-muted');
          if (!cell.muted && eventDays.has(cell.dateKey)) classes.push('is-event');
          if (!cell.muted && cell.dateKey === todayKey) classes.push('is-today');
          if (!cell.muted && cell.dateKey && cell.dateKey === selectedDate) classes.push('is-selected');
          if (cell.muted) {
            return `<span class="${classes.join(' ')}">${cell.day}</span>`;
          }
          return `
            <span class="${classes.join(' ')}" data-date="${cell.dateKey}" role="button" tabindex="0" aria-pressed="${cell.dateKey === selectedDate}">
              ${cell.day}
            </span>
          `;
        }).join('');
      }

      function setCalendarToDate(value) {
        const date = new Date(value + 'T00:00:00');
        if (Number.isNaN(date.getTime())) return;
        renderCalendar(date.getFullYear(), date.getMonth());
      }

      function setSelectedDate(value) {
        selectedDate = value;
        window.scheduleSelectedDate = value;
        renderScheduleList();
        setCalendarToDate(value);
        if (openSchedulePageBtn) {
          openSchedulePageBtn.dataset.selectedDate = value;
        }
      }

      if (openSchedulePageBtn) {
        openSchedulePageBtn.addEventListener('click', () => {
          const selected = (openSchedulePageBtn.dataset.selectedDate || selectedDate || '').trim();
          let url = 'admin_dashboard.php?section=add-schedule-activity';
          if (selected !== '') {
            url += '&selected_date=' + encodeURIComponent(selected);
          }
          window.location.href = url;
        });
      }

      calendarGrid.addEventListener('click', (event) => {
        const target = event.target.closest('.calendar-day');
        if (!target || target.classList.contains('is-muted')) return;
        const dateKey = target.getAttribute('data-date');
        if (!dateKey) return;
        setSelectedDate(dateKey);
      });

      calendarGrid.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        const target = event.target.closest('.calendar-day');
        if (!target || target.classList.contains('is-muted')) return;
        const dateKey = target.getAttribute('data-date');
        if (!dateKey) return;
        event.preventDefault();
        setSelectedDate(dateKey);
      });

      const calPrevBtn = document.getElementById('calPrevBtn');
      const calNextBtn = document.getElementById('calNextBtn');
      const calTodayBtn = document.getElementById('calTodayBtn');

      if (calPrevBtn) {
        calPrevBtn.addEventListener('click', () => {
          currentMonth -= 1;
          if (currentMonth < 0) { currentMonth = 11; currentYear -= 1; }
          renderCalendar(currentYear, currentMonth);
        });
      }

      if (calNextBtn) {
        calNextBtn.addEventListener('click', () => {
          currentMonth += 1;
          if (currentMonth > 11) { currentMonth = 0; currentYear += 1; }
          renderCalendar(currentYear, currentMonth);
        });
      }

      if (calTodayBtn) {
        calTodayBtn.addEventListener('click', () => {
          const t = new Date();
          const todayKey = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
          setSelectedDate(todayKey);
        });
      }

      const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      setSelectedDate(todayKey);
    })();
  </script>
</section>
