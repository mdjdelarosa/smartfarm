<?php
require_once '../config.php';

header('Content-Type: application/json');

$sessionRole = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
if ($sessionRole !== 'admin') {
    http_response_code(403);
    echo json_encode([
        'success' => false,
        'error' => 'Unauthorized access'
    ]);
    exit;
}

$crop_id = (int)($_GET['crop_id'] ?? 0);
if ($crop_id <= 0) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid crop id.'
    ]);
    exit;
}

if (!ensureCropHistoryTable($conn)) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Unable to initialize crop history table.'
    ]);
    exit;
}

$stmt = $conn->prepare(
    "SELECT
        history_id,
        crop_id,
        farmer_id,
        changed_by_user_id,
        actor_role,
        actor_name,
        event_type,
        old_quantity,
        new_quantity,
        quantity_delta,
        crop_name,
        crop_unit,
        remarks,
        created_at
     FROM crop_history
     WHERE crop_id = ?
     ORDER BY created_at DESC, history_id DESC"
);

if (!$stmt) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Failed to prepare history query.'
    ]);
    exit;
}

$stmt->bind_param('i', $crop_id);
$stmt->execute();
$result = $stmt->get_result();

$history = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $history[] = [
            'history_id' => (int)$row['history_id'],
            'crop_id' => (int)$row['crop_id'],
            'farmer_id' => isset($row['farmer_id']) ? (int)$row['farmer_id'] : 0,
            'changed_by_user_id' => isset($row['changed_by_user_id']) ? (int)$row['changed_by_user_id'] : 0,
            'actor_role' => (string)($row['actor_role'] ?? 'system'),
            'actor_name' => (string)($row['actor_name'] ?? 'System'),
            'event_type' => (string)($row['event_type'] ?? 'record_updated'),
            'old_quantity' => isset($row['old_quantity']) ? (float)$row['old_quantity'] : null,
            'new_quantity' => isset($row['new_quantity']) ? (float)$row['new_quantity'] : null,
            'quantity_delta' => isset($row['quantity_delta']) ? (float)$row['quantity_delta'] : null,
            'crop_name' => (string)($row['crop_name'] ?? ''),
            'crop_unit' => (string)($row['crop_unit'] ?? ''),
            'remarks' => (string)($row['remarks'] ?? ''),
            'created_at' => (string)($row['created_at'] ?? '')
        ];
    }
}
$stmt->close();

echo json_encode([
    'success' => true,
    'history' => $history
]);
exit;
?>
