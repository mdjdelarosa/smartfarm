<?php
require_once __DIR__ . '/../config.php';

$type = $_GET['type'] ?? '';
$id = (int)($_GET['id'] ?? 0);

if (!in_array($type, ['farmer','client']) || $id <= 0) {
    http_response_code(400);
    echo 'Invalid request';
    exit;
}

if ($type === 'farmer') {
    $stmt = $conn->prepare('SELECT farmer_id_file, farmer_id_file_name, farmer_id_file_mime_type FROM farmers WHERE farmer_id = ? LIMIT 1');
} else {
    $stmt = $conn->prepare('SELECT client_id_file, client_id_file_name, client_id_file_mime_type FROM clients WHERE client_id = ? LIMIT 1');
}

$stmt->bind_param('i', $id);
$stmt->execute();
$res = $stmt->get_result();
if (!$res || $res->num_rows === 0) {
    http_response_code(404);
    echo 'File not found';
    exit;
}
$row = $res->fetch_assoc();
$stmt->close();

$fileData = $type === 'farmer' ? ($row['farmer_id_file'] ?? null) : ($row['client_id_file'] ?? null);
$fileName = $type === 'farmer' ? ($row['farmer_id_file_name'] ?? '') : ($row['client_id_file_name'] ?? '');
$mime = $type === 'farmer' ? ($row['farmer_id_file_mime_type'] ?? '') : ($row['client_id_file_mime_type'] ?? '');

if ($fileData === null || $fileData === '') {
    http_response_code(404);
    echo 'No file uploaded';
    exit;
}

if ($fileName === '') {
    $fallbackExt = $mime === 'application/pdf' ? 'pdf' : ($mime === 'image/png' ? 'png' : ($mime === 'image/gif' ? 'gif' : 'jpg'));
    $fileName = $type . '-id-' . $id . '.' . $fallbackExt;
}

header('Content-Description: File Transfer');
header('Content-Type: ' . ($mime ?: 'application/octet-stream'));
$inline = isset($_GET['inline']) && $_GET['inline'] === '1';
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . basename($fileName) . '"');
header('Content-Length: ' . strlen($fileData));
echo $fileData;
exit;

?>
