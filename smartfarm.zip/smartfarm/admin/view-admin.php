<!-- View Admin Account Section -->
<?php
// Fetch logged-in admin's data
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    echo "<section id='section-view-admin' class='admin-section'><div class='section-header'><h1>Error</h1></div><p>Unauthorized.</p></section>";
    exit;
}

$user_id = $_SESSION['user_id'];
$query = "SELECT u.user_id, u.email, u.is_active, u.created_at, a.fullname FROM users u JOIN admins a ON u.user_id = a.user_id WHERE u.user_id = ?";
$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "<section id='section-view-admin' class='admin-section'><p>Error: " . htmlspecialchars($conn->error) . "</p></section>";
    exit;
}
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

if (!$admin) {
    echo "<section id='section-view-admin' class='admin-section'><p>Admin record not found.</p></section>";
    exit;
}

$joined_date = date('F j, Y', strtotime($admin['created_at']));
$status = $admin['is_active'] ? 'Active' : 'Inactive';
$status_class = $admin['is_active'] ? 'approved' : 'pending';
?>
<section id="section-view-admin" class="admin-section">
  <div class="section-header">
    <h1>My Admin Account</h1>
  </div>
  <div class="form-container" style="width:100%;margin:0;">
    <div class="admin-form">
      <div style="padding: 1.5rem; background: rgba(40, 167, 69, 0.05); border-radius: 8px; border-left: 4px solid #28a745;">
        <p><strong>Admin Name:</strong> <?php echo htmlspecialchars($admin['fullname']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($admin['email']); ?></p>
        <p><strong>Role:</strong> Administrator</p>
        <p><strong>Joined:</strong> <?php echo $joined_date; ?></p>
        <p><strong>Status:</strong> <span class="status <?php echo $status_class; ?>"><?php echo $status; ?></span></p>
      </div>
      <button class="btn-primary" onclick="alert('Admin account management functionality coming soon...')" data-tooltip="Manage Account"><i class="fas fa-edit"></i></button>
      <button class="btn-secondary" onclick="alert('Change password functionality coming soon...')" data-tooltip="Change Password"><i class="fas fa-key"></i></button>
    </div>
  </div>
</section>
