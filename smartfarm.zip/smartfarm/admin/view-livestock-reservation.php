<?php
$reservation_id = (int)($_GET['reservation_id'] ?? $_POST['reservation_id'] ?? 0);
$from_param = trim((string)($_GET['from'] ?? $_POST['from'] ?? 'manage-livestock-products'));
$success_msg = '';
$error_msg = '';

if ($reservation_id <= 0) {
  echo "<section id='section-view-livestock-reservation' class='admin-section'>";
  echo "<div class='section-header'><h1>Reservation Details</h1></div>";
  echo "<p>Invalid reservation.</p>";
  echo "</section>";
  return;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array(($_POST['action'] ?? ''), ['update_transaction_from_view', 'update_payment_from_view'], true)) {
  $post_action = (string)($_POST['action'] ?? '');
  $post_reservation_id = (int)($_POST['reservation_id'] ?? 0);
  $status = strtolower(trim((string)($_POST['status'] ?? '')));
  $payment_status = strtolower(trim((string)($_POST['payment_status'] ?? '')));
  $admin_notes = trim((string)($_POST['admin_notes'] ?? ''));

  $allowed_status = ['pending', 'confirmed', 'ready', 'completed', 'cancelled'];
  $allowed_payment = ['unpaid', 'paid'];

  if ($post_reservation_id !== $reservation_id || $reservation_id <= 0) {
    $error_msg = 'Invalid reservation selected.';
  } else {
    if ($post_action === 'update_transaction_from_view') {
      if (!in_array($status, $allowed_status, true)) {
        $error_msg = 'Invalid transaction status selected.';
      } elseif (strlen($admin_notes) > 500) {
        $error_msg = 'Admin note is too long.';
      } else {
        $stmt = $conn->prepare(
          "UPDATE livestock_reservations
           SET status = ?, admin_notes = ?
           WHERE reservation_id = ?"
        );
        if ($stmt) {
          $stmt->bind_param('ssi', $status, $admin_notes, $reservation_id);
        }
      }
    } elseif ($post_action === 'update_payment_from_view') {
      if (!in_array($payment_status, $allowed_payment, true)) {
        $error_msg = 'Invalid payment status selected.';
      } elseif ($payment_status === 'paid') {
        $payment_marked_at = date('Y-m-d H:i:s');
        $stmt = $conn->prepare(
          "UPDATE livestock_reservations
           SET payment_status = ?, payment_marked_at = ?
           WHERE reservation_id = ?"
        );
        if ($stmt) {
          $stmt->bind_param('ssi', $payment_status, $payment_marked_at, $reservation_id);
        }
      } else {
        $stmt = $conn->prepare(
          "UPDATE livestock_reservations
           SET payment_status = ?, payment_marked_at = NULL
           WHERE reservation_id = ?"
        );
        if ($stmt) {
          $stmt->bind_param('si', $payment_status, $reservation_id);
        }
      }
    }

    if ($error_msg !== '') {
      // Validation already failed for this scope.
    } elseif (!isset($stmt) || !$stmt) {
      $error_msg = 'Unable to prepare reservation update.';
    } elseif ($stmt->execute()) {
      $success_msg = $post_action === 'update_payment_from_view'
        ? 'Payment status updated successfully.'
        : 'Transaction details updated successfully.';
      if ($stmt->affected_rows === 0) {
        $success_msg = 'No changes were detected, but the form was submitted successfully.';
      }
      $stmt->close();
    } else {
      $error_msg = 'Failed to update reservation.';
      $stmt->close();
    }
  }
}

$stmt = $conn->prepare(
  "SELECT
      r.reservation_id,
      r.status,
      COALESCE(r.payment_status, 'unpaid') AS payment_status,
      r.payment_marked_at,
      COALESCE(r.admin_notes, '') AS admin_notes,
      COALESCE(r.notes, '') AS client_notes,
      r.quantity,
      COALESCE(r.unit_price, lp.price) AS unit_price,
      COALESCE(r.total_price, lp.price) AS total_price,
      r.preferred_date,
      r.created_at,
      lp.product_name,
      lp.product_type,
      lp.unit,
      COALESCE(c.client_fullname, '') AS client_fullname,
      COALESCE(c.client_contact_number, '') AS client_contact_number,
      COALESCE(u.email, '') AS client_email
   FROM livestock_reservations r
   INNER JOIN livestock_products lp ON lp.product_id = r.product_id
   LEFT JOIN clients c ON c.client_id = r.client_id
   LEFT JOIN users u ON u.user_id = c.user_id
   WHERE r.reservation_id = ?
   LIMIT 1"
);

$stmt->bind_param('i', $reservation_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
  echo "<section id='section-view-livestock-reservation' class='admin-section'>";
  echo "<div class='section-header'><h1>Reservation Details</h1></div>";
  echo "<p>Reservation not found.</p>";
  echo "</section>";
  return;
}

$status_map = [
  'pending' => ['label' => 'Pending Approval', 'class' => 'pending'],
  'confirmed' => ['label' => 'Confirmed', 'class' => 'approved'],
  'ready' => ['label' => 'Ready for Pickup', 'class' => 'ready'],
  'completed' => ['label' => 'Completed', 'class' => 'completed'],
  'cancelled' => ['label' => 'Cancelled', 'class' => 'cancelled']
];

$status_key = strtolower((string)$row['status']);
if (!isset($status_map[$status_key])) {
  $status_key = 'pending';
}

$status_label = $status_map[$status_key]['label'];
$status_class = $status_map[$status_key]['class'];

$payment_key = strtolower((string)$row['payment_status']) === 'paid' ? 'paid' : 'unpaid';
$payment_label = $payment_key === 'paid' ? 'Paid' : 'Unpaid';
$payment_class = $payment_key === 'paid' ? 'approved' : 'pending';

$created_at_text = '-';
if (!empty($row['created_at'])) {
  $created_at_text = date('F j, Y h:i A', strtotime((string)$row['created_at']));
}

$pickup_date_text = '-';
if (!empty($row['preferred_date'])) {
  $pickup_date_text = date('F j, Y', strtotime((string)$row['preferred_date']));
}

$qty_text = (string)((int)$row['quantity']) . ' ' . (string)$row['unit'];
$total_text = 'P' . number_format((float)$row['total_price'], 2);
$unit_price_text = 'P' . number_format((float)$row['unit_price'], 2);
$client_name = trim((string)$row['client_fullname']) !== '' ? (string)$row['client_fullname'] : 'Unknown Client';
$avatar_letter = strtoupper(substr($client_name, 0, 1));

$payment_marked_at_text = '-';
if (!empty($row['payment_marked_at'])) {
  $payment_marked_at_text = date('F j, Y h:i A', strtotime((string)$row['payment_marked_at']));
}
?>

<section id="section-view-livestock-reservation" class="admin-section">
  <div class="section-header sf-account-header">
    <div class="sf-account-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>')" data-tooltip="Back to list">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Reservation Details</h1>
        <p>Review reservation details, client information, and payment status.</p>
      </div>
    </div>
  </div>

  <?php if ($success_msg !== ''): ?>
    <div class="alert-success alert-message" style="margin-bottom:10px;">
      <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <?php if ($error_msg !== ''): ?>
    <div class="alert-error alert-message" style="margin-bottom:10px;">
      <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_msg, ENT_QUOTES, 'UTF-8'); ?>
    </div>
  <?php endif; ?>

  <div class="form-container sf-account-shell" style="width:100%;margin:0;">
    <div id="reservationView" class="admin-form">

      <section class="sf-summary-card">
        <div class="sf-summary-main">
          <div class="sf-summary-identity">
            <div class="sf-avatar"><?php echo htmlspecialchars($avatar_letter, ENT_QUOTES, 'UTF-8'); ?></div>
            <div>
              <h2><?php echo htmlspecialchars($client_name, ENT_QUOTES, 'UTF-8'); ?></h2>
              <p><?php echo htmlspecialchars((string)($row['client_email'] ?: '-'), ENT_QUOTES, 'UTF-8'); ?></p>
            </div>
          </div>

          <div class="sf-pill-row">
            <span id="mode-chip" class="sf-mode-chip view">Viewing</span>
          </div>
        </div>

        <div class="sf-summary-meta">
          <div><span>Reservation</span><strong>#RES<?php echo str_pad((string)$reservation_id, 3, '0', STR_PAD_LEFT); ?></strong></div>
          <div><span>Requested</span><strong><?php echo htmlspecialchars($created_at_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div><span>Payment Marked</span><strong><?php echo htmlspecialchars($payment_marked_at_text, ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div><span>Client Contact</span><strong><?php echo htmlspecialchars((string)($row['client_contact_number'] !== '' ? $row['client_contact_number'] : '-'), ENT_QUOTES, 'UTF-8'); ?></strong></div>
        </div>
      </section>

      <div class="sf-content-grid">
        <section class="sf-panel">
          <h3>Reservation Information</h3>
          <div class="sf-field-grid">
            <div class="sf-field">
              <label>Product</label>
              <span class="sf-field-value"><?php echo htmlspecialchars((string)$row['product_name'], ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Product Type</label>
              <span class="sf-field-value"><?php echo htmlspecialchars((string)$row['product_type'], ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Quantity</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($qty_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Unit Price</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($unit_price_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Total</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($total_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field">
              <label>Pickup Date</label>
              <span class="sf-field-value"><?php echo htmlspecialchars($pickup_date_text, ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
            <div class="sf-field sf-field-span-2">
              <label>Client Note</label>
              <span class="sf-field-value"><?php echo htmlspecialchars((string)($row['client_notes'] !== '' ? $row['client_notes'] : '-'), ENT_QUOTES, 'UTF-8'); ?></span>
            </div>
          </div>
        </section>

        <section class="sf-panel sf-update-panel">
          <h3>Update Reservation</h3>

          <div class="sf-action-bar">
            <button type="button" class="btn-primary" onclick="openTransactionEditor()">
              <i class="fas fa-pen"></i>
              Update Transaction
            </button>
            <button type="button" class="btn-secondary" onclick="openPaymentEditor()">
              <i class="fas fa-credit-card"></i>
              Update Payment
            </button>
          </div>

          <div id="update-view-readonly" class="sf-inline-view">
            <div class="sf-field-grid sf-field-grid-single">
              <div class="sf-field">
                <label>Transaction Status</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($status_label, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>

              <div class="sf-field">
                <label>Payment Status</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($payment_label, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>

              <div class="sf-field">
                <label>Admin Note</label>
                <span class="sf-field-value"><?php echo htmlspecialchars((string)($row['admin_notes'] !== '' ? $row['admin_notes'] : '-'), ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
            </div>
          </div>

          <div id="update-view-transaction" class="sf-inline-view sf-hidden">
            <div class="sf-inline-head">
              <h4>Transaction Update</h4>
              <button type="button" class="btn-tertiary" onclick="backToUpdateSummary()">Cancel</button>
            </div>
            <form method="post" id="transaction-update-form" class="sf-manage-form">
              <input type="hidden" name="action" value="update_transaction_from_view">
              <input type="hidden" name="reservation_id" value="<?php echo (int)$reservation_id; ?>">
              <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>">

              <div class="sf-field">
                <label for="transaction-status-input">Transaction Status</label>
                <select id="transaction-status-input" name="status" class="sf-field-input" data-initial="<?php echo htmlspecialchars($status_key, ENT_QUOTES, 'UTF-8'); ?>">
                  <option value="pending" <?php echo $status_key === 'pending' ? 'selected' : ''; ?>>Pending Approval</option>
                  <option value="confirmed" <?php echo $status_key === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                  <option value="ready" <?php echo $status_key === 'ready' ? 'selected' : ''; ?>>Ready for Pickup</option>
                  <option value="completed" <?php echo $status_key === 'completed' ? 'selected' : ''; ?>>Completed</option>
                  <option value="cancelled" <?php echo $status_key === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                </select>
              </div>

              <div class="sf-field">
                <label for="transaction-admin-note-input">Admin Note</label>
                <textarea id="transaction-admin-note-input" name="admin_notes" class="sf-field-input" rows="4" maxlength="500" data-initial="<?php echo htmlspecialchars((string)$row['admin_notes'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)$row['admin_notes'], ENT_QUOTES, 'UTF-8'); ?></textarea>
              </div>

              <button type="submit" class="btn-primary">Save Transaction Update</button>
            </form>
          </div>

          <div id="update-view-payment" class="sf-inline-view sf-hidden">
            <div class="sf-inline-head">
              <h4>Payment Update</h4>
              <button type="button" class="btn-tertiary" onclick="backToUpdateSummary()">Cancel</button>
            </div>
            <form method="post" id="payment-update-form" class="sf-manage-form">
              <input type="hidden" name="action" value="update_payment_from_view">
              <input type="hidden" name="reservation_id" value="<?php echo (int)$reservation_id; ?>">
              <input type="hidden" name="from" value="<?php echo htmlspecialchars($from_param, ENT_QUOTES, 'UTF-8'); ?>">
              <div class="sf-field">
                <label for="payment-status-input">Payment Status</label>
                <select id="payment-status-input" name="payment_status" class="sf-field-input" data-initial="<?php echo htmlspecialchars($payment_key, ENT_QUOTES, 'UTF-8'); ?>">
                  <option value="unpaid" <?php echo $payment_key === 'unpaid' ? 'selected' : ''; ?>>Unpaid</option>
                  <option value="paid" <?php echo $payment_key === 'paid' ? 'selected' : ''; ?>>Paid</option>
                </select>
              </div>

              <div class="sf-field">
                <label>Current Payment Marked</label>
                <span class="sf-field-value"><?php echo htmlspecialchars($payment_marked_at_text, ENT_QUOTES, 'UTF-8'); ?></span>
              </div>

              <button type="submit" class="btn-primary">Save Payment Update</button>
            </form>
          </div>
        </section>
      </div>
    </div>
  </div>
</section>

<style>
.sf-account-header {
  margin-bottom: 16px;
}

.sf-account-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}

.sf-account-shell {
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 14px;
  background: #f7fbf8;
  box-shadow: 0 6px 18px rgba(23, 66, 38, 0.08);
  padding: 18px;
  width: 100%;
  max-width: none !important;
  display: grid;
  gap: 18px;
}

.sf-summary-card {
  background: #ffffff;
  border: 1px solid #d9e7de;
  border-radius: 14px;
  padding: 16px;
  display: grid;
  grid-template-columns: minmax(360px, 1fr) minmax(620px, 2fr);
  align-items: start;
  gap: 16px;
}

.sf-summary-main {
  display: grid;
  gap: 10px;
  min-width: 0;
}

.sf-summary-identity {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

.sf-summary-identity h2 {
  margin: 0;
  color: #22c55e;
  font-size: 1.1rem;
}

.sf-summary-identity p {
  margin: 2px 0 0;
  color: #5a7061;
}

.sf-avatar {
  flex: 0 0 52px;
  width: 52px;
  height: 52px;
  border-radius: 999px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  font-size: 1.25rem;
  font-weight: 700;
  color: #fff;
  background: linear-gradient(135deg, #00a86b 0%, #0b7d52 100%);
  box-shadow: 0 5px 14px rgba(0, 132, 84, 0.22);
}

.sf-pill-row {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  justify-content: flex-start;
}

.sf-summary-meta {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 10px;
  min-width: 0;
}

.sf-summary-meta div {
  display: grid;
  gap: 2px;
  background: #f6fbf8;
  border: 1px solid #e0ece4;
  border-radius: 10px;
  padding: 10px 12px;
}

.sf-summary-meta span {
  color: #5f7665;
  font-size: 0.76rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.02em;
}

.sf-summary-meta strong {
  color: #214532;
  font-size: 0.9rem;
  line-height: 1.3;
}

.sf-panel {
  border: 1px solid rgba(27, 90, 42, 0.12);
  border-radius: 14px;
  background: #fff;
  padding: 18px;
}

.sf-panel h3 {
  margin: 0 0 12px;
  color: #22c55e;
}

.sf-content-grid {
  display: grid;
  grid-template-columns: minmax(0, 2fr) minmax(360px, 1fr);
  gap: 18px;
  align-items: stretch;
}

.sf-update-panel {
  border-color: rgba(0, 168, 107, 0.28);
  background: linear-gradient(180deg, #ffffff, #f8fcfa);
  height: 100%;
}

.sf-update-panel .sf-field-grid {
  grid-template-columns: 1fr;
}

.sf-update-panel .sf-field-span-2 {
  grid-column: span 1;
}

.sf-field-grid-single {
  grid-template-columns: 1fr;
}

.sf-mode-chip {
  font-size: 0.78rem;
  font-weight: 700;
  border-radius: 999px;
  padding: 6px 10px;
  letter-spacing: 0.02em;
}

.sf-mode-chip.view {
  color: #155724;
  background: rgba(40, 167, 69, 0.16);
}

.sf-mode-chip.edit {
  color: #7a5200;
  background: rgba(255, 193, 7, 0.2);
}

.sf-readonly-note {
  margin: 0 0 12px;
  padding: 10px 12px;
  border-radius: 10px;
  background: rgba(1, 87, 53, 0.08);
  color: #28543b;
  font-size: 0.88rem;
}

.sf-action-bar {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: stretch;
  gap: 10px;
  margin-bottom: 14px;
}

.sf-field-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 10px;
}

.sf-field-span-2 {
  grid-column: span 2;
}

.sf-field {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.sf-field label {
  font-weight: 700;
  font-size: 0.8rem;
  color: #45624f;
}

.sf-field-value {
  min-height: 36px;
  border: 1px solid #d9e4dd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #f8fcf9;
  display: block;
  line-height: 1.35;
}

.sf-field-input {
  width: 100%;
  border: 1px solid #c7d6cd;
  border-radius: 8px;
  padding: 8px 10px;
  color: #203629;
  background: #fff;
  outline: none;
}

.sf-field-input:focus {
  border-color: #00a86b;
  box-shadow: 0 0 0 3px rgba(0, 168, 107, 0.15);
}

.sf-inline-view {
  margin-top: 12px;
}

.sf-inline-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 12px;
}

.sf-inline-head h4 {
  margin: 0;
  color: #1f5c37;
}

.sf-action-bar button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
}

.sf-manage-form {
  border: 1px solid #dce8df;
  border-radius: 12px;
  padding: 12px;
  background: #fbfefd;
  display: grid;
  gap: 10px;
}

.sf-hidden {
  display: none !important;
}

@media (max-width: 1280px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
    align-items: flex-start;
  }

  .sf-summary-meta {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}

@media (max-width: 1080px) {
  .sf-summary-card {
    grid-template-columns: 1fr;
  }

  .sf-content-grid {
    grid-template-columns: 1fr;
  }

  .sf-summary-meta {
    grid-template-columns: 1fr;
  }
}

@media (max-width: 760px) {
  .sf-field-grid {
    grid-template-columns: 1fr;
  }

  .sf-field-span-2 {
    grid-column: span 1;
  }

  .sf-account-shell {
    padding: 12px;
  }

  .sf-panel {
    padding: 12px;
  }

  .sf-summary-meta div { min-width: 100%; }

}
</style>

<script>
function setUpdateView(viewKey) {
  const sections = {
    readonly: document.getElementById('update-view-readonly'),
    transaction: document.getElementById('update-view-transaction'),
    payment: document.getElementById('update-view-payment')
  };

  Object.keys(sections).forEach(function (key) {
    if (sections[key]) {
      sections[key].classList.add('sf-hidden');
    }
  });

  if (sections[viewKey]) {
    sections[viewKey].classList.remove('sf-hidden');
  }
}

function openTransactionEditor() {
  setUpdateView('transaction');
}

function openPaymentEditor() {
  setUpdateView('payment');
}

function backToUpdateSummary() {
  setUpdateView('readonly');
}

function statusLabelMap(value) {
  const map = {
    pending: 'Pending Approval',
    confirmed: 'Confirmed',
    ready: 'Ready for Pickup',
    completed: 'Completed',
    cancelled: 'Cancelled'
  };
  return map[value] || value;
}

function paymentLabelMap(value) {
  return value === 'paid' ? 'Paid' : 'Unpaid';
}

document.addEventListener('DOMContentLoaded', function () {
  const transactionForm = document.getElementById('transaction-update-form');
  const paymentForm = document.getElementById('payment-update-form');

  if (transactionForm) {
    transactionForm.addEventListener('submit', function (event) {
      const statusInput = document.getElementById('transaction-status-input');
      const noteInput = document.getElementById('transaction-admin-note-input');
      const oldStatus = (statusInput?.dataset.initial || '').trim();
      const newStatus = (statusInput?.value || '').trim();
      const oldNote = (noteInput?.dataset.initial || '').trim();
      const newNote = (noteInput?.value || '').trim();
      const changes = [];

      if (oldStatus !== newStatus) {
        changes.push('Transaction Status: ' + statusLabelMap(oldStatus) + ' -> ' + statusLabelMap(newStatus));
      }
      if (oldNote !== newNote) {
        changes.push('Admin Note updated');
      }

      if (changes.length === 0) {
        event.preventDefault();
        window.alert('No changes detected in Transaction Update.');
        return;
      }

      const message = 'Confirm transaction update:\n- ' + changes.join('\n- ');
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  }

  if (paymentForm) {
    paymentForm.addEventListener('submit', function (event) {
      const paymentInput = document.getElementById('payment-status-input');
      const oldPayment = (paymentInput?.dataset.initial || '').trim();
      const newPayment = (paymentInput?.value || '').trim();

      if (oldPayment === newPayment) {
        event.preventDefault();
        window.alert('No changes detected in Payment Update.');
        return;
      }

      const message = 'Confirm payment update:\n- Payment Status: ' + paymentLabelMap(oldPayment) + ' -> ' + paymentLabelMap(newPayment);
      if (!window.confirm(message)) {
        event.preventDefault();
      }
    });
  }

  setUpdateView('readonly');
});
</script>
