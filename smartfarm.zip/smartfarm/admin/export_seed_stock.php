<?php
// admin/export_seed_stock.php
// Generates a CSV for seed stock/warehouse records
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="seed_stock.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'seed_id', 'seed_name', 'unit', 'available_quantity', 'low_stock_threshold', 'last_updated'
]);

$q = $conn->query("SELECT seed_id, seed_name, unit, available_quantity, low_stock_threshold, updated_at AS last_updated FROM seed_stock");
if ($q) {
    while ($row = $q->fetch_assoc()) {
        fputcsv($out, $row);
    }
}
fclose($out);
exit;
