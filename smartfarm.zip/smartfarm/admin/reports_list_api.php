<?php
/**
 * Reports List API
 * - GET ?scope=all|month|year &period=YYYY-MM|YYYY        → generate CSVs + return file list (JSON)
 * - GET ?download=<filename.csv>&format=csv|xls|pdf       → serve report in the chosen format
 */
require_once __DIR__ . '/../config.php';

$exportDir = dirname(__DIR__) . '/exports/reports';
if (!is_dir($exportDir)) @mkdir($exportDir, 0775, true);

// ── Download handler ──────────────────────────────────────────────────────────
$dlFile = isset($_GET['download']) ? basename(trim((string)$_GET['download'])) : '';
if ($dlFile !== '') {
    if (!preg_match('/^[a-zA-Z0-9_\-]+\.csv$/', $dlFile)) { http_response_code(400); exit; }
    $dlPath = $exportDir . '/' . $dlFile;
    if (!file_exists($dlPath)) { http_response_code(404); exit; }

    $format = (string)($_GET['format'] ?? 'csv');
    if (!in_array($format, ['csv', 'xls', 'pdf'], true)) $format = 'csv';
    $baseName = preg_replace('/\.csv$/', '', $dlFile);
    $title = ucwords(str_replace(['_', '-'], ' ', $baseName));

    if ($format === 'csv') {
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $dlFile . '"');
        readfile($dlPath);
        exit;
    }

    // xls/pdf both need the parsed rows
    $rows = [];
    if (($fh = fopen($dlPath, 'r')) !== false) {
        while (($r = fgetcsv($fh)) !== false) {
            $rows[] = $r;
        }
        fclose($fh);
    }

    if ($format === 'xls') {
        // Excel opens an HTML table served with this content-type/extension as a spreadsheet.
        header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
        header('Content-Disposition: attachment; filename="' . $baseName . '.xls"');
        echo "\xEF\xBB\xBF";
        echo '<table border="1">';
        foreach ($rows as $i => $r) {
            echo '<tr>';
            foreach ($r as $cell) {
                $tag = $i === 0 ? 'th' : 'td';
                echo "<$tag>" . htmlspecialchars((string)$cell) . "</$tag>";
            }
            echo '</tr>';
        }
        echo '</table>';
        exit;
    }

    // PDF: print-ready HTML — the admin saves it as PDF via the browser's print dialog.
    header('Content-Type: text/html; charset=UTF-8');
    ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo htmlspecialchars($title); ?></title>
<style>
  body { font-family: Arial, sans-serif; padding: 24px; color: #1f2937; }
  h1 { font-size: 18px; margin: 0 0 4px; }
  .meta { color: #6b7280; font-size: 12px; margin-bottom: 16px; }
  table { border-collapse: collapse; width: 100%; font-size: 12px; }
  th, td { border: 1px solid #d0d7de; padding: 6px 8px; text-align: left; }
  th { background: #eef5f0; }
  .hint { margin-top: 16px; color: #6b7280; font-size: 12px; }
  @media print { .hint { display: none; } }
</style>
</head>
<body onload="window.print()">
  <h1><?php echo htmlspecialchars($title); ?></h1>
  <div class="meta">Generated <?php echo date('F j, Y g:i A'); ?></div>
  <table>
    <?php foreach ($rows as $i => $r): $tag = $i === 0 ? 'th' : 'td'; ?>
      <tr><?php foreach ($r as $cell): ?><<?php echo $tag; ?>><?php echo htmlspecialchars((string)$cell); ?></<?php echo $tag; ?>><?php endforeach; ?></tr>
    <?php endforeach; ?>
  </table>
  <div class="hint">If the print dialog didn't open, use your browser's Print command and choose "Save as PDF".</div>
</body>
</html>
    <?php
    exit;
}

header('Content-Type: application/json; charset=UTF-8');

$scope  = in_array($_GET['scope'] ?? '', ['month', 'year'], true) ? (string)$_GET['scope'] : 'all';
$period = trim((string)($_GET['period'] ?? ''));

// ── Scope WHERE-condition builder (returns condition only, no WHERE keyword) ──
// $col may be 'alias.column' or plain 'column'
function rlScopeCond(mysqli $c, string $scope, string $period, string $col): string {
    $esc = fn(string $s) => $c->real_escape_string($s);
    // Build safe column expression — handle alias.column correctly
    if (strpos($col, '.') !== false) {
        [$alias, $column] = explode('.', $col, 2);
        $safeCol = '`' . str_replace('`', '', $alias) . '`.`' . str_replace('`', '', $column) . '`';
    } else {
        $safeCol = '`' . str_replace('`', '', $col) . '`';
    }
    if ($scope === 'month' && preg_match('/^\d{4}-\d{2}$/', $period)) {
        $s = $esc($period . '-01');
        $e = $esc(date('Y-m-d', strtotime($period . '-01 +1 month')));
        return "DATE($safeCol) >= '$s' AND DATE($safeCol) < '$e'";
    }
    if ($scope === 'year' && preg_match('/^\d{4}$/', $period)) {
        $s = $esc($period . '-01-01');
        $e = $esc(((int)$period + 1) . '-01-01');
        return "DATE($safeCol) >= '$s' AND DATE($safeCol) < '$e'";
    }
    return '';
}

// ── CSV generator (first row becomes headers from column aliases) ─────────────
function rlWriteCsv(string $path, string $sql, mysqli $c): int {
    $res = $c->query($sql);
    if (!$res) return 0;
    $fh = fopen($path, 'w');
    if (!$fh) { $res->free(); return 0; }
    $count = 0; $headerWritten = false;
    while ($row = $res->fetch_assoc()) {
        if (!$headerWritten) { fputcsv($fh, array_keys($row)); $headerWritten = true; }
        fputcsv($fh, array_map(fn($v) => $v ?? '', array_values($row)));
        $count++;
    }
    if (!$headerWritten) fputcsv($fh, []); // empty file still has header space
    fclose($fh); $res->free();
    return $count;
}

$files = [];

// ── 1. Bidding Transactions ───────────────────────────────────────────────────
$cond = rlScopeCond($conn, $scope, $period, 'b.payment_marked_at');
$bWhere = $cond ? "AND $cond" : '';
$rows = rlWriteCsv($exportDir . '/bidding_transactions.csv', "
    SELECT
        b.bid_id            AS 'Bid ID',
        c.crop_name         AS 'Crop Name',
        c.crop_quantity     AS 'Qty',
        c.crop_unit         AS 'Unit',
        b.bid_amount        AS 'Bid Amount (PHP)',
        c.starting_price    AS 'Starting Price (PHP)',
        b.bid_status        AS 'Bid Status',
        c.crop_status       AS 'Crop Status',
        c.bidding_end_date  AS 'Bidding End Date',
        COALESCE(cl.client_fullname, '—') AS 'Bidder',
        b.payment_status    AS 'Payment Status',
        b.payment_marked_at AS 'Payment Date',
        b.created_at        AS 'Bid Placed At'
    FROM bids b
    INNER JOIN crops c  ON c.crop_id  = b.crop_id
    LEFT  JOIN clients cl ON cl.client_id = b.client_id
    WHERE 1=1 $bWhere
    ORDER BY b.payment_marked_at DESC, b.bid_id DESC", $conn);
$files[] = ['file' => 'bidding_transactions.csv', 'title' => 'Bidding Transactions', 'rows' => $rows];

// ── 2. Livestock Reservations ─────────────────────────────────────────────────
$cond = rlScopeCond($conn, $scope, $period, 'lr.payment_marked_at');
$lrWhere = $cond ? "AND $cond" : '';
$rows = rlWriteCsv($exportDir . '/livestock_reservations.csv', "
    SELECT
        lr.reservation_id               AS 'Reservation ID',
        COALESCE(cl.client_fullname,'—') AS 'Client',
        lp.product_name                 AS 'Product',
        lr.quantity                     AS 'Qty',
        lr.unit_price                   AS 'Unit Price (PHP)',
        lr.total_price                  AS 'Total Price (PHP)',
        lr.preferred_date               AS 'Preferred Date',
        lr.status                       AS 'Status',
        lr.payment_status               AS 'Payment Status',
        lr.payment_marked_at            AS 'Payment Date',
        lr.created_at                   AS 'Reserved At'
    FROM livestock_reservations lr
    LEFT JOIN clients cl          ON cl.client_id  = lr.client_id
    LEFT JOIN livestock_products lp ON lp.product_id = lr.product_id
    WHERE 1=1 $lrWhere
    ORDER BY lr.payment_marked_at DESC, lr.reservation_id DESC", $conn);
$files[] = ['file' => 'livestock_reservations.csv', 'title' => 'Livestock Reservations', 'rows' => $rows];

// ── 3. Machinery Rentals ──────────────────────────────────────────────────────
$cond = rlScopeCond($conn, $scope, $period, 'payment_marked_at');
$mrCond = $cond ? "AND $cond" : '';
$rows = rlWriteCsv($exportDir . '/machinery_rentals.csv', "
    SELECT
        rental_code        AS 'Rental Code',
        equipment_name     AS 'Equipment',
        owner_name         AS 'Owner',
        renter_name        AS 'Renter',
        start_date         AS 'Start Date',
        end_date           AS 'End Date',
        total_cost         AS 'Total Cost (PHP)',
        rental_status      AS 'Status',
        payment_status     AS 'Payment Status',
        payment_marked_at  AS 'Payment Date'
    FROM machinery_rentals
    WHERE TRIM(COALESCE(renter_name,'')) != '' $mrCond
    ORDER BY payment_marked_at DESC, rental_id DESC", $conn);
$files[] = ['file' => 'machinery_rentals.csv', 'title' => 'Machinery Rentals', 'rows' => $rows];

// ── 4. Seed Distributions ─────────────────────────────────────────────────────
$cond = rlScopeCond($conn, $scope, $period, 'sd.distribution_date');
$sdWhere = $cond ? "AND $cond" : '';
$rows = rlWriteCsv($exportDir . '/seed_distributions.csv', "
    SELECT
        sd.distribution_id           AS 'Distribution ID',
        f.farmer_fullname            AS 'Farmer',
        si.seed_name                 AS 'Seed',
        sd.quantity_distributed      AS 'Qty Distributed',
        sd.distribution_date         AS 'Distribution Date',
        sd.status                    AS 'Status',
        sd.notes                     AS 'Notes',
        sd.created_at                AS 'Created At'
    FROM seed_distributions sd
    LEFT JOIN farmers f      ON f.farmer_id = sd.farmer_id
    LEFT JOIN seed_inventory si ON si.seed_id  = sd.seed_id
    WHERE 1=1 $sdWhere
    ORDER BY sd.distribution_date DESC, sd.distribution_id DESC", $conn);
$files[] = ['file' => 'seed_distributions.csv', 'title' => 'Seed Distributions', 'rows' => $rows];

// ── 5. All Accounts ───────────────────────────────────────────────────────────
$rows = rlWriteCsv($exportDir . '/all_accounts.csv', "
    SELECT
        'Client'                 AS 'Type',
        u.user_id                AS 'User ID',
        cl.client_fullname       AS 'Full Name',
        u.email                  AS 'Email',
        cl.client_contact_number AS 'Contact',
        cl.client_address        AS 'Address',
        CASE WHEN cl.client_is_verified=1 THEN 'Approved' ELSE 'Pending' END AS 'Status',
        cl.client_created_at     AS 'Registered At'
    FROM clients cl
    INNER JOIN users u ON u.user_id = cl.user_id
    UNION ALL
    SELECT
        'Farmer',
        u.user_id,
        f.farmer_fullname,
        u.email,
        f.farmer_contact_number,
        f.farmer_address,
        CASE WHEN f.farmer_is_verified=1 THEN 'Approved' ELSE 'Pending' END,
        f.farmer_created_at
    FROM farmers f
    INNER JOIN users u ON u.user_id = f.user_id
    ORDER BY `Registered At` DESC", $conn);
$files[] = ['file' => 'all_accounts.csv', 'title' => 'All Accounts', 'rows' => $rows];

// ── 6. Crop Inventory (no date filter) ───────────────────────────────────────
$rows = rlWriteCsv($exportDir . '/crop_inventory.csv', "
    SELECT
        crop_id                AS 'Crop ID',
        crop_name              AS 'Crop Name',
        crop_quantity          AS 'Quantity',
        crop_unit              AS 'Unit',
        market_price_per_unit  AS 'Market Price/Unit (PHP)',
        crop_status            AS 'Status',
        created_at             AS 'Added At'
    FROM crops
    WHERE starting_price = 0
    ORDER BY crop_id ASC", $conn);
$files[] = ['file' => 'crop_inventory.csv', 'title' => 'Crop Inventory', 'rows' => $rows];

echo json_encode(['ok' => true, 'files' => $files, 'scope' => $scope, 'period' => $period],
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
