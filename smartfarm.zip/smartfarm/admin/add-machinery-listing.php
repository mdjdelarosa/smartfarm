<?php
$edit_rental_id = (int)($_GET['edit_rental_id'] ?? 0);
$is_edit_mode = $edit_rental_id > 0;
$edit_row = null;

if ($is_edit_mode) {
  $stmt = $conn->prepare("SELECT rental_id, equipment_name, owner_name, total_cost, rental_status, renter_name FROM machinery_rentals WHERE rental_id = ? LIMIT 1");
  if ($stmt) {
    $stmt->bind_param('i', $edit_rental_id);
    $stmt->execute();
    $edit_row = $stmt->get_result()->fetch_assoc();
    $stmt->close();
  }

  // Only allow edit if available (pending) and not rented
  if (!$edit_row || ($edit_row['rental_status'] !== 'pending') || trim((string)($edit_row['renter_name'] ?? '')) !== '') {
    $is_edit_mode = false;
    $edit_rental_id = 0;
    $edit_row = null;
    $edit_error = 'Only available machinery that is not rented can be edited.';
  }
}
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-add-machinery-listing" class="admin-section">
    <?php if (!empty($edit_error)): ?>
      <div style="color:#b91c1c;background:#fee2e2;border:1px solid #fca5a5;padding:1rem 1.5rem;margin:1.5rem 0;border-radius:8px;font-weight:600;">
        <?php echo htmlspecialchars($edit_error); ?>
      </div>
    <?php endif; ?>
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('rental-monitor')" data-tooltip="Back to monitor">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1><?php echo $is_edit_mode ? 'Edit Machinery Listing' : 'Add Machinery Listing'; ?></h1>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3><i class="fas <?php echo $is_edit_mode ? 'fa-pen' : 'fa-plus-circle'; ?>" style="color:#22c55e;margin-right:0.4rem;"></i><?php echo $is_edit_mode ? 'Update Machinery Listing' : 'New Machinery Listing'; ?></h3>
        <span class="card-subtitle"><?php echo $is_edit_mode ? 'Update the stock listing that can be reserved again' : 'Create a machinery entry that appears in Machinery Rental Monitor'; ?></span>
      </div>
    </div>

    <form class="schedule-form" method="post" action="admin_dashboard.php?section=rental-monitor" enctype="multipart/form-data">
      <input type="hidden" name="action" value="<?php echo $is_edit_mode ? 'edit_rental_listing' : 'add_rental_listing'; ?>">
      <?php if ($is_edit_mode): ?>
      <input type="hidden" name="rental_id" value="<?php echo (int)$edit_rental_id; ?>">
      <?php endif; ?>

      <div class="form-grid">
        <label class="form-field">Equipment Name
          <input type="text" name="equipment_name" placeholder="e.g. Four-Wheel Tractor" value="<?php echo htmlspecialchars((string)($edit_row['equipment_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>

        <label class="form-field">Owner
          <input type="text" name="owner_name" placeholder="e.g. Juan Dela Cruz" value="<?php echo htmlspecialchars((string)($edit_row['owner_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>

        <label class="form-field">Daily Rate (PHP)
          <input type="number" name="daily_rate" min="1" step="0.01" placeholder="e.g. 4000" value="<?php echo htmlspecialchars((string)($edit_row['total_cost'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required>
        </label>

        <label class="form-field">Status
          <select name="listing_status" required>
            <option value="available" <?php echo (!$is_edit_mode || (string)($edit_row['rental_status'] ?? '') === 'pending') ? 'selected' : ''; ?>>Available</option>
            <option value="in-rental" <?php echo (string)($edit_row['rental_status'] ?? '') === 'in-rental' ? 'selected' : ''; ?>>In Rental</option>
            <option value="maintenance" <?php echo (string)($edit_row['rental_status'] ?? '') === 'cancelled' ? 'selected' : ''; ?>>Maintenance</option>
          </select>
        </label>

        <!-- Machinery Image field removed as requested -->
      </div>

      <div class="form-actions-inline">
        <button type="button" class="btn-secondary" onclick="showSection('rental-monitor')">Cancel</button>
        <button type="submit" class="btn-primary"><?php echo $is_edit_mode ? 'Save Changes' : 'Add Machinery'; ?></button>
      </div>
    </form>
  </div>
</section>