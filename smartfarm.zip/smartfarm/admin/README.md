# Admin Dashboard - Modular Structure

This directory contains all the individual sections for the admin dashboard. Each file is a separate module that makes the code much cleaner and easier to maintain.

## Directory Structure

```
admin/
├── dashboard.php              # Main dashboard with stats and activity
├── verify-farmers.php         # View and approve/reject farmer accounts
├── verify-clients.php         # View and approve/reject client accounts
├── manage-accounts.php        # View all accounts (farmers, clients, admins)
├── add-account.php            # Add new account form
├── bidding-monitor.php        # Monitor bidding transactions
├── rental-monitor.php         # Monitor machinery rentals
├── manage-crops.php           # Manage crop types
├── distribute-seeds.php       # Distribute seeds to farmers
├── manage-machinery.php       # Manage agricultural machinery
├── forecasting.php            # Analytics and forecast data
├── reports.php                # Export reports and data
├── view-admin.php             # View current admin profile
├── manage-admins.php          # View and manage admin accounts
└── add-admin.php              # Add new admin account form
```

## How It Works

### Main File: `/admin_dashboard.php`

The main `admin_dashboard.php` file:
1. Handles all form submissions (approvals, rejections, account creation)
2. Calculates dashboard statistics
3. Loads the HTML template with navigation
4. **Includes the appropriate section file** based on the `?section=` GET parameter

### Section Files

Each section file in the `/admin/` directory contains:
- HTML for that specific section
- Any PHP queries needed for that section
- Table displays, forms, or analytics specific to that section

Example navigation link:
```html
<a href="admin_dashboard.php?section=verify-farmers" onclick="showSection('verify-farmers')">
  Verify Farmers
</a>
```

When you click the link, the page reloads with that section included.

## Adding a New Section

To add a new section:

1. **Create a new PHP file** in `admin/` directory (e.g., `my-new-section.php`)
2. **Wrap content in a section tag**:
   ```html
   <section id="section-my-new-section" class="admin-section">
     <div class="section-header">
       <h1>My New Section</h1>
     </div>
     <!-- Your content here -->
   </section>
   ```
3. **Add the nav link** in `admin_dashboard.php` with appropriate icon and label
4. **Add to valid_sections array** in `admin_dashboard.php`:
   ```php
   $valid_sections = [
     // ... other sections ...
     'my-new-section'
   ];
   ```

## File includes in admin_dashboard.php

```php
// Get section from URL
$section = $_GET['section'] ?? 'dashboard';

// Include appropriate section file
$section_file = __DIR__ . '/admin/' . $section . '.php';
if (file_exists($section_file)) {
    include $section_file;
}
```

## Benefits of This Structure

✅ **Cleaner Code** - Each section is in its own file (~100-200 lines vs 1300+ lines)
✅ **Easier Maintenance** - Find and edit specific sections quickly
✅ **Better Organization** - Clear directory structure
✅ **Reusability** - Can include sections on other pages if needed
✅ **Team Development** - Multiple people can work on different sections simultaneously
✅ **Faster Load Times** - Only the needed section is included per page load

## Notes

- All section files have access to `$conn` (database connection) from the main file
- All section files have access to dashboard stats: `$total_farmers`, `$total_clients`, `$total_admins`, etc.
- Form submissions are still handled in the main `admin_dashboard.php`
- JavaScript functions are available globally from the main file
