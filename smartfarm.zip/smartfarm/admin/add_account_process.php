<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json');

function send_json_response($status_code, array $payload) {
    http_response_code($status_code);
    echo json_encode($payload);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_json_response(405, ['success' => false, 'message' => 'Invalid request method']);
}

$session_role = $_SESSION['user_role'] ?? ($_SESSION['role'] ?? null);
$session_user_id = (int)($_SESSION['user_id'] ?? 0);

if ($session_user_id <= 0 || $session_role !== 'admin') {
    send_json_response(403, ['success' => false, 'message' => 'Unauthorized request']);
}

$admin_check = $conn->prepare("SELECT u.user_id FROM users u INNER JOIN admins a ON a.user_id = u.user_id WHERE u.user_id = ? AND u.role = 'admin' AND u.is_active = 1 LIMIT 1");
if (!$admin_check) {
    send_json_response(500, ['success' => false, 'message' => 'System error: Unable to verify admin session']);
}

$admin_check->bind_param('i', $session_user_id);
$admin_check->execute();
$admin_check->store_result();

if ($admin_check->num_rows === 0) {
    $admin_check->close();
    send_json_response(403, ['success' => false, 'message' => 'Unauthorized request']);
}

$admin_check->close();

$csrf_token = $_POST['csrf_token'] ?? '';
$session_csrf = $_SESSION['add_account_csrf'] ?? '';

if ($session_csrf === '' || $csrf_token === '' || !hash_equals($session_csrf, $csrf_token)) {
    send_json_response(403, ['success' => false, 'message' => 'Security token mismatch. Refresh the page and try again.']);
}

$role = sanitizeInput($_POST['role'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';

// Determine fullname based on role-specific field names
$fullname = '';
if (!empty($_POST['farmer_fullname'])) $fullname = sanitizeInput($_POST['farmer_fullname']);
elseif (!empty($_POST['client_fullname'])) $fullname = sanitizeInput($_POST['client_fullname']);
elseif (!empty($_POST['fullname'])) $fullname = sanitizeInput($_POST['fullname']);

// Contact number
$contact_number = sanitizeInput($_POST['farmer_contact_number'] ?? $_POST['client_contact_number'] ?? ($_POST['contact_number'] ?? ''));

// Addresses (matching schema: farmer_address, farm_address, client_address)
$farmer_address = sanitizeInput($_POST['farmer_address'] ?? '');
$farm_address = sanitizeInput($_POST['farm_address'] ?? '');
$client_address = sanitizeInput($_POST['client_address'] ?? '');

// Farm name (farmer only)
$farm_name = sanitizeInput($_POST['farmer_farm_name'] ?? '');

// Validation
$errors = [];
if (!in_array($role, ['admin', 'farmer', 'client'])) {
    $errors[] = 'Invalid account type';
}

if (empty($fullname) || strlen($fullname) < 3) {
    $errors[] = 'Full name must be at least 3 characters';
}

if (!isValidEmail($email)) {
    $errors[] = 'Invalid email format';
}

if (!isStrongPassword($password)) {
    $errors[] = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character';
}

if ($password !== $confirm_password) {
    $errors[] = 'Passwords do not match';
}

// Role-specific required fields
if ($role === 'farmer') {
    if (empty($contact_number)) $errors[] = 'Farmer contact number is required';
    if (empty($farmer_address)) $errors[] = 'Farmer home address is required';
    if (empty($farm_address)) $errors[] = 'Farm address is required';
    if (empty($farm_name)) $errors[] = 'Farm name is required';
}

if ($role === 'client') {
    if (empty($contact_number)) $errors[] = 'Client contact number is required';
    if (empty($client_address)) $errors[] = 'Client home address is required';
}

if (!empty($errors)) {
    send_json_response(422, ['success' => false, 'message' => implode(', ', $errors)]);
}

// All good — insert into users and role table
try {
    $hashed = hashPassword($password);

    // Start transaction and check for duplicate email with a lock
    $conn->begin_transaction();
    $chk = $conn->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1 FOR UPDATE');
    if (!$chk) throw new Exception('Prepare check failed: ' . $conn->error);
    $chk->bind_param('s', $email);
    $chk->execute();
    $chk->store_result();
    if ($chk->num_rows > 0) {
        $chk->close();
        throw new Exception('Email already registered');
    }
    $chk->close();

    $stmt = $conn->prepare('INSERT INTO users (email, password, role, is_active) VALUES (?, ?, ?, 1)');
    if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
    $stmt->bind_param('sss', $email, $hashed, $role);
    if (!$stmt->execute()) throw new Exception('Insert users failed: ' . $stmt->error);

    $user_id = $stmt->insert_id;
    $stmt->close();

    if ($role === 'admin') {
        $stmt = $conn->prepare('INSERT INTO admins (user_id, fullname) VALUES (?, ?)');
        $stmt->bind_param('is', $user_id, $fullname);
        if (!$stmt->execute()) throw new Exception('Insert admins failed: ' . $stmt->error);
        $stmt->close();
    } elseif ($role === 'farmer') {
        // Auto-approve farmer when admin creates account
        $verified_status = 'approved';
        $is_verified = 1;
        
        $stmt = $conn->prepare('INSERT INTO farmers (
            user_id, farmer_fullname, farmer_contact_number, farmer_farm_name,
            farmer_address, farm_address, farmer_id_verification_status, farmer_is_verified
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');

        if (!$stmt) throw new Exception('Prepare farmers failed: ' . $conn->error);

        $stmt->bind_param(
            'issssssi',
            $user_id,
            $fullname,
            $contact_number,
            $farm_name,
            $farmer_address,
            $farm_address,
            $verified_status,
            $is_verified
        );

        if (!$stmt->execute()) throw new Exception('Insert farmers failed: ' . $stmt->error);
        $stmt->close();

    } elseif ($role === 'client') {
        // Auto-approve client when admin creates account
        $verified_status = 'approved';
        $is_verified = 1;
        
        $stmt = $conn->prepare('INSERT INTO clients (
            user_id, client_fullname, client_contact_number, client_address,
            client_id_verification_status, client_is_verified
        ) VALUES (?, ?, ?, ?, ?, ?)');

        if (!$stmt) throw new Exception('Prepare clients failed: ' . $conn->error);

        $stmt->bind_param(
            'issssi',
            $user_id,
            $fullname,
            $contact_number,
            $client_address,
            $verified_status,
            $is_verified
        );

        if (!$stmt->execute()) throw new Exception('Insert clients failed: ' . $stmt->error);
        $stmt->close();
    }

    $conn->commit();

    send_json_response(200, ['success' => true, 'message' => 'Account created successfully and auto-approved', 'user_id' => $user_id]);

} catch (Exception $e) {
    $conn->rollback();
    send_json_response(500, ['success' => false, 'message' => 'System error: ' . $e->getMessage()]);
}

?>
