<!-- Add New Account Section -->
<?php
require_once __DIR__ . '/../maps_helper.php';

if (empty($_SESSION['add_account_csrf'])) {
  $_SESSION['add_account_csrf'] = generateSessionToken();
}

$add_account_csrf = $_SESSION['add_account_csrf'];
$requested_role = $_GET['role'] ?? '';
$requested_from = $_GET['from'] ?? 'dashboard';

$allowed_roles = ['farmer', 'client', 'admin'];
$allowed_from_sections = ['dashboard', 'verify-farmers', 'verify-clients', 'manage-admins'];

$prefilled_role = in_array($requested_role, $allowed_roles, true) ? $requested_role : '';
$back_section = in_array($requested_from, $allowed_from_sections, true) ? $requested_from : 'dashboard';
?>
<section id="section-add-account" class="admin-section">
  <div class="section-header">
    <div style="display: flex; align-items: center; gap: 1rem;">
      <button type="button" class="btn-tertiary" onclick="showSection('<?php echo htmlspecialchars($back_section); ?>')" data-tooltip="Back to List">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1>Add New Account</h1>
    </div>
  </div>

  <div class="form-container" style="width:100%;margin:0;">
    <form class="admin-form" method="post" action="admin/add_account_process.php" enctype="multipart/form-data">
      <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($add_account_csrf); ?>">
      <div class="form-group">
        <label>Account Type</label>
        <select name="role" required>
          <option value="">Select Account Type</option>
          <option value="farmer" <?php echo $prefilled_role === 'farmer' ? 'selected' : ''; ?>>Farmer</option>
          <option value="client" <?php echo $prefilled_role === 'client' ? 'selected' : ''; ?>>Client</option>
          <option value="admin" <?php echo $prefilled_role === 'admin' ? 'selected' : ''; ?>>Admin</option>
        </select>
      </div>

      <div id="fields-wrapper">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name</label>
          <input id="input-fullname" type="text" name="fullname" placeholder="Enter full name" required>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" placeholder="Enter email" required>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Password</label>
          <input type="password" name="password" placeholder="Enter password" required>
        </div>
        <div class="form-group">
          <label>Confirm Password</label>
          <input type="password" name="confirm_password" placeholder="Confirm password" required>
        </div>
      </div>

      <div id="address-section" style="display:none;">
        <div class="form-row">
          <div class="form-group">
            <label>Contact Number</label>
            <input id="input-contact" type="text" placeholder="Enter contact number" required>
          </div>
        </div>
        
        <!-- Home Address (single field) -->
        <div class="form-row">
          <div class="form-group">
            <label>Home Address</label>
            <input id="input-home-address" type="text" placeholder="Full home address (street, barangay, municipality)" required>
          </div>
        </div>
      </div>

      <div id="farmer-specific" style="display:none;">
        <div class="form-row">
          <div class="form-group">
            <label>Farm Name</label>
            <input id="input-farm-name" type="text" name="farmer_farm_name" placeholder="Enter farm name" required>
          </div>
        </div>
        
        <!-- Farm Address (single field) -->
        <div class="form-row">
          <div class="form-group">
            <label>Farm Address</label>
            <input id="input-farm-address" type="text" placeholder="Full farm address (street, barangay, municipality)" required>
          </div>
        </div>
      </div>

      </div>

      <div class="form-actions">
        <button type="reset" class="btn-secondary" data-tooltip="Clear Form"><i class="fas fa-redo"></i></button>
        <button type="submit" class="btn-primary" data-tooltip="Create Account"><i class="fas fa-check"></i></button>
      </div>
    </form>
  </div>
</section>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<script>
// Show/hide fields based on selected role
const roleSelect = document.querySelector('select[name="role"]');
const fieldsWrapper = document.getElementById('fields-wrapper');
const addressSection = document.getElementById('address-section');
const farmerBlock = document.getElementById('farmer-specific');
const idBlock = document.getElementById('id-upload');

function setFieldsDisabled(disabled) {
  const inputs = fieldsWrapper.querySelectorAll('input, select, textarea, button');
  inputs.forEach(i => {
    // keep the form actions buttons enabled (they are inside fields-wrapper)
    if (i.type === 'submit' || i.type === 'reset') return;
    i.disabled = disabled;
  });
}

function onRoleChange(e) {
  const role = e.target.value;

  if (!role) {
    fieldsWrapper.style.display = 'none';
    setFieldsDisabled(true);
    addressSection.style.display = 'none';
    farmerBlock.style.display = 'none';
    if (idBlock) idBlock.style.display = 'none';
    return;
  }

  fieldsWrapper.style.display = '';
  setFieldsDisabled(false);

  if (role === 'farmer') {
    addressSection.style.display = 'block';
    farmerBlock.style.display = 'block';
    
    document.getElementById('input-fullname').name = 'farmer_fullname';
    document.getElementById('input-contact').name = 'farmer_contact_number';
    document.getElementById('input-home-address').name = 'farmer_address';
    document.getElementById('input-farm-address').name = 'farm_address';
  } else if (role === 'client') {
    addressSection.style.display = 'block';
    farmerBlock.style.display = 'none';
    
    document.getElementById('input-fullname').name = 'client_fullname';
    document.getElementById('input-contact').name = 'client_contact_number';
    document.getElementById('input-home-address').name = 'client_address';
  } else {
    addressSection.style.display = 'none';
    farmerBlock.style.display = 'none';
    
    document.getElementById('input-fullname').name = 'fullname';
    document.getElementById('input-contact').removeAttribute('name');
    document.getElementById('input-home-address').removeAttribute('name');
    document.getElementById('input-farm-name').removeAttribute('name');
    document.getElementById('input-farm-address').removeAttribute('name');
  }
}

roleSelect.addEventListener('change', onRoleChange);

// Initialize
onRoleChange({ target: roleSelect });

// Inline messages container
const msgBox = document.createElement('div');
msgBox.id = 'addAccountMsg';
msgBox.style.margin = '12px 0';
document.querySelector('.form-container').prepend(msgBox);

// AJAX submit with inline validation
const addForm = document.querySelector('.admin-form');
const submitBtn = addForm.querySelector('button[type="submit"]');
addForm.addEventListener('submit', function(e){
  e.preventDefault();
  msgBox.innerHTML = '';

  const role = roleSelect.value;
  if (!role) return msgBox.innerHTML = '<div class="alert-error">Please select account type first.</div>';

  // Basic client-side validation
  const pwd = addForm.querySelector('input[name="password"]').value || '';
  const cpwd = addForm.querySelector('input[name="confirm_password"]').value || '';
  if (!pwd || !cpwd) return msgBox.innerHTML = '<div class="alert-error">Password fields required.</div>';
  if (pwd !== cpwd) return msgBox.innerHTML = '<div class="alert-error">Passwords do not match.</div>';

  const fd = new FormData(addForm);
  submitBtn.disabled = true;

  fetch(addForm.action, {
    method: 'POST',
    headers: {
      'X-Requested-With': 'XMLHttpRequest'
    },
    body: fd
  })
    .then(res => res.json())
    .then(data => {
      submitBtn.disabled = false;
      if (data.success) {
        msgBox.innerHTML = '<div class="alert-success">' + (data.message || 'Account created') + '</div>';
        addForm.reset();
        onRoleChange({ target: roleSelect });
      } else {
        msgBox.innerHTML = '<div class="alert-error">' + (data.message || 'Error') + '</div>';
      }
    })
    .catch(err => {
      submitBtn.disabled = false;
      msgBox.innerHTML = '<div class="alert-error">Network or server error</div>';
      console.error(err);
    });
});
</script>
