<?php
// admin/export_livestock_reservations.php
// Generates a CSV for livestock reservation/transaction records
require_once __DIR__ . '/../config.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="livestock_reservations.csv"');

$out = fopen('php://output', 'w');

// Write header
fputcsv($out, [
    'reservation_id', 'product_id', 'client_id', 'quantity', 'total_price', 'status', 'payment_status', 'reserved_at', 'updated_at', 'remarks'
]);

$q = $conn->query("SELECT reservation_id, product_id, client_id, quantity, total_price, status, payment_status, reserved_at, updated_at, remarks FROM livestock_reservations");
if ($q) {
    while ($row = $q->fetch_assoc()) {
        fputcsv($out, $row);
    }
}
fclose($out);
exit;
