<?php
if (!function_exists('txPreviewEsc')) {
  function txPreviewEsc(string $value): string {
    return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
  }
}

if (!function_exists('txPreviewCsvEsc')) {
  function txPreviewCsvEsc($value): string {
    if (is_null($value)) {
      return '';
    }
    if (is_bool($value)) {
      return $value ? '1' : '0';
    }
    return (string)$value;
  }
}

if (!function_exists('txPreviewTableExists')) {
  function txPreviewTableExists(mysqli $conn, string $table): bool {
    $safe = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '" . $safe . "'");
    return (bool)($result && $result->num_rows > 0);
  }
}

if (!function_exists('txPreviewMoney')) {
  function txPreviewMoney($value): string {
    return 'PHP ' . number_format((float)$value, 2);
  }
}

if (!function_exists('txPreviewBuildBidding')) {
  function txPreviewBuildBidding(mysqli $conn): array {
    $columns = [
      'Bid Ref', 'Crop', 'Farmer', 'Top Client', 'Starting Price', 'Highest Bid',
      'Bid Count', 'Quantity', 'Unit', 'Status', 'Bidding End', 'Payment Status', 'Created At'
    ];

    if (!txPreviewTableExists($conn, 'crops')) {
      return [$columns, []];
    }

    $sql = "SELECT
              c.crop_id,
              c.crop_name,
              c.crop_quantity,
              c.crop_unit,
              c.starting_price,
              c.crop_status,
              c.payment_status,
              c.bidding_end_date,
              c.created_at,
              COALESCE(f.farmer_fullname, 'Admin Entry') AS farmer_name,
              (
                SELECT MAX(b2.bid_amount)
                FROM bids b2
                WHERE b2.crop_id = c.crop_id
              ) AS highest_bid,
              (
                SELECT COUNT(*)
                FROM bids b3
                WHERE b3.crop_id = c.crop_id
              ) AS bid_count,
              (
                SELECT cl.client_fullname
                FROM bids b4
                INNER JOIN clients cl ON cl.client_id = b4.client_id
                WHERE b4.crop_id = c.crop_id
                ORDER BY b4.bid_amount DESC, b4.created_at ASC, b4.bid_id ASC
                LIMIT 1
              ) AS top_client
            FROM crops c
            LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
            WHERE c.starting_price > 0
            ORDER BY c.created_at DESC, c.crop_id DESC";

    $result = $conn->query($sql);
    $rows = [];
    if ($result) {
      while ($row = $result->fetch_assoc()) {
        $bid_id = (int)($row['bid_id'] ?? 0);
        $crop_id = (int)($row['crop_id'] ?? 0);
        $bid_ref = $bid_id > 0
          ? '#BID' . str_pad((string)$bid_id, 4, '0', STR_PAD_LEFT)
          : '#BIDC' . str_pad((string)$crop_id, 4, '0', STR_PAD_LEFT);
        $status = (string)($row['crop_status'] ?? '');
        $statusMap = [
          'available' => 'Ongoing/Available',
          'sold' => 'Sold',
          'expired' => 'Ended',
          'claimed' => 'Claimed',
          'returned' => 'Returned'
        ];

        $rows[] = [
          $bid_ref,
          (string)($row['crop_name'] ?? ''),
          (string)($row['farmer_name'] ?? 'Admin Entry'),
          (string)($row['top_client'] ?? '-'),
          txPreviewMoney($row['starting_price'] ?? 0),
          txPreviewMoney(($row['highest_bid'] ?? null) === null ? ($row['starting_price'] ?? 0) : $row['highest_bid']),
          (string)((int)($row['bid_count'] ?? 0)),
          number_format((float)($row['crop_quantity'] ?? 0), 2),
          (string)($row['crop_unit'] ?? ''),
          (string)($statusMap[$status] ?? ucfirst($status)),
          (string)($row['bidding_end_date'] ?? ''),
          strtoupper((string)($row['payment_status'] ?? 'unpaid')),
          (string)($row['created_at'] ?? '')
        ];
      }
    }

    return [$columns, $rows];
  }
}

if (!function_exists('txPreviewBuildRentals')) {
  function txPreviewBuildRentals(mysqli $conn): array {
    $columns = [
      'Rental ID', 'Code', 'Equipment', 'Owner', 'Renter', 'Start Date', 'End Date',
      'Total Cost', 'Rental Status', 'Payment Status', 'Payment Marked At'
    ];

    if (!txPreviewTableExists($conn, 'machinery_rentals')) {
      return [$columns, []];
    }

    $sql = "SELECT rental_id, rental_code, equipment_name, owner_name, renter_name,
                   start_date, end_date, total_cost, rental_status, payment_status, payment_marked_at
            FROM machinery_rentals
            ORDER BY start_date DESC, rental_id DESC";

    $result = $conn->query($sql);
    $rows = [];
    if ($result) {
      while ($row = $result->fetch_assoc()) {
        $rows[] = [
          '#REN' . str_pad((string)($row['rental_id'] ?? 0), 3, '0', STR_PAD_LEFT),
          '#REN' . str_pad((string)($row['rental_id'] ?? 0), 3, '0', STR_PAD_LEFT),
          (string)($row['equipment_name'] ?? ''),
          (string)($row['owner_name'] ?? ''),
          (string)($row['renter_name'] ?? ''),
          (string)($row['start_date'] ?? ''),
          (string)($row['end_date'] ?? ''),
          txPreviewMoney($row['total_cost'] ?? 0),
          strtoupper((string)($row['rental_status'] ?? 'pending')),
          strtoupper((string)($row['payment_status'] ?? 'unpaid')),
          (string)($row['payment_marked_at'] ?? '')
        ];
      }
    }

    return [$columns, $rows];
  }
}

if (!function_exists('txPreviewBuildSeeds')) {
  function txPreviewBuildSeeds(mysqli $conn): array {
    $columns = [
      'Record Type', 'Reference', 'Seed', 'Farmer', 'Quantity', 'Unit',
      'Distribution Date', 'Status', 'Notes', 'Available Stock', 'Low Stock Threshold'
    ];

    if (!txPreviewTableExists($conn, 'seed_inventory')) {
      return [$columns, []];
    }

    $hasDistributions = txPreviewTableExists($conn, 'seed_distributions');

    $sql = "SELECT *
            FROM (
              SELECT
                'stock' AS record_type,
                0 AS record_rank,
                si.seed_id,
                NULL AS distribution_id,
                NULL AS farmer_name,
                si.seed_name,
                si.seed_unit,
                si.available_quantity AS quantity_distributed,
                si.created_at AS distribution_date,
                'stock' AS status,
                CASE
                  WHEN si.available_quantity <= 0 THEN 'Out of stock'
                  WHEN si.available_quantity <= si.low_stock_threshold THEN 'Low stock'
                  ELSE 'Unassigned stock'
                END AS notes,
                si.low_stock_threshold,
                si.available_quantity
              FROM seed_inventory si
              WHERE si.available_quantity > 0

              UNION ALL

              SELECT
                'distribution' AS record_type,
                1 AS record_rank,
                sd.seed_id,
                sd.distribution_id,
                COALESCE(f.farmer_fullname, '') AS farmer_name,
                si.seed_name,
                si.seed_unit,
                sd.quantity_distributed,
                sd.distribution_date,
                sd.status,
                sd.notes,
                si.low_stock_threshold,
                si.available_quantity
              FROM seed_distributions sd
              LEFT JOIN seed_inventory si ON sd.seed_id = si.seed_id
              LEFT JOIN farmers f ON sd.farmer_id = f.farmer_id
            ) AS unified
            ORDER BY seed_name ASC, record_rank ASC, distribution_date DESC, distribution_id DESC";

    if (!$hasDistributions) {
      $sql = "SELECT
                'stock' AS record_type,
                si.seed_id,
                NULL AS distribution_id,
                NULL AS farmer_name,
                si.seed_name,
                si.seed_unit,
                si.available_quantity AS quantity_distributed,
                si.created_at AS distribution_date,
                'stock' AS status,
                CASE
                  WHEN si.available_quantity <= 0 THEN 'Out of stock'
                  WHEN si.available_quantity <= si.low_stock_threshold THEN 'Low stock'
                  ELSE 'Unassigned stock'
                END AS notes,
                si.low_stock_threshold,
                si.available_quantity
              FROM seed_inventory si
              WHERE si.available_quantity > 0
              ORDER BY si.seed_name ASC";
    }

    $result = $conn->query($sql);
    $records = [];
    if ($result) {
      while ($row = $result->fetch_assoc()) {
        $records[] = $row;
      }
    }

    $rows = [];
    $reserved_reference_ids = [];
    $used_reference_ids = [];
    $max_reference_id = 0;

    foreach ($records as $record) {
      $distribution_id = (int)($record['distribution_id'] ?? 0);
      if ($distribution_id > 0) {
        $reserved_reference_ids[$distribution_id] = true;
        if ($distribution_id > $max_reference_id) {
          $max_reference_id = $distribution_id;
        }
      }
    }

    $next_generated_reference_id = $max_reference_id + 1;

    foreach ($records as $record) {
      $isStock = ((string)($record['record_type'] ?? 'distribution') === 'stock');
      $candidate_id = $isStock
        ? (int)($record['seed_id'] ?? 0)
        : (int)($record['distribution_id'] ?? 0);

      $can_keep_original = !$isStock
        && $candidate_id > 0
        && !isset($used_reference_ids[$candidate_id]);

      if (!$can_keep_original) {
        if ($isStock && $candidate_id > 0 && !isset($reserved_reference_ids[$candidate_id]) && !isset($used_reference_ids[$candidate_id])) {
          // Stock rows can keep seed IDs only if they do not collide with reserved distribution IDs.
        } else {
          while (isset($used_reference_ids[$next_generated_reference_id]) || isset($reserved_reference_ids[$next_generated_reference_id])) {
            $next_generated_reference_id++;
          }
          $candidate_id = $next_generated_reference_id;
          $next_generated_reference_id++;
        }
      }

      if ($candidate_id <= 0) {
        while (isset($used_reference_ids[$next_generated_reference_id]) || isset($reserved_reference_ids[$next_generated_reference_id])) {
          $next_generated_reference_id++;
        }
        $candidate_id = $next_generated_reference_id;
        $next_generated_reference_id++;
      }

      $used_reference_ids[$candidate_id] = true;
      $reference = '#DIST' . str_pad((string)$candidate_id, 4, '0', STR_PAD_LEFT);

      $rows[] = [
        $isStock ? 'Stock' : 'Distribution',
        $reference,
        (string)($record['seed_name'] ?? ''),
        (string)($record['farmer_name'] ?? '-'),
        number_format((float)($record['quantity_distributed'] ?? 0), 2),
        (string)($record['seed_unit'] ?? ''),
        (string)($record['distribution_date'] ?? ''),
        strtoupper((string)($record['status'] ?? '')),
        (string)($record['notes'] ?? ''),
        number_format((float)($record['available_quantity'] ?? 0), 2),
        number_format((float)($record['low_stock_threshold'] ?? 0), 2)
      ];
    }

    return [$columns, $rows];
  }
}

if (!function_exists('txPreviewBuildLivestock')) {
  function txPreviewNormalizeLivestockName(string $productName): string {
    return trim(preg_replace('/\s+/', ' ', $productName));
  }

  function txPreviewNormalizeLivestockUnit(string $unit, string $productType = ''): string {
    $normalized = strtolower(trim(preg_replace('/\s+/', ' ', $unit)));
    $defaults = [
      'livestock' => 'head',
      'dairy products' => 'liter',
      'farm products' => 'kg',
      'supplies' => 'pack'
    ];
    $default = $defaults[strtolower(trim($productType))] ?? 'box';
    $aliases = [
      'head' => 'head', 'heads' => 'head',
      'kg' => 'kg', 'kilogram' => 'kg', 'kilograms' => 'kg',
      'g' => 'g', 'gram' => 'g', 'grams' => 'g',
      'liter' => 'liter', 'liters' => 'liter', 'litre' => 'liter', 'litres' => 'liter',
      'bottle' => 'bottle', 'bottles' => 'bottle',
      'tray' => 'tray', 'trays' => 'tray',
      'pack' => 'pack', 'packs' => 'pack',
      'sack' => 'sack', 'sacks' => 'sack',
      'box' => 'box', 'boxes' => 'box',
      'dozen' => 'dozen', 'dozens' => 'dozen'
    ];

    if ($normalized === '' || in_array($normalized, ['unit', 'piece', 'pieces', 'pc', 'pcs'], true)) {
      return $default;
    }

    return $aliases[$normalized] ?? $default;
  }

  function txPreviewBuildLivestock(mysqli $conn): array {
    $columns = [
      'Record ID', 'Product', 'Type', 'Client', 'Quantity', 'Unit', 'Pickup Date',
      'Total Amount', 'Status', 'Payment Status', 'Client Note', 'Admin Note', 'Requested At'
    ];

    if (!txPreviewTableExists($conn, 'livestock_products')) {
      return [$columns, []];
    }

    $sql = "SELECT
              'reservation' AS record_type,
              r.reservation_id,
              lp.product_id,
              COALESCE(r.quantity, 0) AS quantity,
              COALESCE(r.total_price, COALESCE(r.quantity, 0) * lp.price) AS total_price,
              r.preferred_date,
              COALESCE(r.notes, '') AS notes,
              COALESCE(r.status, 'pending') AS status,
              COALESCE(r.admin_notes, '') AS admin_notes,
              COALESCE(r.created_at, lp.created_at) AS created_at,
              COALESCE(r.payment_status, 'unpaid') AS payment_status,
              lp.product_name,
              lp.product_type,
              lp.unit,
              COALESCE(c.client_fullname, '') AS client_fullname
            FROM livestock_reservations r
            INNER JOIN livestock_products lp ON lp.product_id = r.product_id
            LEFT JOIN clients c ON c.client_id = r.client_id

            UNION ALL

            SELECT
              'stock' AS record_type,
              NULL AS reservation_id,
              lp.product_id,
              GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) AS quantity,
              GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) * lp.price AS total_price,
              NULL AS preferred_date,
              CASE
                WHEN lp.status = 'Inactive' THEN 'Inactive listing'
                WHEN lp.status = 'Out of Stock' THEN 'Out of stock listing'
                ELSE 'Unordered stock'
              END AS notes,
              CASE
                WHEN lp.status = 'Inactive' THEN 'inactive'
                WHEN lp.status = 'Out of Stock' OR GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) <= 0 THEN 'out-stock'
                ELSE 'listed'
              END AS status,
              '' AS admin_notes,
              lp.created_at AS created_at,
              'na' AS payment_status,
              lp.product_name,
              lp.product_type,
              lp.unit,
              '' AS client_fullname
            FROM livestock_products lp
            LEFT JOIN (
              SELECT product_id, SUM(quantity) AS active_reserved_qty
              FROM livestock_reservations
              WHERE status IN ('pending', 'confirmed', 'ready')
              GROUP BY product_id
            ) a ON a.product_id = lp.product_id
            WHERE GREATEST(lp.stock - COALESCE(a.active_reserved_qty, 0), 0) > 0

            ORDER BY created_at DESC";

    $result = $conn->query($sql);
    $rows = [];
    if ($result) {
      while ($row = $result->fetch_assoc()) {
        $hasReservation = (int)($row['reservation_id'] ?? 0) > 0;
        $recordId = $hasReservation
          ? '#RES' . str_pad((string)($row['reservation_id'] ?? 0), 3, '0', STR_PAD_LEFT)
          : '#PRD' . str_pad((string)($row['product_id'] ?? 0), 3, '0', STR_PAD_LEFT);

        $rows[] = [
          $recordId,
          txPreviewNormalizeLivestockName((string)($row['product_name'] ?? '')),
          (string)($row['product_type'] ?? ''),
          (string)($row['client_fullname'] ?? ''),
          (string)((int)($row['quantity'] ?? 0)),
          txPreviewNormalizeLivestockUnit((string)($row['unit'] ?? ''), (string)($row['product_type'] ?? '')),
          (string)($row['preferred_date'] ?? ''),
          txPreviewMoney($row['total_price'] ?? 0),
          strtoupper((string)($row['status'] ?? '')),
          strtoupper((string)($row['payment_status'] ?? 'na')),
          (string)($row['notes'] ?? ''),
          (string)($row['admin_notes'] ?? ''),
          (string)($row['created_at'] ?? '')
        ];
      }
    }

    return [$columns, $rows];
  }
}

$type = strtolower(trim((string)($_GET['type'] ?? '')));
$from = trim((string)($_GET['from'] ?? ''));
$download = isset($_GET['download']) && (string)$_GET['download'] === '1';

$types = [
  'bidding' => ['title' => 'Bidding Transactions Report', 'back_section' => 'bidding-monitor'],
  'rentals' => ['title' => 'Machinery Rental Transactions Report', 'back_section' => 'rental-monitor'],
  'seeds' => ['title' => 'Seed Distribution Report', 'back_section' => 'distribute-seeds'],
  'livestock' => ['title' => 'Livestock Reservation Report', 'back_section' => 'manage-livestock-products']
];

if (!isset($types[$type])) {
  $type = 'bidding';
}

if ($from === '') {
  $from = $types[$type]['back_section'];
}

switch ($type) {
  case 'bidding':
    [$columns, $rows] = txPreviewBuildBidding($conn);
    break;
  case 'rentals':
    [$columns, $rows] = txPreviewBuildRentals($conn);
    break;
  case 'seeds':
    [$columns, $rows] = txPreviewBuildSeeds($conn);
    break;
  case 'livestock':
    [$columns, $rows] = txPreviewBuildLivestock($conn);
    break;
  default:
    $columns = [];
    $rows = [];
}

$title = $types[$type]['title'];
$backSection = $types[$type]['back_section'];
$totalRows = count($rows);
$generatedAt = date('Y-m-d H:i:s');

if ($download) {
  $filename = $type . '_transactions_' . date('Ymd_His') . '.csv';
  header('Content-Type: text/csv; charset=UTF-8');
  header('Content-Disposition: attachment; filename="' . $filename . '"');

  $output = fopen('php://output', 'w');
  if ($output !== false) {
    fputcsv($output, [$title]);
    fputcsv($output, []);
    fputcsv($output, $columns);
    foreach ($rows as $row) {
      $csvRow = [];
      foreach ($row as $value) {
        $csvRow[] = txPreviewCsvEsc($value);
      }
      fputcsv($output, $csvRow);
    }
    fputcsv($output, []);
    fputcsv($output, ['File', $type . '_transactions.csv', 'Rows', (string)$totalRows, 'Generated', $generatedAt]);
    fclose($output);
  }
  exit;
}
?>

<style>
  .tx-export-header {
    margin-bottom: 10px;
  }

  .tx-export-header-main {
    display: flex;
    align-items: flex-start;
    gap: 12px;
  }

  .tx-export-back-btn {
    margin-top: 2px;
  }

  .tx-export-subtitle {
    margin: 0;
    color: #76877c;
    font-size: 0.95rem;
  }

  .tx-export-card {
    border: 1px solid #d6e6d9;
    border-radius: 14px;
    background: linear-gradient(140deg, #f7fcf8 0%, #f3f8f4 100%);
    padding: 14px;
    margin-bottom: 14px;
  }

  .tx-export-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    flex-wrap: wrap;
  }

  .tx-export-stat {
            $productName = txPreviewNormalizeLivestockName((string)($row['product_name'] ?? ''));
            $productUnit = txPreviewNormalizeLivestockUnit((string)($row['unit'] ?? ''), (string)($row['product_type'] ?? ''));

            $rows[] = [
              $recordId,
              $productName,
              (string)($row['product_type'] ?? ''),
              (string)($row['client_fullname'] ?? ''),
              (string)((int)($row['quantity'] ?? 0)),
              $productUnit,
              (string)($row['preferred_date'] ?? ''),
              txPreviewMoney($row['total_price'] ?? 0),
              strtoupper((string)($row['status'] ?? '')),
              strtoupper((string)($row['payment_status'] ?? 'na')),
              (string)($row['notes'] ?? ''),
              (string)($row['admin_notes'] ?? ''),
              (string)($row['created_at'] ?? '')
  }

  .tx-export-table-wrap {
    width: 100%;
    overflow: auto;
    border: 1px solid #d6e6d9;
    border-radius: 12px;
    background: #fff;
    max-height: calc(100vh - 295px);
  }

  .tx-export-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 980px;
    font-size: 0.86rem;
  }

  .tx-export-table thead th {
    position: sticky;
    top: 0;
    background: #edf6ef;
    color: #2e4f39;
    font-weight: 700;
    border-bottom: 1px solid #d9e8dc;
    text-align: left;
    padding: 9px 10px;
    white-space: nowrap;
    z-index: 1;
  }

  .tx-export-table tbody td {
    padding: 8px 10px;
    border-bottom: 1px solid #edf3ee;
    color: #32473a;
    white-space: nowrap;
  }

  .tx-export-table tbody tr:nth-child(even) {
    background: #fbfdfb;
  }

  .tx-export-empty {
    padding: 22px;
    text-align: center;
    color: #74857a;
  }

  .tx-export-print-meta {
    display: none;
    font-size: 12px;
    color: #556b5d;
    margin: 0 0 8px;
  }

  .tx-export-print-title {
    display: none;
    font-size: 24px;
    line-height: 1.2;
    font-weight: 700;
    color: #1f4d34;
    margin: 0 0 6px;
  }

  @media print {
    .admin-sidebar,
    .admin-top-nav,
    .btn-tertiary,
    .tx-export-card,
    .tx-export-subtitle,
    .tx-export-empty,
    .alert-message {
      display: none !important;
    }

    .admin-main {
      padding: 0 !important;
      margin: 0 !important;
      background: #fff !important;
    }

    .admin-section {
      padding: 0 !important;
      margin: 0 !important;
    }

    .section-header {
      display: none !important;
    }

    .tx-export-print-meta {
      display: block;
    }

    .tx-export-print-title {
      display: block;
    }

    .tx-export-table-wrap {
      border: 0;
      border-radius: 0;
      max-height: none;
      overflow: visible;
    }

    .tx-export-table {
      min-width: 0;
      width: 100%;
      font-size: 10px;
    }

    .tx-export-table thead th,
    .tx-export-table tbody td {
      white-space: normal;
      word-break: break-word;
      padding: 5px 6px;
    }

    .tx-export-table thead th {
      position: static;
    }
  }
</style>

<section id="section-transaction-export-preview" class="admin-section">
  <div class="section-header tx-export-header">
    <div class="tx-export-header-main">
      <button class="btn-tertiary tx-export-back-btn" type="button" onclick="window.location.href='admin_dashboard.php?section=<?php echo txPreviewEsc($backSection); ?>'">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1><?php echo txPreviewEsc($title); ?></h1>
        <p class="tx-export-subtitle">Review records first, then print or download CSV.</p>
      </div>
    </div>
  </div>

  <div class="tx-export-card">
    <div class="tx-export-actions">
      <div class="tx-export-stat">Rows: <?php echo number_format($totalRows); ?> | Generated: <?php echo txPreviewEsc(date('Y-m-d H:i:s')); ?></div>
      <div class="tx-export-buttons">
        <a class="btn-secondary" href="admin_dashboard.php?section=transaction-export-preview&type=<?php echo txPreviewEsc($type); ?>&from=<?php echo txPreviewEsc($from); ?>&download=1">
          <i class="fas fa-download"></i> Download CSV
        </a>
        <button type="button" class="btn-primary" onclick="window.print()">
          <i class="fas fa-print"></i> Print
        </button>
      </div>
    </div>
  </div>

  <h2 class="tx-export-print-title"><?php echo txPreviewEsc($title); ?></h2>

  <?php if ($totalRows === 0): ?>
    <div class="tx-export-empty">No transaction records found for this export.</div>
  <?php else: ?>
    <div class="tx-export-table-wrap">
      <table class="tx-export-table">
        <thead>
          <tr>
            <?php foreach ($columns as $column): ?>
              <th><?php echo txPreviewEsc((string)$column); ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <?php foreach ($row as $cell): ?>
                <td><?php echo txPreviewEsc((string)$cell); ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>

  <p class="tx-export-print-meta">
    File: <?php echo txPreviewEsc($type . '_transactions.csv'); ?> |
    Rows: <?php echo number_format($totalRows); ?> |
    Generated: <?php echo txPreviewEsc($generatedAt); ?>
  </p>
</section>
