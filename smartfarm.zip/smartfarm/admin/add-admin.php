<!-- Add Admin Account Section -->
<section id="section-add-admin" class="admin-section">
  <div class="section-header">
    <h1>Add New Admin Account</h1>
  </div>
  <div class="form-container" style="width:100%;margin:0;">
    <form class="admin-form" method="post">
      <input type="hidden" name="action" value="create_admin">
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" name="fullname" placeholder="Enter admin name" required>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" placeholder="Enter admin email" required>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="Min 8 chars, uppercase, lowercase, number, special char" required>
      </div>
      <div class="form-group">
        <label>Confirm Password</label>
        <input type="password" name="confirm_password" placeholder="Confirm password" required>
      </div>
      <div class="form-actions">
        <button type="submit" class="btn-primary" data-tooltip="Create Account"><i class="fas fa-check"></i> Create</button>
        <button type="button" class="btn-secondary" onclick="showSection('manage-admins')" data-tooltip="Cancel"><i class="fas fa-times"></i> Cancel</button>
      </div>
    </form>
  </div>
</section>
