<?php
$crop_id = (int)($_GET['crop_id'] ?? $_POST['crop_id'] ?? 0);
$crop_data = null;

if ($crop_id <= 0) {
  echo "<section id='section-edit-crop' class='admin-section'>";
  echo "<div class='section-header'><h1>Edit Crop</h1></div>";
  echo "<p>Invalid crop ID.</p>";
  echo "</section>";
  return;
}

$crop_query = "
  SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit, c.market_price_per_unit, c.crop_description
  FROM crops c
  WHERE c.crop_id = ?
  LIMIT 1
";
$crop_stmt = $conn->prepare($crop_query);
if ($crop_stmt) {
  $crop_stmt->bind_param('i', $crop_id);
  $crop_stmt->execute();
  $crop_result = $crop_stmt->get_result();
  $crop_data = $crop_result ? $crop_result->fetch_assoc() : null;
  $crop_stmt->close();
}

if (!$crop_data) {
  echo "<section id='section-edit-crop' class='admin-section'>";
  echo "<div class='section-header'><h1>Edit Crop</h1></div>";
  echo "<p>Crop not found.</p>";
  echo "</section>";
  return;
}
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-edit-crop" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('manage-crops')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Edit Crop Record</h1>
      </div>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <form method="post" action="admin_dashboard.php?section=manage-crops" class="schedule-form">
      <input type="hidden" name="action" value="update_crop_quantity">
      <input type="hidden" name="crop_id" value="<?php echo (int)$crop_data['crop_id']; ?>">

      <div class="form-grid">
        <label class="form-field" style="grid-column: 1 / -1;">Crop Name
          <input type="text" name="crop_name" value="<?php echo htmlspecialchars($crop_data['crop_name'], ENT_QUOTES); ?>" maxlength="255" required>
        </label>

        <label class="form-field">Available Quantity
          <input type="number" name="crop_quantity" value="<?php echo (float)$crop_data['crop_quantity']; ?>" min="0.01" step="0.01" required>
        </label>

        <label class="form-field">Unit
          <input type="text" value="<?php echo htmlspecialchars($crop_data['crop_unit'], ENT_QUOTES); ?>" readonly style="background:#f5f7f5;color:#636b63;cursor:not-allowed;">
          <input type="hidden" name="crop_unit" value="<?php echo htmlspecialchars($crop_data['crop_unit'], ENT_QUOTES); ?>">
        </label>

        <label class="form-field">Market Price per Unit (PHP)
          <input type="number" name="market_price_per_unit" value="<?php echo (float)$crop_data['market_price_per_unit']; ?>" min="0.01" step="0.01" required>
        </label>

        <label class="form-field" style="grid-column: 1 / -1;">Description
          <textarea name="crop_description" rows="3" maxlength="500"><?php echo htmlspecialchars($crop_data['crop_description'], ENT_QUOTES); ?></textarea>
        </label>
      </div>

      <div class="form-actions-inline" style="margin-top:1rem;">
        <button type="button" class="btn-secondary" onclick="showSection('manage-crops')">Cancel</button>
        <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
          <i class="fas fa-save"></i>
          <span>Update Crop</span>
        </button>
      </div>
    </form>
  </div>
</section>
