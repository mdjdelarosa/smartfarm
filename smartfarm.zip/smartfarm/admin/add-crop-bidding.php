<?php
$source_crop_id = (int)($_GET['source_crop_id'] ?? 0);
$source_crop = null;

if ($source_crop_id > 0) {
  $source_stmt = $conn->prepare(
    "SELECT c.crop_id, c.crop_name, c.crop_quantity, c.crop_unit,
            COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
     FROM crops c
     LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
     WHERE c.crop_id = ?
       AND c.starting_price <= 0
     LIMIT 1"
  );

  if ($source_stmt) {
    $source_stmt->bind_param('i', $source_crop_id);
    $source_stmt->execute();
    $source_result = $source_stmt->get_result();
    $source_crop = $source_result ? $source_result->fetch_assoc() : null;
    $source_stmt->close();
  }
}

$available_qty = $source_crop ? (float)$source_crop['crop_quantity'] : 0.0;
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-add-crop-bidding" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('manage-crops')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>Allocate Crop to Bidding</h1>
      </div>
    </div>
  </div>

  <?php if (!$source_crop): ?>
    <div class="alert-error alert-message" style="margin-bottom:10px;">
      <i class="fas fa-exclamation-circle"></i> Crop not found or not eligible for bidding allocation.
    </div>
  <?php elseif ($available_qty <= 0): ?>
    <div class="alert-error alert-message" style="margin-bottom:10px;">
      <i class="fas fa-exclamation-circle"></i> This crop has no available quantity for bidding.
    </div>
  <?php endif; ?>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <?php if ($source_crop && $available_qty > 0): ?>
      <div style="margin-bottom:1rem;padding:0.85rem 1rem;background:#f0f7f0;border:1px solid #c8e6c9;border-radius:8px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;">
          <div>
            <strong style="color:#1b6e31;font-size:1rem;"><?php echo htmlspecialchars((string)$source_crop['crop_name'], ENT_QUOTES); ?></strong>
            <div style="font-size:0.85rem;color:#6b776b;margin-top:2px;">Owner: <?php echo htmlspecialchars((string)$source_crop['owner_name'], ENT_QUOTES); ?></div>
          </div>
          <div style="font-size:0.86rem;color:#2f4e2f;font-weight:700;">
            Available: <?php echo number_format($available_qty, 2); ?> <?php echo htmlspecialchars((string)$source_crop['crop_unit'], ENT_QUOTES); ?>
          </div>
        </div>
      </div>

      <form method="post" action="admin_dashboard.php?section=manage-crops" class="schedule-form">
        <input type="hidden" name="action" value="create_crop_bidding_lot">
        <input type="hidden" name="source_crop_id" value="<?php echo (int)$source_crop['crop_id']; ?>">
        <input type="hidden" name="_redirect" value="manage-crops">

        <div class="form-grid">
          <label class="form-field">Crop
            <input type="text" value="<?php echo htmlspecialchars((string)$source_crop['crop_name'], ENT_QUOTES); ?>" readonly style="background:#f5f7f5;color:#636b63;cursor:not-allowed;">
          </label>

          <label class="form-field">Unit
            <input type="text" value="<?php echo htmlspecialchars((string)$source_crop['crop_unit'], ENT_QUOTES); ?>" readonly style="background:#f5f7f5;color:#636b63;cursor:not-allowed;">
          </label>

          <label class="form-field">Bidding Quantity (<?php echo htmlspecialchars((string)$source_crop['crop_unit'], ENT_QUOTES); ?>)
            <input type="number" name="bid_quantity" min="0.01" max="<?php echo htmlspecialchars((string)$available_qty, ENT_QUOTES); ?>" step="0.01" placeholder="e.g. 50" required>
          </label>

          <label class="form-field">Starting Price (PHP)
            <input type="number" name="starting_price" min="0.01" step="0.01" placeholder="e.g. 5000" required>
          </label>

          <label class="form-field" style="grid-column:1/-1;">Bidding Ends
            <input type="datetime-local" name="bidding_end_date" min="<?php echo date('Y-m-d\\TH:i', strtotime('+1 hour')); ?>" required>
          </label>
        </div>

        <p style="font-size:0.84rem;color:#6b776b;margin:0.6rem 0 0.8rem;">
          <i class="fas fa-info-circle" style="margin-right:0.35rem;"></i>
          This allocation is for the selected crop only. Inventory is deducted once the lot is marked as claimed.
        </p>

        <div class="form-actions-inline" style="margin-top:0.5rem;">
          <button type="button" class="btn-secondary" onclick="showSection('manage-crops')">Cancel</button>
          <button type="submit" class="btn-primary" style="display:inline-flex;align-items:center;gap:0.45rem;">
            <i class="fas fa-gavel"></i>
            <span>Create Bidding Lot</span>
          </button>
        </div>
      </form>
    <?php else: ?>
      <div style="padding:0.5rem 0;color:#5b6a5b;">Please go back to Manage Crops and choose a valid crop with available quantity.</div>
    <?php endif; ?>
  </div>
</section>