<?php
$analytics_note = 'Forecasts use linear regression on each crop\'s price history, adjusted for the inverse of the seasonal supply curve (scarce months push price up, harvest-heavy months pull it down).';

$market_forecast_rows = (isset($conn) && $conn instanceof mysqli)
  ? computeMarketForecastRows($conn)
  : [];
?>

<section id="section-forecast-market" class="admin-section">
  <div class="section-header" style="display:flex;align-items:center;justify-content:space-between;gap:1rem;">
    <div style="display:flex;align-items:center;gap:0.75rem;">
      <button type="button" class="btn-tertiary" onclick="showSection('forecasting')">
        <i class="fas fa-arrow-left"></i>
      </button>
      <div>
        <h1>All Market Price Forecast</h1>
      </div>
    </div>
  </div>

  <div class="filter-bar">
    <div class="sf-filter-field sf-filter-field-search">
      <label class="sf-filter-label" for="marketForecastSearch">Search</label>
      <input type="text" id="marketForecastSearch" placeholder="Search crop..." class="search-input" oninput="filterTable('marketForecast')">
    </div>
  </div>

  <div class="table-container">
    <table class="data-table" id="marketForecastTable">
      <thead>
        <tr>
          <th>Crop</th>
          <th>Current Price</th>
          <th>Forecast Price</th>
          <th>Change</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($market_forecast_rows)): ?>
        <tr>
          <td colspan="4" style="text-align:center;color:#6b776b;">No market forecast rows available.</td>
        </tr>
        <?php else: ?>
        <?php foreach ($market_forecast_rows as $market_row): ?>
        <tr>
          <td><?php echo htmlspecialchars((string)$market_row['crop_name']); ?></td>
          <td>PHP <?php echo number_format((float)$market_row['current'], 2); ?> / <?php echo htmlspecialchars((string)$market_row['unit']); ?></td>
          <td>PHP <?php echo number_format((float)$market_row['forecast'], 2); ?> / <?php echo htmlspecialchars((string)$market_row['unit']); ?></td>
          <td><span class="market-badge <?php echo htmlspecialchars((string)$market_row['badge_class']); ?>"><?php echo ((float)$market_row['delta_pct'] >= 0 ? '+' : '') . number_format((float)$market_row['delta_pct'], 1); ?>%</span></td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <small class="analytics-note"><?php echo htmlspecialchars($analytics_note); ?></small>
</section>
