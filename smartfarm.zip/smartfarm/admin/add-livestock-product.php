<?php
$edit_product_id = (int)($_GET['edit_product_id'] ?? 0);
$is_edit_mode = $edit_product_id > 0;
?>

<style>
.sf-add-header {
  margin-bottom: 16px;
}

.sf-add-header-left {
  display: flex;
  align-items: center;
  gap: 14px;
}
</style>

<section id="section-add-livestock-product" class="admin-section">
  <div class="section-header sf-add-header">
    <div class="sf-add-header-left">
      <button type="button" class="btn-tertiary" onclick="showSection('manage-livestock-products')" data-tooltip="Back to monitor">
        <i class="fas fa-arrow-left"></i>
      </button>
      <h1><?php echo $is_edit_mode ? 'Edit Livestock' : 'Add Livestock'; ?></h1>
    </div>
  </div>

  <div class="schedule-modal-card" style="width:100%;margin:0;">
    <div class="schedule-modal-header">
      <div>
        <h3><i class="fas <?php echo $is_edit_mode ? 'fa-pen' : 'fa-plus-circle'; ?>" style="color:#22c55e;margin-right:0.4rem;"></i><?php echo $is_edit_mode ? 'Update Livestock' : 'New Livestock'; ?></h3>
        <span class="card-subtitle"><?php echo $is_edit_mode ? 'Edit this livestock record' : 'Add a livestock entry to the monitor'; ?></span>
      </div>
    </div>

    <form class="schedule-form" id="lpAddProductPageForm" enctype="multipart/form-data" data-edit-product-id="<?php echo (int)$edit_product_id; ?>">
      <div class="form-grid">
        <label class="form-field">Livestock Name
          <input type="text" id="lpAddProductName" maxlength="255" placeholder="e.g. Dairy Cow, Broiler Chicken, Carabao" required>
        </label>

        <input type="hidden" id="lpAddProductType" value="Livestock">
        <input type="hidden" id="lpAddProductUnit" value="head">

        <label class="form-field">Price (PHP)
          <input type="number" id="lpAddProductPrice" min="0" step="0.01" placeholder="0.00" required>
        </label>

        <label class="form-field">Quantity
          <input type="number" id="lpAddProductStock" min="0" step="1" placeholder="0" required>
        </label>

        <label class="form-field">Unit
          <input type="text" value="head" readonly style="background:#f4f7f5;color:#6b7280;cursor:not-allowed;">
        </label>

        <label class="form-field">Status
          <select id="lpAddProductStatus" required>
            <option>Active</option>
            <option>Inactive</option>
            <option>Out of Stock</option>
          </select>
        </label>

        <label class="form-field" style="grid-column: 1 / -1;">Description (Optional)
          <textarea id="lpAddProductDescription" rows="4" maxlength="1000" placeholder="Brief description of the livestock..."></textarea>
        </label>

        <!-- Product Image field removed as requested -->
      </div>

      <div class="form-actions-inline">
        <button type="button" class="btn-secondary" onclick="showSection('manage-livestock-products')">Cancel</button>
        <button type="submit" class="btn-primary"><?php echo $is_edit_mode ? 'Save Changes' : 'Add Livestock'; ?></button>
      </div>
    </form>
  </div>
</section>

<script>
(function () {
  const form = document.getElementById('lpAddProductPageForm');
  if (!form) return;
  const editProductId = parseInt(form.dataset.editProductId || '0', 10) || 0;
  const isEditMode = editProductId > 0;

  const typeInput = document.getElementById('lpAddProductType');
  const unitInput = document.getElementById('lpAddProductUnit');

  if (isEditMode) {
    fetch('admin/livestock_product_process.php?action=get_product&product_id=' + encodeURIComponent(String(editProductId)))
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.success || !data.product) {
          window.alert(data.message || 'Unable to load product details.');
          window.location.href = 'admin_dashboard.php?section=manage-livestock-products';
          return;
        }

        const p = data.product;
        document.getElementById('lpAddProductName').value = p.product_name || '';
        document.getElementById('lpAddProductType').value = p.product_type || '';
        document.getElementById('lpAddProductPrice').value = p.price != null ? p.price : '';
        document.getElementById('lpAddProductStock').value = p.stock != null ? p.stock : '';
        document.getElementById('lpAddProductUnit').value = p.unit || '';
        document.getElementById('lpAddProductStatus').value = p.status || 'Active';
        document.getElementById('lpAddProductDescription').value = p.product_description || '';
      })
      .catch(function () {
        window.alert('Connection error while loading product details.');
        window.location.href = 'admin_dashboard.php?section=manage-livestock-products';
      });
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();

    const name = document.getElementById('lpAddProductName').value.trim();
    const type = document.getElementById('lpAddProductType').value;
    const price = document.getElementById('lpAddProductPrice').value;
    const stock = document.getElementById('lpAddProductStock').value;
    const unit = document.getElementById('lpAddProductUnit').value.trim();
    const status = document.getElementById('lpAddProductStatus').value;
    const description = document.getElementById('lpAddProductDescription').value.trim();
    const imageInput = document.getElementById('lpAddProductImage');
    const imageFile = imageInput && imageInput.files && imageInput.files[0] ? imageInput.files[0] : null;

    if (!name || !type || price === '' || stock === '' || !unit) {
      window.alert('Please complete the required product fields.');
      return;
    }

    const fd = new FormData();
    fd.append('action', isEditMode ? 'edit_product' : 'add_product');
    if (isEditMode) {
      fd.append('product_id', String(editProductId));
    }
    fd.append('product_name', name);
    fd.append('product_type', type);
    fd.append('price', price);
    fd.append('stock', stock);
    fd.append('unit', unit);
    fd.append('status', status);
    fd.append('product_description', description);
    fd.append('farmer_id', '0');
    if (imageFile) {
      fd.append('product_image', imageFile);
    }

    fetch('admin/livestock_product_process.php', { method: 'POST', body: fd })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.success) {
          window.alert(data.message || (isEditMode ? 'Failed to update product.' : 'Failed to add product.'));
          return;
        }
        window.location.href = 'admin_dashboard.php?section=manage-livestock-products';
      })
      .catch(function () {
        window.alert(isEditMode ? 'Connection error while updating product.' : 'Connection error while adding product.');
      });
  });
})();
</script>