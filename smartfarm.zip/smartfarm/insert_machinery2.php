<?php
require 'config.php';

/*
 * 1. Insert 8 machinery listings (available, renter='', total_cost = daily rate)
 * 2. Insert rental transactions per machine (returned + paid) — NO date overlaps
 *
 * Machines & daily rates:
 *   4WD Tractor (55 HP)  = 8000/day
 *   Power Tiller         = 2500/day
 *   Rice Transplanter    = 4500/day
 *   Combine Harvester    = 12000/day
 *   Mechanical Dryer     = 3500/day
 *   Rice Mill            = 5000/day
 *   Corn Sheller         = 2000/day
 *   Hand Tractor         = 3000/day
 */

$owner = 'Morong Cooperative';
$today = '2026-04-16';

// ─── 1. Listing rows ──────────────────────────────────────────────────────────
$listings = [
    ['4WD Tractor (55 HP)', 8000.00],
    ['Power Tiller',        2500.00],
    ['Rice Transplanter',   4500.00],
    ['Combine Harvester',  12000.00],
    ['Mechanical Dryer',    3500.00],
    ['Rice Mill',           5000.00],
    ['Corn Sheller',        2000.00],
    ['Hand Tractor',        3000.00],
];

$next_id = (int)$conn->query("SELECT COALESCE(MAX(rental_id),0)+1 AS n FROM machinery_rentals")->fetch_assoc()['n'];

foreach ($listings as [$equip, $daily]) {
    $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
    $ts = $today . ' 08:00:00';
    $stmt = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
             total_cost, rental_status, payment_status, created_at, updated_at)
         VALUES (?, ?, ?, '', ?, ?, ?, 'pending', 'unpaid', ?, ?)"
    );
    $stmt->bind_param('sssssdss', $rental_code, $equip, $owner, $today, $today, $daily, $ts, $ts);
    if (!$stmt->execute()) { echo "FAILED listing ($equip): " . $stmt->error . "\n"; exit(1); }
    $stmt->close();
    echo "Listed  [{$next_id}]: $equip @ P$daily/day\n";
    $next_id++;
}

echo "\n── Listings done. Inserting transactions ──\n\n";

// ─── 2. Transactions ─────────────────────────────────────────────────────────
// [equipment_name, renter, start(YYYY-MM-DD), end(YYYY-MM-DD), daily_rate]
// Verified no overlaps per machine (calendar is wide-spaced)
$txns = [
    // 4WD Tractor (55 HP) @ 8000 — no overlaps
    ['4WD Tractor (55 HP)', 'Juan Dela Cruz',    '2025-09-10', '2025-09-12',  8000.00],
    ['4WD Tractor (55 HP)', 'Maria Santos',      '2025-11-05', '2025-11-07',  8000.00],
    ['4WD Tractor (55 HP)', 'Carlo Reyes',       '2026-01-15', '2026-01-17',  8000.00],
    ['4WD Tractor (55 HP)', 'Angela Garcia',     '2026-03-20', '2026-03-22',  8000.00],
    ['4WD Tractor (55 HP)', 'Mark Villanueva',   '2026-04-08', '2026-04-10',  8000.00],
    // Power Tiller @ 2500
    ['Power Tiller',        'Carlo Reyes',       '2025-09-20', '2025-09-22',  2500.00],
    ['Power Tiller',        'Angela Garcia',     '2025-11-15', '2025-11-17',  2500.00],
    ['Power Tiller',        'Christine Lopez',   '2026-01-25', '2026-01-27',  2500.00],
    ['Power Tiller',        'Joshua Bautista',   '2026-03-10', '2026-03-12',  2500.00],
    ['Power Tiller',        'Juan Dela Cruz',    '2026-04-05', '2026-04-07',  2500.00],
    // Rice Transplanter @ 4500
    ['Rice Transplanter',   'Angela Garcia',     '2025-10-05', '2025-10-08',  4500.00],
    ['Rice Transplanter',   'Mark Villanueva',   '2025-12-05', '2025-12-08',  4500.00],
    ['Rice Transplanter',   'Christine Lopez',   '2026-02-10', '2026-02-13',  4500.00],
    ['Rice Transplanter',   'Carlo Reyes',       '2026-04-02', '2026-04-05',  4500.00],
    // Combine Harvester @ 12000
    ['Combine Harvester',   'Mark Villanueva',   '2025-10-15', '2025-10-17', 12000.00],
    ['Combine Harvester',   'Joshua Bautista',   '2026-01-10', '2026-01-12', 12000.00],
    ['Combine Harvester',   'Juan Dela Cruz',    '2026-03-05', '2026-03-07', 12000.00],
    ['Combine Harvester',   'Maria Santos',      '2026-04-12', '2026-04-14', 12000.00],
    // Mechanical Dryer @ 3500
    ['Mechanical Dryer',    'Christine Lopez',   '2025-10-25', '2025-10-28',  3500.00],
    ['Mechanical Dryer',    'Maria Santos',      '2026-01-05', '2026-01-08',  3500.00],
    ['Mechanical Dryer',    'Carlo Reyes',       '2026-03-15', '2026-03-18',  3500.00],
    ['Mechanical Dryer',    'Angela Garcia',     '2026-04-10', '2026-04-13',  3500.00],
    // Rice Mill @ 5000
    ['Rice Mill',           'Joshua Bautista',   '2025-11-01', '2025-11-03',  5000.00],
    ['Rice Mill',           'Mark Villanueva',   '2026-01-20', '2026-01-22',  5000.00],
    ['Rice Mill',           'Christine Lopez',   '2026-03-25', '2026-03-27',  5000.00],
    ['Rice Mill',           'Joshua Bautista',   '2026-04-07', '2026-04-09',  5000.00],
    // Corn Sheller @ 2000
    ['Corn Sheller',        'Maria Santos',      '2025-11-20', '2025-11-22',  2000.00],
    ['Corn Sheller',        'Carlo Reyes',       '2026-02-05', '2026-02-07',  2000.00],
    ['Corn Sheller',        'Juan Dela Cruz',    '2026-04-03', '2026-04-05',  2000.00],
    // Hand Tractor @ 3000
    ['Hand Tractor',        'Christine Lopez',   '2025-09-05', '2025-09-08',  3000.00],
    ['Hand Tractor',        'Joshua Bautista',   '2025-11-28', '2025-12-01',  3000.00],
    ['Hand Tractor',        'Angela Garcia',     '2026-02-20', '2026-02-23',  3000.00],
    ['Hand Tractor',        'Mark Villanueva',   '2026-04-11', '2026-04-14',  3000.00],
];

// ── Overlap safety check ──────────────────────────────────────────────────────
$by_machine = [];
foreach ($txns as $t) $by_machine[$t[0]][] = [$t[2], $t[3]];
$ok = true;
foreach ($by_machine as $m => $periods) {
    usort($periods, fn($a, $b) => strcmp($a[0], $b[0]));
    for ($i = 1; $i < count($periods); $i++) {
        if ($periods[$i][0] <= $periods[$i-1][1]) {
            echo "OVERLAP: $m → {$periods[$i-1][0]}–{$periods[$i-1][1]} vs {$periods[$i][0]}–{$periods[$i][1]}\n";
            $ok = false;
        }
    }
}
if (!$ok) { exit(1); }
echo "Overlap check: PASSED\n\n";

// ── Insert transactions ───────────────────────────────────────────────────────
foreach ($txns as [$equip, $renter, $start, $end, $daily]) {
    $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
    $days        = (int)((strtotime($end) - strtotime($start)) / 86400) + 1;
    $total       = $daily * $days;
    $paid_at     = date('Y-m-d', strtotime($end  . ' +1 day')) . ' 10:00:00';
    $booked_at   = date('Y-m-d', strtotime($start . ' -2 days')) . ' 09:00:00';

    $stmt = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
             total_cost, rental_status, payment_status, payment_marked_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'returned', 'paid', ?, ?, ?)"
    );
    $stmt->bind_param('ssssssdsss',
        $rental_code, $equip, $owner, $renter,
        $start, $end, $total,
        $paid_at, $booked_at, $paid_at
    );
    if (!$stmt->execute()) { echo "FAILED tx ($equip/$renter): " . $stmt->error . "\n"; exit(1); }
    $rid = $conn->insert_id;
    $stmt->close();

    echo "Tx #{$rid} ({$rental_code}): {$equip} | {$renter} | {$start}→{$end} ({$days}d) | P{$total} | paid {$paid_at}\n";
    $next_id++;
}

echo "\n── Summary ──────────────────────────────────────────────────────────────\n";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals"); echo "Total rows   : " . $r->fetch_assoc()['c'] . "\n";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals WHERE TRIM(renter_name)='' AND rental_status='pending'"); echo "Listings     : " . $r->fetch_assoc()['c'] . "\n";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals WHERE rental_status='returned' AND payment_status='paid'");  echo "Transactions : " . $r->fetch_assoc()['c'] . "\n";
