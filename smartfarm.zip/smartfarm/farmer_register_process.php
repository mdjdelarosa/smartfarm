<?php
// Farmer Registration Process
// Handle farmer account creation with ID file upload

require 'config.php';

header('Content-Type: application/json');

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

// ============================================
// STEP 1: VALIDATE AND SANITIZE INPUT
// ============================================

// Get form data
$fullname = sanitizeInput($_POST['fullname'] ?? $_POST['farmer_fullname'] ?? '');
$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';
$confirm_password = $_POST['confirm_password'] ?? '';
$contact_number = sanitizeInput($_POST['contact_number'] ?? $_POST['farmer_contact_number'] ?? '');
$farmer_address = sanitizeInput($_POST['farmer_address'] ?? '');
$farm_name = sanitizeInput($_POST['farmer_farm_name'] ?? '');
$farm_address = sanitizeInput($_POST['farm_address'] ?? '');
$id_type = sanitizeInput($_POST['id_type'] ?? '');
$captcha_answer = sanitizeInput($_POST['captcha_answer'] ?? '');
$agree = $_POST['agree'] ?? '';

// Validate required fields
$errors = [];

if (empty($fullname) || strlen($fullname) < 3) {
    $errors[] = 'Full name must be at least 3 characters';
}

// Only one contact method is required overall — whichever was verified.
if ($email === '' && $contact_number === '') {
    $errors[] = 'Email or contact number is required';
}

if ($email !== '' && !isValidEmail($email)) {
    $errors[] = 'Invalid email format';
}

if (!isStrongPassword($password)) {
    $errors[] = 'Password must be at least 8 characters with uppercase, lowercase, number, and special character';
}

if ($password !== $confirm_password) {
    $errors[] = 'Passwords do not match';
}

if ($contact_number !== '' && strlen($contact_number) < 10) {
    $errors[] = 'Invalid contact number';
}

if (empty($farmer_address)) {
    $errors[] = 'Home address is required';
}

if (empty($farm_name)) {
    $errors[] = 'Farm name is required';
}

if (empty($farm_address)) {
    $errors[] = 'Farm address is required';
}

if (empty($id_type)) {
    $errors[] = 'ID type is required';
}

if ($agree !== '1') {
    $errors[] = 'You must agree to the Terms and Privacy Policy';
}

if (empty($captcha_answer)) {
    $errors[] = 'Security verification is required';
}

// Skip session-based captcha check for mobile app requests
// (mobile app handles captcha client-side and sends 'mobile_app' as the answer)
if ($captcha_answer !== 'mobile_app') {
    if (!isset($_SESSION['reg_captcha_code']) ||
        strcasecmp(trim($captcha_answer), trim((string)$_SESSION['reg_captcha_code'])) !== 0) {
        $errors[] = 'Incorrect security verification answer';
    }
    // Clear used captcha
    unset($_SESSION['reg_captcha_code'], $_SESSION['reg_captcha_ts']);
}

// Block duplicate or suspicious accounts before any insert
$registration_conflicts = findRegistrationConflicts($email, $contact_number);
if (!empty($registration_conflicts)) {
    $errors = array_merge($errors, $registration_conflicts);
}

// Return errors if validation failed
if (!empty($errors)) {
    die(json_encode(['success' => false, 'message' => implode(', ', $errors)]));
}

// Require the email/phone code (send_registration_code.php + verify_registration_code.php)
// to have been confirmed for THIS email/contact before allowing registration to proceed.
if (empty($_SESSION['reg_verify_passed'])) {
    die(json_encode(['success' => false, 'message' => 'Please verify your email or phone number before registering.']));
}

$verified_channel = (string)($_SESSION['reg_verify_channel'] ?? '');
$verified_destination = (string)($_SESSION['reg_verify_destination'] ?? '');
$destination_matches = ($verified_channel === 'email' && strcasecmp($verified_destination, $email) === 0)
    || ($verified_channel === 'sms' && normalizeContactNumber($verified_destination) === normalizeContactNumber($contact_number));

if (!$destination_matches) {
    die(json_encode(['success' => false, 'message' => 'The verified email/phone no longer matches this form. Please verify again.']));
}

// ============================================
// STEP 2: HANDLE FILE UPLOAD
// ============================================

$id_file_data = null;
$id_file_name = null;
$id_file_mime_type = null;

if (isset($_FILES['id_card']) && $_FILES['id_card']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['id_card'];
    
    // Validate file size
    if ($file['size'] > MAX_FILE_SIZE) {
        die(json_encode(['success' => false, 'message' => 'File size exceeds 10MB limit']));
    }
    
    // Validate MIME type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mime_type, ALLOWED_MIME_TYPES)) {
        die(json_encode(['success' => false, 'message' => 'Invalid file type. Only JPG, PNG, GIF, and PDF allowed']));
    }
    
    // Read file contents into binary data
    $id_file_data = file_get_contents($file['tmp_name']);
    $id_file_mime_type = $mime_type;

    $original_name = basename($file['name']);
    $name_base = pathinfo($original_name, PATHINFO_FILENAME);
    $name_ext = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));
    $name_base = preg_replace('/[^a-zA-Z0-9_-]/', '', $name_base);
    if ($name_base === '') {
        $name_base = 'farmer_id_' . time();
    }
    $id_file_name = $name_base . ($name_ext !== '' ? '.' . $name_ext : '');
} else {
    die(json_encode(['success' => false, 'message' => 'ID file upload failed']));
}

// ============================================
// STEP 3: INSERT INTO DATABASE (users + farmers)
// ============================================

try {
    $hashed_password = hashPassword($password);

    // Only one of email/contact_number is guaranteed to be filled — the
    // other stores as NULL, so relax the columns' NOT NULL constraint.
    ensureOptionalContactColumns($conn);
    $email_param = $email !== '' ? $email : null;
    $contact_param = $contact_number !== '' ? $contact_number : null;

    // Start transaction and ensure email uniqueness in users
    $conn->begin_transaction();
    if ($email_param !== null) {
        $chk = $conn->prepare('SELECT user_id FROM users WHERE email = ? LIMIT 1 FOR UPDATE');
        if (!$chk) throw new Exception('Prepare check failed: ' . $conn->error);
        $chk->bind_param('s', $email_param);
        $chk->execute();
        $chk->store_result();
        if ($chk->num_rows > 0) {
            $chk->close();
            throw new Exception('Email already registered');
        }
        $chk->close();
    }

    // Email/phone verification already completed pre-registration — activate immediately.
    $stmt = $conn->prepare('INSERT INTO users (email, password, role, is_active) VALUES (?, ?, ?, 1)');
    if (!$stmt) throw new Exception('Prepare users failed: ' . $conn->error);
    $role = 'farmer';
    $stmt->bind_param('sss', $email_param, $hashed_password, $role);
    if (!$stmt->execute()) throw new Exception('Insert users failed: ' . $stmt->error);
    $user_id = $stmt->insert_id;
    $stmt->close();

    // Insert into farmers table
    $stmt = $conn->prepare('INSERT INTO farmers (
        user_id, farmer_fullname, farmer_contact_number, farmer_farm_name, farmer_address, farm_address, farmer_id_type, farmer_id_file, farmer_id_file_name, farmer_id_file_mime_type, farmer_id_verification_status, farmer_is_verified, farmer_id_uploaded_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, "pending", 0, NOW())');
    if (!$stmt) throw new Exception('Prepare farmers failed: ' . $conn->error);
    $null_blob = null;
    $stmt->bind_param('issssssbss', $user_id, $fullname, $contact_param, $farm_name, $farmer_address, $farm_address, $id_type, $null_blob, $id_file_name, $id_file_mime_type);
    $stmt->send_long_data(7, $id_file_data);
    if (!$stmt->execute()) throw new Exception('Insert farmers failed: ' . $stmt->error);
    $farmer_id = $stmt->insert_id;
    $stmt->close();

    // Email/phone code was already confirmed pre-registration; record that here.
    if (!markAccountVerificationComplete($conn, (int)$user_id)) {
        throw new Exception('Unable to finalize account verification');
    }

    $conn->commit();

    unset($_SESSION['reg_verify_code'], $_SESSION['reg_verify_channel'], $_SESSION['reg_verify_destination'], $_SESSION['reg_verify_expires'], $_SESSION['reg_verify_passed']);

    pushUserNotification(
        $conn,
        (int)$user_id,
        'Account created',
        'Your farmer account has been created and verified. You can now log in; some features remain locked until admin review is complete.',
        'account_created',
        (int)$farmer_id
    );

    pushNotificationToRole(
        $conn,
        'admin',
        'New farmer account awaiting review',
        $fullname . ' has created a farmer account and is waiting for admin ID review.',
        'account_created',
        (int)$farmer_id
    );

    echo json_encode([
        'success' => true,
        'message' => 'Registration successful! You can now log in — your ID is still pending admin review.',
        'farmer_id' => $farmer_id
    ]);
    exit;

} catch (Exception $e) {
    $conn->rollback();
    die(json_encode(['success' => false, 'message' => 'System error: ' . $e->getMessage()]));
}

$conn->close();
?>
