<?php
require 'config.php';

/*
 * Insert ongoing (active) bidding lots — crop_status='available', bidding_end_date in the future
 * Each lot deducts from source inventory and gets some early bids (bid_status='pending')
 *
 * Today: 2026-04-16
 * Remaining inventory: Palay=55, Corn=31, Tomato=18, Eggplant=14, Lettuce=10,
 *                      Chili=10, Cucumber=9, Carrot=20, Onion=23, Watermelon=30
 *
 * Client IDs: Juan=1, Maria=2, Carlo=3, Angela=4, Mark=5, Christine=6, Joshua=7
 */

$farmer_id = 9;

// [src_id, crop_name, qty, unit, market_price, starting_price, listed_at, end_date, bids[]]
// bids: [client_id, amount, bid_time] — all bid_status='pending' (active auction)
$lots = [
    // Ends Apr 21 — Palay 8kg, listed Apr 14
    [1, 'Palay',      8,  'kg',  25.00,  160.00, '2026-04-14 08:00:00', '2026-04-21 18:00:00',
        [[2, 180.00, '2026-04-14 10:00:00'], [5, 210.00, '2026-04-15 09:30:00']]],

    // Ends Apr 22 — Corn 10kg, listed Apr 15
    [2, 'Corn',      10,  'kg',  22.00,  180.00, '2026-04-15 08:00:00', '2026-04-22 18:00:00',
        [[3, 200.00, '2026-04-15 11:00:00'], [7, 230.00, '2026-04-16 08:00:00']]],

    // Ends Apr 23 — Tomato 8kg, listed Apr 16
    [3, 'Tomato',     8,  'kg',  60.00,  420.00, '2026-04-16 08:00:00', '2026-04-23 18:00:00',
        [[4, 450.00, '2026-04-16 09:00:00']]],

    // Ends Apr 24 — Carrot 8kg, listed Apr 16
    [8, 'Carrot',     8,  'kg',  55.00,  380.00, '2026-04-16 09:00:00', '2026-04-24 18:00:00',
        [[1, 410.00, '2026-04-16 10:00:00'], [6, 450.00, '2026-04-16 14:00:00']]],

    // Ends Apr 25 — Watermelon 12kg, listed Apr 15
    [10, 'Watermelon',12, 'kg',  30.00,  300.00, '2026-04-15 08:00:00', '2026-04-25 18:00:00',
        [[5, 330.00, '2026-04-15 13:00:00']]],

    // Ends Apr 26 — Eggplant 6kg, listed Apr 16
    [4, 'Eggplant',   6,  'kg',  50.00,  260.00, '2026-04-16 10:00:00', '2026-04-26 18:00:00',
        [[2, 280.00, '2026-04-16 11:00:00'], [7, 310.00, '2026-04-16 15:00:00']]],

    // Ends Apr 28 — Onion 8kg, listed Apr 16
    [9, 'Onion',      8,  'kg',  90.00,  640.00, '2026-04-16 08:00:00', '2026-04-28 18:00:00',
        [[3, 680.00, '2026-04-16 09:30:00']]],

    // Ends Apr 30 — Cucumber 5kg, listed Apr 16
    [7, 'Cucumber',   5,  'kg',  45.00,  190.00, '2026-04-16 09:00:00', '2026-04-30 18:00:00',
        [[6, 220.00, '2026-04-16 12:00:00'], [1, 250.00, '2026-04-16 16:00:00']]],
];

/*
 * Deductions per source (this script only):
 *   Palay(1):      55 - 8  = 47 ✓
 *   Corn(2):       31 - 10 = 21 ✓
 *   Tomato(3):     18 - 8  = 10 ✓
 *   Carrot(8):     20 - 8  = 12 ✓
 *   Watermelon(10):30 - 12 = 18 ✓
 *   Eggplant(4):   14 - 6  =  8 ✓
 *   Onion(9):      23 - 8  = 15 ✓
 *   Cucumber(7):    9 - 5  =  4 ✓
 */

$insert_lot = $conn->prepare(
    "INSERT INTO crops
        (farmer_id, crop_name, crop_quantity, crop_unit, market_price_per_unit, starting_price,
         source_crop_id, inventory_deducted_on_claim, crop_status, bidding_end_date,
         payment_status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'available', ?, 'unpaid', ?, ?)"
);
// 10 ? : i s d s d d i s s s

$insert_bid = $conn->prepare(
    "INSERT INTO bids (crop_id, client_id, bid_amount, bid_status, payment_status, created_at, updated_at)
     VALUES (?, ?, ?, 'pending', 'unpaid', ?, ?)"
);
// 5 ? : i i d s s

$deduct_inv = $conn->prepare(
    "UPDATE crops SET crop_quantity = crop_quantity - ? WHERE crop_id = ? AND crop_quantity >= ?"
);

foreach ($lots as [$src_id, $name, $qty, $unit, $market, $start, $listed, $end_date, $bids]) {
    $conn->begin_transaction();
    try {
        $qty_f    = (float)$qty;
        $market_f = (float)$market;
        $start_f  = (float)$start;

        $insert_lot->bind_param('isdsddisss',
            $farmer_id, $name, $qty_f, $unit, $market_f, $start_f, $src_id,
            $end_date, $listed, $listed
        );
        if (!$insert_lot->execute()) throw new Exception("Lot insert failed: " . $insert_lot->error);
        $lot_id = $conn->insert_id;

        $deduct_inv->bind_param('did', $qty_f, $src_id, $qty_f);
        $deduct_inv->execute();
        if ($deduct_inv->affected_rows <= 0) throw new Exception("Insufficient stock for $name (src=$src_id)");

        foreach ($bids as [$client_id, $amount, $bid_time]) {
            $amount_f = (float)$amount;
            $insert_bid->bind_param('iidss', $lot_id, $client_id, $amount_f, $bid_time, $bid_time);
            if (!$insert_bid->execute()) throw new Exception("Bid insert failed: " . $insert_bid->error);
        }

        $conn->commit();
        $bid_count = count($bids);
        $top_bid   = max(array_column($bids, 1));
        echo "Lot #$lot_id: $name {$qty}kg | ends $end_date | $bid_count bids (top: P$top_bid)\n";
    } catch (Exception $e) {
        $conn->rollback();
        echo "FAILED ($name): " . $e->getMessage() . "\n";
    }
}

$insert_lot->close();
$insert_bid->close();
$deduct_inv->close();

echo "\nRemaining inventory:\n";
$r = $conn->query("SELECT crop_id, crop_name, crop_quantity FROM crops WHERE starting_price = 0 ORDER BY crop_id");
while ($row = $r->fetch_assoc()) {
    echo "  [{$row['crop_id']}] {$row['crop_name']}: {$row['crop_quantity']} kg\n";
}

echo "\nOngoing bidding lots:\n";
$r = $conn->query("
    SELECT c.crop_id, c.crop_name, c.crop_quantity, c.bidding_end_date,
           COUNT(b.bid_id) AS bid_count,
           MAX(b.bid_amount) AS top_bid
    FROM crops c
    LEFT JOIN bids b ON b.crop_id = c.crop_id
    WHERE c.crop_status = 'available' AND c.bidding_end_date > NOW()
    GROUP BY c.crop_id ORDER BY c.bidding_end_date
");
while ($row = $r->fetch_assoc()) {
    echo "  [{$row['crop_id']}] {$row['crop_name']} {$row['crop_quantity']}kg | ends {$row['bidding_end_date']} | bids: {$row['bid_count']}, top: P{$row['top_bid']}\n";
}
