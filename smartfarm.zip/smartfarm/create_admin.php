<?php
/**
 * Smart Farm - Admin Account Creation Tool
 * Use this to create your first admin account
 * Delete after use for security
 * 
 * Works with unified users table schema
 */

require 'config.php';

$success = false;
$errors = [];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = sanitizeInput($_POST['fullname'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validation
    if (empty($fullname) || strlen($fullname) < 3) {
        $errors[] = 'Full name must be at least 3 characters';
    }
    
    if (!isValidEmail($email)) {
        $errors[] = 'Invalid email format';
    }
    
    if (!isStrongPassword($password)) {
        $errors[] = 'Password must be 8+ chars with uppercase, lowercase, number, and special character';
    }
    
    if ($password !== $confirm_password) {
        $errors[] = 'Passwords do not match';
    }
    
    // Check if email already exists in users table
    if (empty($errors)) {
        $query = "SELECT user_id FROM users WHERE email = ? LIMIT 1";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            $errors[] = 'Database error: ' . $conn->error;
        } else {
            $stmt->bind_param('s', $email);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $errors[] = 'Email already exists';
            }
            $stmt->close();
        }
    }
    
    // Create account in two steps: users table, then admins table
    if (empty($errors)) {
        $hashed_password = hashPassword($password);
        $role = 'admin';
        $is_active = 1;
        
        // Step 1: Insert into users table
        $query = "INSERT INTO users (email, password, role, is_active) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        if (!$stmt) {
            $errors[] = 'Database error: ' . $conn->error;
        } else {
            $stmt->bind_param('sssi', $email, $hashed_password, $role, $is_active);
            
            if ($stmt->execute()) {
                $user_id = $conn->insert_id;
                $stmt->close();
                
                // Step 2: Insert into admins table
                $query = "INSERT INTO admins (user_id, fullname) VALUES (?, ?)";
                $stmt = $conn->prepare($query);
                if (!$stmt) {
                    $errors[] = 'Database error: ' . $conn->error;
                } else {
                    $stmt->bind_param('is', $user_id, $fullname);
                    
                    if ($stmt->execute()) {
                        $success = true;
                        $message = "Admin account created successfully!<br>Email: <strong>$email</strong><br>User ID: <strong>$user_id</strong>";
                    } else {
                        $errors[] = "Database error: " . $stmt->error;
                    }
                    $stmt->close();
                }
            } else {
                $errors[] = "Database error: " . $stmt->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Admin Account - Smart Farm</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            max-width: 480px;
            width: 100%;
            padding: 40px;
        }
        h1 {
            color: #333;
            margin-bottom: 8px;
            font-size: 26px;
        }
        .subtitle {
            color: #666;
            font-size: 14px;
            margin-bottom: 30px;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .alert-success {
            background: #d4edda;
            border: 2px solid #28a745;
            color: #155724;
            text-align: center;
        }
        .alert-error {
            background: #f8d7da;
            border: 2px solid #f5c6cb;
            color: #721c24;
        }
        .alert-error ul {
            margin: 0;
            padding-left: 20px;
            margin-top: 8px;
        }
        .alert-error li {
            margin: 6px 0;
        }
        .alert-warning {
            background: #fff3cd;
            border: 2px solid #ffc107;
            color: #856404;
        }
        .form-group {
            margin-bottom: 18px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        input {
            width: 100%;
            padding: 11px 13px;
            border: 2px solid #ddd;
            border-radius: 6px;
            font-size: 14px;
            font-family: inherit;
            transition: border-color 0.3s;
        }
        input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .hint {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .requirements {
            background: #f0f4ff;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 12px;
            color: #555;
            line-height: 1.5;
        }
        .req-title {
            font-weight: 600;
            color: #333;
            margin-bottom: 6px;
        }
        .req-item {
            margin: 4px 0;
            padding-left: 18px;
        }
        .req-item:before {
            content: "✓ ";
            color: #28a745;
            margin-left: -13px;
            margin-right: 4px;
            font-weight: bold;
        }
        button {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
        button:active {
            transform: translateY(0);
        }
        .next-steps {
            background: #e7f3ff;
            border: 2px solid #0066cc;
            color: #004085;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            font-size: 13px;
            line-height: 1.6;
        }
        .next-steps strong {
            display: block;
            margin-bottom: 8px;
        }
        .next-steps a {
            color: #0066cc;
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="card">
        <h1>🔐 Create Admin Account</h1>
        <p class="subtitle">Smart Farm Admin Panel Setup</p>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                ✅ Success! Account created.<br>
                <?php echo $message; ?>
            </div>
            <div class="next-steps">
                <strong>Next:</strong>
                1. Go to <a href="login.php">login.php</a><br>
                2. Login with your credentials<br>
                3. Delete this file (create_admin.php)
            </div>
        <?php else: ?>
            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <strong>❌ Errors:</strong>
                    <ul>
                        <?php foreach ($errors as $err): ?>
                            <li><?php echo htmlspecialchars($err); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="alert alert-warning">
                ⚠️ Delete this file after creating your account!
            </div>
            
            <form method="post">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" name="fullname" placeholder="e.g., John Admin" required autofocus>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" placeholder="e.g., admin@smartfarm.local" required>
                </div>
                
                <div class="requirements">
                    <div class="req-title">Password Requirements:</div>
                    <div class="req-item">8+ characters</div>
                    <div class="req-item">UPPERCASE letter</div>
                    <div class="req-item">lowercase letter</div>
                    <div class="req-item">Number (0-9)</div>
                    <div class="req-item">Special char (@$!%*?&)</div>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" placeholder="Enter password" required>
                    <div class="hint">Example: Admin@123</div>
                </div>
                
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" name="confirm_password" placeholder="Re-enter password" required>
                </div>
                
                <button type="submit">✓ Create Admin Account</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
