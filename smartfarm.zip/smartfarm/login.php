<?php
require 'config.php';
$login_error = '';
if (isset($_SESSION['error'])) {
  $login_error = $_SESSION['error'];
  unset($_SESSION['error']);
}

// Generate a creative registration captcha (code) stored in session
if (empty($_SESSION['reg_captcha_code']) || !isset($_SESSION['reg_captcha_ts']) || time() - $_SESSION['reg_captcha_ts'] > 600) {
  $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  $code = '';
  for ($i = 0; $i < 6; $i++) {
    $code .= $alphabet[rand(0, strlen($alphabet) - 1)];
  }
  $_SESSION['reg_captcha_code'] = $code;
  $_SESSION['reg_captcha_ts'] = time();
}

// Build captcha display with light distortion for a more creative look
$captcha_display = '';
$code_chars = str_split($_SESSION['reg_captcha_code'] ?? '');
foreach ($code_chars as $ch) {
  $rot = rand(-18, 18);
  $y = rand(-2, 2);
  $captcha_display .= '<span style="display:inline-block; transform:rotate(' . $rot . 'deg) translateY(' . $y . 'px); margin-right:4px;">' . htmlspecialchars($ch) . '</span>';
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Smart Farm Login</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <style>
    /* About Us services - grid layout (no scrolling) */
    .services-grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 3px;
      padding: 2px;
      width: 100%;
      max-width: 100%;
    }
    .service-card {
      background: #ffffff9a;
      border-radius: 4px;
      padding: 4px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.04);
      cursor: pointer;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      display: flex;
      flex-direction: column;
      gap: 2px;
      opacity: 8;
    }
    .service-card:hover { transform: translateY(-6px); box-shadow: 0 6px 18px rgba(0,0,0,0.08); }
    .service-card:focus { outline: 3px solid rgba(65,117,62,0.15); }
    .service-icon { font-size: 14px; }
    .service-card h4 { margin: 0; font-size: 0.8rem; color: #2f5c34; }
    .short-desc { color: #242323; font-size: 0.65rem; margin-top: 0px; line-height: 1.15; }

    /* Modal for full service details */
    .service-modal { position: fixed; inset: 0; display: none; align-items: center; justify-content: center; z-index: 2500; }
    .service-modal.active { display: flex; }
    .service-modal-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,0.7); }
    .service-modal-card { position: relative; z-index: 2501; background: #fff; border-radius: 10px; padding: 20px; max-width: 720px; width: calc(100% - 40px); max-height: 80vh; overflow: auto; box-shadow: 0 12px 40px rgba(0,0,0,0.25); }
    .service-modal-close { position: absolute; right: 12px; top: 8px; background: none; border: none; font-size: 22px; cursor: pointer; color: #666; }
    .service-modal-close:hover { color: #1d1c1c; background-color: transparent; }
    .service-modal-icon { font-size: 36px; color: #41753e; margin-bottom: 8px; }
    .service-modal-card h3 { margin: 0 0 8px 0; color: #2f5c34; }
    .service-modal-card p { color: #444; line-height: 1.6; }

    /* Registration confirm modal */
    .confirm-modal { position: fixed; inset: 0; display: none; align-items: center; justify-content: center; z-index: 2600; }
    .confirm-modal.active { display: flex; }
    .confirm-backdrop { position: absolute; inset: 0; background: rgba(0,0,0,0.55); }
    .confirm-card { position: relative; z-index: 2601; background: #fff; border-radius: 10px; padding: 20px; width: min(420px, 90vw); box-shadow: 0 12px 40px rgba(0,0,0,0.25); }
    .confirm-card h3 { margin: 0 0 8px 0; color: #2f5c34; font-size: 18px; }
    .confirm-card p { margin: 0 0 16px 0; color: #444; line-height: 1.5; font-size: 14px; }
    .confirm-actions { display: flex; gap: 10px; justify-content: flex-end; }
    .confirm-actions button { width: auto; margin: 0; padding: 10px 14px; }
    .confirm-actions .cancel-btn { background: #464545; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-weight: 700; font-size: 14px; padding: 10px 14px; }
    .confirm-actions .cancel-btn { background: #464545; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-weight: 700; font-size: 14px; }

    .form-feedback {
      display: none;
      margin: 0 0 8px 0;
      padding: 8px 10px;
      border-radius: 6px;
      font-size: 13px;
      line-height: 1.4;
      font-weight: 600;
    }
    .form-feedback.info { background: #eef6ff; border: 1px solid #b7d7ff; color: #2257a4; }
    .form-feedback.success { background: #e8f5e9; border: 1px solid #a5d6a7; color: #2e7d32; }
    .form-feedback.error { background: #fee; border: 1px solid #fcc; color: #c33; }

    .signup-guide {
      background: rgba(40, 167, 69, 0.08);
      border: 1px solid rgba(40, 167, 69, 0.18);
      border-radius: 8px;
      padding: 12px 14px;
      margin-bottom: 14px;
      color: #2f5c34;
      line-height: 1.5;
      font-size: 13px;
      font-weight: 600;
    }

    .signup-step[style*="display:none"] {
      display: none !important;
    }

    /* Terms and privacy agreement */
    .terms-box {
      background: #f5f5f5;
      border: 1px solid #ddd;
      border-radius: 6px;
      padding: 12px;
      margin: 12px 0;
    }
    .terms-label {
      display: flex;
      align-items: flex-start;
      gap: 10px;
      cursor: pointer;
      font-size: 13px;
      text-align: left;
    }
    .terms-checkbox {
      width: 16px;
      height: 16px;
      margin: 2px 0 0;
      padding: 0;
      border-radius: 3px;
      cursor: pointer;
      flex: 0 0 auto;
    }
    .terms-text {
      display: block;
      flex: 1;
      min-width: 0;
      line-height: 1.4;
      color: #333;
    }
    .terms-link { color: #28a745; text-decoration: none; }
    .terms-link:hover { text-decoration: underline; }

    /* Step 4: email/phone verification */
    .verify-back-link {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: none;
      border: none;
      color: #2f5c34;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      padding: 0;
      margin-bottom: 14px;
    }
    .verify-back-link:hover { text-decoration: underline; }
    .verify-title { margin: 0 0 4px; color: #2a3730; font-size: 20px; }

    .verify-input-row {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 16px 0 8px;
    }
    .verify-input-label {
      flex: 0 0 auto;
      display: flex;
      align-items: center;
      height: 42px;
      font-weight: 700;
      font-size: 14px;
      color: #2f3d31;
      white-space: nowrap;
    }
    .verify-input-field {
      flex: 1 1 auto;
      min-width: 0;
      height: 42px;
      padding: 0 12px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
      box-sizing: border-box;
    }
    .verify-input-field:focus {
      outline: none;
      border-color: #28a745;
      box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.15);
    }
    .verify-send-btn {
      flex: 0 0 auto;
      height: 42px;
      padding: 0 18px;
      background: #28a745;
      color: #fff;
      border: none;
      border-radius: 6px;
      font-weight: 700;
      font-size: 13px;
      cursor: pointer;
      white-space: nowrap;
      transition: background 0.2s ease;
    }
    .verify-send-btn:hover { background: #218838; }
    .verify-send-btn:disabled { background: #a8d8b5; cursor: not-allowed; }
    .verify-switch-link {
      margin: 2px 0 0;
      font-size: 13px;
    }
    .verify-switch-link a {
      color: #28a745;
      font-weight: 700;
      text-decoration: none;
      cursor: pointer;
    }
    .verify-switch-link a:hover { text-decoration: underline; }

    @media (max-width: 480px) {
      .verify-input-row { flex-wrap: wrap; }
      .verify-input-label { flex: 0 0 100%; }
      .verify-input-field { flex: 1 1 100%; }
      .verify-send-btn { flex: 1 1 100%; padding: 10px; }
    }

    @media (max-width: 768px) {
      .services-grid { height: 260px; }
      .service-card { flex: 0 0 220px; }
    }
    @media (max-width: 480px) {
      .terms-box { padding: 10px; }
      .terms-label { font-size: 12.5px; }
    }
  </style>
</head>
<body>
    <!-- Top Navigation -->
    <nav class="top-nav">
    <div class="nav-logo">
        <img src="images/smartfarm_logo.png" alt="Smart Farm Logo">
        <span>Smart Farm</span>
    </div>
    <ul class="nav-links">
        <li><a href="#" class="nav-link active" id="login-nav" onclick="showPage('login')">Login</a></li>
        <li><a href="#" class="nav-link" onclick="showPage('aboutus')">About Us</a></li>
        <li><a href="#" class="nav-link" onclick="showPage('contact')">Contact</a></li>
    </ul>
    </nav>

  <div class="rotator">
    <div class="container">
    <!-- Left Info Section -->
    <div class="info-section">
        <img src="images/smartfarm_logo.png" alt="Smart Farm Logo" class="login-logo">
        <h2>Welcome to <span class="highlight">Smart Farm</span></h2>
        <p id="tagline" class="tagline">Whether you’re a farmer joining the cooperative or a client looking to bid on crops and rent machineries with ease, sign in now to begin.</p>
        <button id="toggle-btn">Create Account</button>
        <p class="footer">Powered by Morong Multi‑Purpose Cooperative</p>
    </div>

    <!-- Right Form Section -->
    <div class="form-section">
      <!-- Login Page (default) -->
      <div id="page-login" class="page-content">
        <!-- Error Message Display -->
        <?php if (!empty($login_error)): ?>
        <div id="login-error-banner" style="background-color: #fee; border: 1px solid #fcc; color: #c33; padding: 10px; border-radius: 4px; margin-bottom: 15px; text-align: center; font-weight: 600; opacity: 1; transition: opacity 0.35s ease, transform 0.35s ease;">
            <?php echo htmlspecialchars($login_error); ?>
        </div>
        <script>
          setTimeout(function() {
            var banner = document.getElementById('login-error-banner');
            if (banner) {
              banner.style.opacity = '0';
              banner.style.transform = 'translateY(-10px)';
            }
          }, 3000);
        </script>
        <?php endif; ?>
        
        <!-- Login Form (default) -->

        <div id="login-form">
          <h2>Login</h2>
          <div id="login-feedback" class="form-feedback" aria-live="polite"></div>
          <form id="login-auth-form" method="post" action="login_process.php">
            <label class="form-label" for="login-email">Email or Phone Number</label>
            <input type="text" id="login-email" name="email" placeholder="" autocomplete="username" required>
            <label class="form-label" for="login-password">Password</label>
            <div class="password-field-wrapper">
              <input type="password" id="login-password" name="password" autocomplete="current-password" required>
            </div>
            <button type="submit">Login</button>
          </form>
          <?php if (!empty($_SESSION['success'])): ?>
          <div id="login-success-banner" style="background-color: #e8f5e9; border: 1px solid #a5d6a7; color: #2e7d32; padding: 10px; border-radius: 4px; margin-top: 15px; text-align: center; font-weight: 600; opacity: 1; transition: opacity 0.35s ease, transform 0.35s ease;">
            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
          </div>
          <script>
            setTimeout(function() {
              var banner = document.getElementById('login-success-banner');
              if (banner) {
                banner.style.opacity = '0';
                banner.style.transform = 'translateY(-10px)';
              }
            }, 3000);
          </script>
                    <div id="login-feedback" class="form-feedback" aria-live="polite"></div>
                    <script>
                      // Fade out any visible feedback after 3 seconds
                      setTimeout(function() {
                        var feedbacks = document.querySelectorAll('.form-feedback');
                        feedbacks.forEach(function(fb) {
                          if (fb && fb.style.display !== 'none' && fb.textContent.trim() !== '') {
                            fb.style.opacity = '0';
                            fb.style.transform = 'translateY(-10px)';
                          }
                        });
                      }, 3000);
                    </script>
          <?php endif; ?>
        </div>

        <!-- Sign Up Form (hidden initially) -->
        <div id="signup-form" style="display:none;">
        
        <!-- Step 0: Role Selection -->
        <div class="signup-step" id="step0" style="display:block;">
          <div class="role-selection-container">
            <h2>Signing up as</h2>
            <div class="role-grid">
                  <button type="button" class="role-btn" onclick="selectRole('client')" id="client-btn">
                      <i class="fas fa-basket-shopping role-icon"></i>
                      <strong>Client</strong>
                      <small>Find and bid on crops or rent machinery</small>
                  </button>
                  <button type="button" class="role-btn" onclick="selectRole('farmer')" id="farmer-btn">
                      <i class="fas fa-leaf role-icon"></i>
                      <strong>Farmer</strong>
                      <small>Sell crops or offer machinery for rent</small>
                  </button>
              </div>
          </div>
        </div>

        <!-- Step 1: Basic Info -->
        <div class="signup-step" id="step1" style="display:none;">
          <label class="form-label" for="input-fullname">Full Name</label>
          <input type="text" id="input-fullname" required>
          <label class="form-label" for="input-password">Password</label>
          <div class="password-field-wrapper">
            <input type="password" id="input-password" required>
          </div>
          <div class="field-hint">Use at least 8 characters with uppercase, lowercase, a number, and a special character.</div>
          <label class="form-label" for="input-confirm">Confirm Password</label>
          <div class="password-field-wrapper">
            <input type="password" id="input-confirm" required>
          </div>
          <div class="field-hint">Re-enter the same password so we can verify it matches.</div>
        </div>

        <!-- Step 2: Address & Contact -->
        <div class="signup-step" id="step2" style="display:none;">
        <label class="form-label" for="input-address">Home Address</label>
        <input type="text" id="input-address" required>
        <div class="field-hint">e.g. Street, Barangay, City, Province, ZIP code</div>
        <div id="farmer-fields" style="display:none;">
          <label class="form-label" for="input-farm-name">Farm Name</label>
          <input type="text" id="input-farm-name" required>
          <div class="field-hint">Use the name your farm is commonly known by.</div>
          <label class="form-label" for="input-farm-address">Farm Address</label>
          <input type="text" id="input-farm-address" required>
          <div class="field-hint">e.g. Farm street, Barangay, City, Province, ZIP code</div>
        </div>
        </div>

        <!-- Step 3: ID Verification (required for both) -->
        <div class="signup-step" id="step3" style="display:none;">
        <label class="form-label" for="input-id-type">Type of ID</label>
        <select id="input-id-type" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 15px; font-weight: 500; margin-bottom: 10px;">
            <option value="">-- Select Type of ID --</option>
            <option value="national_id">National ID (PhilID)</option>
            <option value="drivers_license">Driver's License</option>
            <option value="passport">Passport</option>
            <option value="tin_id">TIN ID</option>
            <option value="prc_id">PRC ID</option>
            <option value="sss_id">SSS ID</option>
            <option value="postal_id">Postal ID</option>
            <option value="senior_id">Senior Citizen ID</option>
            <option value="pwd_id">PWD ID</option>
            <option value="voter_id">Voter's ID</option>
            <option value="company_id">Company ID</option>
            <option value="barangay_clearance">Barangay Clearance</option>
            <option value="other">Other</option>
        </select>
          <label class="form-label" for="input-id-card">Upload ID File</label>
        <input type="file" id="input-id-card" accept="image/*,.pdf" required>
        <div id="registration-msg" style="margin-bottom:12px; display:none;"></div>

        <!-- Terms and Privacy Policy Agreement -->


        <div class="terms-box">
          <label class="terms-label">
            <input type="checkbox" id="input-agree" class="terms-checkbox">
            <span class="terms-text">
              I agree to the <strong><a href="terms.php" class="terms-link" target="_blank" rel="noopener">Terms and Conditions</a></strong>
              and <strong><a href="privacy.php" class="terms-link" target="_blank" rel="noopener">Privacy Policy</a></strong> of Smart Farm.
            </span>
          </label>
        </div>




      <!-- Move these panels OUTSIDE the signup-form -->
</div>

<!-- Step 4: Verify Email/Phone before final registration -->
<div class="signup-step" id="step4" style="display:none;">
  <button type="button" class="verify-back-link" onclick="backToEditFromVerify()"><i class="fas fa-arrow-left"></i> Back to edit information</button>
  <h3 class="verify-title">Verify your account</h3>
  <p class="field-hint">We'll send a one-time code to confirm it's really you.</p>

  <div class="verify-input-row">
    <label class="verify-input-label" for="input-verify-destination" id="verify-field-label">Email</label>
    <input type="text" id="input-verify-destination" class="verify-input-field" placeholder="Enter your email address" autocomplete="email">
    <button type="button" class="verify-send-btn" id="verify-send-code-btn" onclick="sendVerificationCode()">Send Code</button>
  </div>

  <div class="verify-switch-link">
    <a href="#" id="verify-switch-link" onclick="toggleVerifyChannel(); return false;">Verify using phone number instead</a>
  </div>

  <div id="verify-code-section" style="display:none;margin-top:16px;">
    <label class="form-label" for="input-verify-code">Enter the code you received</label>
    <input type="text" id="input-verify-code" maxlength="8" placeholder="6-digit code">
    <button type="button" class="register-btn" style="width:100%;margin-top:10px;" onclick="confirmVerificationCode()">Verify Code</button>
    <div class="field-hint">Didn't get a code? <a href="#" onclick="sendVerificationCode(); return false;">Resend</a></div>
  </div>

  <div id="verify-step-msg" class="form-feedback" style="display:none;margin-top:12px;"></div>
</div>

<!-- Terms Panel (replaces signup form) -->
<div id="terms-panel" class="panel-page" style="display:none;">
  <h2>Terms and Conditions</h2>
  <ol class="panel-list">
    <li>You must provide accurate and complete registration information.</li>
    <li>All transactions must comply with Smart Farm rules and local laws.</li>
    <li>Do not share your password or account with others.</li>
    <li>Smart Farm is not liable for losses due to user negligence or fraud.</li>
    <li>We reserve the right to suspend or terminate accounts for violations.</li>
    <li>By using Smart Farm, you agree to these terms and any future updates.</li>
  </ol>
  <button type="button" class="back-btn" onclick="showPanel('signup-form')">Back</button>
</div>

<!-- Privacy Policy Panel (replaces signup form) -->
<div id="privacy-panel" class="panel-page" style="display:none;">
  <h2>Privacy Policy</h2>
  <ol class="panel-list">
    <li>We collect your information only for account management and service improvement.</li>
    <li>Your data is stored securely and not shared with third parties except as required by law.</li>
    <li>You may request to view, update, or delete your personal information at any time.</li>
    <li>We use cookies for session management and analytics.</li>
    <li>By using Smart Farm, you consent to this privacy policy and any future updates.</li>
  </ol>
  <button type="button" class="back-btn" onclick="showPanel('signup-form')">Back</button>
</div>

        <div class="nav-buttons signup-actions" id="signup-actions">
          <button type="button" class="cancel-btn" onclick="cancelSignup()">Cancel</button>
          <button type="button" class="register-btn" onclick="proceedToVerification()">Continue</button>
        </div>
        </div>

        <p class="footer">Powered by Morong Multi‑Purpose Cooperative</p>
        </div>
      </div>
      </div>
    </div>
  </div>

  <!-- About Us Page - Floating on Background -->
  <div id="page-aboutus" class="floating-page" style="display:none;">
    <div class="floating-container">
      <!-- Introduction Section -->
      <div class="aboutus-intro">
        <h2>About Us</h2>
        <p style="line-height: 1.8; color: #333;">
          <strong>Smart Farm</strong> is the official platform of the <strong>Morong Multi-Purpose Cooperative</strong>, revolutionizing how farmers and clients connect in the agricultural community. We empower farmers with modern tools for data management and showcase, while enabling clients to participate in fair and transparent agricultural transactions through our innovative bidding and rental systems.
        </p>
        <p style="line-height: 1.8; color: #555;">
          By bridging farmers and clients through cooperative values, Smart Farm creates a trustworthy ecosystem where agricultural growth and collaboration flourish.
        </p>
      </div>

      <!-- Services Gallery Grid -->
      <div class="services-header">
        <h3>Our Services</h3>
      </div>
      <div class="services-grid" aria-label="Smart Farm services" role="list">
        <div class="service-card" role="button" tabindex="0" data-title="Crop Bidding" data-full="Participate in fair, transparent bidding for quality agricultural products directly from verified farmers. Monitor bids, set reserve prices, and finalize transactions with cooperative oversight.">
          <div class="service-icon"><i class="fa-solid fa-leaf" style="color: #41753e;"></i></div>
          <h4>Crop Bidding</h4>
          <p class="short-desc">Fair and transparent bidding for quality crops.</p>
        </div>

        <div class="service-card" role="button" tabindex="0" data-title="Machinery Rental" data-full="Access cooperative machinery with scheduled bookings and verified ownership for reliable agricultural operations. Manage rental periods, payments, and owner approvals.">
          <div class="service-icon"><i class="fa-solid fa-tractor" style="color: #41753e;"></i></div>
          <h4>Machinery Rental</h4>
          <p class="short-desc">Book verified machinery with ease.</p>
        </div>

        <div class="service-card" role="button" tabindex="0" data-title="Farmer Profiles" data-full="Build complete profiles showcasing crops, machinery, farm details, cooperative membership credentials, and performance history to help clients make informed decisions.">
          <div class="service-icon"><i class="fa-solid fa-address-card" style="color: #41753e;"></i></div>
          <h4>Farmer Profiles</h4>
          <p class="short-desc">Detailed farmer profiles and credentials.</p>
        </div>

        <div class="service-card" role="button" tabindex="0" data-title="Verified Membership" data-full="All farmers and clients undergo cooperative verification to ensure trust and security across transactions. Verification includes ID checks and cooperative approvals.">
          <div class="service-icon"><i class="fa-solid fa-user-check" style="color: #41753e;"></i></div>
          <h4>Verified Membership</h4>
          <p class="short-desc">Verified accounts for safer transactions.</p>
        </div>

        <div class="service-card" role="button" tabindex="0" data-title="Data Management" data-full="Comprehensive tools to organize, track, and manage farm records, listings, inventory, and cooperative data efficiently with exportable reports.">
          <div class="service-icon"><i class="fa-solid fa-chart-bar" style="color: #41753e;"></i></div>
          <h4>Data Management</h4>
          <p class="short-desc">Organize and export cooperative data.</p>
        </div>

        <div class="service-card" role="button" tabindex="0" data-title="Secure Transactions" data-full="All payments and transactions are processed securely through cooperative admin oversight and verification with transparent logs and receipts for users.">
          <div class="service-icon"><i class="fa-solid fa-file-shield" style="color: #41753e;"></i></div>
          <h4>Secure Transactions</h4>
          <p class="short-desc">Secure, admin‑overseen payments and logs.</p>
        </div>
      </div>
      </div>
    </div>
  </div>

  <!-- Contact Page - Floating on Background -->
  <div id="page-contact" class="floating-page" style="display:none;">
    <div class="floating-container">
      <h2>Contact Us</h2>
      <p style="color: #333; margin-bottom: 15px; font-size:14.5px;">
      <strong>Email:</strong> <a href="mailto:morongmpc@yahoo.com" class="contact-link">morongmpc@yahoo.com</a><br>
      <strong>Phone:</strong> <a href="tel:+639083974010" class="contact-link">0908 397 4010</a><br>
      <strong>Facebook:</strong> <a href="https://www.facebook.com/morongmultipurposecooperative.bataan/directory_basic_info" target="_blank" class="contact-link">
          Morong Multi-Purpose Cooperative
      </a><br>
      <strong>Address:</strong> <a href="https://www.google.com/maps/place/Juan+Luna+St+corner+Sulangi+St,+Binatitan,+Morong,+Bataan,+Philippines,+21018" target="_blank" class="contact-link">
          Juan Luna St. corner Sulangi St., Binatitan, Morong, Bataan, Philippines, 21018
      </a><br>
      <strong>Hours:</strong> Mon–Fri, 9:00 AM – 6:00 PM
      </p>
      <p style="color: #292828; font-size: 12px;">
        Have questions? We're here to help. Send us a message and we'll respond as soon as possible.
      </p>
    </div>
  </div>

  <!-- Service detail modal (moved outside floating containers so backdrop covers entire viewport) -->
  <div id="service-modal" class="service-modal" aria-hidden="true">
    <div class="service-modal-backdrop" data-action="close"></div>
    <div class="service-modal-card" role="dialog" aria-modal="true">
      <button class="service-modal-close" aria-label="Close">×</button>
      <div class="service-modal-icon" id="service-modal-icon"></div>
      <h3 id="service-modal-title"></h3>
      <p id="service-modal-full"></p>
    </div>
  </div>

  <!-- Registration confirmation modal -->
  <div id="confirm-modal" class="confirm-modal" aria-hidden="true">
    <div class="confirm-backdrop"></div>
    <div class="confirm-card" role="dialog" aria-modal="true">
      <h3>Confirm Registration</h3>
      <p>Please confirm to proceed. A security verification code will appear next.</p>
      <div class="confirm-actions">
        <button type="button" class="cancel-btn" id="confirm-cancel">Cancel</button>
        <button type="button" class="btn-primary" id="confirm-continue">Continue</button>
      </div>
    </div>
  </div>

  <!-- Captcha verification modal -->
  <div id="captcha-modal" class="confirm-modal" aria-hidden="true">
    <div class="confirm-backdrop" id="captcha-backdrop"></div>
    <div class="confirm-card" role="dialog" aria-modal="true" style="width:min(460px,90vw);">
      <h3>Security Verification</h3>
      <p style="margin-bottom:10px;">Type the code shown below to complete your registration.</p>
      <div style="background:#fff3cd; border:2px solid #ffc107; border-radius:6px; padding:14px; margin-bottom:12px;">
        <div style="background:#fff; border:1px dashed #d39e00; border-radius:6px; padding:10px; margin-bottom:10px; text-align:center; font-size:20px; letter-spacing:3px; font-family:'Courier New', monospace; color:#5a4b00; user-select:none;">
          <?php echo $captcha_display; ?>
        </div>
        <label for="input-captcha" style="display:block; margin-bottom:6px; font-size:14px; font-weight:600; color:#333;">Enter the code above</label>
        <input type="text" id="input-captcha" placeholder="Enter the code" style="width:100%; box-sizing:border-box; padding:10px; border:1px solid #ffc107; border-radius:4px; font-size:15px; font-weight:500;" autocomplete="off">
        <div id="captcha-modal-error" style="display:none; color:#c33; font-size:13px; margin-top:6px; font-weight:600;">Please enter the security code shown above.</div>
      </div>
      <div class="confirm-actions">
        <button type="button" class="cancel-btn" id="captcha-cancel">Cancel</button>
        <button type="button" class="btn-primary" id="captcha-submit">Verify &amp; Register</button>
      </div>
    </div>
  </div>

  <script>
    const toggleBtn = document.getElementById('toggle-btn');
    const loginForm = document.getElementById('login-form');
    const loginAuthForm = document.getElementById('login-auth-form');
    const loginFeedback = document.getElementById('login-feedback');
    const signupForm = document.getElementById('signup-form');
    const signupSteps = Array.from(document.querySelectorAll('.signup-step')).filter(step => step.id !== 'step0' && step.id !== 'step4');

    const rotator = document.querySelector('.rotator');

    const tagline = document.getElementById('tagline');

    // initial tagline for login state (info on left beside Login form)
    const loginTagline = "Whether you’re a farmer joining the cooperative or a client ready to bid on crops and rent machinery, Smart Farm welcomes you — join today!";
    const signupTagline = "Already have an account? Go Back to Login and continue exploring Smart Farm’s cooperative support and secure agricultural transactions.";

    // track current visible page (about/services/contact/login)
    let currentPage = 'login';
    let selectedRole = null; // Track selected role
    let captchaRevealed = false;
    let confirmCallback = null;
    let pendingFormData = null;

    function setFeedback(target, message, type = 'info', autoHide = false) {
      if (!target) {
        return;
      }

      if (!message) {
        target.style.display = 'none';
        target.textContent = '';
        target.className = 'form-feedback';
        return;
      }

      target.textContent = message;
      target.className = 'form-feedback ' + type;
      target.style.display = 'block';

      if (autoHide) {
        setTimeout(() => {
          if (target) {
            target.style.display = 'none';
          }
        }, 3500);
      }
    }

    function updateSignupVisibility() {
      const ready = selectedRole !== null;

      signupSteps.forEach(step => {
        step.style.display = ready ? 'block' : 'none';
      });

      const step0 = document.getElementById('step0');
      if (step0) {
        step0.style.display = 'block';
      }

      // Hide signup actions on first step, show otherwise
      const signupActions = document.getElementById('signup-actions');
      if (signupActions) {
        signupActions.style.display = ready ? 'flex' : 'none';
      }
    }

    // set initial text based on rotator state
    tagline.textContent = rotator.classList.contains('switched') ? signupTagline : loginTagline;

    // creative taglines per page
    const pageTaglines = {
      login: loginTagline,
      aboutus: 'Discover how Smart Farm empowers farmers and clients through cooperative innovation, fair transactions, and modern agricultural technology.',
      contact: 'Get in touch with Smart Farm for support on farmer services, cooperative tools, and agricultural transactions.'
    };

    (function autoDismissLoginError() {
      const loginErrorBanner = document.getElementById('login-error-banner');
      if (!loginErrorBanner) {
        return;
      }

      setTimeout(() => {
        loginErrorBanner.style.opacity = '0';
        loginErrorBanner.style.transform = 'translateY(-4px)';

        setTimeout(() => {
          if (loginErrorBanner && loginErrorBanner.parentNode) {
            loginErrorBanner.parentNode.removeChild(loginErrorBanner);
          }
        }, 360);
      }, 3000);
    })();

    if (loginAuthForm) {
      loginAuthForm.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!loginFeedback) {
          loginAuthForm.submit();
          return;
        }

        const formData = new FormData(loginAuthForm);
        setFeedback(loginFeedback, 'Signing you in...', 'info');

        fetch(loginAuthForm.action, {
          method: 'POST',
          body: formData,
          headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'application/json'
          }
        })
        .then(async response => {
          let result;
          try {
            result = await response.json();
          } catch (e) {
            setFeedback(loginFeedback, 'Invalid server response. Please contact support.', 'error', true);
            console.error('Invalid JSON response from server.');
            return;
          }
          console.log('Login response:', result);
          if (result.success) {
            setFeedback(loginFeedback, result.message || 'Login successful.', 'success');
            const redirectTarget = result.redirect || 'login.php';
            setTimeout(() => {
              window.location.href = redirectTarget;
            }, 900);
          } else {
            setFeedback(loginFeedback, result.message || 'Login failed.', 'error', true);
          }
        })
        .catch(error => {
          setFeedback(loginFeedback, 'Network error: ' + error.message, 'error', true);
          console.error('Login fetch error:', error);
        });
      });
    }

    toggleBtn.addEventListener('click', () => {
      // if user is on any page other than login, the button should take them to login
      if (currentPage !== 'login') {
        showPage('login');
        return;
      }

      // on login page, the button toggles between login/signup
      if (rotator.classList.contains('switched')) {
        rotator.classList.remove('switched');
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        toggleBtn.textContent = 'Create Account';
        tagline.textContent = loginTagline;
      } else {
        rotator.classList.add('switched');
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        toggleBtn.textContent = 'Back to Login';
        tagline.textContent = signupTagline;
      }
    });
    
    function openConfirmModal(cb) {
      confirmCallback = cb;
      const modal = document.getElementById('confirm-modal');
      if (modal) {
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
      }
    }

    function closeConfirmModal() {
      const modal = document.getElementById('confirm-modal');
      if (modal) {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
      }
      confirmCallback = null;
    }

    function revealCaptcha() {
      openCaptchaModal();
    }

    function openCaptchaModal() {
      captchaRevealed = true;
      const modal = document.getElementById('captcha-modal');
      if (modal) {
        modal.classList.add('active');
        modal.setAttribute('aria-hidden', 'false');
        const captchaInput = document.getElementById('input-captcha');
        if (captchaInput) { captchaInput.value = ''; captchaInput.focus(); }
        const captchaError = document.getElementById('captcha-modal-error');
        if (captchaError) captchaError.style.display = 'none';
      }
    }

    function closeCaptchaModal() {
      captchaRevealed = false;
      pendingFormData = null;
      const modal = document.getElementById('captcha-modal');
      if (modal) {
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden', 'true');
      }
      const captchaInput = document.getElementById('input-captcha');
      if (captchaInput) captchaInput.value = '';
    }

    // Submit registration form with AJAX
    let verifySelectedChannel = null;
    let verifyPassed = false;

    function proceedToVerification() {
      const fullname = document.getElementById('input-fullname').value.trim();
      const password = document.getElementById('input-password').value;
      const confirm_password = document.getElementById('input-confirm').value;
      const idType = document.getElementById('input-id-type').value;
      const idFile = document.getElementById('input-id-card').files[0];
      const agree = document.getElementById('input-agree').checked;
      const msgBox = document.getElementById('registration-msg');
      let msgTimer = null;
      const showMsg = (html, autoHide = false) => {
        msgBox.innerHTML = html;
        msgBox.style.display = 'block';
        if (msgTimer) {
          clearTimeout(msgTimer);
        }
        if (autoHide) {
          msgTimer = setTimeout(() => {
            msgBox.style.display = 'none';
          }, 3000);
        }
      };

      // Basic validation
      if (!fullname || !password || !confirm_password || !idType || !idFile) {
        showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;">Please fill in all required fields</div>', true);
        return;
      }

      if (password !== confirm_password) {
        showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;">Passwords do not match</div>', true);
        return;
      }

      if (!selectedRole) {
        showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;">Please choose account type (Client or Farmer)</div>', true);
        return;
      }

      // Validate agreement
      if (!agree) {
        showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;"><i class="fas fa-exclamation-circle"></i> You must agree to the Terms and Privacy Policy</div>', true);
        return;
      }

      if (selectedRole === 'farmer') {
        const farmName = document.getElementById('input-farm-name').value.trim();
        const farmerAddress = document.getElementById('input-address').value.trim();
        const farmAddress = document.getElementById('input-farm-address').value.trim();
        if (!farmName || !farmerAddress || !farmAddress) {
          showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;">Please fill in all farmer fields</div>', true);
          return;
        }
      } else if (selectedRole === 'client') {
        const clientAddress = document.getElementById('input-address').value.trim();
        if (!clientAddress) {
          showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;">Please fill in address</div>', true);
          return;
        }
      }

      // Form is valid — move to the verification step (fields stay filled, just hidden).
      verifySelectedChannel = 'email';
      verifyPassed = false;
      document.getElementById('input-verify-destination').value = '';
      document.getElementById('verify-code-section').style.display = 'none';
      document.getElementById('input-verify-code').value = '';
      applyVerifyChannelUI();
      setVerifyMsg('');

      signupSteps.forEach(step => { step.style.display = 'none'; });
      document.getElementById('step0').style.display = 'none';
      document.getElementById('signup-actions').style.display = 'none';
      document.getElementById('step4').style.display = 'block';
      document.getElementById('input-verify-destination').focus();
    }

    function backToEditFromVerify() {
      document.getElementById('step4').style.display = 'none';
      updateSignupVisibility();
    }

    function setVerifyMsg(message, type = 'info') {
      const el = document.getElementById('verify-step-msg');
      if (!el) return;
      if (!message) {
        el.style.display = 'none';
        el.textContent = '';
        return;
      }
      el.textContent = message;
      el.className = 'form-feedback ' + type;
      el.style.display = 'block';
    }

    function applyVerifyChannelUI() {
      const label = document.getElementById('verify-field-label');
      const input = document.getElementById('input-verify-destination');
      const link = document.getElementById('verify-switch-link');
      if (verifySelectedChannel === 'email') {
        label.textContent = 'Email';
        input.placeholder = 'Enter your email address';
        input.setAttribute('autocomplete', 'email');
        link.textContent = 'Verify using phone number instead';
      } else {
        label.textContent = 'Phone';
        input.placeholder = 'Enter your contact number';
        input.setAttribute('autocomplete', 'tel');
        link.textContent = 'Verify using email instead';
      }
    }

    function toggleVerifyChannel() {
      verifySelectedChannel = verifySelectedChannel === 'email' ? 'sms' : 'email';
      verifyPassed = false;
      document.getElementById('input-verify-destination').value = '';
      document.getElementById('verify-code-section').style.display = 'none';
      document.getElementById('input-verify-code').value = '';
      applyVerifyChannelUI();
      setVerifyMsg('');
      document.getElementById('input-verify-destination').focus();
    }

    function sendVerificationCode() {
      const destination = document.getElementById('input-verify-destination').value.trim();
      if (!destination) {
        setVerifyMsg('Please enter your ' + (verifySelectedChannel === 'email' ? 'email address' : 'contact number') + ' first.', 'error');
        return;
      }

      setVerifyMsg('Sending code...', 'info');

      fetch('send_registration_code.php', {
        method: 'POST',
        body: new URLSearchParams({ channel: verifySelectedChannel, destination })
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          setVerifyMsg(res.message, 'success');
          document.getElementById('verify-code-section').style.display = 'block';
          document.getElementById('input-verify-code').focus();
        } else {
          setVerifyMsg(res.message || 'Unable to send code.', 'error');
        }
      })
      .catch(err => setVerifyMsg('Network error: ' + err.message, 'error'));
    }

    function confirmVerificationCode() {
      const code = document.getElementById('input-verify-code').value.trim();
      if (!code) {
        setVerifyMsg('Please enter the code you received.', 'error');
        return;
      }

      setVerifyMsg('Verifying...', 'info');

      fetch('verify_registration_code.php', {
        method: 'POST',
        body: new URLSearchParams({ code })
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          verifyPassed = true;
          setVerifyMsg(res.message, 'success');
          setTimeout(() => {
            buildRegistrationFormData();
          }, 600);
        } else {
          setVerifyMsg(res.message || 'Incorrect code.', 'error');
        }
      })
      .catch(err => setVerifyMsg('Network error: ' + err.message, 'error'));
    }

    function buildRegistrationFormData() {
      const fullname = document.getElementById('input-fullname').value.trim();
      const password = document.getElementById('input-password').value;
      const confirm_password = document.getElementById('input-confirm').value;
      const idType = document.getElementById('input-id-type').value;
      const idFile = document.getElementById('input-id-card').files[0];
      const agree = document.getElementById('input-agree').checked;
      const destination = document.getElementById('input-verify-destination').value.trim();
      const email = verifySelectedChannel === 'email' ? destination : '';
      const contact = verifySelectedChannel === 'sms' ? destination : '';
      // step3 (and its #registration-msg box) is hidden by now — use the
      // visible step4 message area instead so success/error is seen.
      const msgBox = document.getElementById('verify-step-msg');

      const formData = new FormData();
      formData.append('role', selectedRole);
      formData.append('fullname', fullname);
      formData.append('email', email);
      formData.append('password', password);
      formData.append('confirm_password', confirm_password);
      formData.append('contact_number', contact);
      formData.append('id_type', idType);
      formData.append('id_card', idFile);
      formData.append('agree', agree ? '1' : '0');

      if (selectedRole === 'farmer') {
        formData.append('farmer_fullname', fullname);
        formData.append('farmer_contact_number', contact);
        formData.append('farmer_address', document.getElementById('input-address').value.trim());
        formData.append('farmer_farm_name', document.getElementById('input-farm-name').value.trim());
        formData.append('farm_address', document.getElementById('input-farm-address').value.trim());
      } else if (selectedRole === 'client') {
        formData.append('client_fullname', fullname);
        formData.append('client_contact_number', contact);
        formData.append('client_address', document.getElementById('input-address').value.trim());
      }

      const endpoint = selectedRole === 'farmer' ? 'farmer_register_process.php' : 'client_register_process.php';
      pendingFormData = { formData, endpoint, msgBox };

      // Captcha is the last gate before the account is actually created.
      openConfirmModal(() => {
        openCaptchaModal();
      });
    }

    function submitFromCaptcha() {
      const captcha = document.getElementById('input-captcha').value.trim();
      const captchaError = document.getElementById('captcha-modal-error');
      if (!captcha) {
        if (captchaError) captchaError.style.display = 'block';
        return;
      }
      if (captchaError) captchaError.style.display = 'none';

      if (!pendingFormData) return;
      const { formData, endpoint, msgBox } = pendingFormData;
      formData.append('captcha_answer', captcha);
      closeCaptchaModal();

      let msgTimer = null;
      const showMsg = (html, autoHide = false) => {
        msgBox.innerHTML = html;
        msgBox.style.display = 'block';
        if (msgTimer) clearTimeout(msgTimer);
        if (autoHide) {
          msgTimer = setTimeout(() => { msgBox.style.display = 'none'; }, 3000);
        }
      };

      msgBox.innerHTML = '<div style="background:#e8f5e9; border:1px solid #a5d6a7; color:#2e7d32; padding:10px; border-radius:4px;">Processing registration...</div>';
      msgBox.style.display = 'block';

      fetch(endpoint, {
        method: 'POST',
        body: formData
      })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          msgBox.innerHTML = '<div style="background:#d4edda; border:1px solid #c3e6cb; color:#155724; padding:10px; border-radius:4px;"><i class="fas fa-check-circle"></i> ' + res.message + '</div>';
          msgBox.style.display = 'block';
          setTimeout(() => {
            document.querySelectorAll('#signup-form input').forEach(inp => inp.value = '');
            cancelSignup();
          }, 2000);
        } else {
          showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;"><i class="fas fa-exclamation-circle"></i> ' + res.message + '</div>', true);
        }
      })
      .catch(err => {
        showMsg('<div style="background:#fee; border:1px solid #fcc; color:#c33; padding:10px; border-radius:4px;"><i class="fas fa-exclamation-circle"></i> Network error: ' + err.message + '</div>', true);
      });
    }

    function selectRole(role) {
      selectedRole = role;
      
      // Highlight selected button
      document.getElementById('client-btn').style.background = role === 'client' ? '#47aa5ea2' : '#f5f5f5';
      document.getElementById('client-btn').style.color = role === 'client' ? '#fff' : '#333';
      document.getElementById('farmer-btn').style.background = role === 'farmer' ? '#47aa5ea2' : '#f5f5f5';
      document.getElementById('farmer-btn').style.color = role === 'farmer' ? '#fff' : '#333';

      // Show/hide farmer-specific fields in one-page signup layout.
      document.getElementById('farmer-fields').style.display = selectedRole === 'farmer' ? 'block' : 'none';
      updateSignupVisibility();
      setFeedback(loginFeedback, '');
    }

    function cancelSignup() {
      // Reset signup form
      selectedRole = null;
      captchaRevealed = false;
      pendingFormData = null;
      verifySelectedChannel = null;
      verifyPassed = false;
      closeCaptchaModal();
      document.getElementById('client-btn').style.background = '#f5f5f5';
      document.getElementById('client-btn').style.color = '#333';
      document.getElementById('farmer-btn').style.background = '#f5f5f5';
      document.getElementById('farmer-btn').style.color = '#333';
      document.getElementById('farmer-fields').style.display = 'none';
      document.getElementById('step4').style.display = 'none';
      document.getElementById('signup-actions').style.display = 'none';
      document.getElementById('verify-code-section').style.display = 'none';
      setVerifyMsg('');
      updateSignupVisibility();
      
      // Clear all form inputs
      document.querySelectorAll('#signup-form input, #signup-form select').forEach(input => {
        if (input.type === 'checkbox') {
          input.checked = false;
          return;
        }
        input.value = '';
      });
      
      // Go back to login
      rotator.classList.remove('switched');
      loginForm.style.display = 'block';
      signupForm.style.display = 'none';
      toggleBtn.textContent = 'Create Account';
      tagline.textContent = loginTagline;
      setFeedback(loginFeedback, '');
    }

    updateSignupVisibility();

    // Confirm modal actions
    const confirmModal = document.getElementById('confirm-modal');
    const confirmContinue = document.getElementById('confirm-continue');
    const confirmCancel = document.getElementById('confirm-cancel');
    const confirmBackdrop = confirmModal ? confirmModal.querySelector('.confirm-backdrop') : null;

    if (confirmContinue) {
      confirmContinue.addEventListener('click', () => {
        const onConfirm = confirmCallback;
        closeConfirmModal();
        if (typeof onConfirm === 'function') onConfirm();
      });
    }

    if (confirmCancel) {
      confirmCancel.addEventListener('click', closeConfirmModal);
    }

    if (confirmBackdrop) {
      confirmBackdrop.addEventListener('click', closeConfirmModal);
    }

    // Captcha modal event listeners
    const captchaModal = document.getElementById('captcha-modal');
    const captchaSubmitBtn = document.getElementById('captcha-submit');
    const captchaCancelBtn = document.getElementById('captcha-cancel');
    const captchaBackdrop = document.getElementById('captcha-backdrop');

    if (captchaSubmitBtn) {
      captchaSubmitBtn.addEventListener('click', submitFromCaptcha);
    }
    if (captchaCancelBtn) {
      captchaCancelBtn.addEventListener('click', closeCaptchaModal);
    }
    if (captchaBackdrop) {
      captchaBackdrop.addEventListener('click', closeCaptchaModal);
    }
    if (captchaModal) {
      document.getElementById('input-captcha').addEventListener('keydown', function(e) {
        if (e.key === 'Enter') submitFromCaptcha();
      });
    }

    // Page switching function with creative fade effect
    function showPage(page) {
      // update current page
      currentPage = page;
      
      // Hide all internal pages with fade out
      const pages = document.querySelectorAll('.page-content');
      pages.forEach(p => {
        p.style.animation = 'fadeOut 0.6s ease';
        setTimeout(() => {
          p.style.display = 'none';
          p.style.animation = '';
        }, 600);
      });

      // Hide all floating pages with fade out
      const floatingPages = document.querySelectorAll('.floating-page');
      floatingPages.forEach(p => {
        p.style.animation = 'fadeOut 0.6s ease';
        setTimeout(() => {
          p.style.display = 'none';
          p.style.animation = '';
        }, 600);
      });

      // Reset the login/signup view if showing login page - DO THIS IMMEDIATELY
      if (page === 'login') {
        rotator.classList.remove('switched');
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        // Ensure toggle button shows appropriate label
        toggleBtn.textContent = 'Create Account';
        tagline.textContent = loginTagline;
        document.querySelector('.rotator').style.opacity = '1';
        document.querySelector('.rotator').style.pointerEvents = 'auto';
      } else if (page === 'aboutus' || page === 'contact') {
        // Hide container and info-section if showing floating pages (About Us, Contact)
        document.querySelector('.rotator').style.opacity = '0';
        document.querySelector('.rotator').style.pointerEvents = 'none';
      } else {
        document.querySelector('.rotator').style.opacity = '1';
        document.querySelector('.rotator').style.pointerEvents = 'auto';
        toggleBtn.textContent = 'Log In';
        // Set info-side tagline to the page-specific creative message
        if (pageTaglines[page]) tagline.textContent = pageTaglines[page];
      }

      // Show selected page with fade in
      setTimeout(() => {
        const el = document.getElementById('page-' + page);
        if (el) {
          el.style.display = 'block';
          el.style.animation = 'fadeIn 0.6s ease';
        }
      }, 600);

      // Update nav link styling (active state)
      document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
      });
      const activeNav = document.querySelector(`[onclick="showPage('${page}')"]`);
      if (activeNav) {
        activeNav.classList.add('active');
      }
    }

    // Remove loading overlay after entrance animation completes
    window.addEventListener('load', () => {
      // Removed loading overlay auto-cleanup
    });

    // Service cards modal behavior
    (function(){
      const modal = document.getElementById('service-modal');
      const modalTitle = document.getElementById('service-modal-title');
      const modalFull = document.getElementById('service-modal-full');
      const modalClose = modal ? modal.querySelector('.service-modal-close') : null;

      function openServiceModal(card) {
        if(!modal) return;
        const title = card.dataset.title || '';
        const full = card.dataset.full || '';
        modalTitle.textContent = title;
        modalFull.textContent = full;
        modal.classList.add('active');
        modal.setAttribute('aria-hidden','false');
        document.body.style.overflow = 'hidden';
        if(modalClose) modalClose.focus();
      }

      function closeServiceModal() {
        if(!modal) return;
        modal.classList.remove('active');
        modal.setAttribute('aria-hidden','true');
        document.body.style.overflow = '';
      }

      document.querySelectorAll('.service-card').forEach(card => {
        card.addEventListener('click', () => openServiceModal(card));
        card.addEventListener('keydown', (e) => {
          if(e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openServiceModal(card); }
        });
      });

      if(modal) {
        modal.addEventListener('click', (e) => {
          if(e.target && e.target.dataset && e.target.dataset.action === 'close') closeServiceModal();
        });
        if(modalClose) modalClose.addEventListener('click', closeServiceModal);
        document.addEventListener('keydown', (e) => { if(e.key === 'Escape') closeServiceModal(); });
      }
    })();

    // Cursor-following background animation - much slower and smoother
    let lastX = 0, lastY = 0;
    let targetX = 30, targetY = 30;
    
    document.addEventListener('mousemove', (e) => {
      const x = (e.clientX / window.innerWidth) * 10; // Very minimal range for slowest movement
      const y = (e.clientY / window.innerHeight) * 10; // Very minimal range for slowest movement
      
      // Calculate target background position
      targetX = 30 + (x - 5); // Center position with limited range
      targetY = 30 + (y - 5); // Center position with limited range
    });
    
    // Animate background position smoothly - VERY SLOW
    function animateBackground() {
      lastX += (targetX - lastX) * 0.03; // Much slower interpolation - 0.03 is very very slow
      lastY += (targetY - lastY) * 0.03;
      
      document.body.style.backgroundPosition = `${lastX}% ${lastY}%`;
      requestAnimationFrame(animateBackground);
    }
    animateBackground();
  </script>
  <script>
  function showPanel(panelId, e) {
    if (e) e.preventDefault();
    // Hide all panels
    document.getElementById('signup-form').style.display = 'none';
    document.getElementById('terms-panel').style.display = 'none';
    document.getElementById('privacy-panel').style.display = 'none';
    // Show the requested panel
    document.getElementById(panelId).style.display = 'block';
  }
  </script>
</body>
</html>
