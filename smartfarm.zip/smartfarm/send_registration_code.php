<?php
// Sends a one-time verification code to the email or phone number a user
// entered on the sign-up form, BEFORE the account is created. The code and
// its target are kept in the session and checked by verify_registration_code.php.

require 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die(json_encode(['success' => false, 'message' => 'Invalid request method']));
}

$channel = strtolower(trim($_POST['channel'] ?? ''));
$destination = trim($_POST['destination'] ?? '');

if (!in_array($channel, ['email', 'sms'], true)) {
    die(json_encode(['success' => false, 'message' => 'Please choose email or phone number.']));
}

if ($destination === '') {
    die(json_encode(['success' => false, 'message' => 'Please fill in your ' . ($channel === 'email' ? 'email address' : 'contact number') . ' first.']));
}

if ($channel === 'email' && !isValidEmail($destination)) {
    die(json_encode(['success' => false, 'message' => 'Please enter a valid email address.']));
}

if ($channel === 'sms' && strlen(normalizeContactNumber($destination)) < 10) {
    die(json_encode(['success' => false, 'message' => 'Please enter a valid contact number.']));
}

$code = generateVerificationCode(6);

$sent = ($channel === 'email')
    ? sendSmartFarmEmail(
        $destination,
        'Your Smart Farm verification code',
        '<h2>Smart Farm Account Verification</h2><p>Your verification code is:</p><p style="font-size:22px;font-weight:700;letter-spacing:2px;">' . htmlspecialchars($code, ENT_QUOTES, 'UTF-8') . '</p><p>This code expires in 10 minutes.</p>'
    )
    : sendSmartFarmSms($destination, 'Smart Farm verification code: ' . $code);

if (!$sent) {
    die(json_encode(['success' => false, 'message' => 'Unable to send the verification code. Please try again.']));
}

$_SESSION['reg_verify_code'] = $code;
$_SESSION['reg_verify_channel'] = $channel;
$_SESSION['reg_verify_destination'] = $destination;
$_SESSION['reg_verify_expires'] = time() + (10 * 60);
$_SESSION['reg_verify_passed'] = false;

echo json_encode([
    'success' => true,
    'message' => 'A verification code was sent to your ' . ($channel === 'email' ? 'email address' : 'phone number') . '.',
]);
