<?php
require 'config.php';

/*
 * 1. Insert 8 machinery listings (available, renter='', daily_rate in total_cost)
 * 2. Insert rental transactions per machine (returned + paid) with NO date overlaps
 *
 * Machines & daily rates (from official rate table):
 *   4WD Tractor (55 HP)  = 8000/day
 *   Power Tiller          = 2500/day
 *   Rice Transplanter     = 4500/day
 *   Combine Harvester     = 12000/day
 *   Mechanical Dryer      = 3500/day
 *   Rice Mill             = 5000/day
 *   Corn Sheller          = 2000/day
 *   Hand Tractor          = 3000/day
 *
 * Renters (clients): Juan Dela Cruz, Maria Santos, Carlo Reyes, Angela Garcia,
 *                    Mark Villanueva, Christine Lopez, Joshua Bautista
 * Owner: Morong Cooperative
 */

$owner = 'Morong Cooperative';
$today = '2026-04-16';

// ─── STEP 1: Insert 8 machinery listings ─────────────────────────────────────
// rental_status='pending' + renter_name='' → shows as "Available" in UI
// total_cost stores the daily rate for listing rows

$listings = [
    ['4WD Tractor (55 HP)',  8000.00],
    ['Power Tiller',         2500.00],
    ['Rice Transplanter',    4500.00],
    ['Combine Harvester',   12000.00],
    ['Mechanical Dryer',     3500.00],
    ['Rice Mill',            5000.00],
    ['Corn Sheller',         2000.00],
    ['Hand Tractor',         3000.00],
];

// Get next available ID
$next_id = (int)$conn->query("SELECT COALESCE(MAX(rental_id),0)+1 AS n FROM machinery_rentals")->fetch_assoc()['n'];

$ins_listing = $conn->prepare(
    "INSERT INTO machinery_rentals
        (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
         total_cost, rental_status, payment_status, created_at, updated_at)
     VALUES (?, ?, ?, '', ?, ?, ?, 'pending', 'unpaid', ?, ?)"
);
// i=next_id used for rental_code only; bind: s s s s s d s s
// placeholders: rental_code(s) equip(s) owner(s) start(s) end(s) cost(d) created(s) updated(s)

$listing_machine_ids = [];
foreach ($listings as [$equip, $daily]) {
    $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
    $ins_listing->bind_param('sssssds s',
        $rental_code, $equip, $owner,
        $today, $today,
        $daily,
        $today . ' 08:00:00', $today . ' 08:00:00'
    );
    // fix whitespace in type string
    $ins_listing->close();
    $ins_listing = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
             total_cost, rental_status, payment_status, created_at, updated_at)
         VALUES (?, ?, ?, '', ?, ?, ?, 'pending', 'unpaid', ?, ?)"
    );
    $ins_listing->bind_param('sssssdss',
        $rental_code, $equip, $owner,
        $today, $today,
        $daily,
        $today . ' 08:00:00', $today . ' 08:00:00'
    );
    if (!$ins_listing->execute()) {
        echo "FAILED listing ($equip): " . $ins_listing->error . "\n";
        exit(1);
    }
    $listing_machine_ids[$equip] = $conn->insert_id;
    echo "Listed: $equip (rental_id={$listing_machine_ids[$equip]}, daily=P$daily)\n";
    $next_id++;
}
$ins_listing->close();

echo "\n── Listings done. Now inserting transactions ──\n\n";

// ─── STEP 2: Rental transactions ─────────────────────────────────────────────
// Each entry: [equipment_name, renter_name, start_date, end_date, daily_rate]
// total_cost = daily_rate * (end - start + 1) days
// rental_status='returned', payment_status='paid'
// created_at = start_date minus 2 days (booking date)
// payment_marked_at = end_date + 1 day 10:00

// Sorted per machine — verified NO overlaps within each machine
$transactions = [
    // ── 4WD Tractor (55 HP) @ 8000/day ─────────────────────────────────────
    ['4WD Tractor (55 HP)', 'Juan Dela Cruz',    '2025-09-10', '2025-09-12',  8000.00],  // 3d = 24000
    ['4WD Tractor (55 HP)', 'Maria Santos',      '2025-11-05', '2025-11-07',  8000.00],  // 3d = 24000
    ['4WD Tractor (55 HP)', 'Carlo Reyes',       '2026-01-15', '2026-01-17',  8000.00],  // 3d = 24000
    ['4WD Tractor (55 HP)', 'Angela Garcia',     '2026-03-20', '2026-03-22',  8000.00],  // 3d = 24000
    ['4WD Tractor (55 HP)', 'Mark Villanueva',   '2026-04-08', '2026-04-10',  8000.00],  // 3d = 24000

    // ── Power Tiller @ 2500/day ──────────────────────────────────────────────
    ['Power Tiller',        'Carlo Reyes',       '2025-09-20', '2025-09-22',  2500.00],  // 3d = 7500
    ['Power Tiller',        'Angela Garcia',     '2025-11-15', '2025-11-17',  2500.00],  // 3d = 7500
    ['Power Tiller',        'Christine Lopez',   '2026-01-25', '2026-01-27',  2500.00],  // 3d = 7500
    ['Power Tiller',        'Joshua Bautista',   '2026-03-10', '2026-03-12',  2500.00],  // 3d = 7500
    ['Power Tiller',        'Juan Dela Cruz',    '2026-04-05', '2026-04-07',  2500.00],  // 3d = 7500

    // ── Rice Transplanter @ 4500/day ─────────────────────────────────────────
    ['Rice Transplanter',   'Angela Garcia',     '2025-10-05', '2025-10-08',  4500.00],  // 4d = 18000
    ['Rice Transplanter',   'Mark Villanueva',   '2025-12-05', '2025-12-08',  4500.00],  // 4d = 18000
    ['Rice Transplanter',   'Christine Lopez',   '2026-02-10', '2026-02-13',  4500.00],  // 4d = 18000
    ['Rice Transplanter',   'Carlo Reyes',       '2026-04-02', '2026-04-05',  4500.00],  // 4d = 18000

    // ── Combine Harvester @ 12000/day ────────────────────────────────────────
    ['Combine Harvester',   'Mark Villanueva',   '2025-10-15', '2025-10-17', 12000.00],  // 3d = 36000
    ['Combine Harvester',   'Joshua Bautista',   '2026-01-10', '2026-01-12', 12000.00],  // 3d = 36000
    ['Combine Harvester',   'Juan Dela Cruz',    '2026-03-05', '2026-03-07', 12000.00],  // 3d = 36000
    ['Combine Harvester',   'Maria Santos',      '2026-04-12', '2026-04-14', 12000.00],  // 3d = 36000

    // ── Mechanical Dryer @ 3500/day ──────────────────────────────────────────
    ['Mechanical Dryer',    'Christine Lopez',   '2025-10-25', '2025-10-28',  3500.00],  // 4d = 14000
    ['Mechanical Dryer',    'Maria Santos',      '2026-01-05', '2026-01-08',  3500.00],  // 4d = 14000
    ['Mechanical Dryer',    'Carlo Reyes',       '2026-03-15', '2026-03-18',  3500.00],  // 4d = 14000
    ['Mechanical Dryer',    'Angela Garcia',     '2026-04-10', '2026-04-13',  3500.00],  // 4d = 14000

    // ── Rice Mill @ 5000/day ─────────────────────────────────────────────────
    ['Rice Mill',           'Joshua Bautista',   '2025-11-01', '2025-11-03',  5000.00],  // 3d = 15000
    ['Rice Mill',           'Mark Villanueva',   '2026-01-20', '2026-01-22',  5000.00],  // 3d = 15000
    ['Rice Mill',           'Christine Lopez',   '2026-03-25', '2026-03-27',  5000.00],  // 3d = 15000
    ['Rice Mill',           'Joshua Bautista',   '2026-04-07', '2026-04-09',  5000.00],  // 3d = 15000

    // ── Corn Sheller @ 2000/day ──────────────────────────────────────────────
    ['Corn Sheller',        'Maria Santos',      '2025-11-20', '2025-11-22',  2000.00],  // 3d = 6000
    ['Corn Sheller',        'Carlo Reyes',       '2026-02-05', '2026-02-07',  2000.00],  // 3d = 6000
    ['Corn Sheller',        'Juan Dela Cruz',    '2026-04-03', '2026-04-05',  2000.00],  // 3d = 6000

    // ── Hand Tractor @ 3000/day ──────────────────────────────────────────────
    ['Hand Tractor',        'Christine Lopez',   '2025-09-05', '2025-09-08',  3000.00],  // 4d = 12000
    ['Hand Tractor',        'Joshua Bautista',   '2025-11-28', '2025-12-01',  3000.00],  // 4d = 12000
    ['Hand Tractor',        'Angela Garcia',     '2026-02-20', '2026-02-23',  3000.00],  // 4d = 12000
    ['Hand Tractor',        'Mark Villanueva',   '2026-04-11', '2026-04-14',  3000.00],  // 4d = 12000
];

// Overlap check per machine before inserting
$by_machine = [];
foreach ($transactions as $t) {
    $by_machine[$t[0]][] = [$t[2], $t[3]]; // start, end
}
$has_overlap = false;
foreach ($by_machine as $machine => $periods) {
    usort($periods, fn($a, $b) => strcmp($a[0], $b[0]));
    for ($i = 1; $i < count($periods); $i++) {
        if ($periods[$i][0] <= $periods[$i-1][1]) {
            echo "OVERLAP DETECTED for $machine: {$periods[$i-1][0]}–{$periods[$i-1][1]} vs {$periods[$i][0]}–{$periods[$i][1]}\n";
            $has_overlap = true;
        }
    }
}
if ($has_overlap) { echo "Fix overlaps before proceeding.\n"; exit(1); }
echo "Overlap check: PASSED\n\n";

$ins_tx = $conn->prepare(
    "INSERT INTO machinery_rentals
        (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
         total_cost, rental_status, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'returned', 'paid', ?, ?, ?)"
);
// placeholders: rental_code(s) equip(s) owner(s) renter(s) start(s) end(s) cost(d) paid_at(s) created(s) updated(s)
// = sssssd sss = 10 params

foreach ($transactions as [$equip, $renter, $start, $end, $daily]) {
    $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
    $next_id++;

    // days inclusive
    $days = (int)((strtotime($end) - strtotime($start)) / 86400) + 1;
    $total = $daily * $days;
    $paid_at  = date('Y-m-d', strtotime($end . ' +1 day')) . ' 10:00:00';
    $booked_at = date('Y-m-d', strtotime($start . ' -2 days')) . ' 09:00:00';

    $ins_tx->bind_param('ssssssdss s',
        $rental_code, $equip, $owner, $renter,
        $start, $end, $total,
        $paid_at, $booked_at, $paid_at
    );
    // rewrite cleanly
    $ins_tx->close();
    $ins_tx = $conn->prepare(
        "INSERT INTO machinery_rentals
            (rental_code, equipment_name, owner_name, renter_name, start_date, end_date,
             total_cost, rental_status, payment_status, payment_marked_at, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'returned', 'paid', ?, ?, ?)"
    );
    $ins_tx->bind_param('ssssssdsss',
        $rental_code, $equip, $owner, $renter,
        $start, $end, $total,
        $paid_at, $booked_at, $paid_at
    );
    if (!$ins_tx->execute()) {
        echo "FAILED tx ($equip / $renter): " . $ins_tx->error . "\n";
        exit(1);
    }
    $rid = $conn->insert_id;
    echo "Tx #$rid ($rental_code): $equip | $renter | $start – $end ($days days) | P$total | paid $paid_at\n";
}
$ins_tx->close();

echo "\n── Done. Total rows: ";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals");
echo $r->fetch_assoc()['c'] . "\n";
echo "── Listings (available): ";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals WHERE TRIM(renter_name)='' AND rental_status='pending'");
echo $r->fetch_assoc()['c'] . "\n";
echo "── Transactions (returned/paid): ";
$r = $conn->query("SELECT COUNT(*) AS c FROM machinery_rentals WHERE rental_status='returned' AND payment_status='paid'");
echo $r->fetch_assoc()['c'] . "\n";
