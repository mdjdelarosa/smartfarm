<!-- Google Maps Location Picker Component -->
<!-- Include this in your form and initialize with JavaScript -->

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="../css/maps.css">

<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo htmlspecialchars(getenv('GOOGLE_MAPS_API_KEY') ?: 'YOUR_API_KEY'); ?>&libraries=places,geocoder"></script>

<script>
/**
 * LocationPicker - Interactive Google Maps location picker
 * Usage:
 *   const picker = new LocationPicker('map-container-id', {
 *       defaultLat: 12.8766,
 *       defaultLng: 121.7740,
 *       latInputId: 'farmer_home_latitude',
 *       lngInputId: 'farmer_home_longitude',
 *       addressInputId: 'farmer_home_address'
 *   });
 */

class LocationPicker {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Container with ID "${containerId}" not found`);
            return;
        }
        
        this.options = {
            defaultLat: options.defaultLat || 12.8766,  // Philippines default
            defaultLng: options.defaultLng || 121.7740,
            zoom: options.zoom || 13,
            latInputId: options.latInputId,
            lngInputId: options.lngInputId,
            addressInputId: options.addressInputId,
            onLocationChanged: options.onLocationChanged || (() => {})
        };
        
        this.marker = null;
        this.map = null;
        this.geocoder = null;
        this.infoWindow = null;
        
        this.init();
    }
    
    init() {
        // Initialize map
        this.map = new google.maps.Map(this.container, {
            center: { lat: this.options.defaultLat, lng: this.options.defaultLng },
            zoom: this.options.zoom,
            mapTypeControl: true,
            fullscreenControl: true,
            streetViewControl: true
        });
        
        this.geocoder = new google.maps.Geocoder();
        this.infoWindow = new google.maps.InfoWindow();
        
        // Add marker at default location
        this.addMarker(this.options.defaultLat, this.options.defaultLng);
        
        // Load existing coordinates from form fields
        const savedLat = document.getElementById(this.options.latInputId)?.value;
        const savedLng = document.getElementById(this.options.lngInputId)?.value;
        if (savedLat && savedLng) {
            const lat = parseFloat(savedLat);
            const lng = parseFloat(savedLng);
            this.map.setCenter({ lat, lng });
            this.addMarker(lat, lng);
        }
        
        // Click handler for map
        this.map.addListener('click', (e) => {
            this.addMarker(e.latLng.lat(), e.latLng.lng());
        });
    }
    
    addMarker(lat, lng) {
        // Remove existing marker
        if (this.marker) {
            this.marker.setMap(null);
        }
        
        // Create new marker
        this.marker = new google.maps.Marker({
            position: { lat, lng },
            map: this.map,
            draggable: true,
            title: 'Drag to move or click map'
        });
        
        // Update form fields
        this.updateCoordinates(lat, lng);
        
        // Reverse geocode and update address
        this.reverseGeocode(lat, lng);
        
        // Drag handler
        this.marker.addListener('dragend', () => {
            const pos = this.marker.getPosition();
            this.updateCoordinates(pos.lat(), pos.lng());
            this.reverseGeocode(pos.lat(), pos.lng());
        });
        
        // Center map on marker
        this.map.setCenter({ lat, lng });
    }
    
    updateCoordinates(lat, lng) {
        const latInput = document.getElementById(this.options.latInputId);
        const lngInput = document.getElementById(this.options.lngInputId);
        
        if (latInput) latInput.value = lat.toFixed(8);
        if (lngInput) lngInput.value = lng.toFixed(8);
        
        // Trigger callback
        this.options.onLocationChanged({ lat, lng });
    }
    
    reverseGeocode(lat, lng) {
        this.geocoder.geocode({ location: { lat, lng } }, (results, status) => {
            if (status === 'OK' && results[0]) {
                const address = results[0].formatted_address;
                const addressInput = document.getElementById(this.options.addressInputId);
                
                if (addressInput) {
                    addressInput.value = address;
                }
                
                // Show address in info window
                this.infoWindow.setContent(`
                    <div style="padding: 8px;">
                        <strong>${address}</strong><br>
                        <small>${lat.toFixed(6)}, ${lng.toFixed(6)}</small>
                    </div>
                `);
                this.infoWindow.open(this.map, this.marker);
            }
        });
    }
    
    // Search for location by address
    searchAddress(address) {
        this.geocoder.geocode({ address }, (results, status) => {
            if (status === 'OK' && results[0]) {
                const loc = results[0].geometry.location;
                this.addMarker(loc.lat(), loc.lng());
            }
        });
    }
    
    // Get current coordinates
    getCoordinates() {
        return {
            lat: parseFloat(document.getElementById(this.options.latInputId)?.value || 0),
            lng: parseFloat(document.getElementById(this.options.lngInputId)?.value || 0)
        };
    }
}

// Global pickers object
const mapPickers = {};

// Initialize picker
function initLocationPicker(containerId, options) {
    mapPickers[containerId] = new LocationPicker(containerId, options);
    return mapPickers[containerId];
}
</script>
