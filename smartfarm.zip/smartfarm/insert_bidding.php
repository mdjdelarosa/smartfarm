<?php
require 'config.php';

/*
 * Insert historical bidding transactions (Sep 2025 – Mar 2026)
 * 14 lots, each with 1 winner + 1–2 outbid bids
 * Inventory is deducted from source crops
 */

$farmer_id = 9; // admin farmer profile

// [source_crop_id, crop_name, qty, unit, market_price, starting_price, listed_at, end_at, paid_at, winner_client_id, winner_bid, outbids]
// outbids: array of [client_id, bid_amount]
$lots = [
    // Sep 2025
    [1, 'Palay',      20, 'kg',  25.00,   450.00, '2025-09-05 08:00:00', '2025-09-10 18:00:00', '2025-09-12 10:00:00', 1,  580.00, [[2,  500.00]]],
    [2, 'Corn',       15, 'kg',  22.00,   300.00, '2025-09-15 08:00:00', '2025-09-20 18:00:00', '2025-09-22 10:00:00', 3,  420.00, [[4,  350.00]]],
    // Oct 2025
    [3, 'Tomato',     10, 'kg',  60.00,   550.00, '2025-09-28 08:00:00', '2025-10-05 18:00:00', '2025-10-07 10:00:00', 2,  720.00, [[5,  600.00]]],
    [9, 'Onion',      15, 'kg',  90.00,  1200.00, '2025-10-10 08:00:00', '2025-10-18 18:00:00', '2025-10-20 10:00:00', 4, 1500.00, [[6, 1320.00],[7, 1250.00]]],
    // Nov 2025
    [4, 'Eggplant',   10, 'kg',  50.00,   450.00, '2025-10-25 08:00:00', '2025-11-03 18:00:00', '2025-11-05 10:00:00', 5,  620.00, [[1,  520.00]]],
    [8, 'Carrot',     12, 'kg',  55.00,   600.00, '2025-11-08 08:00:00', '2025-11-15 18:00:00', '2025-11-17 10:00:00', 6,  800.00, [[3,  700.00]]],
    // Dec 2025
    [6, 'Chili',       5, 'kg', 120.00,   550.00, '2025-11-25 08:00:00', '2025-12-02 18:00:00', '2025-12-04 10:00:00', 7,  720.00, [[2,  620.00]]],
    [7, 'Cucumber',    8, 'kg',  45.00,   320.00, '2025-12-12 08:00:00', '2025-12-20 18:00:00', '2025-12-22 10:00:00', 1,  480.00, [[4,  400.00]]],
    // Jan 2026
    [5, 'Lettuce',     8, 'kg',  70.00,   500.00, '2026-01-03 08:00:00', '2026-01-08 18:00:00', '2026-01-10 10:00:00', 2,  680.00, [[5,  580.00]]],
    [10,'Watermelon', 20, 'kg',  30.00,   550.00, '2026-01-15 08:00:00', '2026-01-22 18:00:00', '2026-01-24 10:00:00', 3,  750.00, [[6,  650.00]]],
    // Feb 2026
    [1, 'Palay',      15, 'kg',  25.00,   350.00, '2026-01-30 08:00:00', '2026-02-05 18:00:00', '2026-02-07 10:00:00', 4,  500.00, [[7,  420.00]]],
    [2, 'Corn',       12, 'kg',  22.00,   240.00, '2026-02-13 08:00:00', '2026-02-20 18:00:00', '2026-02-22 10:00:00', 5,  380.00, [[1,  300.00]]],
    // Mar 2026
    [8, 'Carrot',     10, 'kg',  55.00,   500.00, '2026-03-02 08:00:00', '2026-03-08 18:00:00', '2026-03-10 10:00:00', 6,  700.00, [[2,  580.00]]],
    [9, 'Onion',      12, 'kg',  90.00,   900.00, '2026-03-18 08:00:00', '2026-03-25 18:00:00', '2026-03-27 10:00:00', 7, 1200.00, [[3, 1000.00],[4,  950.00]]],
];

$insert_lot = $conn->prepare(
    "INSERT INTO crops (farmer_id, crop_name, crop_quantity, crop_unit, market_price_per_unit, starting_price, source_crop_id, inventory_deducted_on_claim, crop_status, bidding_end_date, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'sold', ?, 'paid', ?, ?, ?)"
);
$insert_bid = $conn->prepare(
    "INSERT INTO bids (crop_id, client_id, bid_amount, bid_status, payment_status, payment_marked_at, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
);
$deduct_inv = $conn->prepare(
    "UPDATE crops SET crop_quantity = crop_quantity - ? WHERE crop_id = ? AND crop_quantity >= ?"
);

foreach ($lots as $i => [$src_id, $name, $qty, $unit, $market, $start, $listed, $ended, $paid, $win_client, $win_bid, $outbids]) {
    $conn->begin_transaction();
    try {
        // 11 ? placeholders: farmer_id(i) name(s) qty(d) unit(s) market(d) start(d) src(i) ended(s) paid(s) listed(s) paid(s)
        $qty_f     = (float)$qty;
        $market_f  = (float)$market;
        $start_f   = (float)$start;
        $insert_lot->bind_param('isdsddissss',
            $farmer_id, $name, $qty_f, $unit, $market_f, $start_f, $src_id,
            $ended, $paid, $listed, $paid
        );
        if (!$insert_lot->execute()) throw new Exception("Lot insert failed: " . $insert_lot->error);
        $lot_id = $conn->insert_id;

        // Deduct from source inventory
        $deduct_inv->bind_param('did', $qty_f, $src_id, $qty_f);
        $deduct_inv->execute();
        if ($deduct_inv->affected_rows <= 0) throw new Exception("Insufficient stock for $name (source crop_id=$src_id)");

        // Insert outbid bids — 8 ? placeholders: crop_id(i) client(i) amount(d) status(s) pay_status(s) pay_at(s) created(s) updated(s)
        $s_outbid  = 'outbid';
        $s_unpaid  = 'unpaid';
        $null_date = null;
        foreach ($outbids as $j => [$ob_client, $ob_amount]) {
            $ob_time   = date('Y-m-d H:i:s', strtotime($listed) + ($j + 1) * 7200);
            $ob_amount_f = (float)$ob_amount;
            $insert_bid->bind_param('iidsssss',
                $lot_id, $ob_client, $ob_amount_f,
                $s_outbid, $s_unpaid, $null_date,
                $ob_time, $ob_time
            );
            if (!$insert_bid->execute()) throw new Exception("Outbid insert failed: " . $insert_bid->error);
        }

        // Insert winning bid (created 1 hour before close)
        $s_won     = 'won';
        $s_paid    = 'paid';
        $win_time  = date('Y-m-d H:i:s', strtotime($ended) - 3600);
        $win_bid_f = (float)$win_bid;
        $insert_bid->bind_param('iidsssss',
            $lot_id, $win_client, $win_bid_f,
            $s_won, $s_paid, $paid,
            $win_time, $paid
        );
        if (!$insert_bid->execute()) throw new Exception("Win bid insert failed: " . $insert_bid->error);

        $conn->commit();
        echo "Lot #$lot_id: $name {$qty}kg — winner bid P{$win_bid} — paid $paid\n";
    } catch (Exception $e) {
        $conn->rollback();
        echo "FAILED ($name): " . $e->getMessage() . "\n";
    }
}

$insert_lot->close();
$insert_bid->close();
$deduct_inv->close();
echo "\nDone. Current inventory:\n";
$r = $conn->query("SELECT crop_id, crop_name, crop_quantity FROM crops WHERE starting_price <= 0 ORDER BY crop_id");
while ($row = $r->fetch_assoc()) {
    echo "  [{$row['crop_id']}] {$row['crop_name']}: {$row['crop_quantity']} kg remaining\n";
}
