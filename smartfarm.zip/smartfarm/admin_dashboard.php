<?php
require 'config.php';

// Check if user is logged in as admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

register_shutdown_function(static function () use ($conn) {
  if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    return;
  }

  $success_message = trim((string)($_SESSION['success'] ?? ''));
  $admin_user_id = (int)($_SESSION['user_id'] ?? 0);
  if ($success_message === '' || $admin_user_id <= 0) {
    return;
  }

  $fingerprint = sha1(($success_message . '|' . (string)($_SERVER['REQUEST_URI'] ?? '')));
  if ((string)($_SESSION['last_admin_success_notice_hash'] ?? '') === $fingerprint) {
    return;
  }

  if (pushUserNotification(
    $conn,
    $admin_user_id,
    'Submission completed',
    $success_message,
    'submission_success',
    null
  )) {
    $_SESSION['last_admin_success_notice_hash'] = $fingerprint;
  }
});

// Resolve current section early so heavy work can be scoped to relevant pages.
$section = $_GET['section'] ?? 'dashboard';
$from_param = $_GET['from'] ?? '';

function ensureScheduleNotificationTables(mysqli $conn): bool {
  $queries = [
    "CREATE TABLE IF NOT EXISTS scheduled_activities (
      activity_id INT NOT NULL AUTO_INCREMENT,
      title VARCHAR(255) NOT NULL,
      category VARCHAR(100) NOT NULL,
      activity_date DATE NOT NULL,
      activity_time TIME NOT NULL,
      location VARCHAR(255) NOT NULL,
      coordinator VARCHAR(255) NOT NULL,
      message TEXT DEFAULT NULL,
      target_farmer TINYINT(1) NOT NULL DEFAULT 0,
      target_client TINYINT(1) NOT NULL DEFAULT 0,
      target_admin TINYINT(1) NOT NULL DEFAULT 0,
      notify_in_app TINYINT(1) NOT NULL DEFAULT 1,
      notify_email TINYINT(1) NOT NULL DEFAULT 1,
      created_by_user_id INT NOT NULL,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (activity_id),
      KEY idx_activity_date (activity_date),
      KEY idx_created_by (created_by_user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci",
    "CREATE TABLE IF NOT EXISTS user_notifications (
      notification_id INT NOT NULL AUTO_INCREMENT,
      user_id INT NOT NULL,
      notification_title VARCHAR(255) NOT NULL,
      notification_message TEXT NOT NULL,
      notification_type VARCHAR(60) NOT NULL DEFAULT 'general',
      related_id INT DEFAULT NULL,
      is_read TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (notification_id),
      KEY idx_user_created (user_id, created_at),
      KEY idx_user_read (user_id, is_read)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci"
  ];

  foreach ($queries as $sql) {
    if (!$conn->query($sql)) {
      return false;
    }
  }

  $required_schedule_columns = [
    'message' => "ALTER TABLE scheduled_activities ADD COLUMN message TEXT DEFAULT NULL",
    'target_farmer' => "ALTER TABLE scheduled_activities ADD COLUMN target_farmer TINYINT(1) NOT NULL DEFAULT 0",
    'target_client' => "ALTER TABLE scheduled_activities ADD COLUMN target_client TINYINT(1) NOT NULL DEFAULT 0",
    'target_admin' => "ALTER TABLE scheduled_activities ADD COLUMN target_admin TINYINT(1) NOT NULL DEFAULT 0",
    'notify_in_app' => "ALTER TABLE scheduled_activities ADD COLUMN notify_in_app TINYINT(1) NOT NULL DEFAULT 1",
    'notify_email' => "ALTER TABLE scheduled_activities ADD COLUMN notify_email TINYINT(1) NOT NULL DEFAULT 1",
    'coordinator' => "ALTER TABLE scheduled_activities ADD COLUMN coordinator VARCHAR(255) NOT NULL DEFAULT ''",
    'created_by_user_id' => "ALTER TABLE scheduled_activities ADD COLUMN created_by_user_id INT NOT NULL DEFAULT 0",
    'recurrence' => "ALTER TABLE scheduled_activities ADD COLUMN recurrence ENUM('none','daily','weekly','biweekly','monthly','yearly') NOT NULL DEFAULT 'none'",
    'notifications_sent' => "ALTER TABLE scheduled_activities ADD COLUMN notifications_sent TINYINT(1) NOT NULL DEFAULT 0"
  ];

  foreach ($required_schedule_columns as $column_name => $alter_sql) {
    $column_check = $conn->query("SHOW COLUMNS FROM scheduled_activities LIKE '" . $conn->real_escape_string($column_name) . "'");
    if (!$column_check) {
      return false;
    }
    if ($column_check->num_rows === 0) {
      if (!$conn->query($alter_sql)) {
        return false;
      }
    }
  }

  return true;
}

function ensureTransactionPaymentTables(mysqli $conn): bool {
  $create_rental_table = "CREATE TABLE IF NOT EXISTS machinery_rentals (
    rental_id INT NOT NULL AUTO_INCREMENT,
    rental_code VARCHAR(20) NOT NULL,
    equipment_name VARCHAR(255) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    machinery_image LONGBLOB NULL,
    machinery_image_name VARCHAR(255) NULL,
    machinery_image_mime_type VARCHAR(50) NULL,
    renter_name VARCHAR(255) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
    rental_status ENUM('pending','approved','in-rental','returned','cancelled') NOT NULL DEFAULT 'pending',
    payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid',
    payment_marked_at DATETIME NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (rental_id),
    UNIQUE KEY uniq_rental_code (rental_code),
    KEY idx_rental_status (rental_status),
    KEY idx_payment_status (payment_status),
    KEY idx_start_date (start_date)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci";

  if (!$conn->query($create_rental_table)) {
    return false;
  }

  if (!$conn->query("ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image LONGBLOB NULL")) {
    return false;
  }
  if (!$conn->query("ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_name VARCHAR(255) NULL")) {
    return false;
  }
  if (!$conn->query("ALTER TABLE machinery_rentals ADD COLUMN IF NOT EXISTS machinery_image_mime_type VARCHAR(50) NULL")) {
    return false;
  }

  $crops_exists = $conn->query("SHOW TABLES LIKE 'crops'");
  if ($crops_exists && $crops_exists->num_rows > 0) {
    if (!$conn->query("ALTER TABLE crops ADD COLUMN IF NOT EXISTS payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid'")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE crops ADD COLUMN IF NOT EXISTS payment_marked_at DATETIME NULL")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE crops ADD COLUMN IF NOT EXISTS market_price_per_unit DECIMAL(10,2) NOT NULL DEFAULT 0")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE crops ADD COLUMN IF NOT EXISTS source_crop_id INT NULL")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE crops ADD COLUMN IF NOT EXISTS inventory_deducted_on_claim TINYINT(1) NOT NULL DEFAULT 0")) {
      return false;
    }

    $crop_status_col = $conn->query("SHOW COLUMNS FROM crops LIKE 'crop_status'");
    if ($crop_status_col && $crop_status_col->num_rows > 0) {
      $crop_status_info = $crop_status_col->fetch_assoc();
      $crop_status_type = strtolower((string)($crop_status_info['Type'] ?? ''));
      if (strpos($crop_status_type, "'claimed'") === false || strpos($crop_status_type, "'returned'") === false) {
        if (!$conn->query("ALTER TABLE crops MODIFY COLUMN crop_status ENUM('available','sold','expired','claimed','returned') NOT NULL DEFAULT 'available'")) {
          return false;
        }
      }
    }
  }

  $reservations_exists = $conn->query("SHOW TABLES LIKE 'livestock_reservations'");
  if ($reservations_exists && $reservations_exists->num_rows > 0) {
    if (!$conn->query("ALTER TABLE livestock_reservations ADD COLUMN IF NOT EXISTS payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid'")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE livestock_reservations ADD COLUMN IF NOT EXISTS payment_marked_at DATETIME NULL")) {
      return false;
    }
  }

  $products_exists = $conn->query("SHOW TABLES LIKE 'livestock_products'");
  if ($products_exists && $products_exists->num_rows > 0) {
    if (!$conn->query("ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image LONGBLOB NULL")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_name VARCHAR(255) NULL")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE livestock_products ADD COLUMN IF NOT EXISTS product_image_mime_type VARCHAR(50) NULL")) {
      return false;
    }
  }

  $bids_exists = $conn->query("SHOW TABLES LIKE 'bids'");
  if ($bids_exists && $bids_exists->num_rows > 0) {
    if (!$conn->query("ALTER TABLE bids ADD COLUMN IF NOT EXISTS payment_status ENUM('unpaid','paid') NOT NULL DEFAULT 'unpaid'")) {
      return false;
    }
    if (!$conn->query("ALTER TABLE bids ADD COLUMN IF NOT EXISTS payment_marked_at DATETIME NULL")) {
      return false;
    }
  }

  $seed_count = 0;
  $count_result = $conn->query("SELECT COUNT(*) AS cnt FROM machinery_rentals");
  if ($count_result) {
    $seed_count = (int)($count_result->fetch_assoc()['cnt'] ?? 0);
  }

  if ($seed_count === 0) {
    $seed_sql = "
      INSERT INTO machinery_rentals
      (rental_code, equipment_name, owner_name, renter_name, start_date, end_date, total_cost, rental_status, payment_status)
      VALUES
      ('#REN001', 'Four-Wheel Tractor', 'Juan Dela Cruz', 'Roberto Cruz', '2026-03-16', '2026-03-18', 12000.00, 'pending', 'unpaid'),
      ('#REN002', 'Combine Harvester', 'Pedro Reyes', 'Ana Reyes', '2026-03-15', '2026-03-17', 8500.00, 'approved', 'unpaid'),
      ('#REN003', 'Rice Transplanter', 'Mario Santos', 'Carlo Rivera', '2026-03-13', '2026-03-16', 6300.00, 'in-rental', 'unpaid'),
      ('#REN004', 'Hand Tractor', 'Lito Mendoza', 'Keisha Lim', '2026-03-10', '2026-03-12', 4100.00, 'returned', 'paid'),
      ('#REN005', 'Water Pump', 'Elena Torres', 'Paolo Garcia', '2026-03-14', '2026-03-15', 2700.00, 'cancelled', 'unpaid')
    ";
    if (!$conn->query($seed_sql)) {
      return false;
    }
  }

  return true;
}

function dashboardEnsureReturnedMachineryStockRows(mysqli $conn): void {
  $missing_sql = "
    SELECT r.equipment_name, r.owner_name, r.machinery_image, r.machinery_image_name, r.machinery_image_mime_type, r.total_cost
    FROM machinery_rentals r
    INNER JOIN (
      SELECT equipment_name, owner_name, MAX(rental_id) AS latest_rental_id
      FROM machinery_rentals
      WHERE rental_status = 'returned'
      GROUP BY equipment_name, owner_name
    ) latest ON latest.latest_rental_id = r.rental_id
    WHERE NOT EXISTS (
      SELECT 1
      FROM machinery_rentals s
      WHERE s.equipment_name = r.equipment_name
        AND s.owner_name = r.owner_name
        AND COALESCE(TRIM(s.renter_name), '') = ''
        AND s.rental_status IN ('pending', 'approved')
    )";

  $missing_result = $conn->query($missing_sql);
  if (!$missing_result || $missing_result->num_rows === 0) {
    return;
  }

  $next_id_result = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS next_id FROM machinery_rentals");
  $next_id = 1;
  if ($next_id_result) {
    $next_id_row = $next_id_result->fetch_assoc();
    $next_id = (int)($next_id_row['next_id'] ?? 1);
  }

  $insert_stmt = $conn->prepare(
    "INSERT INTO machinery_rentals
      (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, renter_name, start_date, end_date, total_cost, rental_status, payment_status, payment_marked_at)
     VALUES
      (?, ?, ?, ?, ?, ?, '', CURDATE(), CURDATE(), ?, 'pending', 'unpaid', NULL)"
  );
  if (!$insert_stmt) {
    return;
  }

  while ($row = $missing_result->fetch_assoc()) {
    $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
    $next_id++;

    $equipment_name = (string)($row['equipment_name'] ?? '');
    $owner_name = (string)($row['owner_name'] ?? '');
    $machinery_image = $row['machinery_image'] ?? null;
    $machinery_image_name = $row['machinery_image_name'] ?? null;
    $machinery_image_mime = $row['machinery_image_mime_type'] ?? null;
    $total_cost = (float)($row['total_cost'] ?? 0);

    if ($equipment_name === '' || $owner_name === '' || $total_cost <= 0) {
      continue;
    }

    $insert_stmt->bind_param(
      'ssssssd',
      $rental_code,
      $equipment_name,
      $owner_name,
      $machinery_image,
      $machinery_image_name,
      $machinery_image_mime,
      $total_cost
    );
    $insert_stmt->execute();
  }

  $insert_stmt->close();
}

function dashboardReadUploadedImage(string $field_name): array {
  if (!isset($_FILES[$field_name]) || !is_array($_FILES[$field_name])) {
    return ['has_file' => false];
  }

  $file = $_FILES[$field_name];
  $error_code = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);

  if ($error_code === UPLOAD_ERR_NO_FILE) {
    return ['has_file' => false];
  }

  if ($error_code !== UPLOAD_ERR_OK) {
    return ['has_file' => true, 'error' => 'Image upload failed. Please try again.'];
  }

  $tmp_name = (string)($file['tmp_name'] ?? '');
  if ($tmp_name === '' || !is_uploaded_file($tmp_name)) {
    return ['has_file' => true, 'error' => 'Invalid uploaded image file.'];
  }

  $file_size = (int)($file['size'] ?? 0);
  $max_size = 5 * 1024 * 1024;
  if ($file_size <= 0 || $file_size > $max_size) {
    return ['has_file' => true, 'error' => 'Image must be 5MB or smaller.'];
  }

  $blob = file_get_contents($tmp_name);
  if ($blob === false) {
    return ['has_file' => true, 'error' => 'Unable to read uploaded image.'];
  }

  $finfo = finfo_open(FILEINFO_MIME_TYPE);
  $mime = $finfo ? (string)finfo_file($finfo, $tmp_name) : '';
  if ($finfo) {
    finfo_close($finfo);
  }

  $allowed_mime = ['image/jpeg', 'image/png'];
  if (!in_array($mime, $allowed_mime, true)) {
    return ['has_file' => true, 'error' => 'Only JPG and PNG images are allowed.'];
  }

  $image_name = trim((string)($file['name'] ?? ''));
  if ($image_name === '') {
    $image_name = 'machinery-image';
  }
  if (strlen($image_name) > 255) {
    $image_name = substr($image_name, 0, 255);
  }

  return [
    'has_file' => true,
    'blob' => $blob,
    'name' => $image_name,
    'mime' => $mime
  ];
}

function dashboardNormalizeCropNameKey(string $crop_name): string {
  $name = strtolower(trim($crop_name));
  $name = preg_replace('/\s*\([^)]*\)\s*/', ' ', $name);
  $name = preg_replace('/\s+/', ' ', $name ?? '');
  $name = trim((string)$name);

  $aliases = [
    'corn maize' => 'corn',
    'maize' => 'corn',
    'corn' => 'corn',
    'tomatoes' => 'tomato',
    'tomato' => 'tomato',
    'onions' => 'onion',
    'onino' => 'onion',
    'onion' => 'onion'
  ];

  if (isset($aliases[$name])) {
    return $aliases[$name];
  }

  return $name;
}

/**
 * Fires pending notifications for any scheduled_activities whose activity_date = today
 * and have not yet had notifications_sent = 1. Safe to call on every page load.
 */
function sendDueActivityNotifications(mysqli $conn): void {
  $tbl = $conn->query("SHOW TABLES LIKE 'scheduled_activities'");
  if (!$tbl || $tbl->num_rows === 0) return;

  $due = $conn->query(
    "SELECT activity_id, title, category, activity_date, activity_time, location, coordinator,
            message, target_farmer, target_client, target_admin, notify_in_app, notify_email,
            recurrence
     FROM scheduled_activities
     WHERE activity_date = CURDATE()
       AND notifications_sent = 0
       AND (notify_in_app = 1 OR notify_email = 1)
     LIMIT 50"
  );
  if (!$due || $due->num_rows === 0) return;

  while ($act = $due->fetch_assoc()) {
    $act_id        = (int)$act['activity_id'];
    $title         = (string)$act['title'];
    $category      = (string)$act['category'];
    $act_date      = (string)$act['activity_date'];
    $act_time      = (string)$act['activity_time'];
    $location      = (string)$act['location'];
    $coordinator   = (string)$act['coordinator'];
    $message       = (string)$act['message'];
    $notify_in_app = (int)$act['notify_in_app'];
    $notify_email  = (int)$act['notify_email'];
    $recurrence    = (string)($act['recurrence'] ?? 'none');

    $date_label = date('M d, Y', strtotime($act_date));
    $time_label = date('h:i A', strtotime($act_time));

    $recurrence_map  = ['daily'=>'daily','weekly'=>'weekly','biweekly'=>'bi-weekly','monthly'=>'monthly','yearly'=>'yearly'];
    $recurrence_lbl  = isset($recurrence_map[$recurrence]) ? $recurrence_map[$recurrence] : '';
    $in_app_title    = 'Activity Reminder: ' . $title . ($recurrence_lbl !== '' ? ' (Repeats ' . ucfirst($recurrence_lbl) . ')' : '');
    $base_msg        = $message !== '' ? $message
      : 'Don\'t forget: "' . $title . '" is scheduled today, ' . $date_label . ' at ' . $time_label . '.';
    $in_app_message  = $base_msg
      . ($recurrence_lbl !== '' ? "\nThis is a recurring " . $recurrence_lbl . " activity." : '')
      . "\n\nDate: " . $date_label . "\nTime: " . $time_label . "\nLocation: " . $location . "\nCoordinator: " . $coordinator;

    // Build recipient list
    $recipient_queries = [];
    if ($act['target_farmer']) {
      $recipient_queries[] = "SELECT u.user_id, u.email, f.farmer_fullname AS fullname FROM users u INNER JOIN farmers f ON f.user_id = u.user_id WHERE u.role='farmer' AND u.is_active=1 AND f.farmer_id_verification_status='approved'";
    }
    if ($act['target_client']) {
      $recipient_queries[] = "SELECT u.user_id, u.email, c.client_fullname AS fullname FROM users u INNER JOIN clients c ON c.user_id = u.user_id WHERE u.role='client' AND u.is_active=1 AND c.client_id_verification_status='approved'";
    }

    $recipients = [];
    foreach ($recipient_queries as $rsql) {
      $rr = $conn->query($rsql);
      if (!$rr) continue;
      while ($row = $rr->fetch_assoc()) {
        $uid = (int)$row['user_id'];
        if ($uid > 0) $recipients[$uid] = ['user_id' => $uid, 'email' => (string)$row['email'], 'fullname' => (string)$row['fullname']];
      }
    }

    if (empty($recipients)) {
      $conn->query("UPDATE scheduled_activities SET notifications_sent = 1 WHERE activity_id = $act_id");
      continue;
    }

    if ($notify_in_app) {
      $ins_n = $conn->prepare("INSERT INTO user_notifications (user_id, notification_title, notification_message, notification_type, related_id) VALUES (?, ?, ?, 'schedule_activity', ?)");
      if ($ins_n) {
        foreach ($recipients as $r) {
          $rid = (int)$r['user_id'];
          $ins_n->bind_param('issi', $rid, $in_app_title, $in_app_message, $act_id);
          $ins_n->execute();
        }
        $ins_n->close();
      }
    }

    if ($notify_email) {
      foreach ($recipients as $r) {
        $to_email = trim($r['email']);
        if (!filter_var($to_email, FILTER_VALIDATE_EMAIL)) continue;
        $rname        = htmlspecialchars($r['fullname'], ENT_QUOTES, 'UTF-8');
        $stitle       = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
        $scategory    = htmlspecialchars($category, ENT_QUOTES, 'UTF-8');
        $slocation    = htmlspecialchars($location, ENT_QUOTES, 'UTF-8');
        $scoordinator = htmlspecialchars($coordinator, ENT_QUOTES, 'UTF-8');
        $smsg         = nl2br(htmlspecialchars($base_msg, ENT_QUOTES, 'UTF-8'));
        $subject      = 'Activity Reminder: ' . $title;
        $body =
          '<div style="font-family:Arial,sans-serif;line-height:1.6;color:#1f2937;">'
          . '<h2 style="margin:0 0 12px;color:#166534;">Activity Reminder</h2>'
          . '<p>Hello ' . $rname . ',</p>'
          . '<p>' . $smsg . '</p>'
          . '<table style="border-collapse:collapse;margin-top:8px;">'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Title:</strong></td><td>' . $stitle . '</td></tr>'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Category:</strong></td><td>' . $scategory . '</td></tr>'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Date:</strong></td><td>' . $date_label . '</td></tr>'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Time:</strong></td><td>' . $time_label . '</td></tr>'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Location:</strong></td><td>' . $slocation . '</td></tr>'
          . '<tr><td style="padding:4px 10px 4px 0;"><strong>Coordinator:</strong></td><td>' . $scoordinator . '</td></tr>'
          . ($recurrence_lbl !== '' ? '<tr><td style="padding:4px 10px 4px 0;"><strong>Recurrence:</strong></td><td>' . htmlspecialchars(ucfirst($recurrence_lbl), ENT_QUOTES, 'UTF-8') . '</td></tr>' : '')
          . '</table>'
          . '<p style="margin-top:14px;">Please log in to Smart Farm for details.</p>'
          . '</div>';
        sendSmartFarmEmail($to_email, $subject, $body);
      }
    }

    $conn->query("UPDATE scheduled_activities SET notifications_sent = 1 WHERE activity_id = $act_id");
  }
}

function sendSmartFarmEmail(string $to, string $subject, string $html): bool {
  $headers = "MIME-Version: 1.0\r\n";
  $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
  $headers .= "From: Smart Farm <no-reply@smartfarm.local>\r\n";
  return @mail($to, $subject, $html, $headers);
}

function dashboardTableExists(mysqli $conn, string $table_name): bool {
  $safe_name = $conn->real_escape_string($table_name);
  $check_result = $conn->query("SHOW TABLES LIKE '" . $safe_name . "'");
  return (bool)($check_result && $check_result->num_rows > 0);
}

function dashboardRelativeTime(int $timestamp): string {
  if ($timestamp <= 0) {
    return '';
  }

  $diff = time() - $timestamp;
  if ($diff < 60) {
    return 'Just now';
  }
  if ($diff < 3600) {
    $minutes = (int)floor($diff / 60);
    return $minutes . ' minute' . ($minutes === 1 ? '' : 's') . ' ago';
  }
  if ($diff < 86400) {
    $hours = (int)floor($diff / 3600);
    return $hours . ' hour' . ($hours === 1 ? '' : 's') . ' ago';
  }
  if ($diff < 604800) {
    $days = (int)floor($diff / 86400);
    return $days . ' day' . ($days === 1 ? '' : 's') . ' ago';
  }

  return date('M d, Y', $timestamp);
}

// Avoid running schema maintenance on every panel load.
// Use both session and a file-based cooldown to prevent repeated heavy ALTER checks.
$schema_ready_file = __DIR__ . '/debug/schema_ready.flag';
$schema_needs_refresh = true;
if (file_exists($schema_ready_file)) {
  $schema_needs_refresh = (time() - (int)filemtime($schema_ready_file)) > 86400;
}

if (empty($_SESSION['sf_schema_ready']) && $schema_needs_refresh) {
  ensureTransactionPaymentTables($conn);
  ensureCropHistoryTable($conn);
  $_SESSION['sf_schema_ready'] = 1;
  @file_put_contents($schema_ready_file, (string)time());
}

if (in_array($section, ['rental-monitor', 'view-machinery-rental', 'add-machinery-listing'], true)) {
  dashboardEnsureReturnedMachineryStockRows($conn);
}

// Auto-finalize any expired bidding lots on every page load
if (dashboardTableExists($conn, 'crops') && dashboardTableExists($conn, 'bids')) {
  finalizeExpiredBiddingLots($conn);
}

// HANDLE FORM SUBMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
  $history_actor_user_id = (int)($_SESSION['user_id'] ?? 0);
  $history_actor_role = 'admin';
  $history_actor_name = getActorDisplayName($conn, $history_actor_user_id, $history_actor_role);
  $crop_history_ready = ensureCropHistoryTable($conn);
    
    // Create New Admin Account
    if ($action === 'create_admin') {
        $fullname = sanitizeInput($_POST['fullname'] ?? '');
        $email = sanitizeInput($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Validation
        $errors = [];
        if (strlen($fullname) < 3) $errors[] = 'Full name must be at least 3 characters';
        if (!isValidEmail($email)) $errors[] = 'Invalid email format';
        if (!isStrongPassword($password)) $errors[] = 'Password must be 8+ chars with uppercase, lowercase, number, and special character';
        if ($password !== $confirm_password) $errors[] = 'Passwords do not match';
        
        if (empty($errors)) {
            // Check if email already exists
            $query = "SELECT admin_id FROM admins WHERE email = ? LIMIT 1";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $email);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                $errors[] = 'Email already exists';
            }
            $stmt->close();
        }
        
        if (empty($errors)) {
            // Create admin account
            $hashed_password = hashPassword($password);
            $query = "INSERT INTO admins (email, password, fullname, is_active) VALUES (?, ?, ?, 1)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('sss', $email, $hashed_password, $fullname);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Admin account created successfully!';
                header('Location: admin_dashboard.php?section=manage-admins');
                exit;
            } else {
                $_SESSION['error'] = 'Failed to create admin account: ' . $conn->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error'] = implode(', ', $errors);
        }
    }
    
    // Toggle Admin Account Status
    elseif ($action === 'toggle_admin_account') {
      $target_user_id = (int)($_POST['user_id'] ?? 0);
      $toggle_type = $_POST['toggle_type'] ?? '';
      $new_status = $toggle_type === 'deactivate' ? 0 : 1;
      $current_admin_user_id = (int)($_SESSION['user_id'] ?? 0);

      if ($target_user_id <= 0 || !in_array($toggle_type, ['activate', 'deactivate'], true)) {
        $_SESSION['error'] = 'Invalid admin account request.';
        header('Location: admin_dashboard.php?section=manage-admins');
        exit;
      }

      if ($target_user_id === $current_admin_user_id && $toggle_type === 'deactivate') {
        $_SESSION['error'] = 'You cannot deactivate your own admin account.';
        header('Location: admin_dashboard.php?section=manage-admins');
        exit;
      }

      $check_admin_stmt = $conn->prepare('SELECT role FROM users WHERE user_id = ? LIMIT 1');
      if ($check_admin_stmt) {
        $check_admin_stmt->bind_param('i', $target_user_id);
        $check_admin_stmt->execute();
        $check_admin_result = $check_admin_stmt->get_result();
        $check_row = $check_admin_result ? $check_admin_result->fetch_assoc() : null;
        $check_admin_stmt->close();

        if (!$check_row || ($check_row['role'] ?? '') !== 'admin') {
          $_SESSION['error'] = 'Selected account is not an admin user.';
          header('Location: admin_dashboard.php?section=manage-admins');
          exit;
        }
      }

      $update_admin_status_stmt = $conn->prepare('UPDATE users SET is_active = ? WHERE user_id = ?');
      if ($update_admin_status_stmt) {
        $update_admin_status_stmt->bind_param('ii', $new_status, $target_user_id);
        if ($update_admin_status_stmt->execute()) {
          $_SESSION['success'] = $toggle_type === 'deactivate'
            ? 'Admin account deactivated successfully.'
            : 'Admin account activated successfully.';
        } else {
          $_SESSION['error'] = 'Failed to update admin status.';
        }
        $update_admin_status_stmt->close();
      } else {
        $_SESSION['error'] = 'Failed to prepare admin status update.';
      }

      header('Location: admin_dashboard.php?section=manage-admins');
      exit;
    }

    // Toggle Farmer/Client Account Status
    elseif ($action === 'toggle_user_account') {
      $target_user_id = (int)($_POST['user_id'] ?? 0);
      $target_role = $_POST['target_role'] ?? '';
      $toggle_type = $_POST['toggle_type'] ?? 'deactivate';
      $new_status = $toggle_type === 'activate' ? 1 : 0;

      if ($target_user_id <= 0 || !in_array($target_role, ['farmer', 'client'], true) || !in_array($toggle_type, ['activate', 'deactivate'], true)) {
        $_SESSION['error'] = 'Invalid account status request.';
        header('Location: admin_dashboard.php?section=dashboard');
        exit;
      }

      $check_user_stmt = $conn->prepare('SELECT role FROM users WHERE user_id = ? LIMIT 1');
      if (!$check_user_stmt) {
        $_SESSION['error'] = 'Failed to verify account role.';
        header('Location: admin_dashboard.php?section=' . ($target_role === 'farmer' ? 'verify-farmers' : 'verify-clients'));
        exit;
      }

      $check_user_stmt->bind_param('i', $target_user_id);
      $check_user_stmt->execute();
      $check_user_result = $check_user_stmt->get_result();
      $check_user_row = $check_user_result ? $check_user_result->fetch_assoc() : null;
      $check_user_stmt->close();

      if (!$check_user_row || ($check_user_row['role'] ?? '') !== $target_role) {
        $_SESSION['error'] = 'Selected account role does not match.';
        header('Location: admin_dashboard.php?section=' . ($target_role === 'farmer' ? 'verify-farmers' : 'verify-clients'));
        exit;
      }

      $toggle_stmt = $conn->prepare('UPDATE users SET is_active = ? WHERE user_id = ?');
      if ($toggle_stmt) {
        $toggle_stmt->bind_param('ii', $new_status, $target_user_id);
        if ($toggle_stmt->execute()) {
          $role_label = ucfirst($target_role);
          $_SESSION['success'] = $toggle_type === 'deactivate'
            ? $role_label . ' account deactivated successfully.'
            : $role_label . ' account activated successfully.';

          pushUserNotification(
            $conn,
            $target_user_id,
            'Account status updated',
            'Your account has been ' . ($new_status === 1 ? 'activated' : 'deactivated') . ' by an administrator.',
            'account_status',
            null
          );
        } else {
          $_SESSION['error'] = 'Failed to update account status.';
        }
        $toggle_stmt->close();
      } else {
        $_SESSION['error'] = 'Failed to prepare account status update.';
      }

      header('Location: admin_dashboard.php?section=' . ($target_role === 'farmer' ? 'verify-farmers' : 'verify-clients'));
      exit;
    }

    // Approve Farmer Account
    elseif ($action === 'approve_farmer') {
        $farmer_id = (int)($_POST['farmer_id'] ?? 0);
        if ($farmer_id > 0) {
        $target_farmer_user_id = 0;
        $farmer_user_stmt = $conn->prepare("SELECT user_id FROM farmers WHERE farmer_id = ? LIMIT 1");
        if ($farmer_user_stmt) {
          $farmer_user_stmt->bind_param('i', $farmer_id);
          $farmer_user_stmt->execute();
          $farmer_user_row = $farmer_user_stmt->get_result()->fetch_assoc();
          $target_farmer_user_id = (int)($farmer_user_row['user_id'] ?? 0);
          $farmer_user_stmt->close();
        }

            $query = "UPDATE farmers SET farmer_is_verified = 1, farmer_id_verification_status = 'approved' WHERE farmer_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $farmer_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Farmer account approved!';
          if ($target_farmer_user_id > 0) {
            pushUserNotification(
              $conn,
              $target_farmer_user_id,
              'Farmer verification approved',
              'Your verification was approved. You can now access all farmer dashboard features.',
              'verification_approved',
              $farmer_id
            );
          }
            } else {
                $_SESSION['error'] = 'Failed to approve farmer account';
            }
            $stmt->close();
        }
        header('Location: admin_dashboard.php?section=verify-farmers');
        exit;
    }
    
    // Reject Farmer Account
    elseif ($action === 'reject_farmer') {
        $farmer_id = (int)($_POST['farmer_id'] ?? 0);
        $reason = sanitizeInput($_POST['reason'] ?? '');
        if ($farmer_id > 0) {
        $target_farmer_user_id = 0;
        $farmer_user_stmt = $conn->prepare("SELECT user_id FROM farmers WHERE farmer_id = ? LIMIT 1");
        if ($farmer_user_stmt) {
          $farmer_user_stmt->bind_param('i', $farmer_id);
          $farmer_user_stmt->execute();
          $farmer_user_row = $farmer_user_stmt->get_result()->fetch_assoc();
          $target_farmer_user_id = (int)($farmer_user_row['user_id'] ?? 0);
          $farmer_user_stmt->close();
        }

            $query = "UPDATE farmers SET farmer_id_verification_status = 'rejected', farmer_id_verification_notes = ? WHERE farmer_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('si', $reason, $farmer_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Farmer account rejected!';
          if ($target_farmer_user_id > 0) {
            $reject_message = 'Your verification was rejected.';
            if (trim($reason) !== '') {
              $reject_message .= ' Reason: ' . trim($reason);
            }
            pushUserNotification(
              $conn,
              $target_farmer_user_id,
              'Farmer verification rejected',
              $reject_message,
              'verification_rejected',
              $farmer_id
            );
          }
            } else {
                $_SESSION['error'] = 'Failed to reject farmer account';
            }
            $stmt->close();
        }
        header('Location: admin_dashboard.php?section=verify-farmers');
        exit;
    }
    
    // Approve Client Account
    elseif ($action === 'approve_client') {
        $client_id = (int)($_POST['client_id'] ?? 0);
        if ($client_id > 0) {
        $target_client_user_id = 0;
        $client_user_stmt = $conn->prepare("SELECT user_id FROM clients WHERE client_id = ? LIMIT 1");
        if ($client_user_stmt) {
          $client_user_stmt->bind_param('i', $client_id);
          $client_user_stmt->execute();
          $client_user_row = $client_user_stmt->get_result()->fetch_assoc();
          $target_client_user_id = (int)($client_user_row['user_id'] ?? 0);
          $client_user_stmt->close();
        }

            $query = "UPDATE clients SET client_is_verified = 1, client_id_verification_status = 'approved' WHERE client_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $client_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Client account approved!';
          if ($target_client_user_id > 0) {
            pushUserNotification(
              $conn,
              $target_client_user_id,
              'Client verification approved',
              'Your verification was approved. You can now access all client dashboard features.',
              'verification_approved',
              $client_id
            );
          }
            } else {
                $_SESSION['error'] = 'Failed to approve client account';
            }
            $stmt->close();
        }
        header('Location: admin_dashboard.php?section=verify-clients');
        exit;
    }
    
    // Reject Client Account
    elseif ($action === 'reject_client') {
        $client_id = (int)($_POST['client_id'] ?? 0);
        $reason = sanitizeInput($_POST['reason'] ?? '');
        if ($client_id > 0) {
        $target_client_user_id = 0;
        $client_user_stmt = $conn->prepare("SELECT user_id FROM clients WHERE client_id = ? LIMIT 1");
        if ($client_user_stmt) {
          $client_user_stmt->bind_param('i', $client_id);
          $client_user_stmt->execute();
          $client_user_row = $client_user_stmt->get_result()->fetch_assoc();
          $target_client_user_id = (int)($client_user_row['user_id'] ?? 0);
          $client_user_stmt->close();
        }

            $query = "UPDATE clients SET client_id_verification_status = 'rejected', client_id_verification_notes = ? WHERE client_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('si', $reason, $client_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Client account rejected!';
          if ($target_client_user_id > 0) {
            $reject_message = 'Your verification was rejected.';
            if (trim($reason) !== '') {
              $reject_message .= ' Reason: ' . trim($reason);
            }
            pushUserNotification(
              $conn,
              $target_client_user_id,
              'Client verification rejected',
              $reject_message,
              'verification_rejected',
              $client_id
            );
          }
            } else {
                $_SESSION['error'] = 'Failed to reject client account';
            }
            $stmt->close();
        }
        header('Location: admin_dashboard.php?section=verify-clients');
        exit;
    }
    
    // Deactivate Account
    elseif ($action === 'deactivate_account') {
        $account_type = $_POST['account_type'] ?? '';
        $account_id = (int)($_POST['account_id'] ?? 0);
      $target_user_id = 0;
        
        if ($account_type === 'farmer' && $account_id > 0) {
        $lookup_stmt = $conn->prepare("SELECT user_id FROM farmers WHERE farmer_id = ? LIMIT 1");
        if ($lookup_stmt) {
          $lookup_stmt->bind_param('i', $account_id);
          $lookup_stmt->execute();
          $lookup_row = $lookup_stmt->get_result()->fetch_assoc();
          $target_user_id = (int)($lookup_row['user_id'] ?? 0);
          $lookup_stmt->close();
        }

            $query = "UPDATE farmers SET farmer_is_active = 0 WHERE farmer_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $account_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Farmer account deactivated!';
          if ($target_user_id > 0) {
            pushUserNotification(
              $conn,
              $target_user_id,
              'Account deactivated',
              'Your account has been deactivated by an administrator.',
              'account_status',
              $account_id
            );
          }
            }
            $stmt->close();
        } elseif ($account_type === 'client' && $account_id > 0) {
        $lookup_stmt = $conn->prepare("SELECT user_id FROM clients WHERE client_id = ? LIMIT 1");
        if ($lookup_stmt) {
          $lookup_stmt->bind_param('i', $account_id);
          $lookup_stmt->execute();
          $lookup_row = $lookup_stmt->get_result()->fetch_assoc();
          $target_user_id = (int)($lookup_row['user_id'] ?? 0);
          $lookup_stmt->close();
        }

            $query = "UPDATE clients SET client_is_active = 0 WHERE client_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('i', $account_id);
            if ($stmt->execute()) {
                $_SESSION['success'] = 'Client account deactivated!';
          if ($target_user_id > 0) {
            pushUserNotification(
              $conn,
              $target_user_id,
              'Account deactivated',
              'Your account has been deactivated by an administrator.',
              'account_status',
              $account_id
            );
          }
            }
            $stmt->close();
        }
        
        $section = $account_type === 'farmer' ? 'verify-farmers' : 'verify-clients';
        header('Location: admin_dashboard.php?section=' . $section);
        exit;
    }

      // Publish Schedule Activity and notify selected participants
      elseif ($action === 'publish_schedule_activity') {

        $title = trim($_POST['activityTitle'] ?? '');
        $category = trim($_POST['activityCategory'] ?? 'General');
        $activity_date = trim($_POST['activityDate'] ?? '');
        $activity_time = trim($_POST['activityTime'] ?? '');
        $location = trim($_POST['activityLocation'] ?? '');
        $coordinator = trim($_POST['activityCoordinator'] ?? '');
        $message = trim($_POST['activityMessage'] ?? '');
        $recurrence = 'none';

        $audience_input = $_POST['audience'] ?? [];
        $audience_input = is_array($audience_input) ? $audience_input : [];
        $audiences = array_values(array_intersect($audience_input, ['farmer', 'client']));

        $errors = [];
        if ($title === '') { $errors[] = 'Activity title is required.'; }
        if ($activity_date === '') { $errors[] = 'Activity date is required.'; }
        if ($activity_time === '') { $errors[] = 'Activity time is required.'; }
        if ($location === '') { $errors[] = 'Activity location is required.'; }
        if ($coordinator === '') { $errors[] = 'Coordinator is required.'; }
        if (empty($audiences)) { $errors[] = 'Select at least one target audience.'; }

        $activity_stamp = strtotime($activity_date . ' ' . $activity_time);
        if ($activity_stamp === false) {
          $errors[] = 'Invalid schedule date/time.';
        } elseif ($activity_stamp < time()) {
          $errors[] = 'Activity date and time must not be in the past.';
        }

        if (!ensureScheduleNotificationTables($conn)) {
          $errors[] = 'Failed to prepare schedule and notification tables.';
        }

        if (!empty($errors)) {
          $_SESSION['error'] = implode(' ', $errors);
          header('Location: admin_dashboard.php?section=schedule');
          exit;
        }

        $target_farmer = in_array('farmer', $audiences, true) ? 1 : 0;
        $target_client = in_array('client', $audiences, true) ? 1 : 0;
        $target_admin = 0;
        $notify_in_app = 1;
        $notify_email = 1;
        $created_by_user_id = (int)($_SESSION['user_id'] ?? 0);

        $date_label = date('M d, Y', strtotime($activity_date));
        $time_label = date('h:i A', strtotime($activity_time));
        $base_message = $message !== ''
          ? $message
          : ('You are invited to participate in "' . $title . '" on ' . $date_label . ' at ' . $time_label . '.');
        $in_app_title = 'New Activity: ' . $title;
        $in_app_message = $base_message
          . "\n\nDate: " . $date_label . "\nTime: " . $time_label . "\nLocation: " . $location . "\nCoordinator: " . $coordinator;

        $recipients = [];
        $in_app_count = 0;
        $email_count = 0;
        $activity_id = 0;

        $conn->begin_transaction();
        try {
          $insert_activity = $conn->prepare(
            "INSERT INTO scheduled_activities (
              title, category, activity_date, activity_time, location, coordinator, message,
              target_farmer, target_client, target_admin, notify_in_app, notify_email, created_by_user_id, recurrence
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
          );
          if (!$insert_activity) {
            throw new RuntimeException('Unable to prepare schedule insert.');
          }

          $insert_activity->bind_param(
            'sssssssiiiiiis',
            $title,
            $category,
            $activity_date,
            $activity_time,
            $location,
            $coordinator,
            $message,
            $target_farmer,
            $target_client,
            $target_admin,
            $notify_in_app,
            $notify_email,
            $created_by_user_id,
            $recurrence
          );

          if (!$insert_activity->execute()) {
            throw new RuntimeException('Failed to save scheduled activity.');
          }
          $activity_id = (int)$conn->insert_id;
          $insert_activity->close();

          $recipient_queries = [];
          if ($target_farmer === 1) {
            $recipient_queries[] = "
              SELECT u.user_id, u.email, f.farmer_fullname AS fullname
              FROM users u
              INNER JOIN farmers f ON f.user_id = u.user_id
              WHERE u.role = 'farmer'
                AND u.is_active = 1
                AND f.farmer_id_verification_status = 'approved'
            ";
          }
          if ($target_client === 1) {
            $recipient_queries[] = "
              SELECT u.user_id, u.email, c.client_fullname AS fullname
              FROM users u
              INNER JOIN clients c ON c.user_id = u.user_id
              WHERE u.role = 'client'
                AND u.is_active = 1
                AND c.client_id_verification_status = 'approved'
            ";
          }

          foreach ($recipient_queries as $recipient_sql) {
            $recipient_result = $conn->query($recipient_sql);
            if (!$recipient_result) {
              continue;
            }
            while ($recipient_row = $recipient_result->fetch_assoc()) {
              $recipient_user_id = (int)($recipient_row['user_id'] ?? 0);
              if ($recipient_user_id <= 0) {
                continue;
              }
              $recipients[$recipient_user_id] = [
                'user_id' => $recipient_user_id,
                'email' => (string)($recipient_row['email'] ?? ''),
                'fullname' => (string)($recipient_row['fullname'] ?? 'Member')
              ];
            }
          }

          // --- BATCH INSERT NOTIFICATIONS ---
          if ($notify_in_app === 1 && !empty($recipients)) {
            $values = [];
            $types = '';
            $params = [];
            foreach ($recipients as $recipient) {
              $values[] = '(?, ?, ?, \'schedule_activity\', ?)';
              $types .= 'issi';
              $params[] = $recipient['user_id'];
              $params[] = $in_app_title;
              $params[] = $in_app_message;
              $params[] = $activity_id;
            }
            if (!empty($values)) {
              $sql = 'INSERT INTO user_notifications (user_id, notification_title, notification_message, notification_type, related_id) VALUES ' . implode(',', $values);
              $stmt = $conn->prepare($sql);
              if ($stmt) {
                $stmt->bind_param(str_repeat('issi', count($recipients)), ...$params);
                if ($stmt->execute()) {
                  $in_app_count = $stmt->affected_rows;
                }
                $stmt->close();
              }
            }
          }

          // Mark as notifications sent
          if ($activity_id > 0) {
            $conn->query("UPDATE scheduled_activities SET notifications_sent = 1 WHERE activity_id = $activity_id");
          }

          $conn->commit();
        } catch (Throwable $e) {
          $conn->rollback();
          $_SESSION['error'] = 'Failed to publish activity: ' . $e->getMessage();
          header('Location: admin_dashboard.php?section=schedule');
          exit;
        }

        // --- DEFER EMAIL SENDING UNTIL AFTER COMMIT ---
        $email_count = 0;
        if ($notify_email === 1 && !empty($recipients)) {
          foreach ($recipients as $recipient) {
            $recipient_email = trim((string)($recipient['email'] ?? ''));
            if (!isValidEmail($recipient_email)) {
              continue;
            }

            $recipient_name = htmlspecialchars((string)($recipient['fullname'] ?? 'Member'), ENT_QUOTES, 'UTF-8');
            $safe_title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
            $safe_category = htmlspecialchars($category, ENT_QUOTES, 'UTF-8');
            $safe_location = htmlspecialchars($location, ENT_QUOTES, 'UTF-8');
            $safe_coordinator = htmlspecialchars($coordinator, ENT_QUOTES, 'UTF-8');
            $safe_message = nl2br(htmlspecialchars($base_message, ENT_QUOTES, 'UTF-8'));

            $email_subject = 'Smart Farm Activity Notice: ' . $title;
            $email_body =
              '<div style="font-family:Arial,sans-serif;line-height:1.6;color:#1f2937;">' .
              '<h2 style="margin:0 0 12px;color:#166534;">New Scheduled Activity</h2>' .
              '<p>Hello ' . $recipient_name . ',</p>' .
              '<p>' . $safe_message . '</p>' .
              '<table style="border-collapse:collapse;margin-top:8px;">' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Title:</strong></td><td style="padding:4px 0;">' . $safe_title . '</td></tr>' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Category:</strong></td><td style="padding:4px 0;">' . $safe_category . '</td></tr>' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Date:</strong></td><td style="padding:4px 0;">' . $date_label . '</td></tr>' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Time:</strong></td><td style="padding:4px 0;">' . $time_label . '</td></tr>' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Location:</strong></td><td style="padding:4px 0;">' . $safe_location . '</td></tr>' .
              '<tr><td style="padding:4px 10px 4px 0;"><strong>Coordinator:</strong></td><td style="padding:4px 0;">' . $safe_coordinator . '</td></tr>' .
              '</table>' .
              '<p style="margin-top:14px;">Please log in to Smart Farm for details and updates.</p>' .
              '</div>';

            if (sendSmartFarmEmail($recipient_email, $email_subject, $email_body)) {
              $email_count++;
            }
          }
        }

        $success_parts = ['Activity published successfully.'];
        $success_parts[] = 'Recipients: ' . count($recipients) . '. In-app: ' . $in_app_count . '. Emails: ' . $email_count . '.';
        $_SESSION['success'] = implode(' ', $success_parts);
        header('Location: admin_dashboard.php?section=schedule');
        exit;
      }

      // Add Crop Record (Admin)
      elseif ($action === 'add_crop_record') {
        $farmer_input = 'admin';
        $farmer_id = 0;
        $crop_name = trim($_POST['crop_name'] ?? '');
        $crop_description = trim($_POST['crop_description'] ?? '');
        $crop_quantity = (float)($_POST['crop_quantity'] ?? 0);
        $crop_unit = strtolower(trim($_POST['crop_unit'] ?? 'kg'));
        $allowed_weight_units = ['kg', 'g', 'ton'];
        $market_price_per_unit = (float)($_POST['market_price_per_unit'] ?? 0);

        $errors = [];

        $table_check = $conn->query("SHOW TABLES LIKE 'crops'");
        if (!$table_check || $table_check->num_rows === 0) {
          $errors[] = 'Crops table not found. Run bidding tables setup first.';
        }

        if ($crop_name === '') {
          $errors[] = 'Crop name is required.';
        }

        if ($crop_quantity <= 0) {
          $errors[] = 'Quantity must be greater than zero.';
        }

        if ($crop_unit === '') {
          $errors[] = 'Unit is required.';
        } elseif (!in_array($crop_unit, $allowed_weight_units, true)) {
          $errors[] = 'Please use a weight-based unit only (kg, g, or ton).';
        }

        if ($market_price_per_unit <= 0) {
          $errors[] = 'Market price per unit must be greater than zero.';
        }

        if (empty($errors)) {
          if ($farmer_input === 'admin' || $farmer_input === '') {
            $admin_user_id = (int)($_SESSION['user_id'] ?? 0);

            if ($admin_user_id <= 0) {
              $errors[] = 'Unable to identify current admin account.';
            } else {
              $find_farmer_stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE user_id = ? LIMIT 1");
              if ($find_farmer_stmt) {
                $find_farmer_stmt->bind_param('i', $admin_user_id);
                $find_farmer_stmt->execute();
                $farmer_lookup = $find_farmer_stmt->get_result();
                $farmer_row = $farmer_lookup ? $farmer_lookup->fetch_assoc() : null;
                $find_farmer_stmt->close();

                if ($farmer_row) {
                  $farmer_id = (int)$farmer_row['farmer_id'];
                } else {
                  $admin_name = 'Admin Entry';
                  $admin_name_stmt = $conn->prepare("SELECT fullname FROM admins WHERE user_id = ? LIMIT 1");
                  if ($admin_name_stmt) {
                    $admin_name_stmt->bind_param('i', $admin_user_id);
                    $admin_name_stmt->execute();
                    $admin_name_result = $admin_name_stmt->get_result();
                    $admin_name_row = $admin_name_result ? $admin_name_result->fetch_assoc() : null;
                    if ($admin_name_row && !empty($admin_name_row['fullname'])) {
                      $admin_name = $admin_name_row['fullname'];
                    }
                    $admin_name_stmt->close();
                  }

                  $create_farmer_stmt = $conn->prepare(
                    "INSERT INTO farmers (user_id, farmer_fullname, farmer_contact_number, farmer_farm_name, farmer_id_verification_status, farmer_is_verified) VALUES (?, ?, 'N/A', 'Admin Managed Crops', 'approved', 1)"
                  );
                  if ($create_farmer_stmt) {
                    $create_farmer_stmt->bind_param('is', $admin_user_id, $admin_name);
                    if ($create_farmer_stmt->execute()) {
                      $farmer_id = (int)$conn->insert_id;
                    } else {
                      $errors[] = 'Failed to create admin crop profile: ' . $create_farmer_stmt->error;
                    }
                    $create_farmer_stmt->close();
                  } else {
                    $errors[] = 'Failed to prepare admin crop profile creation.';
                  }
                }
              } else {
                $errors[] = 'Failed to validate admin crop profile.';
              }
            }
          } else {
            $farmer_id = (int)$farmer_input;
            if ($farmer_id <= 0) {
              $errors[] = 'Invalid farmer selected.';
            } else {
              $farmer_check_stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE farmer_id = ? LIMIT 1");
              if ($farmer_check_stmt) {
                $farmer_check_stmt->bind_param('i', $farmer_id);
                $farmer_check_stmt->execute();
                $farmer_exists = $farmer_check_stmt->get_result()->num_rows > 0;
                $farmer_check_stmt->close();

                if (!$farmer_exists) {
                  $errors[] = 'Selected farmer does not exist.';
                }
              } else {
                $errors[] = 'Failed to validate selected farmer.';
              }
            }
          }
        }

        if (empty($errors)) {
          $existing_crop = null;
          $operation_error = '';
          $incoming_crop_key = dashboardNormalizeCropNameKey($crop_name);
          $existing_stmt = $conn->prepare(
            "SELECT crop_id, crop_name, crop_quantity, crop_description, market_price_per_unit
             FROM crops
             WHERE starting_price <= 0
               AND crop_unit = ?
             ORDER BY crop_id DESC"
          );

          if ($existing_stmt) {
            $existing_stmt->bind_param('s', $crop_unit);
            $existing_stmt->execute();
            $existing_result = $existing_stmt->get_result();
            if ($existing_result) {
              while ($candidate = $existing_result->fetch_assoc()) {
                $candidate_key = dashboardNormalizeCropNameKey((string)($candidate['crop_name'] ?? ''));
                if ($candidate_key === $incoming_crop_key) {
                  $existing_crop = $candidate;
                  break;
                }
              }
            }
            $existing_stmt->close();
          } else {
            $operation_error = 'Failed to prepare crop duplication check.';
          }

          if ($operation_error === '') {
            if ($existing_crop) {
              $existing_crop_id = (int)$existing_crop['crop_id'];
              $old_quantity = (float)$existing_crop['crop_quantity'];
              $new_quantity = $old_quantity + $crop_quantity;
              $updated_description = $crop_description !== '' ? $crop_description : (string)($existing_crop['crop_description'] ?? '');

              $update_stmt = $conn->prepare(
                "UPDATE crops
                 SET crop_name = ?, crop_description = ?, crop_quantity = ?, market_price_per_unit = ?
                 WHERE crop_id = ?"
              );

              if ($update_stmt) {
                $update_stmt->bind_param('ssddi', $crop_name, $updated_description, $new_quantity, $market_price_per_unit, $existing_crop_id);
                if ($update_stmt->execute()) {
                  if ($crop_history_ready) {
                    logCropHistoryEvent($conn, [
                      'crop_id' => $existing_crop_id,
                      'farmer_id' => $farmer_id,
                      'changed_by_user_id' => $history_actor_user_id,
                      'actor_role' => $history_actor_role,
                      'actor_name' => $history_actor_name,
                      'event_type' => 'crop_updated',
                      'old_quantity' => $old_quantity,
                      'new_quantity' => $new_quantity,
                      'quantity_delta' => $crop_quantity,
                      'crop_name' => $crop_name,
                      'crop_unit' => $crop_unit,
                      'remarks' => 'Existing crop quantity increased by ' . number_format($crop_quantity, 2) . ' from Manage Crops add form. Market price set to PHP ' . number_format($market_price_per_unit, 2) . ' per ' . $crop_unit . '.'
                    ]);
                  }
                  $_SESSION['success'] = 'Existing crop record updated. Quantity was added instead of creating a duplicate entry.';
                } else {
                  $_SESSION['error'] = 'Failed to update existing crop record: ' . $update_stmt->error;
                }
                $update_stmt->close();
              } else {
                $_SESSION['error'] = 'Failed to prepare existing crop update.';
              }
            } else {
              $insert_sql = "
                INSERT INTO crops (
                  farmer_id,
                  crop_name,
                  crop_description,
                  crop_quantity,
                  crop_unit,
                  market_price_per_unit,
                  starting_price,
                  crop_status,
                  bidding_end_date
                ) VALUES (?, ?, ?, ?, ?, ?, 0, 'expired', NOW())
              ";

              $insert_stmt = $conn->prepare($insert_sql);
              if ($insert_stmt) {
                $insert_stmt->bind_param(
                  'issdsd',
                  $farmer_id,
                  $crop_name,
                  $crop_description,
                  $crop_quantity,
                  $crop_unit,
                  $market_price_per_unit
                );

                if ($insert_stmt->execute()) {
                  $new_crop_id = (int)$conn->insert_id;
                  if ($crop_history_ready && $new_crop_id > 0) {
                    logCropHistoryEvent($conn, [
                      'crop_id' => $new_crop_id,
                      'farmer_id' => $farmer_id,
                      'changed_by_user_id' => $history_actor_user_id,
                      'actor_role' => $history_actor_role,
                      'actor_name' => $history_actor_name,
                      'event_type' => 'crop_created',
                      'old_quantity' => 0,
                      'new_quantity' => $crop_quantity,
                      'quantity_delta' => $crop_quantity,
                      'crop_name' => $crop_name,
                      'crop_unit' => $crop_unit,
                      'remarks' => 'Crop record created from Manage Crops with market price PHP ' . number_format($market_price_per_unit, 2) . ' per ' . $crop_unit . '.'
                    ]);
                  }
                  $_SESSION['success'] = 'Crop record added. You can now list it on bidding from Manage Crops.';
                } else {
                  $_SESSION['error'] = 'Failed to add crop record: ' . $insert_stmt->error;
                }
                $insert_stmt->close();
              } else {
                $_SESSION['error'] = 'Failed to prepare crop insert statement.';
              }
            }
          } else {
            $_SESSION['error'] = $operation_error;
          }
        } else {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=manage-crops');
        exit;
      }

      // Edit Crop Quantity (Admin)
      elseif ($action === 'update_crop_quantity') {
        $crop_id = (int)($_POST['crop_id'] ?? 0);
        $new_quantity = (float)($_POST['crop_quantity'] ?? 0);
        $new_market_price = (float)($_POST['market_price_per_unit'] ?? 0);
        $existing_crop = null;
        $errors = [];

        if ($crop_id <= 0) {
          $errors[] = 'Invalid crop selected.';
        }

        if ($new_quantity <= 0) {
          $errors[] = 'Quantity must be greater than zero.';
        }

        if ($new_market_price <= 0) {
          $errors[] = 'Market price per unit must be greater than zero.';
        }

        if (empty($errors)) {
          $check_stmt = $conn->prepare(
            "SELECT crop_id, farmer_id, crop_name, crop_description, crop_quantity, crop_unit, market_price_per_unit
             FROM crops
             WHERE crop_id = ? AND starting_price <= 0
             LIMIT 1"
          );
          if ($check_stmt) {
            $check_stmt->bind_param('i', $crop_id);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            $existing_crop = $check_result ? $check_result->fetch_assoc() : null;
            $check_stmt->close();

            if (!$existing_crop) {
              $errors[] = 'Crop record not found or already listed for bidding.';
            }
          } else {
            $errors[] = 'Failed to validate crop record.';
          }
        }

        if (empty($errors)) {
          $new_crop_name = trim($_POST['crop_name'] ?? '');
          $new_crop_desc = trim($_POST['crop_description'] ?? '');
          if ($new_crop_name === '') {
            $_SESSION['error'] = 'Crop name cannot be empty.';
          } else {
            $update_stmt = $conn->prepare("UPDATE crops SET crop_name = ?, crop_description = ?, crop_quantity = ?, market_price_per_unit = ? WHERE crop_id = ?");
            if ($update_stmt) {
              $update_stmt->bind_param('ssddi', $new_crop_name, $new_crop_desc, $new_quantity, $new_market_price, $crop_id);
              if ($update_stmt->execute()) {
                if ($crop_history_ready && $existing_crop) {
                  $old_quantity = (float)$existing_crop['crop_quantity'];
                  $quantity_delta = $new_quantity - $old_quantity;
                  $old_market_price = (float)($existing_crop['market_price_per_unit'] ?? 0);
                  $remark_parts = [];

                  if (abs($quantity_delta) > 0.00001) {
                    $remark_parts[] = 'Quantity changed from ' . number_format($old_quantity, 2) . ' to ' . number_format($new_quantity, 2) . '.';
                  }
                  if ((string)$existing_crop['crop_name'] !== $new_crop_name) {
                    $remark_parts[] = 'Name updated from "' . (string)$existing_crop['crop_name'] . '" to "' . $new_crop_name . '".';
                  }
                  if ((string)($existing_crop['crop_description'] ?? '') !== $new_crop_desc) {
                    $remark_parts[] = 'Description updated.';
                  }
                  if (abs($old_market_price - $new_market_price) > 0.00001) {
                    $remark_parts[] = 'Market price changed from PHP ' . number_format($old_market_price, 2) . ' to PHP ' . number_format($new_market_price, 2) . ' per ' . (string)$existing_crop['crop_unit'] . '.';
                  }

                  $history_remarks = empty($remark_parts)
                    ? 'Crop record updated.'
                    : implode(' ', $remark_parts);

                  logCropHistoryEvent($conn, [
                    'crop_id' => $crop_id,
                    'farmer_id' => (int)$existing_crop['farmer_id'],
                    'changed_by_user_id' => $history_actor_user_id,
                    'actor_role' => $history_actor_role,
                    'actor_name' => $history_actor_name,
                    'event_type' => 'crop_updated',
                    'old_quantity' => $old_quantity,
                    'new_quantity' => $new_quantity,
                    'quantity_delta' => $quantity_delta,
                    'crop_name' => $new_crop_name,
                    'crop_unit' => (string)$existing_crop['crop_unit'],
                    'remarks' => $history_remarks
                  ]);
                }
                $_SESSION['success'] = 'Crop record updated successfully.';
              } else {
                $_SESSION['error'] = 'Failed to update crop record: ' . $update_stmt->error;
              }
              $update_stmt->close();
            } else {
              $_SESSION['error'] = 'Failed to prepare crop update statement.';
            }
          }
        } else {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=manage-crops');
        exit;
      }

      // Create Bidding Lot From Crop Record (Admin)
      elseif ($action === 'create_crop_bidding_lot' || $action === 'publish_crop_to_bidding') {
        $source_crop_id = (int)($_POST['source_crop_id'] ?? ($_POST['crop_id'] ?? 0));
        $bid_quantity = (float)($_POST['bid_quantity'] ?? 0);
        $starting_price = (float)($_POST['starting_price'] ?? 0);
        $bidding_end_input = trim($_POST['bidding_end_date'] ?? '');
        $errors = [];

        if ($source_crop_id <= 0) {
          $errors[] = 'Invalid crop selected.';
        }

        if ($starting_price <= 0) {
          $errors[] = 'Starting price must be greater than zero.';
        }

        $bidding_end_ts = strtotime($bidding_end_input);
        if ($bidding_end_ts === false) {
          $errors[] = 'Please provide a valid bidding end date and time.';
        } elseif ($bidding_end_ts <= time()) {
          $errors[] = 'Bidding end date must be in the future.';
        }

        $source_crop = null;
        if (empty($errors)) {
          $source_stmt = $conn->prepare(
            "SELECT crop_id, farmer_id, crop_name, crop_description, crop_quantity, crop_unit
             FROM crops
             WHERE crop_id = ? AND starting_price <= 0
             LIMIT 1"
          );
          if ($source_stmt) {
            $source_stmt->bind_param('i', $source_crop_id);
            $source_stmt->execute();
            $source_result = $source_stmt->get_result();
            $source_crop = $source_result ? $source_result->fetch_assoc() : null;
            $source_stmt->close();

            if (!$source_crop) {
              $errors[] = 'Crop record not found or already listed only as bidding lot.';
            }
          } else {
            $errors[] = 'Failed to validate source crop record.';
          }
        }

        if (empty($errors) && $source_crop) {
          if ($bid_quantity <= 0) {
            $errors[] = 'Bidding quantity must be greater than zero.';
          } elseif ($bid_quantity > (float)$source_crop['crop_quantity']) {
            $errors[] = 'Bidding quantity cannot exceed available crop quantity.';
          }
        }

        if (empty($errors) && $source_crop) {
          $bidding_end_date = date('Y-m-d H:i:s', $bidding_end_ts);
          $farmer_id = (int)$source_crop['farmer_id'];
          $crop_name = $source_crop['crop_name'];
          $crop_description = $source_crop['crop_description'];
          $crop_unit = $source_crop['crop_unit'];

          $conn->begin_transaction();

          try {
            $insert_stmt = $conn->prepare(
              "INSERT INTO crops (
                farmer_id,
                crop_name,
                crop_description,
                crop_quantity,
                crop_unit,
                starting_price,
                source_crop_id,
                inventory_deducted_on_claim,
                crop_status,
                bidding_end_date
              ) VALUES (?, ?, ?, ?, ?, ?, ?, 1, 'available', ?)"
            );

            if (!$insert_stmt) {
              throw new Exception('Failed to prepare bidding lot insert statement.');
            }

            $insert_stmt->bind_param(
              'issdsdis',
              $farmer_id,
              $crop_name,
              $crop_description,
              $bid_quantity,
              $crop_unit,
              $starting_price,
              $source_crop_id,
              $bidding_end_date
            );

            if (!$insert_stmt->execute()) {
              throw new Exception('Failed to create bidding lot: ' . $insert_stmt->error);
            }
            $new_lot_crop_id = (int)$conn->insert_id;
            $insert_stmt->close();

            // Deduct the bidding quantity from the source inventory crop immediately
            $deduct_stmt = $conn->prepare(
              "UPDATE crops SET crop_quantity = crop_quantity - ? WHERE crop_id = ? AND crop_quantity >= ?"
            );
            if (!$deduct_stmt) {
              throw new Exception('Failed to prepare inventory deduction.');
            }
            $deduct_stmt->bind_param('did', $bid_quantity, $source_crop_id, $bid_quantity);
            $deduct_stmt->execute();
            if ($deduct_stmt->affected_rows <= 0) {
              throw new Exception('Insufficient crop inventory to create this bidding lot.');
            }
            $deduct_stmt->close();

            if ($crop_history_ready) {
              if ($new_lot_crop_id > 0) {
                logCropHistoryEvent($conn, [
                  'crop_id' => $new_lot_crop_id,
                  'farmer_id' => $farmer_id,
                  'changed_by_user_id' => $history_actor_user_id,
                  'actor_role' => $history_actor_role,
                  'actor_name' => $history_actor_name,
                  'event_type' => 'bidding_lot_created',
                  'old_quantity' => (float)$source_crop['crop_quantity'],
                  'new_quantity' => (float)$source_crop['crop_quantity'] - $bid_quantity,
                  'quantity_delta' => -$bid_quantity,
                  'crop_name' => $crop_name,
                  'crop_unit' => $crop_unit,
                  'remarks' => 'Bidding lot created. ' . $bid_quantity . ' ' . $crop_unit . ' deducted from source crop #' . $source_crop_id . ' inventory immediately.'
                ]);
              }
            }

            $conn->commit();
            $_SESSION['success'] = 'Bidding lot created successfully. ' . number_format($bid_quantity, 2) . ' ' . $crop_unit . ' deducted from crop inventory.';
          } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = $e->getMessage();
          }
        } elseif (!empty($errors)) {
          $_SESSION['error'] = implode(' ', $errors);
        }

        $redirect_section = (trim($_POST['_redirect'] ?? '') === 'bidding-monitor') ? 'bidding-monitor' : 'manage-crops';
        header('Location: admin_dashboard.php?section=' . $redirect_section);
        exit;
      }

      elseif ($action === 'update_crop_bidding_lot') {
        $crop_id = (int)($_POST['crop_id'] ?? 0);
        $source_crop_id = (int)($_POST['source_crop_id'] ?? $crop_id);
        $bid_quantity = (float)($_POST['bid_quantity'] ?? 0);
        $starting_price = (float)($_POST['starting_price'] ?? 0);
        $bidding_end_input = trim($_POST['bidding_end_date'] ?? '');
        $errors = [];

        if ($crop_id <= 0 || $source_crop_id <= 0 || $crop_id !== $source_crop_id) {
          $errors[] = 'Invalid bidding lot selected.';
        }
        if ($starting_price <= 0) {
          $errors[] = 'Starting price must be greater than zero.';
        }

        $bidding_end_ts = strtotime($bidding_end_input);
        if ($bidding_end_ts === false) {
          $errors[] = 'Please provide a valid bidding end date and time.';
        } elseif ($bidding_end_ts <= time()) {
          $errors[] = 'Bidding end date must be in the future.';
        }

        $crop_row = null;
        if (empty($errors)) {
          $crop_stmt = $conn->prepare(
            "SELECT crop_id, farmer_id, crop_name, crop_description, crop_quantity, crop_unit, crop_status, source_crop_id, inventory_deducted_on_claim
             FROM crops
             WHERE crop_id = ?
             LIMIT 1"
          );
          if ($crop_stmt) {
            $crop_stmt->bind_param('i', $crop_id);
            $crop_stmt->execute();
            $crop_row = $crop_stmt->get_result()->fetch_assoc();
            $crop_stmt->close();

            if (!$crop_row) {
              $errors[] = 'Bidding record not found.';
            }
          } else {
            $errors[] = 'Failed to validate bidding record.';
          }
        }

        $bid_count = 0;
        if (empty($errors)) {
          $bid_stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM bids WHERE crop_id = ?");
          if ($bid_stmt) {
            $bid_stmt->bind_param('i', $crop_id);
            $bid_stmt->execute();
            $bid_count = (int)($bid_stmt->get_result()->fetch_assoc()['cnt'] ?? 0);
            $bid_stmt->close();
            if ($bid_count > 0) {
              $errors[] = 'This bidding lot already has bids and can no longer be edited.';
            }
          }
        }

        if (empty($errors) && $crop_row) {
          $existing_quantity = (float)($crop_row['crop_quantity'] ?? 0);
          $source_inventory_id = (int)($crop_row['source_crop_id'] ?? 0);
          if ($bid_quantity <= 0) {
            $errors[] = 'Bidding quantity must be greater than zero.';
          } elseif ($source_inventory_id > 0) {
            // Stock already deducted at creation; available = current source qty + currently-held lot qty
            $source_qty_stmt = $conn->prepare("SELECT crop_quantity FROM crops WHERE crop_id = ? LIMIT 1");
            if ($source_qty_stmt) {
              $source_qty_stmt->bind_param('i', $source_inventory_id);
              $source_qty_stmt->execute();
              $source_qty_row = $source_qty_stmt->get_result()->fetch_assoc();
              $source_qty_stmt->close();
              $source_available = (float)($source_qty_row['crop_quantity'] ?? 0) + $existing_quantity;
              if ($bid_quantity > $source_available) {
                $errors[] = 'Bidding quantity cannot exceed available crop quantity (' . number_format($source_available, 2) . ').';
              }
            }
          }
        }

        if (empty($errors) && $crop_row) {
          $existing_quantity = (float)($crop_row['crop_quantity'] ?? 0);
          $source_inventory_id = (int)($crop_row['source_crop_id'] ?? 0);
          $qty_delta = $bid_quantity - $existing_quantity; // positive = need more from source, negative = return some
          $bidding_end_date = date('Y-m-d H:i:s', $bidding_end_ts);

          $conn->begin_transaction();
          try {
            $update_stmt = $conn->prepare(
              "UPDATE crops SET crop_quantity = ?, starting_price = ?, crop_status = 'available', bidding_end_date = ? WHERE crop_id = ?"
            );
            if (!$update_stmt) throw new Exception('Failed to prepare bidding update.');
            $update_stmt->bind_param('ddsi', $bid_quantity, $starting_price, $bidding_end_date, $crop_id);
            if (!$update_stmt->execute()) throw new Exception('Failed to update bidding lot: ' . $update_stmt->error);
            $update_stmt->close();

            // Adjust source inventory by the quantity difference
            if ($source_inventory_id > 0 && $qty_delta != 0) {
              $adj_stmt = $conn->prepare(
                "UPDATE crops SET crop_quantity = crop_quantity - ? WHERE crop_id = ? AND crop_quantity >= ?"
              );
              if (!$adj_stmt) throw new Exception('Failed to prepare inventory adjustment.');
              $adj_stmt->bind_param('did', $qty_delta, $source_inventory_id, $qty_delta);
              $adj_stmt->execute();
              if ($adj_stmt->affected_rows <= 0 && $qty_delta > 0) {
                throw new Exception('Insufficient crop inventory for the increased quantity.');
              }
              $adj_stmt->close();
            }

            $conn->commit();
            $_SESSION['success'] = 'Bidding lot updated successfully.';
          } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['error'] = $e->getMessage();
          }
        }

        header('Location: admin_dashboard.php?section=bidding-monitor');
        exit;
      }

      // Reopen Expired Bidding Lot (extend bidding period)
      elseif ($action === 'reopen_crop_bidding') {
        $crop_id = (int)($_POST['crop_id'] ?? 0);
        $bid_quantity = (float)($_POST['bid_quantity'] ?? 0);
        $starting_price = (float)($_POST['starting_price'] ?? 0);
        $bidding_end_input = trim($_POST['bidding_end_date'] ?? '');
        $errors = [];

        if ($crop_id <= 0) {
          $errors[] = 'Invalid bidding lot selected.';
        }
        if ($starting_price <= 0) {
          $errors[] = 'Starting price must be greater than zero.';
        }

        $bidding_end_ts = strtotime($bidding_end_input);
        if ($bidding_end_ts === false) {
          $errors[] = 'Please provide a valid bidding end date and time.';
        } elseif ($bidding_end_ts <= time()) {
          $errors[] = 'Bidding end date must be in the future.';
        }

        $crop_row = null;
        if (empty($errors)) {
          $crop_stmt = $conn->prepare(
            "SELECT crop_id, farmer_id, crop_name, crop_status, source_crop_id, crop_quantity
             FROM crops
             WHERE crop_id = ? AND crop_status = 'expired'
             LIMIT 1"
          );
          if ($crop_stmt) {
            $crop_stmt->bind_param('i', $crop_id);
            $crop_stmt->execute();
            $crop_row = $crop_stmt->get_result()->fetch_assoc();
            $crop_stmt->close();

            if (!$crop_row) {
              $errors[] = 'Bidding record not found or is not in expired state.';
            }
          } else {
            $errors[] = 'Failed to validate bidding record.';
          }
        }

        // Verify no bids exist
        $bid_count = 0;
        if (empty($errors)) {
          $bid_stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM bids WHERE crop_id = ?");
          if ($bid_stmt) {
            $bid_stmt->bind_param('i', $crop_id);
            $bid_stmt->execute();
            $bid_count = (int)($bid_stmt->get_result()->fetch_assoc()['cnt'] ?? 0);
            $bid_stmt->close();
            if ($bid_count > 0) {
              $errors[] = 'This bidding lot already has bids and cannot be reopened.';
            }
          }
        }

        if (empty($errors) && $crop_row) {
          if ($bid_quantity <= 0) {
            $errors[] = 'Bidding quantity must be greater than zero.';
          }
        }

        if (empty($errors) && $crop_row) {
          $bidding_end_date = date('Y-m-d H:i:s', $bidding_end_ts);
          $update_stmt = $conn->prepare(
            "UPDATE crops
             SET crop_quantity = ?,
                 starting_price = ?,
                 crop_status = 'available',
                 bidding_end_date = ?
             WHERE crop_id = ?"
          );
          if (!$update_stmt) {
            $errors[] = 'Failed to prepare bidding reopen statement.';
          } else {
            $update_stmt->bind_param('ddsi', $bid_quantity, $starting_price, $bidding_end_date, $crop_id);
            if ($update_stmt->execute()) {
              $_SESSION['success'] = 'Bidding lot reopened successfully. New bidding period starts now.';
            } else {
              $_SESSION['error'] = 'Failed to reopen bidding lot: ' . $update_stmt->error;
            }
            $update_stmt->close();
          }
        }

        if (!empty($errors)) {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=bidding-monitor');
        exit;
      }

      // Add Manual Bidding Product (no inventory deduction)
      elseif ($action === 'add_manual_bid_product') {
        $crop_name       = trim($_POST['crop_name'] ?? '');
        $farmer_name_raw = trim($_POST['farmer_name'] ?? '');
        $bid_quantity    = (float)($_POST['bid_quantity'] ?? 0);
        $crop_unit       = trim($_POST['crop_unit'] ?? 'pcs');
        $starting_price  = (float)($_POST['starting_price'] ?? 0);
        $bidding_end_input = trim($_POST['bidding_end_date'] ?? '');
        $errors = [];

        if ($crop_name === '') { $errors[] = 'Product name is required.'; }
        if ($farmer_name_raw === '') { $errors[] = 'Farmer / owner name is required.'; }
        if ($bid_quantity <= 0) { $errors[] = 'Quantity must be greater than zero.'; }
        if ($starting_price <= 0) { $errors[] = 'Starting price must be greater than zero.'; }

        $bidding_end_ts = strtotime($bidding_end_input);
        if ($bidding_end_ts === false || $bidding_end_ts <= time()) {
          $errors[] = 'Bidding end date must be a valid future date and time.';
        }

        if (empty($errors)) {
          // Resolve or create a minimal farmer record for this manual product
          $admin_user_id = (int)($_SESSION['user_id'] ?? 0);
          $farmer_id = 0;

          // Try to find existing farmer by name (case-insensitive partial match)
          $fn_stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE farmer_fullname = ? LIMIT 1");
          if ($fn_stmt) {
            $fn_stmt->bind_param('s', $farmer_name_raw);
            $fn_stmt->execute();
            $fn_result = $fn_stmt->get_result();
            $fn_row = $fn_result ? $fn_result->fetch_assoc() : null;
            $fn_stmt->close();
            if ($fn_row) { $farmer_id = (int)$fn_row['farmer_id']; }
          }

          // If no matching farmer, create a placeholder (user_id = 0 for manual entries)
          if ($farmer_id <= 0) {
            $cf_stmt = $conn->prepare(
              "INSERT INTO farmers (user_id, farmer_fullname, farmer_contact_number, farmer_farm_name, farmer_id_verification_status, farmer_is_verified) VALUES (0, ?, 'N/A', 'Manual Entry', 'approved', 1)"
            );
            if ($cf_stmt) {
              $cf_stmt->bind_param('s', $farmer_name_raw);
              if ($cf_stmt->execute()) { $farmer_id = (int)$conn->insert_id; }
              $cf_stmt->close();
            }
          }

          if ($farmer_id > 0) {
            $bidding_end_date = date('Y-m-d H:i:s', $bidding_end_ts);
            $ins_stmt = $conn->prepare(
              "INSERT INTO crops (farmer_id, crop_name, crop_description, crop_quantity, crop_unit, starting_price, crop_status, bidding_end_date)
               VALUES (?, ?, '', ?, ?, ?, 'available', ?)"
            );
            if ($ins_stmt) {
              $ins_stmt->bind_param('isdsds', $farmer_id, $crop_name, $bid_quantity, $crop_unit, $starting_price, $bidding_end_date);
              if ($ins_stmt->execute()) {
                $manual_crop_id = (int)$conn->insert_id;
                if ($crop_history_ready && $manual_crop_id > 0) {
                  logCropHistoryEvent($conn, [
                    'crop_id' => $manual_crop_id,
                    'farmer_id' => $farmer_id,
                    'changed_by_user_id' => $history_actor_user_id,
                    'actor_role' => $history_actor_role,
                    'actor_name' => $history_actor_name,
                    'event_type' => 'manual_bidding_product_created',
                    'old_quantity' => 0,
                    'new_quantity' => $bid_quantity,
                    'quantity_delta' => $bid_quantity,
                    'crop_name' => $crop_name,
                    'crop_unit' => $crop_unit,
                    'remarks' => 'Manual bidding product created with starting price PHP ' . number_format($starting_price, 2) . '.'
                  ]);
                }
                $_SESSION['success'] = 'Manual bidding product added successfully.';
              } else {
                $_SESSION['error'] = 'Failed to create bidding product: ' . $ins_stmt->error;
              }
              $ins_stmt->close();
            } else {
              $_SESSION['error'] = 'Failed to prepare bidding product insert.';
            }
          } else {
            $_SESSION['error'] = 'Could not resolve farmer record for the product.';
          }
        } else {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=bidding-monitor');
        exit;
      }

      // Mark bidding lot as paid
      elseif ($action === 'mark_bidding_paid') {
        $crop_id = (int)($_POST['crop_id'] ?? 0);
        if ($crop_id <= 0) {
          $_SESSION['error'] = 'Invalid bidding lot selected.';
          header('Location: admin_dashboard.php?section=bidding-monitor');
          exit;
        }

        $pay_stmt = $conn->prepare(
          "UPDATE crops
           SET payment_status = 'paid', payment_marked_at = NOW()
            WHERE crop_id = ? AND crop_status IN ('sold', 'claimed')"
        );

        if ($pay_stmt) {
          $pay_stmt->bind_param('i', $crop_id);
          if ($pay_stmt->execute()) {
            if ($pay_stmt->affected_rows > 0) {
              $_SESSION['success'] = 'Bidding payment marked as paid.';
            } else {
              $_SESSION['error'] = 'Payment can only be marked for sold or claimed bidding lots.';
            }
          } else {
            $_SESSION['error'] = 'Failed to update bidding payment: ' . $pay_stmt->error;
          }
          $pay_stmt->close();
        } else {
          $_SESSION['error'] = 'Failed to prepare bidding payment update.';
        }

        header('Location: admin_dashboard.php?section=bidding-monitor');
        exit;
      }

      // Mark machinery rental as paid
      elseif ($action === 'mark_rental_paid') {
        $rental_id = (int)($_POST['rental_id'] ?? 0);
        if ($rental_id <= 0) {
          $_SESSION['error'] = 'Invalid rental transaction selected.';
          header('Location: admin_dashboard.php?section=rental-monitor');
          exit;
        }

        $pay_stmt = $conn->prepare(
          "UPDATE machinery_rentals
           SET payment_status = 'paid', payment_marked_at = NOW()
           WHERE rental_id = ?"
        );

        if ($pay_stmt) {
          $pay_stmt->bind_param('i', $rental_id);
          if ($pay_stmt->execute()) {
            if ($pay_stmt->affected_rows > 0) {
              $_SESSION['success'] = 'Rental payment marked as paid.';
            } else {
              $_SESSION['error'] = 'Rental transaction not found or already paid.';
            }
          } else {
            $_SESSION['error'] = 'Failed to update rental payment: ' . $pay_stmt->error;
          }
          $pay_stmt->close();
        } else {
          $_SESSION['error'] = 'Failed to prepare rental payment update.';
        }

        header('Location: admin_dashboard.php?section=rental-monitor');
        exit;
      }

      elseif ($action === 'add_rental_listing') {
        $equipment_name = trim((string)($_POST['equipment_name'] ?? ''));
        $owner_name = trim((string)($_POST['owner_name'] ?? ''));
        $daily_rate = (float)($_POST['daily_rate'] ?? 0);
        $listing_status = strtolower(trim((string)($_POST['listing_status'] ?? 'available')));
        $image_upload = dashboardReadUploadedImage('machinery_image');

        $status_map = [
          'available' => 'pending',
          'in-rental' => 'in-rental',
          'maintenance' => 'cancelled'
        ];

        if ($equipment_name === '' || $owner_name === '' || $daily_rate <= 0) {
          $_SESSION['error'] = 'Please complete machinery name, owner, and daily rate.';
          header('Location: admin_dashboard.php?section=rental-monitor');
          exit;
        }

        if (!isset($status_map[$listing_status])) {
          $listing_status = 'available';
        }

        if (!empty($image_upload['error'])) {
          $_SESSION['error'] = $image_upload['error'];
          header('Location: admin_dashboard.php?section=add-machinery-listing');
          exit;
        }

        $mapped_status = $status_map[$listing_status];
        $machinery_image_blob = $image_upload['has_file'] ? (string)$image_upload['blob'] : null;
        $machinery_image_name = $image_upload['has_file'] ? (string)$image_upload['name'] : null;
        $machinery_image_mime = $image_upload['has_file'] ? (string)$image_upload['mime'] : null;

        $existing_listing_stmt = $conn->prepare(
          "SELECT rental_id
           FROM machinery_rentals
           WHERE LOWER(TRIM(equipment_name)) = LOWER(TRIM(?))
             AND LOWER(TRIM(owner_name)) = LOWER(TRIM(?))
             AND COALESCE(TRIM(renter_name), '') = ''
           ORDER BY rental_id DESC
           LIMIT 1"
        );

        if ($existing_listing_stmt) {
          $existing_listing_stmt->bind_param('ss', $equipment_name, $owner_name);
          $existing_listing_stmt->execute();
          $existing_listing_result = $existing_listing_stmt->get_result();
          $existing_listing_row = $existing_listing_result ? $existing_listing_result->fetch_assoc() : null;
          $existing_listing_stmt->close();

          if ($existing_listing_row) {
            $existing_rental_id = (int)$existing_listing_row['rental_id'];
            if ($image_upload['has_file']) {
              $update_listing_stmt = $conn->prepare(
                "UPDATE machinery_rentals
                 SET equipment_name = ?, owner_name = ?, machinery_image = ?, machinery_image_name = ?, machinery_image_mime_type = ?,
                     total_cost = ?, rental_status = ?, payment_status = 'unpaid', payment_marked_at = NULL, updated_at = NOW()
                 WHERE rental_id = ?"
              );
              if ($update_listing_stmt) {
                $update_listing_stmt->bind_param('sssssdsi', $equipment_name, $owner_name, $machinery_image_blob, $machinery_image_name, $machinery_image_mime, $daily_rate, $mapped_status, $existing_rental_id);
              }
            } else {
              $update_listing_stmt = $conn->prepare(
                "UPDATE machinery_rentals
                 SET equipment_name = ?, owner_name = ?, total_cost = ?, rental_status = ?, payment_status = 'unpaid', payment_marked_at = NULL, updated_at = NOW()
                 WHERE rental_id = ?"
              );
              if ($update_listing_stmt) {
                $update_listing_stmt->bind_param('ssdsi', $equipment_name, $owner_name, $daily_rate, $mapped_status, $existing_rental_id);
              }
            }

            if (!$update_listing_stmt) {
              $_SESSION['error'] = 'Failed to prepare machinery listing update.';
              header('Location: admin_dashboard.php?section=rental-monitor');
              exit;
            }

            if ($update_listing_stmt->execute()) {
              $_SESSION['success'] = 'Existing machinery listing updated. Duplicate listing was not created.';
            } else {
              $_SESSION['error'] = 'Failed to update existing machinery listing: ' . $update_listing_stmt->error;
            }
            $update_listing_stmt->close();

            header('Location: admin_dashboard.php?section=rental-monitor');
            exit;
          }
        }

        $next_id_result = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS next_id FROM machinery_rentals");
        $next_id = 1;
        if ($next_id_result) {
          $next_id_row = $next_id_result->fetch_assoc();
          $next_id = (int)($next_id_row['next_id'] ?? 1);
        }
        $rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);

        $insert_stmt = $conn->prepare(
          "INSERT INTO machinery_rentals
             (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, renter_name, start_date, end_date, total_cost, rental_status, payment_status)
           VALUES
             (?, ?, ?, ?, ?, ?, '', CURDATE(), CURDATE(), ?, ?, 'unpaid')"
        );

        if (!$insert_stmt) {
          $_SESSION['error'] = 'Failed to prepare machinery listing.';
          header('Location: admin_dashboard.php?section=rental-monitor');
          exit;
        }

        $insert_stmt->bind_param('ssssssds', $rental_code, $equipment_name, $owner_name, $machinery_image_blob, $machinery_image_name, $machinery_image_mime, $daily_rate, $mapped_status);

        if ($insert_stmt->execute()) {
          $_SESSION['success'] = 'Machinery listing added to rental transactions monitor.';
        } else {
          $_SESSION['error'] = 'Failed to add machinery listing: ' . $insert_stmt->error;
        }
        $insert_stmt->close();

        header('Location: admin_dashboard.php?section=rental-monitor');
        exit;
      }

      elseif ($action === 'edit_rental_listing') {
        $rental_id = (int)($_POST['rental_id'] ?? 0);
        $equipment_name = trim((string)($_POST['equipment_name'] ?? ''));
        $owner_name = trim((string)($_POST['owner_name'] ?? ''));
        $daily_rate = (float)($_POST['daily_rate'] ?? 0);
        $listing_status = strtolower(trim((string)($_POST['listing_status'] ?? 'available')));
        $image_upload = dashboardReadUploadedImage('machinery_image');

        $status_map = [
          'available' => 'pending',
          'in-rental' => 'in-rental',
          'maintenance' => 'cancelled'
        ];

        if ($rental_id <= 0 || $equipment_name === '' || $owner_name === '' || $daily_rate <= 0) {
          $_SESSION['error'] = 'Please complete machinery name, owner, and daily rate.';
          header('Location: admin_dashboard.php?section=add-machinery-listing');
          exit;
        }

        if (!isset($status_map[$listing_status])) {
          $listing_status = 'available';
        }

        if (!empty($image_upload['error'])) {
          $_SESSION['error'] = $image_upload['error'];
          header('Location: admin_dashboard.php?section=add-machinery-listing&edit_rental_id=' . $rental_id);
          exit;
        }

        $mapped_status = $status_map[$listing_status];
        $machinery_image_blob = $image_upload['has_file'] ? (string)$image_upload['blob'] : null;
        $machinery_image_name = $image_upload['has_file'] ? (string)$image_upload['name'] : null;
        $machinery_image_mime = $image_upload['has_file'] ? (string)$image_upload['mime'] : null;

        if ($image_upload['has_file']) {
          $update_listing_stmt = $conn->prepare(
            "UPDATE machinery_rentals
             SET equipment_name = ?, owner_name = ?, machinery_image = ?, machinery_image_name = ?, machinery_image_mime_type = ?,
                 total_cost = ?, rental_status = ?, payment_status = 'unpaid', payment_marked_at = NULL, updated_at = NOW()
             WHERE rental_id = ? AND COALESCE(TRIM(renter_name), '') = '' AND rental_status = 'pending'"
          );
          if ($update_listing_stmt) {
            $update_listing_stmt->bind_param('sssssdsi', $equipment_name, $owner_name, $machinery_image_blob, $machinery_image_name, $machinery_image_mime, $daily_rate, $mapped_status, $rental_id);
          }
        } else {
          $update_listing_stmt = $conn->prepare(
            "UPDATE machinery_rentals
             SET equipment_name = ?, owner_name = ?, total_cost = ?, rental_status = ?, payment_status = 'unpaid', payment_marked_at = NULL, updated_at = NOW()
             WHERE rental_id = ? AND COALESCE(TRIM(renter_name), '') = '' AND rental_status = 'pending'"
          );
          if ($update_listing_stmt) {
            $update_listing_stmt->bind_param('ssdsi', $equipment_name, $owner_name, $daily_rate, $mapped_status, $rental_id);
          }
        }

        if (!$update_listing_stmt) {
          $_SESSION['error'] = 'Failed to prepare machinery listing update.';
          header('Location: admin_dashboard.php?section=add-machinery-listing&edit_rental_id=' . $rental_id);
          exit;
        }

        if ($update_listing_stmt->execute()) {
          $_SESSION['success'] = 'Machinery listing updated successfully.';
          header('Location: admin_dashboard.php?section=rental-monitor');
        } else {
          $_SESSION['error'] = 'Failed to update machinery listing: ' . $update_listing_stmt->error;
          header('Location: admin_dashboard.php?section=add-machinery-listing&edit_rental_id=' . $rental_id);
        }
        $update_listing_stmt->close();
        exit;
      }

      elseif ($action === 'update_rental_status') {
        $rental_id = (int)($_POST['rental_id'] ?? 0);
        $status = $_POST['status'] ?? '';
        $payment_status = $_POST['payment_status'] ?? '';
        $current_status = '';

        $current_stmt = $conn->prepare("SELECT rental_status FROM machinery_rentals WHERE rental_id = ? LIMIT 1");
        if ($current_stmt) {
          $current_stmt->bind_param('i', $rental_id);
          $current_stmt->execute();
          $current_row = $current_stmt->get_result()->fetch_assoc();
          $current_status = strtolower((string)($current_row['rental_status'] ?? ''));
          $current_stmt->close();
        }

        $allowed_status = ['pending', 'approved', 'in-rental', 'returned', 'cancelled'];
        $allowed_payment = ['unpaid', 'paid'];

        if ($rental_id <= 0 || !in_array($status, $allowed_status) || !in_array($payment_status, $allowed_payment)) {
          $_SESSION['error'] = 'Invalid rental or payment status.';
          header('Location: admin_dashboard.php?section=rental-monitor');
          exit;
        }

        $payment_marked_at = null;
        if ($payment_status === 'paid') {
          $payment_marked_at = date('Y-m-d H:i:s');
          $upd_stmt = $conn->prepare(
            "UPDATE machinery_rentals
             SET rental_status = ?, payment_status = ?, payment_marked_at = ?
             WHERE rental_id = ?"
          );
          $upd_stmt->bind_param('sssi', $status, $payment_status, $payment_marked_at, $rental_id);
        } else {
          $upd_stmt = $conn->prepare(
            "UPDATE machinery_rentals
             SET rental_status = ?, payment_status = ?
             WHERE rental_id = ?"
          );
          $upd_stmt->bind_param('ssi', $status, $payment_status, $rental_id);
        }

        if ($upd_stmt->execute()) {
          if ($upd_stmt->affected_rows > 0) {
            if ($status === 'returned' && $current_status !== 'returned') {
              $source_stmt = $conn->prepare(
                "SELECT rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, total_cost
                 FROM machinery_rentals
                 WHERE rental_id = ?
                 LIMIT 1"
              );
              if ($source_stmt) {
                $source_stmt->bind_param('i', $rental_id);
                $source_stmt->execute();
                $source_row = $source_stmt->get_result()->fetch_assoc();
                $source_stmt->close();

                if ($source_row) {
                  $next_id_result = $conn->query("SELECT COALESCE(MAX(rental_id), 0) + 1 AS next_id FROM machinery_rentals");
                  $next_id = $rental_id + 1;
                  if ($next_id_result) {
                    $next_id_row = $next_id_result->fetch_assoc();
                    $next_id = (int)($next_id_row['next_id'] ?? $next_id);
                  }

                  $new_rental_code = '#REN' . str_pad((string)$next_id, 3, '0', STR_PAD_LEFT);
                  $clone_stmt = $conn->prepare(
                    "INSERT INTO machinery_rentals
                       (rental_code, equipment_name, owner_name, machinery_image, machinery_image_name, machinery_image_mime_type, renter_name, start_date, end_date, total_cost, rental_status, payment_status, payment_marked_at)
                     VALUES
                       (?, ?, ?, ?, ?, ?, '', CURDATE(), CURDATE(), ?, 'pending', 'unpaid', NULL)"
                  );
                  if ($clone_stmt) {
                    $clone_stmt->bind_param(
                      'ssssssd',
                      $new_rental_code,
                      $source_row['equipment_name'],
                      $source_row['owner_name'],
                      $source_row['machinery_image'],
                      $source_row['machinery_image_name'],
                      $source_row['machinery_image_mime_type'],
                      $source_row['total_cost']
                    );
                    $clone_stmt->execute();
                    $clone_stmt->close();
                  }
                }
              }

              $_SESSION['success'] = 'Rental returned and new stock listing created for reuse.';
            } else {
              $_SESSION['success'] = 'Rental updated successfully.';
            }
          } else {
            $_SESSION['error'] = 'Rental not found or no changes made.';
          }
        } else {
          $_SESSION['error'] = 'Failed to update rental: ' . $upd_stmt->error;
        }
        $upd_stmt->close();

        header('Location: admin_dashboard.php?section=rental-monitor');
        exit;
      }

      // Distribute Seeds to Farmer
      elseif ($action === 'distribute_seeds') {
        $farmer_id       = (int)($_POST['farmer_id'] ?? 0);
        $seed_id        = (int)($_POST['seed_id'] ?? 0);
        $quantity       = (float)($_POST['quantity_distributed'] ?? 0);
        $dist_date      = trim($_POST['distribution_date'] ?? '');
        $notes          = trim($_POST['notes'] ?? '');
        $errors = [];

        if ($farmer_id <= 0) { $errors[] = 'Farmer is required.'; }
        if ($seed_id <= 0) { $errors[] = 'Seed is required.'; }
        if ($quantity <= 0) { $errors[] = 'Quantity must be greater than zero.'; }
        if ($dist_date === '') { $errors[] = 'Distribution date is required.'; }

        if (!empty($errors)) {
          $_SESSION['error'] = implode(' ', $errors);
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        // Validate farmer exists
        $farmer_check = $conn->prepare("SELECT farmer_id FROM farmers WHERE farmer_id = ?");
        $farmer_check->bind_param('i', $farmer_id);
        $farmer_check->execute();
        if ($farmer_check->get_result()->num_rows === 0) {
          $_SESSION['error'] = 'Selected farmer does not exist.';
          $farmer_check->close();
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }
        $farmer_check->close();

        // Check seed inventory and get available quantity
        $seed_check = $conn->prepare(
          "SELECT seed_id, available_quantity FROM seed_inventory WHERE seed_id = ?"
        );
        $seed_check->bind_param('i', $seed_id);
        $seed_check->execute();
        $seed_result = $seed_check->get_result();
        if ($seed_result->num_rows === 0) {
          $_SESSION['error'] = 'Selected seed does not exist.';
          $seed_check->close();
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $seed_row = $seed_result->fetch_assoc();
        $available_qty = (float)$seed_row['available_quantity'];
        $seed_check->close();

        // Validate sufficient inventory
        if ($quantity > $available_qty) {
          $_SESSION['error'] = "Insufficient inventory. Only {$available_qty} available.";
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        // Create distribution record
        $admin_id = (int)($_SESSION['user_id'] ?? 0);
        $insert_dist = $conn->prepare(
          "INSERT INTO seed_distributions (farmer_id, seed_id, quantity_distributed, distribution_date, status, notes, created_by)
           VALUES (?, ?, ?, ?, 'Released', ?, ?)"
        );

        if (!$insert_dist) {
          $_SESSION['error'] = 'Database error: ' . $conn->error;
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $insert_dist->bind_param('iddssi', $farmer_id, $seed_id, $quantity, $dist_date, $notes, $admin_id);
        if (!$insert_dist->execute()) {
          $_SESSION['error'] = 'Failed to create distribution record: ' . $insert_dist->error;
          $insert_dist->close();
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }
        $insert_dist->close();

        // Deduct from seed inventory
        $new_quantity = $available_qty - $quantity;
        $update_inventory = $conn->prepare(
          "UPDATE seed_inventory SET available_quantity = ? WHERE seed_id = ?"
        );
        
        if ($update_inventory) {
          $update_inventory->bind_param('di', $new_quantity, $seed_id);
          $update_inventory->execute();
          $update_inventory->close();
        }

        $_SESSION['success'] = 'Seeds distributed successfully to farmer.';
        header('Location: admin_dashboard.php?section=distribute-seeds');
        exit;
      }

      // Update Seed Distribution Record
      elseif ($action === 'update_seed_distribution') {
        $record_type = strtolower(trim($_POST['record_type'] ?? 'request'));
        $distribution_id = (int)($_POST['distribution_id'] ?? 0);
        $quantity = (float)($_POST['quantity_distributed'] ?? 0);
        $dist_date = trim($_POST['distribution_date'] ?? '');
        $status = strtolower(trim($_POST['status'] ?? 'released'));
        $notes = trim($_POST['notes'] ?? '');
        $allowed_statuses = $record_type === 'request'
          ? ['pending', 'confirmed', 'completed', 'cancelled']
          : ['released', 'pending', 'returned'];
        $errors = [];

        if ($distribution_id <= 0) { $errors[] = 'Invalid distribution selected.'; }
        if ($quantity <= 0) { $errors[] = 'Quantity must be greater than zero.'; }
        if ($dist_date === '') { $errors[] = 'Distribution date is required.'; }
        if (!in_array($status, $allowed_statuses, true)) { $errors[] = 'Invalid status selected.'; }

        if (!empty($errors)) {
          $_SESSION['error'] = implode(' ', $errors);
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        if ($record_type === 'request') {
          $existing_stmt = $conn->prepare(
            "SELECT request_id, seed_id, quantity_requested, request_status
             FROM seed_requests
             WHERE request_id = ?
             LIMIT 1"
          );
          if (!$existing_stmt) {
            $_SESSION['error'] = 'Failed to prepare request lookup.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $existing_stmt->bind_param('i', $distribution_id);
          $existing_stmt->execute();
          $existing_result = $existing_stmt->get_result();
          if ($existing_result->num_rows === 0) {
            $existing_stmt->close();
            $_SESSION['error'] = 'Request record not found.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $existing_row = $existing_result->fetch_assoc();
          $seed_id = (int)$existing_row['seed_id'];
          $old_quantity = (float)$existing_row['quantity_requested'];
          $current_status = strtolower(trim((string)($existing_row['request_status'] ?? 'pending')));
          $existing_stmt->close();

          $inventory_stmt = $conn->prepare(
            "SELECT available_quantity FROM seed_inventory WHERE seed_id = ? LIMIT 1"
          );
          if (!$inventory_stmt) {
            $_SESSION['error'] = 'Failed to prepare inventory lookup.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $inventory_stmt->bind_param('i', $seed_id);
          $inventory_stmt->execute();
          $inventory_result = $inventory_stmt->get_result();
          if ($inventory_result->num_rows === 0) {
            $inventory_stmt->close();
            $_SESSION['error'] = 'Related seed inventory record was not found.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $available_qty = (float)$inventory_result->fetch_assoc()['available_quantity'];
          $inventory_stmt->close();

          $inventory_adjustment = 0.0;
          if ($current_status === 'completed' && $status === 'completed') {
            // Admin edits quantity on an already-completed request
            $inventory_adjustment = $old_quantity - $quantity;
          } elseif ($current_status !== 'cancelled' && $status === 'cancelled') {
            // Cancelling any active request → restore the deducted stock
            $inventory_adjustment = $old_quantity;
          } elseif ($current_status === 'cancelled' && $status !== 'cancelled') {
            // Re-activating a cancelled request → re-deduct
            $inventory_adjustment = -$quantity;
          }
          // pending/confirmed → completed: no change (stock already deducted at submit)

          if ($inventory_adjustment < 0 && abs($inventory_adjustment) > $available_qty) {
            $_SESSION['error'] = 'Insufficient inventory to complete this request.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $new_available_qty = $available_qty + $inventory_adjustment;
          if ($new_available_qty < 0) {
            $_SESSION['error'] = 'Inventory cannot become negative after update.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $conn->begin_transaction();

          $update_request_stmt = $conn->prepare(
            "UPDATE seed_requests
             SET quantity_requested = ?, requested_at = ?, request_status = ?, request_notes = ?, reviewed_at = NOW(), reviewed_by_user_id = ?
             WHERE request_id = ?"
          );
          if (!$update_request_stmt) {
            $conn->rollback();
            $_SESSION['error'] = 'Failed to prepare request update.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          $admin_id = (int)($_SESSION['user_id'] ?? 0);
          $update_request_stmt->bind_param('dsssii', $quantity, $dist_date, $status, $notes, $admin_id, $distribution_id);
          $updated_request = $update_request_stmt->execute();
          $update_request_stmt->close();

          if (!$updated_request) {
            $conn->rollback();
            $_SESSION['error'] = 'Failed to update request record.';
            header('Location: admin_dashboard.php?section=distribute-seeds');
            exit;
          }

          if ($inventory_adjustment !== 0.0) {
            $update_inventory_stmt = $conn->prepare(
              "UPDATE seed_inventory SET available_quantity = ? WHERE seed_id = ?"
            );
            if (!$update_inventory_stmt) {
              $conn->rollback();
              $_SESSION['error'] = 'Failed to prepare inventory update.';
              header('Location: admin_dashboard.php?section=distribute-seeds');
              exit;
            }

            $update_inventory_stmt->bind_param('di', $new_available_qty, $seed_id);
            $updated_inventory = $update_inventory_stmt->execute();
            $update_inventory_stmt->close();

            if (!$updated_inventory) {
              $conn->rollback();
              $_SESSION['error'] = 'Failed to update seed inventory.';
              header('Location: admin_dashboard.php?section=distribute-seeds');
              exit;
            }
          }

          $conn->commit();

          $_SESSION['success'] = 'Seed request updated successfully.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $existing_stmt = $conn->prepare(
          "SELECT distribution_id, seed_id, quantity_distributed FROM seed_distributions WHERE distribution_id = ? LIMIT 1"
        );
        if (!$existing_stmt) {
          $_SESSION['error'] = 'Failed to prepare distribution lookup.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $existing_stmt->bind_param('i', $distribution_id);
        $existing_stmt->execute();
        $existing_result = $existing_stmt->get_result();
        if ($existing_result->num_rows === 0) {
          $existing_stmt->close();
          $_SESSION['error'] = 'Distribution record not found.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $existing_row = $existing_result->fetch_assoc();
        $seed_id = (int)$existing_row['seed_id'];
        $old_quantity = (float)$existing_row['quantity_distributed'];
        $existing_stmt->close();

        $inventory_stmt = $conn->prepare(
          "SELECT available_quantity FROM seed_inventory WHERE seed_id = ? LIMIT 1"
        );
        if (!$inventory_stmt) {
          $_SESSION['error'] = 'Failed to prepare inventory lookup.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $inventory_stmt->bind_param('i', $seed_id);
        $inventory_stmt->execute();
        $inventory_result = $inventory_stmt->get_result();
        if ($inventory_result->num_rows === 0) {
          $inventory_stmt->close();
          $_SESSION['error'] = 'Related seed inventory record was not found.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $available_qty = (float)$inventory_result->fetch_assoc()['available_quantity'];
        $inventory_stmt->close();

        $delta = $quantity - $old_quantity;
        if ($delta > 0 && $delta > $available_qty) {
          $_SESSION['error'] = 'Insufficient inventory for quantity increase. Additional available: ' . number_format($available_qty, 2) . '.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $new_available_qty = $available_qty - $delta;
        if ($new_available_qty < 0) {
          $_SESSION['error'] = 'Inventory cannot become negative after update.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $conn->begin_transaction();

        $update_dist_stmt = $conn->prepare(
          "UPDATE seed_distributions
           SET quantity_distributed = ?, distribution_date = ?, status = ?, notes = ?
           WHERE distribution_id = ?"
        );
        if (!$update_dist_stmt) {
          $conn->rollback();
          $_SESSION['error'] = 'Failed to prepare distribution update.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $update_dist_stmt->bind_param('dsssi', $quantity, $dist_date, $status, $notes, $distribution_id);
        $updated_distribution = $update_dist_stmt->execute();
        $update_dist_stmt->close();

        if (!$updated_distribution) {
          $conn->rollback();
          $_SESSION['error'] = 'Failed to update distribution record.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $update_inventory_stmt = $conn->prepare(
          "UPDATE seed_inventory SET available_quantity = ? WHERE seed_id = ?"
        );
        if (!$update_inventory_stmt) {
          $conn->rollback();
          $_SESSION['error'] = 'Failed to prepare inventory update.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $update_inventory_stmt->bind_param('di', $new_available_qty, $seed_id);
        $updated_inventory = $update_inventory_stmt->execute();
        $update_inventory_stmt->close();

        if (!$updated_inventory) {
          $conn->rollback();
          $_SESSION['error'] = 'Failed to update seed inventory.';
          header('Location: admin_dashboard.php?section=distribute-seeds');
          exit;
        }

        $conn->commit();

        $_SESSION['success'] = 'Seed distribution updated successfully.';
        header('Location: admin_dashboard.php?section=distribute-seeds');
        exit;
      }

      // Add Seed Stock Record
      elseif ($action === 'add_seed_stock') {
        $seed_name = trim($_POST['seed_name'] ?? '');
        $seed_unit = trim($_POST['seed_unit'] ?? 'kg');
        $available_quantity = (float)($_POST['available_quantity'] ?? 0);
        $low_stock_threshold = (float)($_POST['low_stock_threshold'] ?? 0);
        $errors = [];

        if ($seed_name === '') { $errors[] = 'Seed type is required.'; }
        if ($seed_unit === '') { $errors[] = 'Seed unit is required.'; }
        if ($available_quantity < 0) { $errors[] = 'Available quantity cannot be negative.'; }
        if ($low_stock_threshold < 0) { $errors[] = 'Low stock threshold cannot be negative.'; }

        if (empty($errors)) {
          $check_stmt = $conn->prepare("SELECT seed_id FROM seed_inventory WHERE seed_name = ? LIMIT 1");
          if ($check_stmt) {
            $check_stmt->bind_param('s', $seed_name);
            $check_stmt->execute();
            $exists = $check_stmt->get_result()->num_rows > 0;
            $check_stmt->close();

            if ($exists) {
              $errors[] = 'Seed type already exists. Please edit it instead.';
            }
          }
        }

        if (empty($errors)) {
          $insert_stmt = $conn->prepare(
            "INSERT INTO seed_inventory (seed_name, seed_unit, available_quantity, low_stock_threshold)
             VALUES (?, ?, ?, ?)"
          );
          if ($insert_stmt) {
            $insert_stmt->bind_param('ssdd', $seed_name, $seed_unit, $available_quantity, $low_stock_threshold);
            if ($insert_stmt->execute()) {
              $_SESSION['success'] = 'Seed stock added successfully.';
            } else {
              $_SESSION['error'] = 'Failed to add seed stock: ' . $insert_stmt->error;
            }
            $insert_stmt->close();
          } else {
            $_SESSION['error'] = 'Failed to prepare seed stock insert.';
          }
        } else {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=distribute-seeds');
        exit;
      }

      // Update Seed Stock Record
      elseif ($action === 'update_seed_stock') {
        $seed_id = (int)($_POST['seed_id'] ?? 0);
        $seed_name = trim($_POST['seed_name'] ?? '');
        $seed_unit = trim($_POST['seed_unit'] ?? 'kg');
        $available_quantity = (float)($_POST['available_quantity'] ?? 0);
        $low_stock_threshold = (float)($_POST['low_stock_threshold'] ?? 0);
        $errors = [];

        if ($seed_id <= 0) { $errors[] = 'Invalid seed selected.'; }
        if ($seed_name === '') { $errors[] = 'Seed type is required.'; }
        if ($seed_unit === '') { $errors[] = 'Seed unit is required.'; }
        if ($available_quantity < 0) { $errors[] = 'Available quantity cannot be negative.'; }
        if ($low_stock_threshold < 0) { $errors[] = 'Low stock threshold cannot be negative.'; }

        if (empty($errors)) {
          $check_stmt = $conn->prepare("SELECT seed_id FROM seed_inventory WHERE seed_id = ? LIMIT 1");
          if ($check_stmt) {
            $check_stmt->bind_param('i', $seed_id);
            $check_stmt->execute();
            $exists = $check_stmt->get_result()->num_rows > 0;
            $check_stmt->close();

            if (!$exists) {
              $errors[] = 'Seed record not found.';
            }
          }
        }

        if (empty($errors)) {
          $dupe_stmt = $conn->prepare(
            "SELECT seed_id FROM seed_inventory WHERE seed_name = ? AND seed_id <> ? LIMIT 1"
          );
          if ($dupe_stmt) {
            $dupe_stmt->bind_param('si', $seed_name, $seed_id);
            $dupe_stmt->execute();
            $has_duplicate = $dupe_stmt->get_result()->num_rows > 0;
            $dupe_stmt->close();

            if ($has_duplicate) {
              $errors[] = 'Seed type name is already used by another record.';
            }
          }
        }

        if (empty($errors)) {
          $update_stmt = $conn->prepare(
            "UPDATE seed_inventory
             SET seed_name = ?, seed_unit = ?, available_quantity = ?, low_stock_threshold = ?
             WHERE seed_id = ?"
          );
          if ($update_stmt) {
            $update_stmt->bind_param('ssddi', $seed_name, $seed_unit, $available_quantity, $low_stock_threshold, $seed_id);
            if ($update_stmt->execute()) {
              $_SESSION['success'] = 'Seed stock updated successfully.';
            } else {
              $_SESSION['error'] = 'Failed to update seed stock: ' . $update_stmt->error;
            }
            $update_stmt->close();
          } else {
            $_SESSION['error'] = 'Failed to prepare seed stock update.';
          }
        } else {
          $_SESSION['error'] = implode(' ', $errors);
        }

        header('Location: admin_dashboard.php?section=distribute-seeds');
        exit;
      }
}

// Fire due notifications in a throttled cadence to prevent slow panel-to-panel navigation.
if (($section === 'dashboard' || $section === 'schedule')) {
  $last_due_check = (int)($_SESSION['sf_last_due_activity_check'] ?? 0);
  if ((time() - $last_due_check) >= 300) {
    sendDueActivityNotifications($conn);
    $_SESSION['sf_last_due_activity_check'] = time();
  }
}

// GET DASHBOARD STATS
$total_farmers = 0;
$total_clients = 0;
$total_crop_listings = 0;
$open_crop_listings = 0;
$pending_farmers = 0;
$pending_clients = 0;
$dashboard_monthly_transaction_value = 0.0;
$dashboard_yearly_transaction_value = 0.0;
$dashboard_income_farmer_share_rate = 0.70;
$dashboard_income_coop_share_rate = 0.30;
$dashboard_monthly_farmer_dividend = 0.0;
$dashboard_monthly_coop_dividend = 0.0;
$dashboard_yearly_farmer_dividend = 0.0;
$dashboard_yearly_coop_dividend = 0.0;
$dashboard_income_series = [];
$dashboard_income_series_json = '[]';
$dashboard_income_start_month = date('Y-m');
$dashboard_best_month_summary = 'No transactions yet';
$dashboard_monthly_average_summary = 'PHP 0.00';
$dashboard_top_source_summary = 'No transactions yet';
$dashboard_farmer_dividend_summary = 'PHP 0.00';
$dashboard_coop_dividend_summary = 'PHP 0.00';
$dashboard_recent_history = [];
$dashboard_upcoming_activities = 0;
$dashboard_pending_reservations = 0;

// Sidebar badges must be accurate on every section, not only dashboard.
$query = "SELECT COUNT(*) as count FROM farmers WHERE farmer_id_verification_status = 'pending'";
$result = $conn->query($query);
if ($result) $pending_farmers = (int)($result->fetch_assoc()['count'] ?? 0);

$query = "SELECT COUNT(*) as count FROM clients WHERE client_id_verification_status = 'pending'";
$result = $conn->query($query);
if ($result) $pending_clients = (int)($result->fetch_assoc()['count'] ?? 0);

if (in_array($section, ['dashboard', 'forecasting'], true)) {
  $query = "SELECT COUNT(*) as count FROM farmers";
  $result = $conn->query($query);
  if ($result) $total_farmers = $result->fetch_assoc()['count'];

  $query = "SELECT COUNT(*) as count FROM clients";
  $result = $conn->query($query);
  if ($result) $total_clients = $result->fetch_assoc()['count'];

  $result = $conn->query("SHOW TABLES LIKE 'crops'");
  if ($result && $result->num_rows > 0) {
    $query = "SELECT COUNT(*) as count FROM crops";
    $crop_result = $conn->query($query);
    if ($crop_result) $total_crop_listings = $crop_result->fetch_assoc()['count'];

    $query = "SELECT COUNT(*) as count FROM crops WHERE starting_price > 0 AND bidding_end_date > NOW()";
    $crop_result = $conn->query($query);
    if ($crop_result) $open_crop_listings = $crop_result->fetch_assoc()['count'];
  }

  $month_series_map = [];
  $month_series_keys = [];
  $month_base = strtotime(date('Y-m-01'));
  for ($month_offset = 11; $month_offset >= 0; $month_offset--) {
    $month_ts = strtotime('-' . $month_offset . ' months', $month_base);
    $month_key = date('Y-m', $month_ts);
    $month_series_keys[] = $month_key;
    $month_series_map[$month_key] = [
      'month' => $month_key,
      'label' => date('M Y', $month_ts),
      'bidding' => 0.0,
      'others' => 0.0,
      'machinery' => 0.0
    ];
  }

  if (dashboardTableExists($conn, 'bids')) {
    $bidding_income_query = "
      SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, SUM(bid_amount) AS total_amount
      FROM bids
      WHERE bid_status = 'won'
        AND payment_status = 'paid'
        AND created_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 11 MONTH)
      GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ";
    $bidding_income_result = $conn->query($bidding_income_query);
    if ($bidding_income_result) {
      while ($income_row = $bidding_income_result->fetch_assoc()) {
        $month_key = (string)($income_row['month_key'] ?? '');
        if (isset($month_series_map[$month_key])) {
          $month_series_map[$month_key]['bidding'] = (float)($income_row['total_amount'] ?? 0);
        }
      }
    }
  }

  if (dashboardTableExists($conn, 'livestock_reservations')) {
    $reservation_income_query = "
      SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, SUM(total_price) AS total_amount
      FROM livestock_reservations
      WHERE status IN ('confirmed', 'ready', 'completed')
        AND payment_status = 'paid'
        AND created_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 11 MONTH)
      GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ";
    $reservation_income_result = $conn->query($reservation_income_query);
    if ($reservation_income_result) {
      while ($income_row = $reservation_income_result->fetch_assoc()) {
        $month_key = (string)($income_row['month_key'] ?? '');
        if (isset($month_series_map[$month_key])) {
          $month_series_map[$month_key]['others'] = (float)($income_row['total_amount'] ?? 0);
        }
      }
    }

    $pending_reservations_result = $conn->query("SELECT COUNT(*) AS count FROM livestock_reservations WHERE status = 'pending'");
    if ($pending_reservations_result) {
      $dashboard_pending_reservations = (int)($pending_reservations_result->fetch_assoc()['count'] ?? 0);
    }
  }

  if (dashboardTableExists($conn, 'machinery_rentals')) {
    $machinery_income_query = "
      SELECT DATE_FORMAT(created_at, '%Y-%m') AS month_key, SUM(total_cost) AS total_amount
      FROM machinery_rentals
      WHERE payment_status = 'paid'
        AND created_at >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 11 MONTH)
      GROUP BY DATE_FORMAT(created_at, '%Y-%m')
    ";
    $machinery_income_result = $conn->query($machinery_income_query);
    if ($machinery_income_result) {
      while ($income_row = $machinery_income_result->fetch_assoc()) {
        $month_key = (string)($income_row['month_key'] ?? '');
        if (isset($month_series_map[$month_key])) {
          $month_series_map[$month_key]['machinery'] = (float)($income_row['total_amount'] ?? 0);
        }
      }
    }
  }

  if (dashboardTableExists($conn, 'scheduled_activities')) {
    $upcoming_activities_result = $conn->query("SELECT COUNT(*) AS count FROM scheduled_activities WHERE activity_date >= CURDATE()");
    if ($upcoming_activities_result) {
      $dashboard_upcoming_activities = (int)($upcoming_activities_result->fetch_assoc()['count'] ?? 0);
    }
  }

  $current_month_key = date('Y-m');
  $current_year_key = date('Y');
  $best_month_key = '';
  $best_month_total = -1.0;
  $total_month_sum = 0.0;
  $current_year_total = 0.0;
  $source_totals = [
    'Bidding' => 0.0,
    'Others' => 0.0,
    'Machinery' => 0.0
  ];

  foreach ($month_series_keys as $month_key) {
    $month_entry = $month_series_map[$month_key];
    $dashboard_income_series[] = [
      'month' => $month_entry['month'],
      'label' => $month_entry['label'],
      'bidding' => round((float)$month_entry['bidding'], 2),
      'others' => round((float)$month_entry['others'], 2),
      'machinery' => round((float)$month_entry['machinery'], 2)
    ];

    $month_total = (float)$month_entry['bidding'] + (float)$month_entry['others'] + (float)$month_entry['machinery'];
    $total_month_sum += $month_total;
    $source_totals['Bidding'] += (float)$month_entry['bidding'];
    $source_totals['Others'] += (float)$month_entry['others'];
    $source_totals['Machinery'] += (float)$month_entry['machinery'];

    if ($month_key === $current_month_key) {
      $dashboard_monthly_transaction_value = $month_total;
    }

    if (strpos($month_key, $current_year_key . '-') === 0) {
      $current_year_total += $month_total;
    }

    if ($month_total > $best_month_total) {
      $best_month_total = $month_total;
      $best_month_key = $month_key;
    }
  }

  if (!empty($dashboard_income_series)) {
    $dashboard_income_start_month = (string)$dashboard_income_series[count($dashboard_income_series) - 1]['month'];
  }

  if ($best_month_key !== '' && $best_month_total >= 0) {
    $dashboard_best_month_summary = date('M Y', strtotime($best_month_key . '-01')) . ' · PHP ' . number_format($best_month_total, 2);
  }

  if (!empty($dashboard_income_series)) {
    $dashboard_monthly_average_summary = 'PHP ' . number_format($total_month_sum / count($dashboard_income_series), 2);
  }

  $dashboard_yearly_transaction_value = $current_year_total;

  $dashboard_monthly_farmer_dividend = $dashboard_monthly_transaction_value * $dashboard_income_farmer_share_rate;
  $dashboard_monthly_coop_dividend = $dashboard_monthly_transaction_value * $dashboard_income_coop_share_rate;
  $dashboard_yearly_farmer_dividend = $current_year_total * $dashboard_income_farmer_share_rate;
  $dashboard_yearly_coop_dividend = $current_year_total * $dashboard_income_coop_share_rate;
  $dashboard_farmer_dividend_summary = 'PHP ' . number_format($dashboard_yearly_farmer_dividend, 2);
  $dashboard_coop_dividend_summary = 'PHP ' . number_format($dashboard_yearly_coop_dividend, 2);

  arsort($source_totals);
  $top_source_name = key($source_totals);
  $top_source_total = current($source_totals);
  if ($top_source_name !== null && $top_source_total > 0) {
    $dashboard_top_source_summary = $top_source_name . ' · PHP ' . number_format((float)$top_source_total, 2);
  }

  $dashboard_income_series_json = json_encode($dashboard_income_series, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
  if ($dashboard_income_series_json === false) {
    $dashboard_income_series_json = '[]';
  }

  $history_pool = [];

  $recent_farmer_result = $conn->query("SELECT farmer_fullname, farmer_created_at FROM farmers ORDER BY farmer_created_at DESC LIMIT 4");
  if ($recent_farmer_result) {
    while ($history_row = $recent_farmer_result->fetch_assoc()) {
      $history_pool[] = [
        'type_class' => 'new-account',
        'type_label' => 'New Farmer',
        'message' => (string)$history_row['farmer_fullname'] . ' registered as Farmer',
        'timestamp' => strtotime((string)$history_row['farmer_created_at']) ?: 0
      ];
    }
  }

  $recent_client_result = $conn->query("SELECT client_fullname, client_created_at FROM clients ORDER BY client_created_at DESC LIMIT 4");
  if ($recent_client_result) {
    while ($history_row = $recent_client_result->fetch_assoc()) {
      $history_pool[] = [
        'type_class' => 'new-account',
        'type_label' => 'New Client',
        'message' => (string)$history_row['client_fullname'] . ' registered as Client',
        'timestamp' => strtotime((string)$history_row['client_created_at']) ?: 0
      ];
    }
  }

  if (dashboardTableExists($conn, 'crops')) {
    $recent_crop_result = $conn->query("
      SELECT c.crop_name, c.created_at, COALESCE(f.farmer_fullname, 'Admin Entry') AS owner_name
      FROM crops c
      LEFT JOIN farmers f ON f.farmer_id = c.farmer_id
      ORDER BY c.created_at DESC
      LIMIT 4
    ");
    if ($recent_crop_result) {
      while ($history_row = $recent_crop_result->fetch_assoc()) {
        $history_pool[] = [
          'type_class' => 'verified',
          'type_label' => 'Crop Added',
          'message' => (string)$history_row['crop_name'] . ' was added by ' . (string)$history_row['owner_name'],
          'timestamp' => strtotime((string)$history_row['created_at']) ?: 0
        ];
      }
    }
  }

  if (dashboardTableExists($conn, 'bids')) {
    $recent_bid_result = $conn->query("
      SELECT b.bid_amount, b.created_at, c.crop_name, cl.client_fullname
      FROM bids b
      INNER JOIN crops c ON c.crop_id = b.crop_id
      INNER JOIN clients cl ON cl.client_id = b.client_id
      ORDER BY b.created_at DESC
      LIMIT 4
    ");
    if ($recent_bid_result) {
      while ($history_row = $recent_bid_result->fetch_assoc()) {
        $history_pool[] = [
          'type_class' => 'bid-placed',
          'type_label' => 'Bid Placed',
          'message' => (string)$history_row['client_fullname'] . ' placed PHP ' . number_format((float)$history_row['bid_amount'], 2) . ' on ' . (string)$history_row['crop_name'],
          'timestamp' => strtotime((string)$history_row['created_at']) ?: 0
        ];
      }
    }
  }

  if (dashboardTableExists($conn, 'livestock_reservations')) {
    $recent_reservation_result = $conn->query("
      SELECT lr.total_price, lr.created_at, lp.product_name, cl.client_fullname
      FROM livestock_reservations lr
      INNER JOIN livestock_products lp ON lp.product_id = lr.product_id
      INNER JOIN clients cl ON cl.client_id = lr.client_id
      ORDER BY lr.created_at DESC
      LIMIT 4
    ");
    if ($recent_reservation_result) {
      while ($history_row = $recent_reservation_result->fetch_assoc()) {
        $history_pool[] = [
          'type_class' => 'rental-booked',
          'type_label' => 'Reservation',
          'message' => (string)$history_row['client_fullname'] . ' reserved ' . (string)$history_row['product_name'] . ' worth PHP ' . number_format((float)$history_row['total_price'], 2),
          'timestamp' => strtotime((string)$history_row['created_at']) ?: 0
        ];
      }
    }
  }

  usort($history_pool, static function ($left, $right) {
    return ($right['timestamp'] ?? 0) <=> ($left['timestamp'] ?? 0);
  });

  $dashboard_recent_history = array_slice($history_pool, 0, 6);
  $dashboard_recent_history_limited = array_slice($history_pool, 0, 3);
  $dashboard_has_more_history = count($history_pool) > 3;

  foreach ($dashboard_recent_history as &$history_item) {
    $history_item['time_label'] = dashboardRelativeTime((int)($history_item['timestamp'] ?? 0));
  }
  unset($history_item);

  foreach ($dashboard_recent_history_limited as &$history_item) {
    $history_item['time_label'] = dashboardRelativeTime((int)($history_item['timestamp'] ?? 0));
  }
  unset($history_item);
}

$admin_notifications = [];
$admin_unread_count = 0;
$admin_notification_table = $conn->query("SHOW TABLES LIKE 'user_notifications'");
if ($admin_notification_table && $admin_notification_table->num_rows > 0) {
  $admin_user_id = (int)($_SESSION['user_id'] ?? 0);
  if ($admin_user_id > 0) {
    $admin_notif_stmt = $conn->prepare(
      "SELECT notification_title, notification_message, created_at, is_read
       FROM user_notifications
       WHERE user_id = ?
       ORDER BY created_at DESC
       LIMIT 12"
    );
    if ($admin_notif_stmt) {
      $admin_notif_stmt->bind_param('i', $admin_user_id);
      $admin_notif_stmt->execute();
      $admin_notif_result = $admin_notif_stmt->get_result();
      if ($admin_notif_result) {
        while ($notif_row = $admin_notif_result->fetch_assoc()) {
          $created_stamp = strtotime((string)($notif_row['created_at'] ?? ''));
          $admin_notifications[] = [
            'title' => (string)($notif_row['notification_title'] ?? 'Notification'),
            'message' => (string)($notif_row['notification_message'] ?? ''),
            'created_label' => $created_stamp ? date('M d, Y h:i A', $created_stamp) : '',
            'is_read' => (int)($notif_row['is_read'] ?? 0) === 1
          ];
          if ((int)($notif_row['is_read'] ?? 0) === 0) {
            $admin_unread_count++;
          }
        }
      }
      $admin_notif_stmt->close();
    }
  }
}

// Get messages
$success_msg = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error_msg = isset($_SESSION['error']) ? $_SESSION['error'] : '';
if ($success_msg) unset($_SESSION['success']);
if ($error_msg) unset($_SESSION['error']);

// Keep track of 'from' parameter for navigation context (e.g., returning from view-account)

$farmers_nav_active = ($section === 'verify-farmers'
  || $section === 'farmer-seed-history'
  || ($section === 'view-account' && $from_param === 'verify-farmers'));

$clients_nav_active = ($section === 'verify-clients'
  || ($section === 'view-account' && $from_param === 'verify-clients'));

$livestock_nav_active = ($section === 'manage-livestock-products'
  || $section === 'view-livestock-reservation'
  || $section === 'add-livestock-product'
  || ($section === 'transaction-export-preview' && $from_param === 'manage-livestock-products'));

$rental_nav_active = ($section === 'rental-monitor'
  || $section === 'view-machinery-rental'
  || $section === 'add-machinery-listing'
  || ($section === 'transaction-export-preview' && $from_param === 'rental-monitor'));

$bidding_nav_active = ($section === 'bidding-monitor'
  || $section === 'view-bidding-transaction'
  || $section === 'add-bidding-transaction'
  || ($section === 'transaction-export-preview' && $from_param === 'bidding-monitor'));

$forecast_nav_active = ($section === 'forecasting'
  || $section === 'forecast-market'
  || $section === 'forecast-yield'
  || $section === 'forecast-machinery');

$seed_nav_active = ($section === 'distribute-seeds'
  || $section === 'view-seed-record'
  || ($section === 'transaction-export-preview' && $from_param === 'distribute-seeds'));
?>
<!DOCTYPE html>
<html>
<head>
  <title>Smart Farm Admin Panel</title>
  <link rel="stylesheet" type="text/css" href="css/admin.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    .alert-success { background-color: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 12px; border-radius: 4px; margin-bottom: 15px; }
    .alert-error { background-color: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 12px; border-radius: 4px; margin-bottom: 15px; }
    .alert-message { transition: opacity 0.4s ease, transform 0.4s ease; }
    .alert-message.hide { opacity: 0; transform: translateY(-6px); }
    .admin-main.is-switching { opacity: 0.55; pointer-events: none; transition: opacity 0.16s ease; }
  </style>
</head>
<body>
  <!-- Top Admin Navigation Bar -->
  <div class="admin-top-nav">
    <div class="admin-logo">
      <img src="images/smartfarm_logo.png" alt="Smart Farm Logo">
      <span>Smart Farm</span>
    </div>
  </div>

  <!-- Sidebar Navigation -->
  <div class="admin-container">
    <aside class="admin-sidebar">
      <nav class="admin-nav">
        <div class="admin-nav-scroll">
        <h3 class="nav-title">Main Menu</h3>

        <a href="admin_dashboard.php?section=dashboard" class="nav-item <?php echo $section === 'dashboard' ? 'active' : ''; ?>" onclick="return showSection('dashboard')">
          <i class="fas fa-chart-line"></i>
          <span>Dashboard</span>
        </a>
        
        <!-- Crop & Resource Management Category (Collapsible) -->
        <h3 class="nav-title nav-category collapsed" data-cat="crop-resource" onclick="toggleCategory(this)">
          <i class="fas fa-chevron-down"></i>
          Crop & Resource
        </h3>
        <div class="nav-category-items collapsed">
          <a href="admin_dashboard.php?section=manage-crops" class="nav-item <?php echo $section === 'manage-crops' ? 'active' : ''; ?>" onclick="return showSection('manage-crops')">
            <i class="fas fa-plant-wilt"></i>
            <span>Manage Crops</span>
          </a>
          <a href="admin_dashboard.php?section=distribute-seeds" class="nav-item <?php echo $seed_nav_active ? 'active' : ''; ?>" onclick="return showSection('distribute-seeds')">
            <i class="fas fa-seedling"></i>
            <span>Distribute Seeds</span>
          </a>
        </div>

        <!-- Monitoring Category (Collapsible) -->
        <h3 class="nav-title nav-category collapsed" data-cat="transactions" onclick="toggleCategory(this)">
          <i class="fas fa-chevron-down"></i>
          Transactions
        </h3>
        <div class="nav-category-items collapsed">
          <a href="admin_dashboard.php?section=bidding-monitor" class="nav-item <?php echo $bidding_nav_active ? 'active' : ''; ?>" onclick="return showSection('bidding-monitor')">
            <i class="fas fa-gavel"></i>
            <span>Bidding Transactions</span>
          </a>
          <a href="admin_dashboard.php?section=rental-monitor" class="nav-item <?php echo $rental_nav_active ? 'active' : ''; ?>" onclick="return showSection('rental-monitor')">
            <i class="fas fa-motorcycle"></i>
            <span>Machinery Rentals</span>
          </a>
          <a href="admin_dashboard.php?section=manage-livestock-products" class="nav-item <?php echo $livestock_nav_active ? 'active' : ''; ?>" onclick="return showSection('manage-livestock-products')">
            <i class="fas fa-warehouse"></i>
            <span>Livestock</span>
          </a>
          <a href="admin_dashboard.php?section=schedule" class="nav-item <?php echo in_array($section, ['schedule', 'add-schedule-activity'], true) ? 'active' : ''; ?>" onclick="return showSection('schedule')">
            <i class="fas fa-calendar-check"></i>
            <span>Schedule Activities</span>
          </a>
        </div>

        <!-- Analytics Category moved to bottom -->
        <h3 class="nav-title nav-category collapsed" data-cat="analytics" onclick="toggleCategory(this)">
          <i class="fas fa-chevron-down"></i>
          Analytics
        </h3>
        <div class="nav-category-items collapsed">
          <a href="admin_dashboard.php?section=forecasting" class="nav-item <?php echo $forecast_nav_active ? 'active' : ''; ?>" onclick="return showSection('forecasting')">
            <i class="fas fa-chart-bar"></i>
            <span>Forecasting</span>
          </a>
          <a href="admin_dashboard.php?section=reports" class="nav-item <?php echo $section === 'reports' ? 'active' : ''; ?>" onclick="return showSection('reports')">
            <i class="fas fa-file-export"></i>
            <span>Reports & Export</span>
          </a>
        </div>

        <!-- Account Management Category (Collapsible) -->
        <h3 class="nav-title nav-category collapsed" data-cat="account-management" onclick="toggleCategory(this)">
          <i class="fas fa-chevron-down"></i>
          Account Management
        </h3>
        <div class="nav-category-items collapsed">
          <a href="admin_dashboard.php?section=verify-farmers" class="nav-item <?php echo $farmers_nav_active ? 'active' : ''; ?>" onclick="return showSection('verify-farmers')">
            <i class="fas fa-user-check"></i>
            <span>Farmers</span>
            <?php if (!empty($pending_farmers) && $pending_farmers > 0): ?>
            <span class="badge pending-count"><?php echo $pending_farmers; ?></span>
            <?php endif; ?>
          </a>
          <a href="admin_dashboard.php?section=verify-clients" class="nav-item <?php echo $clients_nav_active ? 'active' : ''; ?>" onclick="return showSection('verify-clients')">
            <i class="fas fa-user-tie"></i>
            <span>Clients</span>
            <?php if (!empty($pending_clients) && $pending_clients > 0): ?>
            <span class="badge pending-count"><?php echo $pending_clients; ?></span>
            <?php endif; ?>
          </a>
        </div>

        </div>

        <div class="admin-profile" data-user-id="<?php echo $_SESSION['user_id']; ?>">
          <button type="button" class="admin-profile-trigger" id="adminProfileTrigger" aria-haspopup="true" aria-expanded="false">
            <span class="admin-profile-avatar">
              <i class="fas fa-user-circle"></i>
            </span>
            <span class="admin-profile-info">
              <span class="admin-profile-name">
                <?php echo htmlspecialchars($_SESSION['user_fullname'] ?? 'Admin'); ?>
              </span>
            </span>
            <i class="fas fa-chevron-down admin-profile-caret"></i>
          </button>
          <div class="admin-profile-dropdown" id="adminProfileDropdown" aria-hidden="true">
            <button type="button" class="admin-profile-action" onclick="viewMyAccount(<?php echo $_SESSION['user_id']; ?>)">
              <i class="fas fa-eye"></i>
              My Account
            </button>
            <button type="button" class="admin-profile-action" onclick="showSection('manage-admins')">
              <i class="fas fa-cog"></i>
              Manage Admin Accounts
            </button>
            <button type="button" class="admin-profile-action admin-profile-logout" onclick="logout()">
              <i class="fas fa-sign-out-alt"></i>
              Logout
            </button>
          </div>
        </div>
      </nav>
    </aside>

    <!-- Main Content Area -->
    <main class="admin-main">
      <!-- Alert Messages -->
      <?php if (!empty($success_msg)): ?>
      <div class="alert-success alert-message">
        <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_msg); ?>
      </div>
      <?php endif; ?>
      
      <?php if (empty($success_msg) && !empty($error_msg)): ?>
      <div class="alert-error alert-message">
        <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_msg); ?>
      </div>
      <?php endif; ?>

      <!-- Load section content -->
      <?php
      // List of valid sections
      $valid_sections = [
        'dashboard',
        'schedule',
        'add-schedule-activity',
        'verify-farmers',
        'verify-clients',
        'farmer-seed-history',
        'add-account',
        'view-account',
        'bidding-monitor',
        'view-bidding-transaction',
        'add-bidding-transaction',
        'rental-monitor',
        'view-machinery-rental',
        'add-machinery-listing',
        'manage-crops',
        'add-crop-bidding',
        'add-crop',
        'edit-crop',
        'view-crop-history',
        'distribute-seeds',
        'view-seed-record',
        'transaction-export-preview',
        'manage-machinery',
        'manage-livestock-products',
        'view-livestock-reservation',
        'add-livestock-product',
        'forecasting',
        'forecast-market',
        'forecast-yield',
        'forecast-machinery',
        'reports',
        'view-admin',
        'manage-admins',
        'add-admin',
        'add-seed-stock'
      ];

      // Check if section is valid, default to dashboard
      if (!in_array($section, $valid_sections)) {
        $section = 'dashboard';
      }

      // Include the section file, but for 'reports', always use the new reports.php
      if ($section === 'reports') {
        include __DIR__ . '/admin/reports.php';
      } else {
        $section_file = __DIR__ . '/admin/' . $section . '.php';
        if (file_exists($section_file)) {
          include $section_file;
        } else {
          echo "<section id='section-error' class='admin-section active'>";
          echo "<div class='section-header'><h1>Section Not Found</h1></div>";
          echo "<p>The requested section could not be loaded.</p>";
          echo "</section>";
        }
      }
      ?>
    </main>
  </div>

  <div id="sfConfirmModal" class="sf-confirm-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sfConfirmTitle">
    <div class="sf-confirm-dialog" role="document">
      <h2 id="sfConfirmTitle">Confirm Submission</h2>
      <p id="sfConfirmMessage">Are you sure you want to continue?</p>
      <div class="sf-confirm-actions">
        <button type="button" class="btn-secondary" id="sfConfirmCancelBtn">Cancel</button>
        <button type="button" class="btn-primary" id="sfConfirmOkBtn">Continue</button>
      </div>
    </div>
  </div>

  <script>
    // View my account - opens view-account with current user in manage-admins context
    function viewMyAccount(userId) {
      window.location.href = 'admin_dashboard.php?section=view-account&user_id=' + userId + '&from=manage-admins';
    }

    // Show/Hide sections
    function showSection(sectionName) {
      // Validate section
        const validSections = ['dashboard', 'schedule', 'add-schedule-activity', 'verify-farmers', 'verify-clients', 'farmer-seed-history', 'add-account', 'view-account',
             'bidding-monitor', 'view-bidding-transaction', 'add-bidding-transaction', 'rental-monitor', 'view-machinery-rental', 'add-machinery-listing', 'manage-crops', 'add-crop-bidding', 'add-crop', 'edit-crop', 'view-crop-history', 'distribute-seeds', 'view-seed-record', 'transaction-export-preview', 'manage-machinery', 'manage-livestock-products', 'view-livestock-reservation', 'add-livestock-product',
                 'forecasting', 'forecast-market', 'forecast-yield', 'forecast-machinery', 'reports', 'view-admin', 'manage-admins', 'add-admin'];
      
      if (!validSections.includes(sectionName)) {
        console.warn('Invalid section:', sectionName);
        return false;
      }

      window.location.href = 'admin_dashboard.php?section=' + encodeURIComponent(sectionName);
      return false;
    }

    // Show reject form with reason
    function showRejectForm(type, id) {
      const reason = prompt('Please provide a reason for rejection:');
      if (reason && reason.trim()) {
        const form = document.createElement('form');
        form.method = 'post';
        form.setAttribute('data-confirm-message', 'Submit rejection for this account?');
        form.innerHTML = '<input type="hidden" name="action" value="reject_' + type + '">' +
                        '<input type="hidden" name="' + type + '_id" value="' + id + '">' +
                        '<input type="hidden" name="reason" value="' + reason.replace(/"/g, '&quot;') + '">';
        document.body.appendChild(form);
        if (typeof form.requestSubmit === 'function') {
          form.requestSubmit();
        } else {
          const fallbackSubmit = document.createElement('button');
          fallbackSubmit.type = 'submit';
          fallbackSubmit.style.display = 'none';
          form.appendChild(fallbackSubmit);
          fallbackSubmit.click();
        }
      }
    }

    // Backward compatibility for sections still calling the older handler name.
    function showRejectFormModal(type, id) {
      showRejectForm(type, id);
    }

    // ── Generic "Group By" engine shared by every data-table on the admin panel ──
    // sfSetGroupBy() records which column a table should be grouped by (from a
    // <select> whose value is the 0-based column index, or '' for no grouping).
    // sfApplyGroupBy() re-sorts the table's *visible* rows into that column's
    // groups, inserting a header row per group. It is called at the end of every
    // filter function so grouping always reflects the current search/filter state.
    const sfGroupState = {};
    const sfOriginalOrder = {};

    function sfSetGroupBy(tableId, selectEl) {
      const val = selectEl ? selectEl.value : '';
      sfGroupState[tableId] = val === '' ? -1 : parseInt(val, 10);
    }

    function sfResetGroupOrder(tableId) {
      delete sfOriginalOrder[tableId];
    }

    function sfEscapeHtml(str) {
      return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
        return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
      });
    }

    function sfApplyGroupBy(tableId) {
      const table = document.getElementById(tableId);
      if (!table) return;
      const tbody = table.tBodies && table.tBodies[0];
      if (!tbody) return;

      if (!sfOriginalOrder[tableId]) {
        sfOriginalOrder[tableId] = Array.from(tbody.children).filter(r => !r.classList.contains('sf-group-row'));
      }

      tbody.querySelectorAll('tr.sf-group-row').forEach(r => r.remove());

      const baseRows = sfOriginalOrder[tableId];
      const colIndex = sfGroupState[tableId];

      if (colIndex === undefined || colIndex === -1 || isNaN(colIndex) || baseRows.length <= 1) {
        baseRows.forEach(r => tbody.appendChild(r));
        return;
      }

      const headRow = table.tHead && table.tHead.rows[0];
      const colCount = headRow ? headRow.children.length : baseRows[0].children.length;

      const visible = baseRows.filter(r => r.style.display !== 'none');
      const hidden = baseRows.filter(r => r.style.display === 'none');

      const groups = new Map();
      visible.forEach(row => {
        const cell = row.children[colIndex];
        const statusEl = cell ? cell.querySelector('.status') : null;
        let key = (statusEl ? statusEl.textContent : (cell ? cell.textContent : '')).trim();
        if (key === '') key = 'Unspecified';
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(row);
      });

      const sortedKeys = Array.from(groups.keys()).sort((a, b) =>
        a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
      );

      sortedKeys.forEach(key => {
        const headerRow = document.createElement('tr');
        headerRow.className = 'sf-group-row';
        const td = document.createElement('td');
        td.colSpan = colCount;
        td.innerHTML = '<i class="fas fa-layer-group"></i> ' + sfEscapeHtml(key) +
          ' <span class="sf-group-count">' + groups.get(key).length + '</span>';
        headerRow.appendChild(td);
        tbody.appendChild(headerRow);
        groups.get(key).forEach(row => tbody.appendChild(row));
      });

      hidden.forEach(row => tbody.appendChild(row));
    }

    function filterBiddingTable() {
      const statusInput = document.getElementById('biddingStatus');
      const searchInput = document.getElementById('biddingSearch');
      const paymentInput = document.getElementById('biddingPayment');
      const priceRangeInput = document.getElementById('biddingPriceRange');
      const table = document.getElementById('biddingTable');
      if (!table) return;

      const selectedStatus = statusInput ? statusInput.value.toLowerCase() : '';
      const searchText = searchInput ? searchInput.value.trim().toLowerCase() : '';
      const selectedPayment = paymentInput ? paymentInput.value.toLowerCase() : '';
      const selectedPriceRange = priceRangeInput ? String(priceRangeInput.value || '').trim() : '';
      const rows = table.querySelectorAll('tbody tr');

      rows.forEach(row => {
        const rowStage = (row.dataset.stage || '').toLowerCase();
        const rowPayment = (row.dataset.payment || '').toLowerCase();
        const rowPrice = parseFloat(row.dataset.price || '0');
        const rowText = row.textContent.toLowerCase();

        const matchesStage = selectedStatus === '' || rowStage === selectedStatus;
        const matchesSearch = searchText === '' || rowText.includes(searchText);
        const matchesPayment = selectedPayment === '' || rowPayment === selectedPayment;
        let matchesPriceRange = true;

        if (selectedPriceRange !== '') {
          if (selectedPriceRange.endsWith('+')) {
            const minOnly = parseFloat(selectedPriceRange.replace('+', ''));
            matchesPriceRange = !Number.isNaN(rowPrice) && !Number.isNaN(minOnly) && rowPrice >= minOnly;
          } else {
            const rangeParts = selectedPriceRange.split('-');
            const minRange = parseFloat(rangeParts[0] || '');
            const maxRange = parseFloat(rangeParts[1] || '');
            matchesPriceRange = !Number.isNaN(rowPrice) && !Number.isNaN(minRange) && !Number.isNaN(maxRange)
              && rowPrice >= minRange && rowPrice <= maxRange;
          }
        }

        row.style.display = matchesStage && matchesSearch && matchesPayment && matchesPriceRange ? '' : 'none';
      });

      sfApplyGroupBy('biddingTable');
    }

    function filterRentalTable() {
      const searchInput = document.getElementById('rentalSearch');
      const statusInput = document.getElementById('rentalStatus');
      const paymentInput = document.getElementById('rentalPayment');
      const priceRangeInput = document.getElementById('rentalPriceRange');
      const table = document.getElementById('rentalTable');
      if (!table) return;

      const searchText = searchInput ? searchInput.value.trim().toLowerCase() : '';
      const selectedStatus = statusInput ? statusInput.value.toLowerCase() : '';
      const selectedPayment = paymentInput ? paymentInput.value.toLowerCase() : '';
      const selectedPriceRange = priceRangeInput ? String(priceRangeInput.value || '').trim() : '';
      const rows = table.querySelectorAll('tbody tr');

      rows.forEach(row => {
        const rowStatus = (row.dataset.status || '').toLowerCase();
        const rowPayment = (row.dataset.payment || '').toLowerCase();
        const rowPrice = parseFloat(row.dataset.price || '0');
        const rowText = (row.textContent + ' ' + (row.dataset.owner || '')).toLowerCase();

        const matchesSearch = searchText === '' || rowText.includes(searchText);
        const matchesStatus = selectedStatus === '' || rowStatus === selectedStatus;
        const matchesPayment = selectedPayment === '' || rowPayment === selectedPayment;
        let matchesPriceRange = true;

        if (selectedPriceRange !== '') {
          if (selectedPriceRange.endsWith('+')) {
            const minOnly = parseFloat(selectedPriceRange.replace('+', ''));
            matchesPriceRange = !Number.isNaN(rowPrice) && !Number.isNaN(minOnly) && rowPrice >= minOnly;
          } else {
            const rangeParts = selectedPriceRange.split('-');
            const minRange = parseFloat(rangeParts[0] || '');
            const maxRange = parseFloat(rangeParts[1] || '');
            matchesPriceRange = !Number.isNaN(rowPrice) && !Number.isNaN(minRange) && !Number.isNaN(maxRange)
              && rowPrice >= minRange && rowPrice <= maxRange;
          }
        }

        row.style.display = matchesSearch && matchesStatus && matchesPayment && matchesPriceRange ? '' : 'none';
      });

      sfApplyGroupBy('rentalTable');
    }

    function filterSeedDistributionTable() {
      const searchInput = document.getElementById('seedSearch');
      const statusInput = document.getElementById('seedStatus');
      const table = document.getElementById('seedDistributionTable');
      if (!table) return;

      const searchText = searchInput ? searchInput.value.trim().toLowerCase() : '';
      const selectedStatus = statusInput ? statusInput.value.toLowerCase() : '';
      const rows = table.querySelectorAll('tbody tr');

      rows.forEach(row => {
        const rowStatus = (row.dataset.status || '').toLowerCase();
        const rowText = row.textContent.toLowerCase();

        const matchesSearch = searchText === '' || rowText.includes(searchText);
        const matchesStatus = selectedStatus === '' || rowStatus === selectedStatus;

        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
      });

      sfApplyGroupBy('seedDistributionTable');
    }

    function openAddBidProductModal() {
      const modal = document.getElementById('addBidProductModal');
      if (modal) modal.classList.add('is-visible');
      if (typeof resetBidSourceSelection === 'function') {
        resetBidSourceSelection();
      }
    }

    function closeAddBidProductModal(event) {
      const modal = document.getElementById('addBidProductModal');
      if (!modal) return;
      if (!event || event.target === modal) {
        modal.classList.remove('is-visible');
        if (typeof resetBidSourceSelection === 'function') {
          resetBidSourceSelection();
        }
      }
    }

    function formatPeso(value) {
      const num = Number(value) || 0;
      return '₱' + num.toLocaleString('en-US');
    }

    function getNextNumericId(tableId, prefix) {
      const table = document.getElementById(tableId);
      if (!table) return 1;

      let maxId = 0;
      table.querySelectorAll('tbody tr').forEach(row => {
        const firstCell = row.cells[0] ? row.cells[0].textContent.trim() : '';
        const match = firstCell.match(new RegExp('#' + prefix + '(\\d+)', 'i'));
        if (match) {
          const current = parseInt(match[1], 10);
          if (!Number.isNaN(current) && current > maxId) maxId = current;
        }
      });

      return maxId + 1;
    }

    function getBidRowById(bidId) {
      const table = document.getElementById('biddingTable');
      if (!table || !bidId) return null;

      const rows = table.querySelectorAll('tbody tr');
      for (const row of rows) {
        const rowBidId = row.cells[0] ? row.cells[0].textContent.trim() : '';
        if (rowBidId === bidId) return row;
      }

      return null;
    }

    function getRentalRowById(rentalId) {
      const table = document.getElementById('rentalTable');
      if (!table || !rentalId) return null;

      const rows = table.querySelectorAll('tbody tr');
      for (const row of rows) {
        const rowRentalId = row.cells[0] ? row.cells[0].textContent.trim() : '';
        if (rowRentalId === rentalId) return row;
      }

      return null;
    }

    function getRentalStatusLabel(statusClass) {
      const labels = {
        'pending': 'Pending Approval',
        'approved': 'Approved',
        'in-rental': 'In Use',
        'returned': 'Returned',
        'cancelled': 'Cancelled'
      };

      return labels[statusClass] || 'Pending Approval';
    }

    function setRentalStatus(row, statusClass, label) {
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge) return;

      statusBadge.className = 'status ' + statusClass;
      statusBadge.textContent = label;
      row.dataset.status = statusClass;
    }

    function populateRentalDetailsModal(row, rentalId) {
      if (!row || row.cells.length < 9) return;

      const modal = document.getElementById('rentalDetailsModal');
      if (!modal) return;

      const statusClass = (row.dataset.status || 'pending').toLowerCase();
      const owner = (row.dataset.owner || '-').trim() || '-';
      const equipment = row.cells[1].textContent.trim();
      const renter = row.cells[2].textContent.trim();
      const startDate = row.cells[3].textContent.trim();
      const endDate = row.cells[4].textContent.trim();
      const cost = row.cells[5].textContent.trim();
      const paymentText = row.cells[7].textContent.trim();
      const paymentStatus = paymentText.toLowerCase().includes('paid') ? 'paid' : 'unpaid';

      modal.dataset.currentRentalId = rentalId;

      const statusInfo = document.getElementById('rentalStatusInfo');
      if (statusInfo) {
        statusInfo.innerHTML = '<strong>Rental:</strong> ' + escapeHtml(rentalId) + '<br>' +
          '<strong>Equipment:</strong> ' + escapeHtml(equipment) + '<br>' +
          '<strong>Owner:</strong> ' + escapeHtml(owner) + '<br>' +
          '<strong>Renter:</strong> ' + escapeHtml(renter) + '<br>' +
          '<strong>Start Date:</strong> ' + escapeHtml(startDate) + '<br>' +
          '<strong>End Date:</strong> ' + escapeHtml(endDate) + '<br>' +
          '<strong>Total:</strong> ' + escapeHtml(cost) + '<br>' +
          '<strong>Payment:</strong> ' + escapeHtml(paymentText);
      }

      const rentalIdInput = document.getElementById('rentalStatusRentalId');
      if (rentalIdInput) rentalIdInput.value = rentalId;

      const statusSelect = document.getElementById('rentalStatusValue');
      if (statusSelect) statusSelect.value = statusClass;

      const paymentSelect = document.getElementById('rentalStatusPayment');
      if (paymentSelect) paymentSelect.value = paymentStatus;

      const adminNoteInput = document.getElementById('rentalStatusAdminNote');
      if (adminNoteInput) adminNoteInput.value = '';
    }

    function viewRentalDetails(button, rentalId) {
      const row = button ? button.closest('tr') : null;
      const modal = document.getElementById('rentalDetailsModal');
      if (!row || !modal) return;

      populateRentalDetailsModal(row, rentalId);
      modal.classList.add('is-visible');
    }

    function closeRentalDetailsModal(event) {
      const modal = document.getElementById('rentalDetailsModal');
      if (!modal) return;

      if (!event || event.target === modal) {
        modal.classList.remove('is-visible');
      }
    }

    function updateRentalStatus(event) {
      if (event) event.preventDefault();

      const modal = document.getElementById('rentalDetailsModal');
      if (!modal) return;

      const rentalId = document.getElementById('rentalStatusRentalId')?.value || modal.dataset.currentRentalId || '';
      const nextStatus = (document.getElementById('rentalStatusValue')?.value || '').toLowerCase();
      const nextPayment = (document.getElementById('rentalStatusPayment')?.value || 'unpaid').toLowerCase();

      if (!rentalId || !nextStatus || !nextPayment) return;

      const formData = new FormData();
      formData.append('action', 'update_rental_status');
      formData.append('rental_id', rentalId.replace(/[^0-9]/g, ''));
      formData.append('status', nextStatus);
      formData.append('payment_status', nextPayment);

      fetch('admin_dashboard.php', { method: 'POST', body: formData })
        .then(function(response) { return response.text(); })
        .then(function(data) {
          closeRentalDetailsModal();
          location.reload();
        })
        .catch(function() {
          alert('Failed to update rental status');
        });
    }

    function openMachineryListModal() {
      const modal = document.getElementById('machineryListModal');
      if (modal) modal.classList.add('is-visible');
    }

    function closeMachineryListModal(event) {
      const modal = document.getElementById('machineryListModal');
      if (!modal) return;

      if (!event || event.target === modal) {
        modal.classList.remove('is-visible');
      }
    }

    function filterMachineryList() {
      const search = (document.getElementById('machineryListSearch')?.value || '').toLowerCase();
      const table = document.getElementById('machineryListTable');
      if (!table) return;

      table.querySelectorAll('tbody tr').forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(search) ? '' : 'none';
      });
    }

    function getMachineryStatusLabel(statusClass) {
      const labels = {
        'available': 'Available',
        'in-rental': 'In Rental',
        'maintenance': 'Maintenance'
      };

      return labels[statusClass] || 'Available';
    }

    function getNextMachineryRowId() {
      const table = document.getElementById('machineryListTable');
      if (!table) return '#EQP001';

      let maxId = 0;
      table.querySelectorAll('tbody tr').forEach(row => {
        const match = (row.dataset.id || '').match(/#EQP(\d+)/i);
        if (match) {
          const current = parseInt(match[1], 10);
          if (!Number.isNaN(current) && current > maxId) maxId = current;
        }
      });

      return '#EQP' + String(maxId + 1).padStart(3, '0');
    }

    function getMachineryRowById(rowId) {
      const table = document.getElementById('machineryListTable');
      if (!table || !rowId) return null;

      const rows = table.querySelectorAll('tbody tr');
      for (const row of rows) {
        if ((row.dataset.id || '') === rowId) return row;
      }

      return null;
    }

    function escapeHtml(value) {
      return String(value || '').replace(/[&<>"']/g, char => {
        const map = {
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;'
        };

        return map[char] || char;
      });
    }

    function sfParseNumeric(value) {
      const cleaned = String(value || '')
        .replace(/,/g, '')
        .replace(/[^0-9+\-.]/g, '');
      if (!cleaned || cleaned === '+' || cleaned === '-' || cleaned === '.' || cleaned === '+.' || cleaned === '-.') {
        return null;
      }
      const parsed = Number(cleaned);
      return Number.isFinite(parsed) ? parsed : null;
    }

    function sfParseDate(value) {
      const text = String(value || '').trim();
      if (!text) return null;
      const timestamp = Date.parse(text);
      return Number.isFinite(timestamp) ? timestamp : null;
    }

    function sfGetCellSortText(row, columnIndex) {
      const cell = row && row.cells ? row.cells[columnIndex] : null;
      if (!cell) return '';
      return cell.textContent.replace(/\s+/g, ' ').trim();
    }

    function sfNormalizeDashCells(root) {
      const scope = root || document;
      const cells = scope.querySelectorAll('table.data-table td, table.tx-export-table td');

      cells.forEach((cell) => {
        if (!cell) return;
        const text = (cell.textContent || '').replace(/\s+/g, ' ').trim();
        if (text === '-') {
          cell.classList.add('sf-dash-cell');
        } else {
          cell.classList.remove('sf-dash-cell');
        }
      });
    }

    function sfDetectColumnType(table, columnIndex) {
      const rows = Array.from(table.querySelectorAll('tbody tr'));
      const samples = [];

      rows.forEach((row) => {
        if (samples.length >= 12) return;
        if (!row || !row.cells || row.cells.length === 0) return;

        // Ignore placeholder rows like "Loading..." / "No records" that usually use colspan.
        if (row.cells.length === 1) {
          const onlyCell = row.cells[0];
          if (onlyCell && Number(onlyCell.colSpan || 1) > 1) return;
        }

        const value = sfGetCellSortText(row, columnIndex);
        if (value !== '' && value !== '-') samples.push(value);
      });

      if (samples.length === 0) return 'text';

      let numberCount = 0;
      let dateCount = 0;

      samples.forEach((value) => {
        if (sfParseNumeric(value) !== null) numberCount++;
        if (sfParseDate(value) !== null) dateCount++;
      });

      if (numberCount >= Math.ceil(samples.length * 0.6)) return 'number';
      if (dateCount >= Math.ceil(samples.length * 0.6)) return 'date';
      return 'text';
    }

    function sfEnsureRowBaseOrder(table) {
      const rows = table.querySelectorAll('tbody tr');
      rows.forEach((row, idx) => {
        if (!row.dataset.sfOriginalIndex) {
          row.dataset.sfOriginalIndex = String(idx);
        }
      });
    }

    function sfSortTableByMode(table, columnIndex, mode) {
      const tbody = table.querySelector('tbody');
      if (!tbody) return;

      sfEnsureRowBaseOrder(table);
      const rows = Array.from(tbody.querySelectorAll('tr'));
      if (rows.length <= 1) return;

      if (mode === 'reset') {
        rows.sort((a, b) => Number(a.dataset.sfOriginalIndex || '0') - Number(b.dataset.sfOriginalIndex || '0'));
        rows.forEach((row) => tbody.appendChild(row));
        return;
      }

      const factor = (mode.endsWith('_desc') || mode === 'z_a') ? -1 : 1;

      rows.sort((a, b) => {
        const aText = sfGetCellSortText(a, columnIndex);
        const bText = sfGetCellSortText(b, columnIndex);

        let diff = 0;
        if (mode.startsWith('num')) {
          const aNum = sfParseNumeric(aText);
          const bNum = sfParseNumeric(bText);
          if (aNum === null && bNum === null) diff = 0;
          else if (aNum === null) diff = 1;
          else if (bNum === null) diff = -1;
          else diff = aNum - bNum;
        } else if (mode.startsWith('date')) {
          const aDate = sfParseDate(aText);
          const bDate = sfParseDate(bText);
          if (aDate === null && bDate === null) diff = 0;
          else if (aDate === null) diff = 1;
          else if (bDate === null) diff = -1;
          else diff = aDate - bDate;
        } else {
          diff = aText.localeCompare(bText, undefined, { numeric: true, sensitivity: 'base' });
        }

        if (diff === 0) {
          diff = Number(a.dataset.sfOriginalIndex || '0') - Number(b.dataset.sfOriginalIndex || '0');
        }

        return diff * factor;
      });

      rows.forEach((row) => tbody.appendChild(row));
    }

    function sfCloseAllSortMenus() {
      document.querySelectorAll('.sf-sort-menu.open').forEach((menu) => {
        menu.classList.remove('open');
      });
    }

    function sfPositionSortMenu(th, menu) {
      if (!th || !menu) return;

      // Start from default right alignment.
      menu.style.left = '';
      menu.style.right = '0';

      const viewportPadding = 8;
      const rectRight = menu.getBoundingClientRect();

      // If clipped on the left, anchor to the left edge of the header cell.
      if (rectRight.left < viewportPadding) {
        menu.style.right = 'auto';
        menu.style.left = '0';
      }

      const rectLeft = menu.getBoundingClientRect();
      // If still clipped on the right, fall back to right alignment.
      if (rectLeft.right > (window.innerWidth - viewportPadding)) {
        menu.style.left = 'auto';
        menu.style.right = '0';
      }

      const finalRect = menu.getBoundingClientRect();
      // Final safety: nudge horizontally to keep fully visible in viewport.
      if (finalRect.left < viewportPadding) {
        const shift = viewportPadding - finalRect.left;
        menu.style.transform = 'translateX(' + shift + 'px)';
      } else if (finalRect.right > (window.innerWidth - viewportPadding)) {
        const shift = (window.innerWidth - viewportPadding) - finalRect.right;
        menu.style.transform = 'translateX(' + shift + 'px)';
      } else {
        menu.style.transform = '';
      }
    }

    function sfMakeColumnSortable(table, th, columnIndex) {
      const isReady = th.dataset.sfSortReady === '1';
      const currentLabel = isReady
        ? (th.dataset.sfSortLabel || '')
        : (th.textContent || '');
      const headerText = currentLabel.replace(/\s+/g, ' ').trim().toLowerCase();
      if (!headerText) return;
      if (/(^|\s)(action|actions|option|options)$/i.test(headerText)) return;

      const type = sfDetectColumnType(table, columnIndex);
      const label = currentLabel.replace(/\s+/g, ' ').trim();

      let titleSpan = th.querySelector('.sf-sort-label');
      let toggle = th.querySelector('.sf-sort-toggle');
      let menu = th.querySelector('.sf-sort-menu');

      if (!isReady) {
        th.textContent = '';
        th.classList.add('sf-sortable');

        titleSpan = document.createElement('span');
        titleSpan.className = 'sf-sort-label';
        titleSpan.textContent = label;

        toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'sf-sort-toggle';
        toggle.setAttribute('aria-label', 'Sort ' + label);
        toggle.innerHTML = '<i class="fas fa-caret-down"></i>';

        menu = document.createElement('div');
        menu.className = 'sf-sort-menu';

        toggle.addEventListener('click', (event) => {
          event.stopPropagation();
          const opening = !menu.classList.contains('open');
          sfCloseAllSortMenus();
          if (opening) {
            menu.classList.add('open');
            sfPositionSortMenu(th, menu);
          }
        });

        th.appendChild(titleSpan);
        th.appendChild(toggle);
        th.appendChild(menu);
        th.dataset.sfSortReady = '1';
        th.dataset.sfSortLabel = label;
      }

      if (toggle) {
        toggle.setAttribute('aria-label', 'Sort ' + label);
      }

      if (!menu) return;
      menu.innerHTML = '';

      let options;
      if (type === 'number') {
        options = [
          { label: 'Low to High', mode: 'num_asc' },
          { label: 'High to Low', mode: 'num_desc' }
        ];
      } else if (type === 'date') {
        options = [
          { label: 'Oldest First', mode: 'date_asc' },
          { label: 'Newest First', mode: 'date_desc' }
        ];
      } else {
        options = [
          { label: 'A to Z', mode: 'text_asc' },
          { label: 'Z to A', mode: 'text_desc' }
        ];
      }

      options.forEach((opt) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'sf-sort-option';
        btn.textContent = opt.label;

        btn.addEventListener('click', () => {
          menu.classList.remove('open');
          sfSortTableByMode(table, columnIndex, opt.mode);
        });
        menu.appendChild(btn);
      });
      th.dataset.sfSortType = type;
    }

    function setupSortableTableDropdowns(root) {
      const scope = root || document;
      const tables = scope.querySelectorAll('table.data-table, table.tx-export-table');

      tables.forEach((table) => {
        const headerCells = table.querySelectorAll('thead th');
        if (!headerCells.length) return;

        sfEnsureRowBaseOrder(table);
        headerCells.forEach((th, idx) => sfMakeColumnSortable(table, th, idx));
        table.dataset.sfSortInit = '1';
      });

      sfNormalizeDashCells(scope);
    }

    function buildMachineryRowMarkup(data) {
      const id = escapeHtml(data.id);
      const name = escapeHtml(data.name);
      const owner = escapeHtml(data.owner);
      const type = escapeHtml(data.type);
      const condition = escapeHtml(data.condition);
      const status = escapeHtml(data.status);
      const rate = Number(data.rate) || 0;
      const rateText = '₱' + rate.toLocaleString('en-US');
      const statusText = getMachineryStatusLabel(data.status);

      return '<tr data-id="' + id + '" data-name="' + name + '" data-owner="' + owner + '" data-type="' + type + '" data-condition="' + condition + '" data-rate="' + rate + '" data-status="' + status + '">' +
        '<td>' + id + '</td>' +
        '<td>' + name + '</td>' +
        '<td>' + owner + '</td>' +
        '<td>' + type + '</td>' +
        '<td>' + condition + '</td>' +
        '<td>' + rateText + '</td>' +
        '<td><span class="status ' + status + '">' + statusText + '</span></td>' +
        '<td><button class="btn-small btn-edit" type="button" data-tooltip="Edit" onclick="editMachineryRow(this)"><i class="fas fa-edit"></i></button></td>' +
      '</tr>';
    }

    function updateMachineryRow(row, data) {
      if (!row) return;

      const rate = Number(data.rate) || 0;
      const statusText = getMachineryStatusLabel(data.status);

      row.dataset.id = data.id;
      row.dataset.name = data.name;
      row.dataset.owner = data.owner;
      row.dataset.type = data.type;
      row.dataset.condition = data.condition;
      row.dataset.rate = String(rate);
      row.dataset.status = data.status;

      row.cells[0].textContent = data.id;
      row.cells[1].textContent = data.name;
      row.cells[2].textContent = data.owner;
      row.cells[3].textContent = data.type;
      row.cells[4].textContent = data.condition;
      row.cells[5].textContent = '₱' + rate.toLocaleString('en-US');
      row.cells[6].innerHTML = '<span class="status ' + data.status + '">' + statusText + '</span>';
    }

    function openMachineryFormModal(row) {
      const formModal = document.getElementById('machineryFormModal');
      const form = document.getElementById('machineryForm');
      if (!formModal || !form) return;

      const modeInput = document.getElementById('machineryFormMode');
      const editIdInput = document.getElementById('machineryEditId');
      const titleEl = document.getElementById('machineryFormTitle');
      const submitBtn = document.getElementById('machinerySubmitBtn');

      if (row) {
        if (modeInput) modeInput.value = 'edit';
        if (editIdInput) editIdInput.value = row.dataset.id || '';
        if (titleEl) titleEl.innerHTML = '<i class="fas fa-edit" style="color:#f59e0b;margin-right:0.4rem;"></i>Edit Machinery';
        if (submitBtn) submitBtn.textContent = 'Update Machinery';

        const nameInput = document.getElementById('machineryName');
        const ownerInput = document.getElementById('machineryOwner');
        const typeInput = document.getElementById('machineryType');
        const conditionInput = document.getElementById('machineryCondition');
        const rateInput = document.getElementById('machineryRate');
        const statusInput = document.getElementById('machineryStatus');

        if (nameInput) nameInput.value = row.dataset.name || '';
        if (ownerInput) ownerInput.value = row.dataset.owner || '';
        if (typeInput) typeInput.value = row.dataset.type || '';
        if (conditionInput) conditionInput.value = row.dataset.condition || '';
        if (rateInput) rateInput.value = row.dataset.rate || '';
        if (statusInput) statusInput.value = row.dataset.status || 'available';
      } else {
        form.reset();
        if (modeInput) modeInput.value = 'add';
        if (editIdInput) editIdInput.value = '';
        if (titleEl) titleEl.innerHTML = '<i class="fas fa-plus-circle" style="color:#22c55e;margin-right:0.4rem;"></i>Add Machinery';
        if (submitBtn) submitBtn.textContent = 'Add Machinery';

        const statusInput = document.getElementById('machineryStatus');
        if (statusInput) statusInput.value = 'available';
      }

      formModal.classList.add('is-visible');
    }

    function closeMachineryFormModal(event) {
      const formModal = document.getElementById('machineryFormModal');
      if (!formModal) return;

      if (!event || event.target === formModal) {
        formModal.classList.remove('is-visible');
      }
    }

    function submitMachineryForm(event) {
      event.preventDefault();

      const mode = document.getElementById('machineryFormMode')?.value || 'add';
      const editId = document.getElementById('machineryEditId')?.value || '';

      const name = document.getElementById('machineryName')?.value.trim() || '';
      const owner = document.getElementById('machineryOwner')?.value.trim() || '';
      const type = document.getElementById('machineryType')?.value || '';
      const condition = document.getElementById('machineryCondition')?.value || '';
      const rate = Number(document.getElementById('machineryRate')?.value || 0);
      const status = document.getElementById('machineryStatus')?.value || 'available';

      if (!name || !owner || !type || !condition || !rate || rate <= 0) {
        alert('Please complete all machinery fields.');
        return;
      }

      const payload = new FormData();
      payload.append('action', 'add_rental_listing');
      payload.append('equipment_name', name);
      payload.append('owner_name', owner);
      payload.append('daily_rate', String(rate));
      payload.append('listing_status', status);

      fetch('admin_dashboard.php?section=rental-monitor', {
        method: 'POST',
        body: payload
      })
        .then(function () {
          closeMachineryFormModal();
          window.location.reload();
        })
        .catch(function () {
          window.alert('Failed to add machinery listing.');
        });
    }

    function editMachineryRow(button) {
      const row = button ? button.closest('tr') : null;
      if (!row) return;

      openMachineryFormModal(row);
    }

    function getBidActionButtonHTML(stageClass, bidId) {
      return '<button class="btn-small" type="button" data-tooltip="View Details" onclick="viewBidDetails(this, \'" + bidId + "\')"><i class="fas fa-eye"></i></button>';
    }

    function setBidStage(row, stageClass, label, bidId) {
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge) return;

      statusBadge.className = 'status ' + stageClass;
      statusBadge.textContent = label;

      const actionCell = row.cells[row.cells.length - 1];
      if (actionCell) {
        actionCell.innerHTML = getBidActionButtonHTML(stageClass, bidId);
      }
    }

    function setBidDetailValue(elementId, value) {
      const el = document.getElementById(elementId);
      if (el) el.textContent = value || '-';
    }

    function populateBidDetailsModal(row, bidId) {
      if (!row || row.cells.length < 9) return;

      const modal = document.getElementById('bidDetailsModal');
      if (!modal) return;

      const statusBadge = row.querySelector('.status');
      const stageText = statusBadge ? statusBadge.textContent.trim() : '-';
      const stageClass = statusBadge
        ? Array.from(statusBadge.classList).find(cls => cls !== 'status') || 'ongoing'
        : 'ongoing';

      modal.dataset.currentBidId = bidId;

      setBidDetailValue('bidDetailsBidId', bidId);
      setBidDetailValue('bidDetailsProduct', row.cells[1].textContent.trim());
      setBidDetailValue('bidDetailsClient', row.cells[2].textContent.trim());
      setBidDetailValue('bidDetailsUserBid', row.cells[3].textContent.trim());
      setBidDetailValue('bidDetailsQuantity', row.cells[4].textContent.trim());
      setBidDetailValue('bidDetailsEndDate', row.cells[6].textContent.trim());

      const stageEl = document.getElementById('bidDetailsStage');
      if (stageEl) {
        stageEl.className = 'status ' + stageClass;
        stageEl.textContent = stageText;
      }

      const claimedBtn = document.getElementById('bidDetailsMarkClaimedBtn');
      if (claimedBtn) {
        claimedBtn.style.display = stageClass === 'sold' ? 'inline-flex' : 'none';
      }
    }

    function viewBidDetails(button, bidId) {
      const row = button ? button.closest('tr') : null;
      const modal = document.getElementById('bidDetailsModal');
      if (!row || !modal) return;

      populateBidDetailsModal(row, bidId);
      modal.classList.add('is-visible');
    }

    function closeBidDetailsModal(event) {
      const modal = document.getElementById('bidDetailsModal');
      if (!modal) return;

      if (!event || event.target === modal) {
        modal.classList.remove('is-visible');
      }
    }

    function markBidClaimedFromModal() {
      const modal = document.getElementById('bidDetailsModal');
      if (!modal) return;

      const bidId = modal.dataset.currentBidId || '';
      if (!bidId) return;

      const row = getBidRowById(bidId);
      if (!row) return;

      markBidClaimed(null, bidId, false, row);
    }

    function markBidEnded(button, bidId) {
      const row = button ? button.closest('tr') : null;
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge || !statusBadge.classList.contains('ongoing')) return;

      if (!confirm('End bidding for ' + bidId + '?')) return;
      setBidStage(row, 'ended', 'Ended', bidId);
    }

    function markBidSold(button, bidId) {
      const row = button ? button.closest('tr') : null;
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge || !statusBadge.classList.contains('ended')) return;

      if (!confirm('Mark ' + bidId + ' as sold?')) return;
      setBidStage(row, 'sold', 'Sold', bidId);
    }

    function markBidClaimed(button, bidId, skipConfirm, rowOverride) {
      const row = rowOverride || (button ? button.closest('tr') : null) || getBidRowById(bidId);
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge || !statusBadge.classList.contains('sold')) return;

      if (!skipConfirm && !confirm('Mark ' + bidId + ' as claimed?')) return;

      setBidStage(row, 'claimed', 'Claimed', bidId);
      populateBidDetailsModal(row, bidId);
    }

    function reopenBid(button, bidId) {
      const row = button ? button.closest('tr') : null;
      if (!row) return;

      const statusBadge = row.querySelector('.status');
      if (!statusBadge || !statusBadge.classList.contains('cancelled')) return;

      if (!confirm('Reopen ' + bidId + ' as ongoing?')) return;
      setBidStage(row, 'ongoing', 'Ongoing', bidId);
    }

    // Filter tables by search and status
    function filterTable(type) {
      const search = document.getElementById(type + 'Search') ? document.getElementById(type + 'Search').value.toLowerCase() : '';
      const status = document.getElementById(type + 'Status') ? document.getElementById(type + 'Status').value : '';
      const table = document.getElementById(type + 'Table');
      if (!table) return;
      
      const rows = table.querySelectorAll('tbody tr');
      
      rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const statusCol = row.querySelector('.status');
        const rowStatus = statusCol ? statusCol.textContent.toLowerCase() : (row.dataset.stockStatus || '').toLowerCase();

        const matchesSearch = search === '' || text.includes(search);
        const matchesStatus = status === '' || rowStatus.includes(status);

        row.style.display = matchesSearch && matchesStatus ? '' : 'none';
      });

      sfApplyGroupBy(type + 'Table');
    }

    // Export data
    function exportData(type) {
      const typeMap = {
        bidding: 'bidding',
        rentals: 'rentals',
        rental: 'rentals',
        seeds: 'seeds',
        livestock: 'livestock'
      };

      const exportType = typeMap[String(type || '').toLowerCase()];
      if (!exportType) {
        alert('Export type is not supported yet.');
        return;
      }

      window.location.href = 'admin_dashboard.php?section=transaction-export-preview&type=' + encodeURIComponent(exportType) + '&from=' + encodeURIComponent(exportType === 'rentals' ? 'rental-monitor' : exportType === 'bidding' ? 'bidding-monitor' : exportType === 'seeds' ? 'distribute-seeds' : 'manage-livestock-products');
    }

    // Export report
    function exportReport(type) {
      alert('Generating ' + type + ' report...');
    }

    // Custom export
    function exportCustom() {
      alert('Generating custom report...');
    }

    // Modal functions
    function openAddCropModal() {
      const addCropModal = document.getElementById('addCropModal');
      if (addCropModal) {
        addCropModal.classList.add('is-visible');
        return;
      }

      alert('Opening Add Crop modal...');
    }

    function openDistributeSeedsModal() {
      const distributeModal = document.getElementById('distributeSeedsModal');
      const distributeForm = document.getElementById('distributeSeedsForm');
      const distDate = document.getElementById('dist_date');

      if (distributeModal) {
        distributeModal.classList.add('is-visible');

        if (distributeForm) {
          distributeForm.reset();
        }

        if (distDate) {
          distDate.value = new Date().toISOString().split('T')[0];
        }
        return;
      }

      alert('Opening Distribute Seeds modal...');
    }

    function openAddMachineryModal() {
      const formModal = document.getElementById('machineryFormModal');
      if (formModal) {
        openMachineryFormModal();
        return;
      }

      alert('Open Machinery Rentals and click the list button to manage machinery cards.');
    }

    // Logout
    function logout() {
      // Use the global confirmation modal for logout
      const modal = document.getElementById('sfConfirmModal');
      const messageEl = document.getElementById('sfConfirmMessage');
      const confirmBtn = document.getElementById('sfConfirmOkBtn');
      const cancelBtn = document.getElementById('sfConfirmCancelBtn');
      if (!modal || !messageEl || !confirmBtn || !cancelBtn) {
        // fallback to confirm if modal not found
        if (confirm('Are you sure you want to logout?')) {
          window.location.href = 'logout.php';
        }
        return;
      }
      messageEl.textContent = 'Are you sure you want to logout?';
      modal.classList.add('is-visible');
      modal.setAttribute('aria-hidden', 'false');
      // Remove any previous listeners
      const newConfirm = confirmBtn.cloneNode(true);
      confirmBtn.parentNode.replaceChild(newConfirm, confirmBtn);
      const newCancel = cancelBtn.cloneNode(true);
      cancelBtn.parentNode.replaceChild(newCancel, cancelBtn);
      // Confirm
      newConfirm.addEventListener('click', function() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
        window.location.href = 'logout.php';
      });
      // Cancel
      newCancel.addEventListener('click', function() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
      });
      // ESC key closes modal
      function escHandler(e) {
        if (e.key === 'Escape') {
          modal.classList.remove('is-visible');
          modal.setAttribute('aria-hidden', 'true');
          document.removeEventListener('keydown', escHandler);
        }
      }
      document.addEventListener('keydown', escHandler);
      newCancel.focus();
    }

    function setupGlobalFormConfirmation() {
      const modal = document.getElementById('sfConfirmModal');
      const titleEl = document.getElementById('sfConfirmTitle');
      const messageEl = document.getElementById('sfConfirmMessage');
      const confirmBtn = document.getElementById('sfConfirmOkBtn');
      const cancelBtn = document.getElementById('sfConfirmCancelBtn');
      if (!modal || !titleEl || !messageEl || !confirmBtn || !cancelBtn) return;

      let pendingForm = null;
      let pendingSubmitter = null;

      function closeModal() {
        modal.classList.remove('is-visible');
        modal.setAttribute('aria-hidden', 'true');
      }

      function openModal(message, form, submitter, title) {
        pendingForm = form;
        pendingSubmitter = submitter || null;
        titleEl.textContent = title || 'Confirm Submission';
        messageEl.textContent = message;
        modal.classList.add('is-visible');
        modal.setAttribute('aria-hidden', 'false');
        cancelBtn.focus();
      }

      confirmBtn.addEventListener('click', () => {
        if (!pendingForm) {
          closeModal();
          return;
        }

        const form = pendingForm;
        const submitter = pendingSubmitter;
        pendingForm = null;
        pendingSubmitter = null;
        form.dataset.sfConfirmArmed = '1';
        closeModal();

        if (typeof form.requestSubmit === 'function') {
          if (submitter && submitter.form === form) {
            form.requestSubmit(submitter);
          } else {
            form.requestSubmit();
          }
        } else {
          form.submit();
        }
      });

      cancelBtn.addEventListener('click', () => {
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      modal.addEventListener('click', (event) => {
        if (event.target !== modal) return;
        pendingForm = null;
        pendingSubmitter = null;
        closeModal();
      });

      document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal.classList.contains('is-visible')) {
          pendingForm = null;
          pendingSubmitter = null;
          closeModal();
        }
      });

      document.addEventListener('submit', (event) => {
        const form = event.target;
        if (!(form instanceof HTMLFormElement)) return;

        if (form.dataset.sfConfirmArmed === '1') {
          delete form.dataset.sfConfirmArmed;
          return;
        }

        if (form.getAttribute('data-skip-confirm') === 'true') {
          return;
        }

        const submitter = event.submitter || null;
        const message = (submitter && submitter.getAttribute('data-confirm-message'))
          || form.getAttribute('data-confirm-message')
          || 'Are you sure you want to continue with this submission?';
        const title = (submitter && submitter.getAttribute('data-confirm-title'))
          || form.getAttribute('data-confirm-title')
          || 'Confirm Submission';

        event.preventDefault();
        event.stopImmediatePropagation();
        openModal(message, form, submitter, title);
      }, true);
    }

    // Toggle category collapse/expand and persist state
    function toggleCategory(element) {
      const key = 'admin_nav_open';
      const cat = element.dataset.cat || element.textContent.trim();

      element.classList.toggle('collapsed');
      const itemsContainer = element.nextElementSibling;
      if (itemsContainer && itemsContainer.classList.contains('nav-category-items')) {
        itemsContainer.classList.toggle('collapsed');
      }

      // Persist open categories in localStorage
      try {
        let arr = JSON.parse(localStorage.getItem(key) || '[]');
        if (!Array.isArray(arr)) arr = [];
        const idx = arr.indexOf(cat);
        const isOpen = !element.classList.contains('collapsed');
        if (isOpen && idx === -1) {
          arr.push(cat);
        } else if (!isOpen && idx !== -1) {
          arr.splice(idx, 1);
        }
        localStorage.setItem(key, JSON.stringify(arr));
      } catch (e) {
        // ignore storage errors
      }
    }

    function toggleNotifyDropdown(e) {
      e.stopPropagation();
      const dropdown = document.getElementById('notifyDropdown');
      if (!dropdown) return;
      const opening = !dropdown.classList.contains('active');
      dropdown.classList.toggle('active');
      if (opening) {
        fetch('mark_notifications_read.php', { method: 'POST', credentials: 'same-origin' })
          .then(r => r.json())
          .then(data => {
            if (data.ok && data.updated > 0) {
              const badge = document.querySelector('.admin-notify-btn .badge');
              if (badge) badge.remove();
            }
          })
          .catch(() => {});
      }
    }

    function toggleProfileDropdown(e) {
      e.stopPropagation();
      const dropdown = document.getElementById('adminProfileDropdown');
      const trigger = document.getElementById('adminProfileTrigger');
      const profileBox = trigger ? trigger.closest('.admin-profile') : null;
      if (!dropdown || !trigger) return;
      const isOpen = dropdown.classList.toggle('active');
      if (profileBox) profileBox.classList.toggle('open', isOpen);
      dropdown.setAttribute('aria-hidden', String(!isOpen));
      trigger.setAttribute('aria-expanded', String(isOpen));
    }

    function setSidebarCollapsed(isCollapsed) {
      document.body.classList.toggle('sidebar-collapsed', isCollapsed);
      const toggleBtn = document.getElementById('adminSidebarToggle');
      if (toggleBtn) {
        toggleBtn.setAttribute('aria-expanded', String(!isCollapsed));
        toggleBtn.setAttribute('aria-label', isCollapsed ? 'Show sidebar' : 'Hide sidebar');
      }
      try {
        localStorage.setItem('admin_sidebar_collapsed', isCollapsed ? '1' : '0');
      } catch (e) {
        // ignore storage errors
      }
    }

    function toggleSidebar() {
      const isCollapsed = document.body.classList.contains('sidebar-collapsed');
      setSidebarCollapsed(!isCollapsed);
    }

    // Auto-dismiss alert messages
    setTimeout(() => {
      document.querySelectorAll('.alert-message').forEach((el) => {
        el.classList.add('hide');
        setTimeout(() => {
          if (el && el.parentNode) el.parentNode.removeChild(el);
        }, 450);
      });
    }, 3000);

    // Close dropdown when clicking outside the dropdown menu and button
    document.addEventListener('click', function(event) {
      const notifyDropdown = document.getElementById('notifyDropdown');
      const adminUserMenu = document.querySelector('.admin-user-menu');
      const profileDropdown = document.getElementById('adminProfileDropdown');
      const profileTrigger = document.getElementById('adminProfileTrigger');
      const profileBox = profileTrigger ? profileTrigger.closest('.admin-profile') : null;
      
      // Only close if clicking outside the entire user menu area
      if (adminUserMenu && !adminUserMenu.contains(event.target)) {
        if (notifyDropdown && notifyDropdown.classList.contains('active')) notifyDropdown.classList.remove('active');
      }

      if (profileBox && !profileBox.contains(event.target)) {
        if (profileDropdown && profileDropdown.classList.contains('active')) {
          profileDropdown.classList.remove('active');
          profileDropdown.setAttribute('aria-hidden', 'true');
        }
        if (profileBox) profileBox.classList.remove('open');
        if (profileTrigger) profileTrigger.setAttribute('aria-expanded', 'false');
      }
    });

    const profileTrigger = document.getElementById('adminProfileTrigger');
    if (profileTrigger) {
      profileTrigger.addEventListener('click', toggleProfileDropdown);
    }

    const sidebarToggle = document.getElementById('adminSidebarToggle');
    if (sidebarToggle) {
      sidebarToggle.addEventListener('click', toggleSidebar);
    }

    document.addEventListener('click', function(event) {
      if (!event.target.closest('.sf-sortable')) {
        sfCloseAllSortMenus();
      }
    });

    setupSortableTableDropdowns(document);

    // Keep default browser history behavior for reliability.

    setupGlobalFormConfirmation();
  </script>

  <script>
    // Activate the correct section immediately and expand sidebar category
    (function() {
      const urlParams = new URLSearchParams(window.location.search);
      const currentSection = urlParams.get('section') || 'dashboard';
      const navScroll = document.querySelector('.admin-nav-scroll');
      let storedScroll = 0;

      // Apply persisted sidebar state
      try {
        const stored = localStorage.getItem('admin_sidebar_collapsed');
        if (stored === '1') {
          setSidebarCollapsed(true);
        }
      } catch (e) {
        // ignore storage errors
      }

      // Read stored sidebar scroll position
      if (navScroll) {
        try {
          storedScroll = parseInt(localStorage.getItem('admin_nav_scroll') || '0', 10) || 0;
        } catch (e) {
          storedScroll = 0;
        }
      }

      // Remove active class from all sections
      const sections = document.querySelectorAll('.admin-section');
      sections.forEach(section => section.classList.remove('active'));

      // Add active class to the current section
      const activeSection = document.getElementById('section-' + currentSection);
      if (activeSection) activeSection.classList.add('active');

      // Apply persisted open categories and expand the category that contains the active nav item
      try {
        const openCats = JSON.parse(localStorage.getItem('admin_nav_open') || '[]');
        document.querySelectorAll('.nav-category').forEach(header => {
          const items = header.nextElementSibling;
          if (!items) return;
          const cat = header.dataset.cat || header.textContent.trim();

          // If persisted as open, expand it
          if (Array.isArray(openCats) && openCats.includes(cat)) {
            header.classList.remove('collapsed');
            items.classList.remove('collapsed');
          }

          // Ensure the category that contains the active item is expanded
          if (items.querySelector('.nav-item.active')) {
            header.classList.remove('collapsed');
            items.classList.remove('collapsed');
          }
        });
      } catch (e) {
        // fallback: only expand active category
        document.querySelectorAll('.nav-category').forEach(header => {
          const items = header.nextElementSibling;
          if (!items) return;
          if (items.querySelector('.nav-item.active')) {
            header.classList.remove('collapsed');
            items.classList.remove('collapsed');
          }
        });
      }

      // Restore sidebar scroll position after layout settles
      if (navScroll) {
        requestAnimationFrame(() => {
          navScroll.scrollTop = storedScroll;
        });
      }

      // Track sidebar scroll position for next load
      if (navScroll) {
        navScroll.addEventListener('scroll', () => {
          try {
            localStorage.setItem('admin_nav_scroll', String(navScroll.scrollTop));
          } catch (e) {
            // ignore storage errors
          }
        });

        document.querySelectorAll('.admin-nav .nav-item').forEach((item) => {
          item.addEventListener('click', () => {
            try {
              localStorage.setItem('admin_nav_scroll', String(navScroll.scrollTop));
            } catch (e) {
              // ignore storage errors
            }
          });
        });
      }
    })();
  </script>
</body>
</html>
