-- Crops table for bidding system
CREATE TABLE IF NOT EXISTS `crops` (
  `crop_id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_id` int(11) NOT NULL,
  `crop_name` varchar(255) NOT NULL,
  `crop_description` text DEFAULT NULL,
  `crop_quantity` decimal(10,2) NOT NULL,
  `crop_unit` varchar(50) NOT NULL DEFAULT 'kg',
  `starting_price` decimal(10,2) NOT NULL,
  `crop_status` enum('available','sold','expired') DEFAULT 'available',
  `bidding_end_date` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`crop_id`),
  KEY `idx_farmer_id` (`farmer_id`),
  KEY `idx_crop_status` (`crop_status`),
  KEY `idx_bidding_end_date` (`bidding_end_date`),
  CONSTRAINT `crops_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`farmer_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Bids table
CREATE TABLE IF NOT EXISTS `bids` (
  `bid_id` int(11) NOT NULL AUTO_INCREMENT,
  `crop_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `bid_amount` decimal(10,2) NOT NULL,
  `bid_status` enum('active','outbid','won','cancelled') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`bid_id`),
  KEY `idx_crop_id` (`crop_id`),
  KEY `idx_client_id` (`client_id`),
  KEY `idx_bid_status` (`bid_status`),
  CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`crop_id`) REFERENCES `crops` (`crop_id`) ON DELETE CASCADE,
  CONSTRAINT `bids_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Optional sample crops for testing.
-- This insert only runs when at least one farmer account exists.
INSERT INTO `crops` (`farmer_id`, `crop_name`, `crop_description`, `crop_quantity`, `crop_unit`, `starting_price`, `crop_status`, `bidding_end_date`)
SELECT
  f.farmer_id,
  s.crop_name,
  s.crop_description,
  s.crop_quantity,
  s.crop_unit,
  s.starting_price,
  'available',
  s.bidding_end_date
FROM `farmers` f
JOIN (
  SELECT 1 AS seq, 'Rice (Jasmine)' AS crop_name, 'Premium quality jasmine rice from our organic farm' AS crop_description, 1000.00 AS crop_quantity, 'kg' AS crop_unit, 15000.00 AS starting_price, '2026-03-15 23:59:59' AS bidding_end_date
  UNION ALL SELECT 2, 'Yellow Corn', 'Fresh yellow corn, suitable for both consumption and feed', 500.00, 'kg', 8000.00, '2026-03-10 23:59:59'
  UNION ALL SELECT 3, 'Sweet Potato', 'Organic sweet potatoes, freshly harvested', 300.00, 'kg', 9000.00, '2026-03-20 23:59:59'
  UNION ALL SELECT 4, 'Tomatoes', 'Ripe, juicy tomatoes perfect for fresh markets', 200.00, 'kg', 6000.00, '2026-03-08 23:59:59'
  UNION ALL SELECT 5, 'Cabbage', 'Fresh green cabbage heads', 400.00, 'kg', 5500.00, '2026-03-12 23:59:59'
) s
WHERE f.farmer_id = (SELECT MIN(farmer_id) FROM `farmers`);
