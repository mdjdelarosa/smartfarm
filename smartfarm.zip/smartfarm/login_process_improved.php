<?php
// SmartFarm Login Process (IMPROVED VERSION)
// Uses unified users table for efficient role detection
// Handles login for Admin, Farmer, and Client accounts
// Automatically redirects based on user role

require 'config.php';

// Debug logging
$debug_enabled = false;
function debug_log($label, $data = null) {
    global $debug_enabled;
    if (!$debug_enabled) return;
    $dir = __DIR__ . '/debug';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $file = $dir . '/login_debug.log';
    $entry = "[" . date('Y-m-d H:i:s') . "] " . $label . ": ";
    if (is_null($data)) {
        $entry .= "\n";
    } elseif (is_scalar($data)) {
        $entry .= $data . "\n";
    } else {
        $entry .= print_r($data, true) . "\n";
    }
    @file_put_contents($file, $entry, FILE_APPEND);
}

debug_log('POST_received', $_POST);

$is_ajax_request = (
    isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower((string)$_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest'
) || stripos((string)($_SERVER['HTTP_ACCEPT'] ?? ''), 'application/json') !== false;

function respondLogin(bool $success, string $message, ?string $redirect = null, array $extra = []): void {
    global $is_ajax_request;

    if ($is_ajax_request) {
        header('Content-Type: application/json');
        echo json_encode(array_merge([
            'success' => $success,
            'message' => $message,
            'redirect' => $redirect
        ], $extra));
        exit;
    }

    if ($success) {
        $_SESSION['success'] = $message;
    } else {
        $_SESSION['error'] = $message;
    }

    if ($redirect !== null) {
        header('Location: ' . $redirect);
        exit;
    }
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respondLogin(false, 'Invalid request method', 'login.php');
}

// ============================================
// STEP 1: GET AND VALIDATE INPUT
// ============================================

$email = sanitizeInput($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    respondLogin(false, 'Email or phone number and password are required', 'login.php');
}

// ============================================
// STEP 2: CHECK USER IN UNIFIED USERS TABLE
// ============================================
// Accept either the account email or the farmer/client's registered
// contact number as the login identifier.

$user = null;
$user_role = null;

$query = "SELECT user_id, email, password, role, is_active FROM users WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
}
$stmt->close();

if ($user === null) {
    $normalizedPhone = normalizeContactNumber($email);
    if ($normalizedPhone !== '') {
        $phone_query = "
            SELECT u.user_id, u.email, u.password, u.role, u.is_active
            FROM users u
            INNER JOIN farmers f ON f.user_id = u.user_id
            WHERE REPLACE(REPLACE(REPLACE(f.farmer_contact_number, '+', ''), '-', ''), ' ', '') = ?
            UNION
            SELECT u.user_id, u.email, u.password, u.role, u.is_active
            FROM users u
            INNER JOIN clients c ON c.user_id = u.user_id
            WHERE REPLACE(REPLACE(REPLACE(c.client_contact_number, '+', ''), '-', ''), ' ', '') = ?
            LIMIT 1
        ";
        $phoneStmt = $conn->prepare($phone_query);
        $phoneStmt->bind_param('ss', $normalizedPhone, $normalizedPhone);
        $phoneStmt->execute();
        $phoneResult = $phoneStmt->get_result();
        if ($phoneResult->num_rows > 0) {
            $user = $phoneResult->fetch_assoc();
        }
        $phoneStmt->close();
    }
}

if ($user !== null) {
    $user_role = $user['role'];
    debug_log('user_found', ['user_id'=>$user['user_id'], 'email'=>$user['email'], 'role'=>$user_role]);
} else {
    debug_log('user_not_found', $email);
}

// ============================================
// STEP 3: USER NOT FOUND
// ============================================

if ($user === null) {
    $_SESSION['error'] = 'Invalid email/phone number or password';
    error_log("Login attempt failed: Email/phone not found - $email");
    debug_log('user_not_found', $email);
    respondLogin(false, 'Invalid email/phone number or password', 'login.php');
}

// ============================================
// STEP 4: CHECK IF ACCOUNT IS ACTIVE
// ============================================

if (!$user['is_active']) {
    $_SESSION['error'] = 'Your account has been deactivated. Contact administrator.';
    error_log("Login attempt failed: Account inactive - $email");
    debug_log('account_inactive', ['email'=>$email, 'role'=>$user_role]);
    respondLogin(false, 'Your account has been deactivated. Contact administrator.', 'login.php');
}

// ============================================
// STEP 5: VERIFY PASSWORD
// ============================================

if (!verifyPassword($password, $user['password'])) {
    $_SESSION['error'] = 'Incorrect password. Please try again.';
    error_log("Login attempt failed: Wrong password - $email");
    debug_log('password_verify_failed', ['email'=>$email, 'role'=>$user_role]);
    respondLogin(false, 'Incorrect password. Please try again.', 'login.php');
}

debug_log('password_verify_success', ['email'=>$email, 'role'=>$user_role]);

// ============================================
// STEP 6: GET ROLE-SPECIFIC DATA
// ============================================
// Now fetch the role-specific information

$user_fullname = '';

if ($user_role === 'admin') {
    $query = "SELECT fullname FROM admins WHERE user_id = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $admin_data = $result->fetch_assoc();
        $user_fullname = $admin_data['fullname'];
    }
    $stmt->close();
} elseif ($user_role === 'farmer') {
    $query = "SELECT user_id, farmer_fullname, farmer_is_verified, farmer_id_verification_status AS verification_status FROM farmers WHERE user_id = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $farmer_data = $result->fetch_assoc();
        $user_fullname = $farmer_data['farmer_fullname'];
        $is_verified = $farmer_data['farmer_is_verified'];
        $verification_status = strtolower((string)($farmer_data['verification_status'] ?? 'pending'));
    }
    $stmt->close();
} elseif ($user_role === 'client') {
    $query = "SELECT user_id, client_fullname, client_is_verified, client_id_verification_status AS verification_status FROM clients WHERE user_id = ? LIMIT 1";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $client_data = $result->fetch_assoc();
        $user_fullname = $client_data['client_fullname'];
        $is_verified = $client_data['client_is_verified'];
        $verification_status = strtolower((string)($client_data['verification_status'] ?? 'pending'));
    }
    $stmt->close();
}

// Require email/SMS verification before non-admin accounts can continue.
if ($user_role === 'farmer' || $user_role === 'client') {
    $verification = getAccountVerificationByUserId($conn, (int)$user['user_id']);
    $verification_ready = $verification && (string)($verification['status'] ?? 'pending') === 'verified';

    if (!$verification_ready) {
        respondLogin(false, 'Your account still needs email and SMS verification before you can log in.', 'login.php');
    }

    $user['is_active'] = 1;
}

// ============================================
// STEP 7: SET SESSION VARIABLES
// ============================================

// Set session variables BEFORE regenerating ID
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['user_role'] = $user_role;
$_SESSION['user_email'] = $user['email'];
$_SESSION['user_fullname'] = $user_fullname;
$_SESSION['login_time'] = time();

// For farmers and clients, also store verification status
if ($user_role === 'farmer' || $user_role === 'client') {
    $_SESSION['is_verified'] = $is_verified ?? 0;
    $_SESSION['verification_status'] = $verification_status ?? 'pending';
}

// Regenerate session ID for security
session_regenerate_id(false);

debug_log('session_after_set', $_SESSION);

// Log successful login
error_log("Login successful: User=$email, Role=$user_role, UserID=" . $user['user_id']);

$approval_message = 'Login successful. Welcome back, ' . $user_fullname . '.';
if (($user_role === 'farmer' || $user_role === 'client') && (($is_verified ?? 0) != 1 || strtolower((string)($verification_status ?? 'pending')) !== 'approved')) {
    $approval_message = 'Login successful. Your account is pending admin approval, so some features remain locked until approval is completed.';
}

$_SESSION['success'] = $approval_message;

// ============================================
// STEP 8: REDIRECT BASED ON ROLE
// ============================================

if ($user_role === 'admin') {
    respondLogin(true, $approval_message, 'admin_dashboard.php', ['role' => $user_role, 'approval_status' => 'approved']);
} elseif ($user_role === 'farmer') {
    respondLogin(true, $approval_message, 'farmer/dashboard.php', ['role' => $user_role, 'approval_status' => (string)($verification_status ?? 'pending')]);
} elseif ($user_role === 'client') {
    respondLogin(true, $approval_message, 'client/dashboard.php', ['role' => $user_role, 'approval_status' => (string)($verification_status ?? 'pending')]);
}

// Should not reach here
respondLogin(false, 'Unable to complete login. Please try again.', 'login.php');
?>
