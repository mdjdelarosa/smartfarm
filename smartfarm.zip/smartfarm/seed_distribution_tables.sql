-- Seed Inventory and Distribution Tables
-- Run this migration to add seed management functionality

-- Seed Inventory Table
CREATE TABLE IF NOT EXISTS `seed_inventory` (
  `seed_id` int(11) NOT NULL AUTO_INCREMENT,
  `seed_name` varchar(100) NOT NULL,
  `seed_unit` varchar(50) NOT NULL DEFAULT 'kg',
  `available_quantity` decimal(10, 2) NOT NULL DEFAULT 0,
  `low_stock_threshold` decimal(10, 2) NOT NULL DEFAULT 5,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`seed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Seed Distribution Table
CREATE TABLE IF NOT EXISTS `seed_distributions` (
  `distribution_id` int(11) NOT NULL AUTO_INCREMENT,
  `farmer_id` int(11) NOT NULL,
  `seed_id` int(11) NOT NULL,
  `quantity_distributed` decimal(10, 2) NOT NULL,
  `distribution_date` date NOT NULL,
  `status` enum('Released','Received','Cancelled') NOT NULL DEFAULT 'Released',
  `notes` text,
  `created_by` int(11),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`distribution_id`),
  KEY `farmer_id` (`farmer_id`),
  KEY `seed_id` (`seed_id`),
  CONSTRAINT `seed_distributions_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`farmer_id`),
  CONSTRAINT `seed_distributions_ibfk_2` FOREIGN KEY (`seed_id`) REFERENCES `seed_inventory` (`seed_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Sample Seed Inventory Data
INSERT INTO `seed_inventory` (`seed_name`, `seed_unit`, `available_quantity`, `low_stock_threshold`) VALUES
('Rice Seeds - Premium', 'kg', 150.00, 10),
('Corn Seeds - Yellow', 'kg', 200.00, 15),
('Wheat Seeds - Winter', 'kg', 180.00, 12),
('Tomato Seeds - Hybrid', 'grams', 500.00, 50),
('Cabbage Seeds - Green', 'grams', 300.00, 30),
('Lettuce Seeds - Romaine', 'grams', 250.00, 25);

-- Temporary farmer account for UI preview (safe to run multiple times)
INSERT INTO `users` (`email`, `password`, `role`, `is_active`)
SELECT 'demo.farmer.seed@smartfarm.local', '$2y$10$4xM3Bg4x5m9N9m8TT6gGzeF6vYw7HkRoqS3M8W8R5J3vI8C7X0QyK', 'farmer', 1
WHERE NOT EXISTS (
  SELECT 1 FROM `users` WHERE `email` = 'demo.farmer.seed@smartfarm.local'
);

INSERT INTO `farmers` (
  `user_id`,
  `farmer_fullname`,
  `farmer_contact_number`,
  `farmer_farm_name`,
  `farmer_id_verification_status`,
  `farmer_is_verified`,
  `farmer_address`
)
SELECT
  u.user_id,
  'Demo Seed Farmer',
  '09170000000',
  'Preview Farm',
  'approved',
  1,
  'Sample Location'
FROM `users` u
WHERE u.email = 'demo.farmer.seed@smartfarm.local'
  AND NOT EXISTS (
    SELECT 1 FROM `farmers` f WHERE f.user_id = u.user_id
  );

INSERT INTO `seed_distributions` (
  `farmer_id`,
  `seed_id`,
  `quantity_distributed`,
  `distribution_date`,
  `status`,
  `notes`,
  `created_by`
)
SELECT
  f.farmer_id,
  si.seed_id,
  20.00,
  CURDATE(),
  'Released',
  'Temporary preview distribution',
  1
FROM `farmers` f
JOIN `seed_inventory` si ON si.seed_name = 'Rice Seeds - Premium'
WHERE f.farmer_fullname = 'Demo Seed Farmer'
  AND NOT EXISTS (
    SELECT 1
    FROM `seed_distributions` sd
    WHERE sd.farmer_id = f.farmer_id
      AND sd.seed_id = si.seed_id
      AND sd.notes = 'Temporary preview distribution'
  )
LIMIT 1;
